﻿var global_data =
{
  "WS 01": {
    "a": "OUTBACK",
    "b": "grad_white",
    "c": "grp_outback",
    "d": 0.75,
    "e": 16672257,
    "f": 15951730,
    "g": 16645629,
    "sets": {
      "set_1": {
        "a": "MIST",
        "aa": 16672257,
        "d": "bg_outback1.jpg",
        "dd": 16672257,
        "e": 0.2,
        "j": 16672257,
        "l": 16672257,
        "levels": {
          "level_001": {
            "a": 347510,
            "b": "HOW",
            "e": [
              ",HOW",
              ",WHO"
            ]
          },
          "level_002": {
            "a": 456581,
            "b": "OPT",
            "e": [
              ",OPT",
              ",POT",
              ",TOP"
            ]
          },
          "level_003": {
            "a": 415233,
            "b": "ARM",
            "e": [
              ",ARM",
              ",MAR",
              ",RAM"
            ]
          },
          "level_004": {
            "a": 415236,
            "b": "ATE",
            "e": [
              ",ATE",
              ",EAT",
              ",TEA"
            ]
          }
        },
        "m": 11748097,
        "o": 42980,
        "r": 11748097,
        "t": 0.73,
        "u": 16776703,
        "v": 16672257,
        "y": 0.85,
        "z": 16776703
      },
      "set_2": {
        "a": "EPIC",
        "aa": 16475677,
        "d": "bg_outback2.jpg",
        "dd": 16475677,
        "e": 0.2,
        "j": 16475677,
        "l": 16475677,
        "levels": {
          "level_001": {
            "a": 472923,
            "b": "TEDI",
            "e": [
              ",TIE",
              ",DIET",
              ",EDIT",
              ",TIDE",
              ",TIED"
            ]
          },
          "level_002": {
            "a": 472922,
            "b": "EBOR",
            "e": [
              ",ORE",
              ",ROB",
              ",BORE",
              ",ROBE"
            ]
          },
          "level_003": {
            "a": 472921,
            "b": "TURO",
            "e": [
              ",OUR",
              ",OUT",
              ",ROT",
              ",RUT",
              ",TOUR"
            ]
          },
          "level_004": {
            "a": 472920,
            "b": "TEDN",
            "e": [
              ",DEN",
              ",END",
              ",NET",
              ",TEN",
              "B,DENT",
              ",TEND"
            ]
          }
        },
        "m": 10572032,
        "o": 42980,
        "r": 10572032,
        "t": 0.8,
        "v": 16475677,
        "y": 0.8
      },
      "set_3": {
        "a": "TIME",
        "aa": 16279097,
        "d": "bg_outback3.jpg",
        "dd": 16279097,
        "e": 0.2,
        "g": 0.79,
        "j": 16279097,
        "l": 16279097,
        "levels": {
          "level_001": {
            "a": 499095,
            "b": "EFDA",
            "e": [
              ",FAD",
              ",FED",
              ",DEAF",
              ",FADE"
            ]
          },
          "level_002": {
            "a": 499096,
            "b": "RPAY",
            "e": [
              ",PAR",
              ",PAY",
              ",PRY",
              ",RAP",
              ",RAY",
              ",PRAY"
            ]
          },
          "level_003": {
            "a": 499094,
            "b": "PWSA",
            "e": [
              ",PAW",
              ",SAP",
              ",SAW",
              "B,SPA",
              ",WAS",
              ",SWAP",
              ",WASP"
            ]
          },
          "level_004": {
            "a": 499097,
            "b": "BRAN",
            "e": [
              ",BAN",
              ",BAR",
              ",BRA",
              ",NAB",
              ",RAN",
              ",BARN",
              ",BRAN"
            ]
          }
        },
        "m": 11296256,
        "o": 16726016,
        "r": 11296256,
        "t": 0.8300000000000001,
        "v": 16279097,
        "y": 0.8300000000000001
      }
    }
  },
  "WS 02": {
    "a": "TIMBER",
    "b": "grad_white",
    "c": "grp_timber",
    "d": 0.75,
    "e": 5586657,
    "f": 8126683,
    "sets": {
      "set_1": {
        "a": "SILENT",
        "aa": 5586657,
        "d": "bg_timber1.jpg",
        "dd": 5586657,
        "e": 0.1,
        "j": 5586657,
        "l": 5586657,
        "levels": {
          "level_001": {
            "a": 642729,
            "b": "HSTRO",
            "e": [
              ",HOST",
              ",SHOT",
              ",SORT",
              ",SHORT"
            ]
          },
          "level_002": {
            "a": 642732,
            "b": "YNOEB",
            "e": [
              ",BOY",
              ",BYE",
              ",ONE",
              ",YEN",
              ",BONE",
              ",BONY",
              ",OBEY"
            ]
          },
          "level_003": {
            "a": 642731,
            "b": "EVEFR",
            "e": [
              ",EVE",
              ",FEE",
              ",EVER",
              "B,FREE",
              ",REEF",
              ",FEVER"
            ]
          },
          "level_004": {
            "a": 642734,
            "b": "CCIHK",
            "e": [
              ",CHI",
              ",CHIC",
              ",HICK",
              ",CHICK"
            ]
          },
          "level_005": {
            "a": 642728,
            "b": "TFIUN",
            "e": [
              ",FIN",
              ",FIT",
              ",FUN",
              ",NIT",
              ",NUT",
              ",TIN",
              ",UNIT"
            ]
          },
          "level_006": {
            "a": 642733,
            "b": "ANCEP",
            "e": [
              ",ACE",
              ",APE",
              ",CAN",
              ",CAP",
              ",NAP",
              ",PAN",
              ",PEA",
              ",PEN",
              ",PECAN"
            ]
          },
          "level_007": {
            "a": 642730,
            "b": "KISMR",
            "e": [
              ",RIM",
              ",SIM",
              ",SIR",
              ",SKI",
              ",RISK",
              ",SKIM"
            ]
          },
          "level_008": {
            "a": 642735,
            "b": "COWLS",
            "e": [
              ",COW",
              ",LOW",
              ",OWL",
              ",COWL",
              "B,SLOW"
            ]
          }
        },
        "m": 3090059,
        "o": 50527,
        "r": 3090059,
        "t": 0.7000000000000001,
        "v": 5586657,
        "y": 0.7000000000000001
      },
      "set_2": {
        "a": "GROW",
        "aa": 6172383,
        "d": "bg_timber2.jpg",
        "dd": 6172383,
        "e": 0.1,
        "j": 6172383,
        "l": 6172383,
        "levels": {
          "level_001": {
            "a": 643121,
            "b": "GONRW",
            "e": [
              ",NOR",
              ",NOW",
              ",OWN",
              ",ROW",
              ",WON",
              ",GOWN",
              ",GROW",
              ",WORN"
            ]
          },
          "level_002": {
            "a": 643123,
            "b": "IDAMT",
            "e": [
              ",AID",
              ",AIM",
              ",DAM",
              ",DIM",
              ",MAD",
              ",MAT",
              ",MID",
              ",TAD",
              ",AMID",
              "B,MAID"
            ]
          },
          "level_003": {
            "a": 643118,
            "b": "TONCI",
            "e": [
              ",COIN",
              ",ICON",
              ",INTO",
              ",TONIC"
            ]
          },
          "level_004": {
            "a": 643125,
            "b": "RCACI",
            "e": [
              ",AIR",
              ",ARC",
              ",CAR",
              ",CIRCA"
            ]
          },
          "level_005": {
            "a": 643117,
            "b": "LRPEI",
            "e": [
              ",LIE",
              ",LIP",
              ",PER",
              ",PIE",
              ",REP",
              ",RIP",
              ",PIER",
              ",PILE",
              ",RILE",
              ",RIPE"
            ]
          },
          "level_006": {
            "a": 643124,
            "b": "EFTHY",
            "e": [
              ",HEY",
              ",THE",
              ",THY",
              ",YET",
              ",THEY",
              ",HEFTY"
            ]
          },
          "level_007": {
            "a": 643116,
            "b": "UEESR",
            "e": [
              ",RUE",
              ",SEE",
              ",SUE",
              ",USE",
              ",SEER",
              ",SURE",
              ",USER"
            ]
          },
          "level_008": {
            "a": 643126,
            "b": "EDMOM",
            "e": [
              ",DOE",
              ",MOM",
              ",DEMO",
              ",DOME",
              ",MEMO",
              ",MODE",
              ",MODEM"
            ]
          },
          "level_009": {
            "a": 643119,
            "b": "EDBRE",
            "e": [
              ",BED",
              ",BEE",
              ",RED",
              ",BEER",
              "B,BRED",
              ",DEER",
              ",REED",
              ",BREED"
            ]
          },
          "level_010": {
            "a": 643122,
            "b": "OESPL",
            "e": [
              ",SOP",
              ",LOSE",
              ",POLE",
              ",POSE",
              ",SLOP",
              ",SOLE",
              ",SLOPE"
            ]
          },
          "level_011": {
            "a": 643120,
            "b": "EVAWD",
            "e": [
              ",AWE",
              ",DEW",
              ",WAD",
              ",WADE",
              ",WAVE"
            ]
          },
          "level_012": {
            "a": 643127,
            "b": "BNIRG",
            "e": [
              ",BIG",
              ",BIN",
              ",GIN",
              ",RIB",
              ",RIG",
              ",BRIG",
              "B,GRIN",
              ",RING",
              ",BRING"
            ]
          }
        },
        "m": 3090061,
        "o": 13434986,
        "r": 3090061,
        "t": 0.8,
        "v": 6172383,
        "y": 0.75
      },
      "set_3": {
        "a": "NEW",
        "aa": 6823902,
        "d": "bg_timber3.jpg",
        "dd": 6823902,
        "e": 0.1,
        "j": 6823902,
        "l": 6823902,
        "levels": {
          "level_001": {
            "a": 644174,
            "b": "HAVES",
            "e": [
              ",ASH",
              ",HAS",
              ",SEA",
              ",SHE",
              ",HAVE",
              ",SAVE",
              ",VASE",
              ",SHAVE"
            ]
          },
          "level_002": {
            "a": 644183,
            "b": "LAZAP",
            "e": [
              ",LAP",
              "B,PAL",
              ",ZAP",
              ",PLAZA"
            ]
          },
          "level_003": {
            "a": 644177,
            "b": "ATSLA",
            "e": [
              ",SAT",
              ",LAST",
              ",SALT",
              ",SLAT",
              ",ATLAS"
            ]
          },
          "level_004": {
            "a": 644187,
            "b": "TRUOT",
            "e": [
              ",OUR",
              ",OUT",
              ",ROT",
              ",RUT",
              ",TORT",
              ",TOUR",
              ",TROUT",
              "B,TUTOR"
            ]
          },
          "level_005": {
            "a": 644179,
            "b": "NAERL",
            "e": [
              ",EARL",
              ",EARN",
              ",LANE",
              ",LEAN",
              ",NEAR",
              ",REAL",
              ",LEARN",
              "B,RENAL"
            ]
          },
          "level_006": {
            "a": 644182,
            "b": "REBKA",
            "e": [
              ",BAKE",
              ",BARE",
              ",BARK",
              ",BEAK",
              ",BEAR",
              ",BAKER",
              ",BRAKE",
              ",BREAK"
            ]
          },
          "level_007": {
            "a": 644172,
            "b": "YGRUB",
            "e": [
              ",BUG",
              ",BUY",
              ",GUY",
              ",RUB",
              ",RUG",
              ",BURG",
              ",BURY"
            ]
          },
          "level_008": {
            "a": 644184,
            "b": "LAZEG",
            "e": [
              ",AGE",
              ",ALE",
              ",GAL",
              ",GEL",
              ",LAG",
              ",LEG",
              ",ZAG",
              ",GLAZE"
            ]
          },
          "level_009": {
            "a": 644175,
            "b": "ISLAN",
            "e": [
              ",SIN",
              ",NAIL",
              "B,SAIL",
              ",SNAIL"
            ]
          },
          "level_010": {
            "a": 644180,
            "b": "ECIVO",
            "e": [
              ",ICE",
              ",VIE",
              ",COVE",
              ",VICE"
            ]
          },
          "level_011": {
            "a": 644176,
            "b": "ADREC",
            "e": [
              ",ACRE",
              ",CARD",
              ",CARE",
              ",DARE",
              ",DEAR",
              ",RACE",
              ",READ",
              ",CADRE",
              ",CARED",
              ",CEDAR",
              ",RACED"
            ]
          },
          "level_012": {
            "a": 644186,
            "b": "OOSLT",
            "e": [
              ",LOT",
              ",TOO",
              ",LOST",
              ",SLOT",
              ",SOLO",
              ",SOOT",
              ",TOOL"
            ]
          },
          "level_013": {
            "a": 644173,
            "b": "TALED",
            "e": [
              ",DATE",
              ",DEAL",
              ",LATE",
              ",LEAD",
              ",TALE",
              ",DEALT",
              ",DELTA"
            ]
          },
          "level_014": {
            "a": 644181,
            "b": "PTISY",
            "e": [
              ",ITS",
              ",PIT",
              ",SIP",
              ",SIT",
              ",SPY",
              ",TIP",
              ",TIS",
              ",PITY",
              ",SPIT"
            ]
          },
          "level_015": {
            "a": 644178,
            "b": "RHIED",
            "e": [
              ",DIRE",
              ",HEIR",
              ",HERD",
              ",HIDE",
              ",HIRE",
              ",RIDE",
              ",HIRED"
            ]
          },
          "level_016": {
            "a": 644185,
            "b": "TGEAR",
            "e": [
              ",GATE",
              ",GEAR",
              ",RAGE",
              ",RATE",
              ",TEAR",
              ",GRATE",
              ",GREAT"
            ]
          }
        },
        "m": 3801748,
        "o": 16753152,
        "r": 3801748,
        "t": 0.8,
        "v": 6823902,
        "y": 0.8
      },
      "set_4": {
        "a": "COOL",
        "aa": 7475164,
        "d": "bg_timber4.jpg",
        "dd": 7475164,
        "e": 0.1,
        "j": 7475164,
        "l": 7475164,
        "levels": {
          "level_001": {
            "a": 649499,
            "b": "IDKNR",
            "e": [
              ",DIN",
              ",INK",
              ",KID",
              ",KIN",
              ",RID",
              ",KIND",
              "B,RIND",
              ",RINK",
              ",DRINK"
            ]
          },
          "level_002": {
            "a": 649510,
            "b": "MAYEB",
            "e": [
              ",AYE",
              ",BAM",
              ",BAY",
              ",BYE",
              ",MAY",
              ",YAM",
              ",BEAM",
              ",MAYBE"
            ]
          },
          "level_003": {
            "a": 649498,
            "b": "MERAK",
            "e": [
              ",ARE",
              ",ARK",
              ",ARM",
              ",EAR",
              ",ERA",
              ",MAR",
              ",RAM",
              ",MAKER"
            ]
          },
          "level_004": {
            "a": 649511,
            "b": "GUHDO",
            "e": [
              ",DOG",
              "B,DUG",
              ",DUH",
              ",DUO",
              ",GOD",
              ",HOG",
              ",HUG",
              ",DOUGH"
            ]
          },
          "level_005": {
            "a": 649503,
            "b": "NYDEE",
            "e": [
              ",DEN",
              ",DYE",
              ",END",
              ",EYE",
              ",YEN",
              ",DENY",
              "B,EYED",
              ",NEED",
              ",NEEDY"
            ]
          },
          "level_006": {
            "a": 649506,
            "b": "WIRTE",
            "e": [
              ",TIE",
              ",WET",
              ",WIT",
              ",RITE",
              ",TIER",
              ",TIRE",
              ",WIRE",
              ",WRITE"
            ]
          },
          "level_007": {
            "a": 649496,
            "b": "EATN",
            "e": [
              ",ANT",
              ",ATE",
              ",EAT",
              ",NET",
              ",TAN",
              ",TEA",
              ",TEN",
              ",NEAT"
            ]
          },
          "level_008": {
            "a": 649512,
            "b": "ILDEF",
            "e": [
              ",DELI",
              ",FILE",
              ",FLED",
              ",IDLE",
              ",LIED",
              ",LIFE",
              ",FIELD",
              ",FILED"
            ]
          },
          "level_009": {
            "a": 649497,
            "b": "KSEAT",
            "e": [
              ",EAST",
              ",SAKE",
              ",SEAT",
              ",TAKE",
              ",TASK",
              ",SKATE",
              ",STAKE",
              ",STEAK"
            ]
          },
          "level_010": {
            "a": 649508,
            "b": "AATRP",
            "e": [
              ",APT",
              ",ART",
              ",PAR",
              ",PAT",
              ",RAP",
              ",RAT",
              ",TAP",
              ",TAR",
              ",APART"
            ]
          },
          "level_011": {
            "a": 649501,
            "b": "IODSL",
            "e": [
              ",LID",
              ",OIL",
              ",OLD",
              ",SOD",
              ",IDOL",
              ",SILO",
              ",SLID",
              ",SOIL",
              ",SOLD",
              ",SOLID"
            ]
          },
          "level_012": {
            "a": 649515,
            "b": "HETCU",
            "e": [
              ",CUE",
              ",CUT",
              ",HUE",
              ",HUT",
              ",THE",
              ",CUTE",
              "B,ETCH",
              ",TECH",
              ",CHUTE"
            ]
          },
          "level_013": {
            "a": 649500,
            "b": "CMOMA",
            "e": [
              ",AMMO",
              ",CAMO",
              ",COMA",
              ",COMMA"
            ]
          },
          "level_014": {
            "a": 649507,
            "b": "BHAIT",
            "e": [
              ",BAT",
              ",BIT",
              ",HAT",
              ",HIT",
              ",TAB",
              ",BAIT",
              "B,BATH",
              ",HABIT"
            ]
          },
          "level_015": {
            "a": 649505,
            "b": "ARGD",
            "e": [
              ",RAD",
              ",RAG",
              ",DRAG",
              ",GRAD"
            ]
          },
          "level_016": {
            "a": 649513,
            "b": "TJOIN",
            "e": [
              ",ION",
              ",JOT",
              ",NIT",
              ",NOT",
              ",TIN",
              ",TON",
              ",INTO",
              ",JOIN",
              ",JOINT"
            ]
          },
          "level_017": {
            "a": 649502,
            "b": "ROODP",
            "e": [
              ",POD",
              ",PRO",
              ",ROD",
              ",DOOR",
              ",DROP",
              ",ODOR",
              ",POOR",
              ",DROOP"
            ]
          },
          "level_018": {
            "a": 649509,
            "b": "PICNA",
            "e": [
              ",CAN",
              ",CAP",
              ",NAP",
              ",NIP",
              ",PAN",
              ",PIC",
              ",PIN",
              ",PAIN"
            ]
          },
          "level_019": {
            "a": 649504,
            "b": "MOPET",
            "e": [
              ",MET",
              ",MOP",
              ",OPT",
              ",PET",
              ",POT",
              ",TOE",
              ",TOP",
              ",POEM",
              ",POET"
            ]
          },
          "level_020": {
            "a": 649514,
            "b": "YIAFR",
            "e": [
              ",AIR",
              ",FAR",
              ",FIR",
              ",FRY",
              ",RAY",
              ",AIRY",
              ",FAIR",
              ",FRAY",
              ",FAIRY"
            ]
          }
        },
        "m": 3801748,
        "o": 47103,
        "r": 3801748,
        "t": 0.65,
        "v": 7475164,
        "y": 0.65
      },
      "set_5": {
        "a": "SIGHT",
        "aa": 8126683,
        "d": "bg_timber5.jpg",
        "dd": 8126683,
        "e": 0.1,
        "j": 8126683,
        "l": 8126683,
        "levels": {
          "level_001": {
            "a": 660434,
            "b": "EUDRP",
            "e": [
              ",DUE",
              ",PER",
              ",RED",
              ",REP",
              ",RUE",
              ",DUPE",
              ",PURE",
              ",RUDE"
            ]
          },
          "level_002": {
            "a": 660445,
            "b": "LGEUB",
            "e": [
              ",BEG",
              ",BUG",
              ",GEL",
              ",LEG",
              ",LUG",
              ",BLUE",
              "B,GLUE",
              ",LUBE"
            ]
          },
          "level_003": {
            "a": 660433,
            "b": "SSUEB",
            "e": [
              ",BUS",
              ",SUB",
              ",SUE",
              ",USE",
              ",BUSES"
            ]
          },
          "level_004": {
            "a": 660447,
            "b": "SERIN",
            "e": [
              ",SIN",
              ",SIR",
              ",REIN",
              ",RISE",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SIREN"
            ]
          },
          "level_005": {
            "a": 660436,
            "b": "RNBEO",
            "e": [
              ",NOR",
              ",ONE",
              ",ORB",
              ",ORE",
              ",ROB",
              ",BONE",
              ",BORE",
              ",BORN",
              ",ROBE"
            ]
          },
          "level_006": {
            "a": 660446,
            "b": "DCMIE",
            "e": [
              ",DIM",
              ",ICE",
              ",MID",
              ",DICE",
              ",DIME",
              ",ICED",
              ",MICE",
              ",MEDIC"
            ]
          },
          "level_007": {
            "a": 660432,
            "b": "EDAMF",
            "e": [
              ",DAM",
              ",FAD",
              ",FED",
              ",MAD",
              ",DAME",
              ",DEAF",
              ",FADE",
              ",FAME",
              ",MADE",
              ",MEAD",
              ",FAMED"
            ]
          },
          "level_008": {
            "a": 660450,
            "b": "BCRAE",
            "e": [
              ",ACRE",
              ",BARE",
              ",BEAR",
              ",CARB",
              ",CARE",
              ",CRAB",
              ",RACE",
              ",BRACE"
            ]
          },
          "level_009": {
            "a": 660441,
            "b": "ERALF",
            "e": [
              ",EARL",
              ",FARE",
              ",FEAR",
              ",FLEA",
              ",LEAF",
              ",REAL",
              ",FERAL",
              "B,FLARE"
            ]
          },
          "level_010": {
            "a": 660442,
            "b": "UORTS",
            "e": [
              ",OUR",
              ",OUT",
              ",ROT",
              ",RUT",
              ",RUST",
              ",SORT",
              ",SOUR",
              ",TOUR"
            ]
          },
          "level_011": {
            "a": 660440,
            "b": "DBNAR",
            "e": [
              ",BAND",
              ",BARD",
              ",BARN",
              ",BRAN",
              ",DARN"
            ]
          },
          "level_012": {
            "a": 660451,
            "b": "LPPAE",
            "e": [
              ",ALE",
              "B,APE",
              ",APP",
              ",LAP",
              ",PAL",
              ",PAP",
              ",PEA",
              ",PEP",
              ",APPLE"
            ]
          },
          "level_013": {
            "a": 660439,
            "b": "HASME",
            "e": [
              ",ASH",
              ",HAM",
              ",HAS",
              ",HEM",
              ",SEA",
              ",SHE",
              ",MESH",
              ",SAME",
              ",SEAM",
              ",SHAM"
            ]
          },
          "level_014": {
            "a": 660443,
            "b": "ABUNR",
            "e": [
              ",BAN",
              ",BAR",
              ",BRA",
              ",BUN",
              ",NAB",
              ",NUB",
              ",RAN",
              ",RUB",
              ",RUN",
              ",URN",
              ",URBAN"
            ]
          },
          "level_015": {
            "a": 660438,
            "b": "LWOBN",
            "e": [
              ",BOW",
              "B,LOB",
              ",LOW",
              ",NOW",
              ",OWL",
              ",OWN",
              ",WON",
              ",BLOWN"
            ]
          },
          "level_016": {
            "a": 660449,
            "b": "LENCA",
            "e": [
              ",ACNE",
              ",CANE",
              ",CLAN",
              ",LACE",
              ",LANE",
              ",LEAN",
              ",CLEAN",
              ",LANCE"
            ]
          },
          "level_017": {
            "a": 660435,
            "b": "YDSAL",
            "e": [
              ",ADS",
              "B,DAY",
              ",LAD",
              ",LAY",
              ",SAD",
              ",SAY",
              ",SLY",
              ",SADLY"
            ]
          },
          "level_018": {
            "a": 660444,
            "b": "AGIAN",
            "e": [
              ",GIN",
              ",NAG",
              ",GAIN",
              ",AGAIN"
            ]
          },
          "level_019": {
            "a": 660437,
            "b": "RALCO",
            "e": [
              ",ARC",
              ",CAR",
              ",OAR",
              ",COAL",
              ",COLA",
              ",ORAL",
              ",CORAL"
            ]
          },
          "level_020": {
            "a": 660448,
            "b": "NIAEV",
            "e": [
              ",VAN",
              ",VIA",
              ",VIE",
              ",VAIN",
              "B,VANE",
              ",VEIN",
              ",VINE",
              ",NAIVE"
            ]
          }
        },
        "m": 5308557,
        "o": 16738922,
        "r": 5308557,
        "t": 0.7000000000000001,
        "v": 8126683,
        "y": 0.7000000000000001
      }
    }
  },
  "WS 03": {
    "a": "COAST",
    "b": "grad_white",
    "c": "grp_tropic",
    "d": 1,
    "e": 16763153,
    "f": 16711476,
    "g": 2451,
    "h": 147,
    "i": true,
    "j": 0.45,
    "sets": {
      "set_1": {
        "a": "FRESH",
        "aa": 16763153,
        "cc": 204947,
        "d": "bg_coast1.jpg",
        "dd": 16763153,
        "e": 0.1,
        "ee": 204947,
        "g": 0.93,
        "i": 204947,
        "j": 16763153,
        "k": 204947,
        "l": 16763153,
        "levels": {
          "level_001": {
            "a": 661825,
            "b": "WADRER",
            "e": [
              ",DARE",
              "B,DEAR",
              ",DRAW",
              ",DREW",
              ",RARE",
              ",READ",
              ",REAR",
              ",WADE",
              ",WARD",
              ",WEAR"
            ]
          },
          "level_002": {
            "a": 661836,
            "b": "THCEA",
            "e": [
              ",ACE",
              ",ACT",
              ",ATE",
              ",CAT",
              ",EAT",
              ",HAT",
              ",TEA",
              ",THE",
              ",CHEAT",
              ",TEACH"
            ]
          },
          "level_003": {
            "a": 661827,
            "b": "SHNIDA",
            "e": [
              ",DASH",
              ",DISH",
              ",HAND",
              ",HIND",
              ",SAID",
              ",SAND",
              ",SHIN",
              ",DANISH"
            ]
          },
          "level_004": {
            "a": 661841,
            "b": "RNUMAE",
            "e": [
              ",AMEN",
              "B,EARN",
              ",MANE",
              ",MARE",
              ",MEAN",
              ",MENU",
              ",NAME",
              ",NEAR"
            ]
          },
          "level_005": {
            "a": 661823,
            "b": "PBKAUC",
            "e": [
              ",BACK",
              ",BUCK",
              ",PACK",
              ",BACKUP"
            ]
          },
          "level_006": {
            "a": 661832,
            "b": "RYGAES",
            "e": [
              ",EASY",
              ",GEAR",
              ",GRAY",
              ",GREY",
              ",RAGE",
              ",SAGE",
              ",SEAR",
              ",YEAR",
              ",GREASY"
            ]
          },
          "level_007": {
            "a": 661826,
            "b": "CHOSTO",
            "e": [
              ",COO",
              ",COT",
              ",HOT",
              ",OOH",
              ",TOO",
              ",SCOOT",
              ",SHOOT",
              ",COHOST"
            ]
          },
          "level_008": {
            "a": 661838,
            "b": "DPLIE",
            "e": [
              ",DELI",
              "B,IDLE",
              ",LIED",
              ",PILE"
            ]
          },
          "level_009": {
            "a": 661829,
            "b": "SNTELE",
            "e": [
              ",ELSE",
              ",LENS",
              ",LENT",
              ",LEST",
              ",NEST",
              ",SEEN",
              ",SENT",
              ",TEEN",
              ",STEEL",
              ",TENSE"
            ]
          },
          "level_010": {
            "a": 661835,
            "b": "SPKEON",
            "e": [
              ",NOPE",
              "B,NOSE",
              ",OPEN",
              ",PEON",
              ",POKE",
              ",POSE",
              ",SPOKE",
              ",SPOKEN"
            ]
          },
          "level_011": {
            "a": 661822,
            "b": "GLEERD",
            "e": [
              ",DEER",
              ",EDGE",
              ",GLEE",
              ",LEER",
              ",REED",
              ",REEL",
              ",ELDER",
              ",GREED",
              ",LEDGE",
              ",LEDGER"
            ]
          },
          "level_012": {
            "a": 661839,
            "b": "ATERLC",
            "e": [
              ",ALERT",
              ",ALTER",
              ",CATER",
              ",CLEAR",
              ",CLEAT",
              ",CRATE",
              ",LATER",
              ",REACT",
              ",TRACE"
            ]
          },
          "level_013": {
            "a": 661828,
            "b": "NROMIF",
            "e": [
              ",FIRM",
              "B,FORM",
              ",FROM",
              ",INFO",
              ",IRON",
              ",NORM",
              ",MINOR",
              ",INFORM"
            ]
          },
          "level_014": {
            "a": 661834,
            "b": "AETBS",
            "e": [
              ",BASE",
              ",BEAT",
              ",BEST",
              ",BETA",
              ",EAST",
              ",SEAT",
              ",STAB",
              ",BEAST"
            ]
          },
          "level_015": {
            "a": 661830,
            "b": "LJYUOF",
            "e": [
              ",FLU",
              ",FLY",
              ",JOY",
              ",YOU",
              ",FOUL"
            ]
          },
          "level_016": {
            "a": 661840,
            "b": "VWEARE",
            "e": [
              ",ARE",
              ",AWE",
              ",EAR",
              ",ERA",
              ",EVE",
              ",EWE",
              ",RAW",
              ",WAR",
              ",WEE",
              ",WEAVE"
            ]
          },
          "level_017": {
            "a": 661831,
            "b": "OEMILB",
            "e": [
              ",BOIL",
              "B,LIMB",
              ",LIME",
              ",LIMO",
              ",LOBE",
              ",MILE",
              ",MOLE",
              ",LIMBO"
            ]
          },
          "level_018": {
            "a": 661833,
            "b": "NALOOG",
            "e": [
              ",GOAL",
              ",GOON",
              ",LOAN",
              ",LOGO",
              ",LONG",
              ",ALONG",
              ",ANGLO",
              ",LAGOON"
            ]
          },
          "level_019": {
            "a": 661824,
            "b": "EKSRHO",
            "e": [
              ",HERO",
              ",HOSE",
              ",ROSE",
              ",SHOE",
              ",SORE",
              ",HORSE",
              ",SHORE",
              ",KOSHER"
            ]
          },
          "level_020": {
            "a": 661837,
            "b": "DEIWSP",
            "e": [
              ",DEW",
              ",DIP",
              ",PEW",
              ",PIE",
              ",SEW",
              ",SIP",
              ",WIPED"
            ]
          }
        },
        "m": 10586447,
        "o": 32511,
        "r": 7757884,
        "t": 0.7000000000000001,
        "u": 16777211,
        "v": 16763153,
        "x": 204947,
        "y": 0.7000000000000001,
        "z": 16777211
      },
      "set_2": {
        "a": "SHELL",
        "aa": 16700953,
        "cc": 204947,
        "d": "bg_coast2.jpg",
        "dd": 16700953,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16700953,
        "k": 204947,
        "l": 16700953,
        "levels": {
          "level_001": {
            "a": 662928,
            "b": "TIEYNM",
            "e": [
              ",MEN",
              ",MET",
              ",NET",
              ",NIT",
              ",TEN",
              ",TIE",
              ",TIN",
              ",YEN",
              ",YET",
              ",MINTY"
            ]
          },
          "level_002": {
            "a": 662930,
            "b": "NFEEID",
            "e": [
              ",DINE",
              ",FEED",
              ",FEND",
              ",FIND",
              ",FINE",
              ",NEED",
              ",FINED",
              ",DEFINE"
            ]
          },
          "level_003": {
            "a": 662923,
            "b": "RCHEEY",
            "e": [
              ",CRY",
              "B,EYE",
              ",HER",
              ",HEY",
              ",RYE",
              ",HERE",
              ",CHEER",
              ",CHEERY"
            ]
          },
          "level_004": {
            "a": 662939,
            "b": "TLGGEO",
            "e": [
              ",EGG",
              "B,EGO",
              ",GEL",
              ",GET",
              ",GOT",
              ",LEG",
              ",LET",
              ",LOG",
              ",LOT",
              ",TOE",
              ",TOGGLE"
            ]
          },
          "level_005": {
            "a": 662925,
            "b": "EERFOB",
            "e": [
              ",BEEF",
              ",BEER",
              ",BORE",
              ",FORE",
              ",FREE",
              ",REEF",
              ",ROBE",
              ",BEFORE"
            ]
          },
          "level_006": {
            "a": 662933,
            "b": "OLVURE",
            "e": [
              ",ORE",
              ",OUR",
              ",RUE",
              ",EURO",
              "B,LORE",
              ",LOVE",
              ",LURE",
              ",OVER",
              ",ROLE",
              ",ROVE",
              ",RULE"
            ]
          },
          "level_007": {
            "a": 662929,
            "b": "CRIEEF",
            "e": [
              ",FEE",
              "B,FIR",
              ",ICE",
              ",FIERCE"
            ]
          },
          "level_008": {
            "a": 662938,
            "b": "ETSEMR",
            "e": [
              ",MEET",
              ",MERE",
              ",REST",
              ",SEEM",
              ",SEER",
              ",STEM",
              ",TERM",
              ",TREE"
            ]
          },
          "level_009": {
            "a": 662924,
            "b": "ECUAFT",
            "e": [
              ",CAFE",
              ",CUTE",
              ",FACE",
              ",FACT",
              ",FATE",
              ",FEAT",
              ",ACUTE",
              ",FACET",
              ",FAUCET"
            ]
          },
          "level_010": {
            "a": 662931,
            "b": "UYRPTI",
            "e": [
              ",PIT",
              ",PRY",
              ",PUT",
              ",RIP",
              ",RUT",
              ",TIP",
              ",TRY",
              ",YUP",
              ",PITY",
              ",TRIP"
            ]
          },
          "level_011": {
            "a": 662927,
            "b": "CNADID",
            "e": [
              ",ADD",
              ",AID",
              ",AND",
              ",CAD",
              ",CAN",
              ",DAD",
              ",DID",
              ",DIN",
              ",CANDID"
            ]
          },
          "level_012": {
            "a": 662936,
            "b": "AOBRNC",
            "e": [
              ",BARN",
              ",BOAR",
              ",BORN",
              ",BRAN",
              ",CARB",
              ",CORN",
              ",CRAB",
              ",ACORN",
              "B,BACON",
              ",BARON",
              ",COBRA",
              ",CARBON"
            ]
          },
          "level_013": {
            "a": 662926,
            "b": "STKRA",
            "e": [
              ",ARK",
              ",ART",
              ",ASK",
              ",RAT",
              ",SAT",
              ",TAR",
              ",STAR",
              "B,TASK"
            ]
          },
          "level_014": {
            "a": 662932,
            "b": "EGALRD",
            "e": [
              ",GLADE",
              ",GLARE",
              ",GRADE",
              ",LAGER",
              ",LARGE",
              ",RAGED",
              ",REGAL",
              ",GLARED"
            ]
          },
          "level_015": {
            "a": 662922,
            "b": "EUMLII",
            "e": [
              ",ELM",
              ",EMU",
              ",LIE",
              ",MILIEU"
            ]
          },
          "level_016": {
            "a": 662937,
            "b": "LRFEI",
            "e": [
              ",FILE",
              ",FIRE",
              ",LIFE",
              ",RIFE",
              ",RILE",
              ",RIFLE"
            ]
          },
          "level_017": {
            "a": 662920,
            "b": "OLDPUH",
            "e": [
              ",DUH",
              ",DUO",
              ",HOP",
              ",OLD",
              ",POD",
              ",HOLD",
              ",LOUD",
              ",UPHOLD"
            ]
          },
          "level_018": {
            "a": 662934,
            "b": "CBULBY",
            "e": [
              ",BUY",
              ",CUB",
              ",BULB",
              ",CLUB"
            ]
          },
          "level_019": {
            "a": 662921,
            "b": "TSMFII",
            "e": [
              ",FIT",
              ",ITS",
              ",SIM",
              ",SIT",
              ",TIS",
              ",FIST",
              ",MIST",
              ",SIFT",
              ",MISFIT"
            ]
          },
          "level_020": {
            "a": 662935,
            "b": "ERPDDI",
            "e": [
              ",DIED",
              ",DIRE",
              ",DRIP",
              ",PIER",
              ",RIDE",
              ",RIPE",
              ",DRIED",
              ",PRIDE"
            ]
          }
        },
        "m": 10386765,
        "o": 32511,
        "r": 9730909,
        "t": 0.7000000000000001,
        "v": 16700953,
        "x": 204947,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "WASH",
        "aa": 16704546,
        "cc": 204947,
        "d": "bg_coast3.jpg",
        "dd": 16704546,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16704546,
        "k": 204947,
        "l": 16704546,
        "levels": {
          "level_001": {
            "a": 664731,
            "b": "ARELLY",
            "e": [
              ",ALLEY",
              ",EARLY",
              ",LAYER",
              ",RALLY",
              ",RELAY",
              ",REALLY"
            ]
          },
          "level_002": {
            "a": 664736,
            "b": "RBNAI",
            "e": [
              ",AIR",
              ",BAN",
              ",BAR",
              ",BIN",
              ",BRA",
              ",NAB",
              ",RAN",
              ",RIB",
              ",BRAIN"
            ]
          },
          "level_003": {
            "a": 664732,
            "b": "UACEMN",
            "e": [
              ",ACNE",
              ",AMEN",
              ",CAME",
              ",CANE",
              ",MACE",
              ",MANE",
              ",MEAN",
              ",MENU",
              ",NAME"
            ]
          },
          "level_004": {
            "a": 664741,
            "b": "FYROTS",
            "e": [
              ",FORT",
              ",ROSY",
              ",SOFT",
              ",SORT",
              ",FORTY",
              ",FROST",
              ",STORY",
              ",FROSTY"
            ]
          },
          "level_005": {
            "a": 664728,
            "b": "PAUOLC",
            "e": [
              ",CAP",
              ",COP",
              ",CUP",
              ",LAP",
              ",PAL",
              ",COAL",
              ",COLA",
              ",COUP"
            ]
          },
          "level_006": {
            "a": 664734,
            "b": "PAINNK",
            "e": [
              ",INK",
              ",INN",
              ",KIN",
              ",NAN",
              ",NAP",
              ",NIP",
              ",PAN",
              ",PIN",
              ",AKIN",
              ",PAIN",
              ",PINK",
              ",NAPKIN"
            ]
          },
          "level_007": {
            "a": 664730,
            "b": "IAENGR",
            "e": [
              ",EARN",
              "B,GAIN",
              ",GEAR",
              ",GRIN",
              ",NEAR",
              ",RAGE",
              ",RAIN",
              ",RANG",
              ",REIN",
              ",RING"
            ]
          },
          "level_008": {
            "a": 664740,
            "b": "NAIELR",
            "e": [
              ",ALIEN",
              "B,LEARN",
              ",LINER",
              ",RENAL"
            ]
          },
          "level_009": {
            "a": 664724,
            "b": "NVECIO",
            "e": [
              ",COIN",
              ",CONE",
              ",COVE",
              ",ICON",
              ",NICE",
              ",ONCE",
              ",OVEN",
              ",VEIN",
              ",VICE",
              ",VINE"
            ]
          },
          "level_010": {
            "a": 664738,
            "b": "VTNYAI",
            "e": [
              ",NAVY",
              ",TINY",
              ",VAIN",
              ",VANITY"
            ]
          },
          "level_011": {
            "a": 664733,
            "b": "EDRVON",
            "e": [
              ",DRONE",
              "B,DROVE",
              ",ROVED",
              ",VENDOR"
            ]
          },
          "level_012": {
            "a": 664743,
            "b": "PAET",
            "e": [
              ",APE",
              ",APT",
              ",ATE",
              ",EAT",
              ",PAT",
              ",PEA",
              ",PET",
              ",TAP",
              ",TEA",
              ",PEAT",
              "B,TAPE"
            ]
          },
          "level_013": {
            "a": 664725,
            "b": "IANMO",
            "e": [
              ",AIM",
              ",ION",
              ",MAN",
              ",AMINO"
            ]
          },
          "level_014": {
            "a": 664735,
            "b": "ISESTD",
            "e": [
              ",DIET",
              ",EDIT",
              ",SIDE",
              ",SITE",
              ",TIDE",
              ",TIED"
            ]
          },
          "level_015": {
            "a": 664726,
            "b": "SFLAE",
            "e": [
              ",ALE",
              ",ELF",
              ",SEA",
              ",FLEA",
              ",LEAF",
              ",SAFE",
              ",SALE",
              ",SEAL",
              ",SELF",
              ",FALSE"
            ]
          },
          "level_016": {
            "a": 664742,
            "b": "POSOT",
            "e": [
              ",OPT",
              ",POT",
              ",SOP",
              ",TOO",
              ",TOP",
              ",OOPS",
              ",POST",
              ",SOOT",
              ",SPOT",
              ",STOP"
            ]
          },
          "level_017": {
            "a": 664729,
            "b": "UBDEG",
            "e": [
              ",BED",
              ",BEG",
              ",BUD",
              ",BUG",
              ",DUB",
              ",DUE",
              ",DUG",
              ",BUDGE"
            ]
          },
          "level_018": {
            "a": 664737,
            "b": "ESCOLT",
            "e": [
              ",COST",
              ",LEST",
              ",LOSE",
              ",LOST",
              ",SECT",
              ",SLOT",
              ",SOLE",
              ",CLOSE",
              "B,STOLE",
              ",CLOSET"
            ]
          },
          "level_019": {
            "a": 664727,
            "b": "YARHD",
            "e": [
              ",DAY",
              ",DRY",
              ",HAD",
              ",HAY",
              ",RAD",
              ",RAY",
              ",HARD",
              "B,YARD"
            ]
          },
          "level_020": {
            "a": 664739,
            "b": "ELLCAR",
            "e": [
              ",ACRE",
              ",CALL",
              ",CARE",
              ",CELL",
              ",EARL",
              ",LACE",
              ",RACE",
              ",REAL",
              ",CLEAR",
              ",CALLER",
              ",CELLAR",
              ",RECALL"
            ]
          }
        },
        "m": 11174743,
        "o": 32511,
        "r": 9072707,
        "t": 0.75,
        "v": 16704546,
        "x": 204947,
        "y": 0.75
      },
      "set_4": {
        "a": "AQUA",
        "aa": 16707883,
        "cc": 204947,
        "d": "bg_coast4.jpg",
        "dd": 16707883,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16707883,
        "k": 204947,
        "l": 16707883,
        "levels": {
          "level_001": {
            "a": 667199,
            "b": "EDONSD",
            "e": [
              ",DONE",
              "B,DOSE",
              ",NODE",
              ",NOSE",
              ",SEND"
            ]
          },
          "level_002": {
            "a": 667210,
            "b": "SRNIEH",
            "e": [
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SHINE",
              ",SHIRE",
              ",SIREN",
              ",SHINER",
              ",SHRINE"
            ]
          },
          "level_003": {
            "a": 667203,
            "b": "RSBWEO",
            "e": [
              ",BORE",
              ",BREW",
              ",BROW",
              ",ROBE",
              ",ROSE",
              ",SORE",
              ",WORE",
              ",BROWSE"
            ]
          },
          "level_004": {
            "a": 667211,
            "b": "VIANDE",
            "e": [
              ",AID",
              ",AND",
              ",DEN",
              ",DIN",
              ",END",
              ",VAN",
              ",VIA",
              ",VIE",
              ",INVADE"
            ]
          },
          "level_005": {
            "a": 667198,
            "b": "CODRIH",
            "e": [
              ",CHI",
              ",COD",
              ",DOC",
              ",HID",
              ",RID",
              ",ROD",
              ",CHOIR",
              ",CHORD",
              ",ORCHID"
            ]
          },
          "level_006": {
            "a": 667206,
            "b": "BYOLBW",
            "e": [
              ",BOB",
              ",BOW",
              ",BOY",
              ",LOB",
              ",LOW",
              ",OWL",
              ",BLOW",
              ",BOWL"
            ]
          },
          "level_007": {
            "a": 667200,
            "b": "ARMEF",
            "e": [
              ",ARE",
              ",ARM",
              ",EAR",
              ",ERA",
              ",FAR",
              ",MAR",
              ",RAM",
              ",FAME",
              ",FARE",
              ",FARM",
              ",FEAR",
              ",MARE"
            ]
          },
          "level_008": {
            "a": 667212,
            "b": "LMIUEH",
            "e": [
              ",ELM",
              "B,EMU",
              ",HEM",
              ",HIM",
              ",HUE",
              ",HUM",
              ",LIE",
              ",HELIUM"
            ]
          },
          "level_009": {
            "a": 667202,
            "b": "GORTHN",
            "e": [
              ",GOT",
              "B,HOG",
              ",HOT",
              ",NOR",
              ",NOT",
              ",ROT",
              ",TON",
              ",THRONG"
            ]
          },
          "level_010": {
            "a": 667209,
            "b": "ALTSYV",
            "e": [
              ",LAST",
              "B,SALT",
              ",SLAT",
              ",SLAY",
              ",STAY",
              ",VAST",
              ",SALTY",
              ",VASTLY"
            ]
          },
          "level_011": {
            "a": 667205,
            "b": "RCTHWE",
            "e": [
              ",HER",
              ",HEW",
              ",THE",
              ",WET",
              ",CHEW",
              "B,CREW",
              ",ETCH",
              ",TECH",
              ",THREW"
            ]
          },
          "level_012": {
            "a": 667213,
            "b": "EAMODW",
            "e": [
              ",DAME",
              ",DEMO",
              ",DOME",
              ",MADE",
              ",MEAD",
              ",MEOW",
              ",MODE",
              ",OWED",
              ",WADE",
              ",MEADOW"
            ]
          },
          "level_013": {
            "a": 667204,
            "b": "EENTY",
            "e": [
              ",EYE",
              ",NET",
              ",TEE",
              ",TEN",
              ",YEN",
              ",YET",
              ",TEEN",
              ",TEENY"
            ]
          },
          "level_014": {
            "a": 667208,
            "b": "ETOILP",
            "e": [
              ",PELT",
              ",PILE",
              ",PLOT",
              ",POET",
              ",POLE",
              ",TILE",
              ",TOIL",
              ",POLITE"
            ]
          },
          "level_015": {
            "a": 667201,
            "b": "CDEER",
            "e": [
              ",RED",
              ",DEER",
              ",REED",
              ",CREED"
            ]
          },
          "level_016": {
            "a": 667214,
            "b": "RNUGW",
            "e": [
              ",GUN",
              ",RUG",
              ",RUN",
              ",URN",
              ",RUNG"
            ]
          },
          "level_017": {
            "a": 667196,
            "b": "TSBEUS",
            "e": [
              ",BET",
              ",BUS",
              ",BUT",
              ",SET",
              ",SUB",
              ",SUE",
              ",TUB",
              ",USE",
              ",SUBSET"
            ]
          },
          "level_018": {
            "a": 667207,
            "b": "SPCEEA",
            "e": [
              ",CAPE",
              ",CASE",
              ",EASE",
              ",PACE",
              ",CEASE",
              ",PEACE",
              ",SPACE",
              ",ESCAPE"
            ]
          },
          "level_019": {
            "a": 667197,
            "b": "ARCWL",
            "e": [
              ",ARC",
              ",CAR",
              ",LAW",
              ",RAW",
              ",WAR",
              ",CLAW",
              ",CRAWL"
            ]
          },
          "level_020": {
            "a": 667215,
            "b": "TARERY",
            "e": [
              ",RARE",
              ",RATE",
              ",REAR",
              ",TEAR",
              ",TRAY",
              ",YEAR",
              ",RATER",
              "B,RETRY",
              ",ARTERY"
            ]
          }
        },
        "m": 12025910,
        "o": 32511,
        "r": 12025910,
        "t": 0.65,
        "v": 16707883,
        "x": 204947,
        "y": 0.63
      },
      "set_5": {
        "a": "PEBBLE",
        "aa": 16711476,
        "cc": 204947,
        "d": "bg_coast5.jpg",
        "dd": 16711476,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16711476,
        "k": 204947,
        "l": 16711476,
        "levels": {
          "level_001": {
            "a": 669067,
            "b": "ABHT",
            "e": [
              ",BAT",
              "B,HAT",
              ",TAB",
              ",BATH"
            ]
          },
          "level_002": {
            "a": 669076,
            "b": "XRPEEI",
            "e": [
              ",PER",
              ",PIE",
              ",REP",
              ",RIP",
              ",PEER",
              ",PIER",
              ",RIPE",
              ",EXPIRE"
            ]
          },
          "level_003": {
            "a": 669066,
            "b": "ISTNA",
            "e": [
              ",ANT",
              ",ITS",
              ",NIT",
              ",SAT",
              ",SIN",
              ",SIT",
              ",TAN",
              ",TIN",
              ",TIS",
              ",SAINT",
              ",SATIN",
              ",STAIN"
            ]
          },
          "level_004": {
            "a": 669082,
            "b": "HAPSDE",
            "e": [
              ",DASH",
              ",HEAD",
              ",HEAP",
              ",SHED",
              ",SPED",
              ",PHASE",
              ",SHADE",
              ",SHAPE",
              ",SPADE"
            ]
          },
          "level_005": {
            "a": 669069,
            "b": "GRFOOT",
            "e": [
              ",FOOT",
              ",FORT",
              ",FROG",
              ",GOOF",
              ",ROOF",
              ",ROOT",
              ",FORGO",
              ",FORGOT"
            ]
          },
          "level_006": {
            "a": 669078,
            "b": "DTGGAE",
            "e": [
              ",AGE",
              ",ATE",
              ",EAT",
              ",EGG",
              ",GAG",
              ",GET",
              ",TAD",
              ",TAG",
              ",TEA",
              ",GADGET",
              ",TAGGED"
            ]
          },
          "level_007": {
            "a": 669071,
            "b": "ESRPEH",
            "e": [
              ",SHEEP",
              ",SHEER",
              ",SPREE",
              ",SPHERE"
            ]
          },
          "level_008": {
            "a": 669072,
            "b": "AVERDC",
            "e": [
              ",CADRE",
              ",CARED",
              ",CARVE",
              ",CAVED",
              ",CEDAR",
              ",CRAVE",
              ",RACED",
              ",RAVED"
            ]
          },
          "level_009": {
            "a": 669064,
            "b": "HFRITS",
            "e": [
              ",FISH",
              ",FIST",
              ",RIFT",
              ",SIFT",
              ",STIR",
              ",THIS",
              ",FIRST",
              ",SHIFT",
              ",SHIRT"
            ]
          },
          "level_010": {
            "a": 669077,
            "b": "HAECNC",
            "e": [
              ",ACE",
              ",CAN",
              ",HEN",
              ",ACHE",
              "B,ACNE",
              ",CANE",
              ",EACH",
              ",CHANCE"
            ]
          },
          "level_011": {
            "a": 669068,
            "b": "BEARTH",
            "e": [
              ",BATHE",
              ",BERTH",
              ",EARTH",
              ",HATER",
              ",HEART",
              ",REHAB",
              ",BATHER",
              ",BREATH"
            ]
          },
          "level_012": {
            "a": 669080,
            "b": "LDGPEE",
            "e": [
              ",GEE",
              ",GEL",
              ",LED",
              ",LEG",
              ",DEEP",
              "B,EDGE",
              ",GLEE",
              ",PEEL"
            ]
          },
          "level_013": {
            "a": 669074,
            "b": "SREATC",
            "e": [
              ",CASTE",
              ",CATER",
              ",CRATE",
              ",CREST",
              ",REACT",
              ",SCARE",
              ",STARE",
              ",TRACE"
            ]
          },
          "level_014": {
            "a": 669075,
            "b": "AKHRSN",
            "e": [
              ",ARK",
              ",ASH",
              ",ASK",
              ",HAS",
              ",RAN",
              ",HARK",
              ",RANK",
              ",RASH",
              ",SANK"
            ]
          },
          "level_015": {
            "a": 669065,
            "b": "SATMP",
            "e": [
              ",MAST",
              ",PAST",
              ",SPAM",
              ",SPAT",
              ",STAMP"
            ]
          },
          "level_016": {
            "a": 669081,
            "b": "PYNOOS",
            "e": [
              ",SON",
              ",SOP",
              ",SOY",
              ",SPY",
              ",OOPS",
              ",PONY",
              ",SOON",
              ",SNOOPY"
            ]
          },
          "level_017": {
            "a": 669070,
            "b": "ARBIAG",
            "e": [
              ",AIR",
              ",BAG",
              ",BAR",
              ",BIG",
              ",BRA",
              ",RAG",
              ",RIB",
              ",RIG",
              ",BRIG",
              "B,GARB",
              ",GRAB"
            ]
          },
          "level_018": {
            "a": 669079,
            "b": "GRALE",
            "e": [
              ",GLARE",
              ",LAGER",
              ",LARGE",
              ",REGAL"
            ]
          },
          "level_019": {
            "a": 669073,
            "b": "CONRKE",
            "e": [
              ",COKE",
              "B,CONE",
              ",CORE",
              ",CORK",
              ",CORN",
              ",NECK",
              ",ONCE",
              ",ROCK",
              ",RECKON"
            ]
          },
          "level_020": {
            "a": 669083,
            "b": "DULHOS",
            "e": [
              ",DUH",
              ",DUO",
              ",OLD",
              ",SOD",
              ",HOLD",
              "B,LOUD",
              ",LUSH",
              ",SOLD",
              ",SOUL"
            ]
          }
        },
        "m": 9793072,
        "o": 32511,
        "r": 9198123,
        "t": 0.72,
        "v": 16711476,
        "x": 204947,
        "y": 0.7000000000000001
      }
    }
  },
  "WS 04": {
    "a": "ROCK",
    "b": "grad_white",
    "c": "grp_lakes",
    "d": 0.75,
    "e": 6080206,
    "f": 3057070,
    "sets": {
      "set_1": {
        "a": "CALM",
        "aa": 6080206,
        "d": "bg_formations1.jpg",
        "dd": 6080206,
        "e": 0,
        "j": 6080206,
        "l": 6080206,
        "levels": {
          "level_001": {
            "a": 669411,
            "b": "LOLRTS",
            "e": [
              ",LOST",
              ",ROLL",
              ",SLOT",
              ",SORT",
              ",TOLL"
            ]
          },
          "level_002": {
            "a": 669408,
            "b": "NEAMDI",
            "e": [
              ",AIMED",
              ",AMEND",
              ",DENIM",
              ",MEDIA",
              ",MINED",
              ",NAMED",
              ",MAIDEN",
              ",MEDIAN"
            ]
          },
          "level_003": {
            "a": 669406,
            "b": "YBDEA",
            "e": [
              ",AYE",
              ",BAD",
              ",BAY",
              ",BED",
              ",BYE",
              ",DAB",
              ",DAY",
              ",DYE",
              ",YEA",
              ",BEAD"
            ]
          },
          "level_004": {
            "a": 669423,
            "b": "ERBMMU",
            "e": [
              ",EMU",
              "B,MUM",
              ",REM",
              ",RUB",
              ",RUE",
              ",RUM",
              ",UMM",
              ",BUMMER"
            ]
          },
          "level_005": {
            "a": 669407,
            "b": "HPLIUL",
            "e": [
              ",HILL",
              "B,HULL",
              ",PILL",
              ",PULL",
              ",UPHILL"
            ]
          },
          "level_006": {
            "a": 669409,
            "b": "ALKFE",
            "e": [
              ",ALE",
              ",ELF",
              ",ELK",
              ",FAKE",
              ",FLAK",
              ",FLEA",
              ",KALE",
              ",LAKE",
              ",LEAF",
              ",LEAK",
              ",FLAKE"
            ]
          },
          "level_007": {
            "a": 669405,
            "b": "DBRAAO",
            "e": [
              ",BARD",
              ",BOAR",
              ",DRAB",
              ",ROAD",
              ",BOARD",
              ",BROAD",
              ",ABOARD",
              ",ABROAD"
            ]
          },
          "level_008": {
            "a": 669415,
            "b": "EMIND",
            "e": [
              ",DEN",
              ",DIM",
              ",DIN",
              ",END",
              ",MEN",
              ",MID",
              ",DIME",
              ",DINE",
              ",MEND",
              ",MIND",
              ",MINE"
            ]
          },
          "level_009": {
            "a": 669412,
            "b": "ITVEC",
            "e": [
              ",ICE",
              ",TIC",
              ",TIE",
              ",VET",
              ",VIE",
              ",CITE",
              ",VICE",
              ",EVICT"
            ]
          },
          "level_010": {
            "a": 669414,
            "b": "CHATCY",
            "e": [
              ",CHAT",
              ",CATCH",
              ",YACHT",
              ",CATCHY"
            ]
          },
          "level_011": {
            "a": 669416,
            "b": "DRWON",
            "e": [
              ",DOW",
              ",NOD",
              ",NOR",
              ",NOW",
              ",OWN",
              ",ROD",
              ",ROW",
              ",WON",
              ",DOWN",
              ",WORD",
              ",WORN",
              ",DROWN"
            ]
          },
          "level_012": {
            "a": 669419,
            "b": "RTUAAM",
            "e": [
              ",AURA",
              ",MART",
              ",TRAM",
              ",TRAUMA"
            ]
          },
          "level_013": {
            "a": 669417,
            "b": "BUGGY",
            "e": [
              ",BUG",
              "B,BUY",
              ",GUY",
              ",BUGGY"
            ]
          },
          "level_014": {
            "a": 669404,
            "b": "FTRIYU",
            "e": [
              ",FIR",
              ",FIT",
              ",FRY",
              ",FUR",
              ",RUT",
              ",TRY",
              ",FRUIT",
              ",FRUITY"
            ]
          },
          "level_015": {
            "a": 669422,
            "b": "LGYINC",
            "e": [
              ",GIN",
              ",ICY",
              ",NIL",
              ",CLING",
              ",LYING"
            ]
          },
          "level_016": {
            "a": 669421,
            "b": "LEBALI",
            "e": [
              ",ABLE",
              ",BAIL",
              ",BALE",
              ",BALL",
              ",BELL",
              ",BILE",
              ",BILL",
              ",LABEL",
              ",LIBEL",
              ",LIABLE"
            ]
          },
          "level_017": {
            "a": 669420,
            "b": "RAESO",
            "e": [
              ",ARE",
              ",EAR",
              ",ERA",
              ",OAR",
              ",ORE",
              ",SEA",
              ",ROSE",
              "B,SEAR",
              ",SOAR",
              ",SORE",
              ",AROSE"
            ]
          },
          "level_018": {
            "a": 669413,
            "b": "GTEOIR",
            "e": [
              ",GRIT",
              "B,OGRE",
              ",RIOT",
              ",RITE",
              ",ROTE",
              ",TIER",
              ",TIRE",
              ",TORE",
              ",TRIO",
              ",TIGER"
            ]
          },
          "level_019": {
            "a": 669410,
            "b": "UIBCLP",
            "e": [
              ",CUB",
              ",CUP",
              ",LIP",
              ",PIC",
              ",PUB",
              ",BLIP",
              "B,CLIP",
              ",CLUB"
            ]
          },
          "level_020": {
            "a": 669418,
            "b": "EGRAP",
            "e": [
              ",GAPE",
              ",GEAR",
              ",PAGE",
              ",PARE",
              ",PEAR",
              ",RAGE",
              ",REAP",
              ",GRAPE",
              ",PAGER"
            ]
          }
        },
        "m": 3057070,
        "o": 16741120,
        "r": 6639281,
        "t": 0.74,
        "v": 6080206,
        "y": 0.74
      },
      "set_2": {
        "a": "SET",
        "aa": 5291462,
        "cc": 4294967295,
        "d": "bg_formations2.jpg",
        "dd": 5291462,
        "e": 0,
        "ee": 4294967295,
        "i": 4294967295,
        "j": 5291462,
        "k": 4294967295,
        "l": 5291462,
        "levels": {
          "level_001": {
            "a": 669970,
            "b": "LNDGA",
            "e": [
              ",AND",
              ",GAL",
              ",LAD",
              ",LAG",
              ",NAG",
              ",GLAD",
              ",LAND",
              ",GLAND"
            ]
          },
          "level_002": {
            "a": 669962,
            "b": "TOAZM",
            "e": [
              ",MAT",
              ",OAT",
              ",ATOM",
              "B,MOAT"
            ]
          },
          "level_003": {
            "a": 669958,
            "b": "NONATI",
            "e": [
              ",ANTI",
              ",INTO",
              ",IOTA",
              ",NATION"
            ]
          },
          "level_004": {
            "a": 669973,
            "b": "IGSTN",
            "e": [
              ",GIST",
              ",SIGN",
              ",SING",
              ",STING"
            ]
          },
          "level_005": {
            "a": 669957,
            "b": "EIDLSC",
            "e": [
              ",DELI",
              ",DICE",
              ",DISC",
              ",ICED",
              ",IDLE",
              ",ISLE",
              ",LICE",
              ",LIED",
              ",SIDE",
              ",SLED",
              ",SLID"
            ]
          },
          "level_006": {
            "a": 669964,
            "b": "BTROH",
            "e": [
              ",BOT",
              ",BRO",
              ",HOT",
              ",ORB",
              ",ROB",
              ",ROT",
              ",BROTH",
              ",THROB"
            ]
          },
          "level_007": {
            "a": 669961,
            "b": "AWEVDE",
            "e": [
              ",AWE",
              ",DEW",
              ",EVE",
              ",EWE",
              ",WAD",
              ",WED",
              ",WEE",
              ",EVADE",
              ",WAVED",
              ",WEAVE"
            ]
          },
          "level_008": {
            "a": 669975,
            "b": "ANEARC",
            "e": [
              ",ACNE",
              ",ACRE",
              ",AREA",
              ",CANE",
              ",CARE",
              ",EARN",
              ",NEAR",
              ",RACE",
              ",ARENA",
              "B,CRANE"
            ]
          },
          "level_009": {
            "a": 669965,
            "b": "OEHLAT",
            "e": [
              ",HALO",
              "B,HALT",
              ",HATE",
              ",HEAL",
              ",HEAT",
              ",HOLE",
              ",LATE",
              ",OATH",
              ",TALE"
            ]
          },
          "level_010": {
            "a": 669969,
            "b": "AMIGE",
            "e": [
              ",AGE",
              ",AIM",
              ",GEM",
              ",MAG",
              ",GAME",
              "B,MAGE",
              ",MEGA",
              ",IMAGE"
            ]
          },
          "level_011": {
            "a": 669968,
            "b": "ELARDD",
            "e": [
              ",DARE",
              ",DEAD",
              ",DEAL",
              ",DEAR",
              ",EARL",
              ",LARD",
              ",LEAD",
              ",READ",
              ",REAL",
              ",LADDER"
            ]
          },
          "level_012": {
            "a": 669972,
            "b": "RAFYTD",
            "e": [
              ",DART",
              ",FRAT",
              ",FRAY",
              ",RAFT",
              ",TRAY",
              ",YARD",
              ",DRAFT",
              "B,TARDY",
              ",DRAFTY"
            ]
          },
          "level_013": {
            "a": 669959,
            "b": "EHKRIS",
            "e": [
              ",HER",
              ",HIS",
              ",IRE",
              ",SHE",
              ",SIR",
              ",SKI",
              ",HEIR",
              "B,HIKE",
              ",HIRE",
              ",RISE",
              ",RISK",
              ",SIRE"
            ]
          },
          "level_014": {
            "a": 669960,
            "b": "SBYBUT",
            "e": [
              ",BUST",
              ",BUSY",
              ",STUB",
              ",STUBBY"
            ]
          },
          "level_015": {
            "a": 669956,
            "b": "LVNYSA",
            "e": [
              ",ANY",
              ",LAY",
              ",NAY",
              ",SAY",
              ",SLY",
              ",VAN",
              ",NAVY",
              ",SLAY"
            ]
          },
          "level_016": {
            "a": 669966,
            "b": "EETRNS",
            "e": [
              ",NET",
              ",SEE",
              ",SET",
              ",TEE",
              ",TEN",
              ",ENTER",
              ",RESET",
              ",SNEER",
              ",STEER",
              ",STERN",
              ",TENSE",
              ",TERSE"
            ]
          },
          "level_017": {
            "a": 669967,
            "b": "CEEDRU",
            "e": [
              ",CREED",
              ",CRUDE",
              ",CURED",
              ",REDUCE"
            ]
          },
          "level_018": {
            "a": 669971,
            "b": "NPAT",
            "e": [
              ",ANT",
              ",APT",
              ",NAP",
              ",PAN",
              ",PAT",
              ",TAN",
              ",TAP",
              ",PANT"
            ]
          },
          "level_019": {
            "a": 669963,
            "b": "RDWEI",
            "e": [
              ",DIRE",
              ",DREW",
              ",RIDE",
              ",WIDE",
              ",WIRE",
              ",WEIRD",
              ",WIDER",
              ",WIRED"
            ]
          },
          "level_020": {
            "a": 669974,
            "b": "HEOPN",
            "e": [
              ",HEN",
              ",HOE",
              ",HOP",
              ",ONE",
              ",PEN",
              ",HONE",
              ",HOPE",
              ",NOPE",
              ",OPEN",
              ",PEON"
            ]
          }
        },
        "m": 2395798,
        "o": 48538,
        "r": 5981855,
        "t": 0.76,
        "v": 5291462,
        "x": 4294967295,
        "y": 0.76
      },
      "set_3": {
        "a": "SERENE",
        "aa": 4568510,
        "cc": 4294967295,
        "d": "bg_formations3.jpg",
        "dd": 4568510,
        "e": 0,
        "ee": 4294967295,
        "g": 0.92,
        "i": 4294967295,
        "j": 4568510,
        "k": 4294967295,
        "l": 4568510,
        "levels": {
          "level_001": {
            "a": 670557,
            "b": "GGIELG",
            "e": [
              ",EGG",
              ",GEL",
              ",GIG",
              ",LEG",
              ",LIE",
              ",GIGGLE"
            ]
          },
          "level_002": {
            "a": 670570,
            "b": "OPIEMS",
            "e": [
              ",IMP",
              ",MOP",
              ",OPS",
              ",PIE",
              ",SIM",
              ",SIP",
              ",SOP",
              ",POISE"
            ]
          },
          "level_003": {
            "a": 670558,
            "b": "OSUINC",
            "e": [
              ",CON",
              ",ION",
              ",SIN",
              ",SON",
              ",SUN",
              ",COIN",
              ",ICON",
              ",SONIC"
            ]
          },
          "level_004": {
            "a": 670566,
            "b": "PSTLEA",
            "e": [
              ",LAPSE",
              ",LEAPT",
              ",LEAST",
              ",PASTE",
              ",PETAL",
              ",PLATE",
              ",SLATE",
              ",SLEPT",
              ",SPATE",
              ",SPLAT",
              ",STALE",
              ",STEAL"
            ]
          },
          "level_005": {
            "a": 670569,
            "b": "ETIDM",
            "e": [
              ",DIET",
              "B,DIME",
              ",EDIT",
              ",EMIT",
              ",ITEM",
              ",MITE",
              ",TIDE",
              ",TIED",
              ",TIME"
            ]
          },
          "level_006": {
            "a": 670572,
            "b": "FIELRL",
            "e": [
              ",FELL",
              ",FILE",
              ",FILL",
              ",FIRE",
              ",LIFE",
              ",RIFE",
              ",RILE",
              ",FLIER",
              "B,RIFLE"
            ]
          },
          "level_007": {
            "a": 670568,
            "b": "TSALB",
            "e": [
              ",LAST",
              ",SALT",
              ",SLAB",
              ",SLAT",
              ",STAB"
            ]
          },
          "level_008": {
            "a": 670561,
            "b": "BBURLE",
            "e": [
              ",EBB",
              ",RUB",
              ",RUE",
              ",BLUE",
              ",BLUR",
              ",BULB",
              ",LUBE",
              ",LURE",
              ",RULE",
              ",BLURB",
              ",RUBLE",
              ",RUBBLE"
            ]
          },
          "level_009": {
            "a": 670564,
            "b": "PSMUL",
            "e": [
              ",SUM",
              ",SUP",
              ",UPS",
              ",LUMP",
              ",PLUM",
              ",PLUS",
              ",SLUM",
              ",SLUMP"
            ]
          },
          "level_010": {
            "a": 670559,
            "b": "LOVWES",
            "e": [
              ",LOW",
              ",OWE",
              ",OWL",
              ",SEW",
              ",SOW",
              ",VOW",
              ",WOE",
              ",SOLVE",
              "B,VOWEL",
              ",WOLVES"
            ]
          },
          "level_011": {
            "a": 670567,
            "b": "EOILV",
            "e": [
              ",EVIL",
              ",LIVE",
              ",LOVE",
              ",VEIL",
              ",VILE"
            ]
          },
          "level_012": {
            "a": 670574,
            "b": "AODEB",
            "e": [
              ",ADO",
              ",BAD",
              ",BED",
              ",BOA",
              ",BOD",
              ",DAB",
              ",DOE",
              ",ODE",
              ",ADOBE"
            ]
          },
          "level_013": {
            "a": 670565,
            "b": "TCAXE",
            "e": [
              ",ACE",
              "B,ACT",
              ",ATE",
              ",AXE",
              ",CAT",
              ",EAT",
              ",TAX",
              ",TEA",
              ",EXACT"
            ]
          },
          "level_014": {
            "a": 670562,
            "b": "NTLNUE",
            "e": [
              ",LENT",
              "B,LUTE",
              ",TUNE",
              ",TUNNEL"
            ]
          },
          "level_015": {
            "a": 670563,
            "b": "ABTR",
            "e": [
              ",ART",
              ",BAR",
              ",BAT",
              ",BRA",
              ",RAT",
              ",TAB",
              ",TAR",
              ",BRAT"
            ]
          },
          "level_016": {
            "a": 670575,
            "b": "LWDLIY",
            "e": [
              ",ILL",
              ",LID",
              ",DILL",
              "B,IDLY",
              ",LILY",
              ",WILD",
              ",WILL",
              ",WILY",
              ",WILDLY"
            ]
          },
          "level_017": {
            "a": 670560,
            "b": "LGDO",
            "e": [
              ",DOG",
              ",GOD",
              ",LOG",
              ",OLD",
              ",GOLD"
            ]
          },
          "level_018": {
            "a": 670573,
            "b": "SBRUH",
            "e": [
              ",BUSH",
              ",RUSH",
              ",BRUSH",
              ",SHRUB"
            ]
          },
          "level_019": {
            "a": 670556,
            "b": "GTRIHB",
            "e": [
              ",BIG",
              ",BIT",
              ",GIT",
              ",HIT",
              ",RIB",
              ",RIG",
              ",BIRTH",
              ",GIRTH",
              ",RIGHT",
              ",BRIGHT"
            ]
          },
          "level_020": {
            "a": 670571,
            "b": "NAOPDR",
            "e": [
              ",DARN",
              ",DROP",
              ",POND",
              ",PROD",
              ",ROAD",
              ",ADORN",
              ",APRON",
              ",RADON",
              ",PARDON"
            ]
          }
        },
        "m": 2063748,
        "o": 48538,
        "r": 2063748,
        "t": 0.6,
        "v": 4568510,
        "x": 4294967295,
        "y": 0.6
      },
      "set_4": {
        "a": "AIR",
        "aa": 3780022,
        "cc": 268435455,
        "d": "bg_formations4.jpg",
        "dd": 3780022,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 3780022,
        "k": 268435455,
        "l": 3780022,
        "levels": {
          "level_001": {
            "a": 670929,
            "b": "ERLFEX",
            "e": [
              ",EEL",
              ",ELF",
              ",FEE",
              ",REF",
              ",FEEL",
              ",FLEE",
              ",FLEX",
              ",FREE",
              ",LEER",
              ",REEF",
              ",REEL"
            ]
          },
          "level_002": {
            "a": 670927,
            "b": "SAHAGT",
            "e": [
              ",AHA",
              ",ASH",
              ",GAS",
              ",HAG",
              ",HAS",
              ",HAT",
              ",SAG",
              ",SAT",
              ",TAG",
              ",AGHAST"
            ]
          },
          "level_003": {
            "a": 670925,
            "b": "PLAPAE",
            "e": [
              ",ALE",
              ",APE",
              ",APP",
              ",LAP",
              ",PAL",
              ",PAP",
              ",PEA",
              ",PEP",
              ",APPLE",
              "B,PAPAL"
            ]
          },
          "level_004": {
            "a": 670941,
            "b": "ANHUM",
            "e": [
              ",HAM",
              "B,HUM",
              ",MAN",
              ",HUMAN"
            ]
          },
          "level_005": {
            "a": 670928,
            "b": "EIZRPP",
            "e": [
              ",PIER",
              "B,PIPE",
              ",PREP",
              ",RIPE",
              ",ZIPPER"
            ]
          },
          "level_006": {
            "a": 670934,
            "b": "AYERLT",
            "e": [
              ",ALERT",
              ",ALTER",
              ",EARLY",
              ",LATER",
              ",LAYER",
              ",RELAY"
            ]
          },
          "level_007": {
            "a": 670933,
            "b": "GOUTH",
            "e": [
              ",GOT",
              ",GUT",
              ",HOG",
              ",HOT",
              ",HUG",
              ",HUT",
              ",OUT",
              ",TUG",
              ",UGH",
              ",THUG",
              ",OUGHT",
              ",TOUGH"
            ]
          },
          "level_008": {
            "a": 670938,
            "b": "SCEDON",
            "e": [
              ",CODE",
              "B,COED",
              ",CONE",
              ",DONE",
              ",DOSE",
              ",NODE",
              ",NOSE",
              ",ONCE",
              ",SEND"
            ]
          },
          "level_009": {
            "a": 670930,
            "b": "TSEEN",
            "e": [
              ",NEST",
              ",SEEN",
              ",SENT",
              ",TEEN"
            ]
          },
          "level_010": {
            "a": 670932,
            "b": "AZGDER",
            "e": [
              ",AGE",
              ",ARE",
              ",EAR",
              ",ERA",
              ",RAD",
              ",RAG",
              ",RED",
              ",ZAG",
              ",GRAZED"
            ]
          },
          "level_011": {
            "a": 670923,
            "b": "OPRYOD",
            "e": [
              ",DRY",
              ",POD",
              ",PRO",
              ",PRY",
              ",ROD",
              ",DROOPY"
            ]
          },
          "level_012": {
            "a": 670939,
            "b": "YSIFRK",
            "e": [
              ",FIR",
              ",FRY",
              ",SIR",
              ",SKI",
              ",SKY",
              ",RISK",
              ",RISKY",
              ",FRISKY"
            ]
          },
          "level_013": {
            "a": 670924,
            "b": "RTSITA",
            "e": [
              ",STAR",
              ",STAT",
              ",STIR",
              ",TART",
              ",STAIR",
              ",START",
              ",TRAIT",
              ",ARTIST",
              ",STRAIT"
            ]
          },
          "level_014": {
            "a": 670936,
            "b": "ILOBM",
            "e": [
              ",BIO",
              ",LOB",
              ",MIL",
              ",MOB",
              ",OIL",
              ",BOIL",
              ",LIMB",
              ",LIMO"
            ]
          },
          "level_015": {
            "a": 670931,
            "b": "DVASEI",
            "e": [
              ",ADS",
              ",AID",
              ",SAD",
              ",SEA",
              ",VIA",
              ",VIE",
              ",ASIDE",
              "B,SAVED",
              ",ADVISE"
            ]
          },
          "level_016": {
            "a": 670937,
            "b": "ESOUR",
            "e": [
              ",EURO",
              ",ROSE",
              ",RUSE",
              ",SORE",
              ",SOUR",
              ",SURE",
              ",USER",
              ",ROUSE"
            ]
          },
          "level_017": {
            "a": 670926,
            "b": "ONLPY",
            "e": [
              ",PLY",
              ",YON",
              ",ONLY",
              ",PLOY",
              ",POLY",
              ",PONY"
            ]
          },
          "level_018": {
            "a": 670935,
            "b": "CTHTYA",
            "e": [
              ",CHAT",
              "B,TACT",
              ",THAT",
              ",YACHT"
            ]
          },
          "level_019": {
            "a": 670922,
            "b": "NFRWO",
            "e": [
              ",FOR",
              ",FRO",
              ",NOR",
              ",NOW",
              ",OWN",
              ",ROW",
              ",WON",
              ",WORN",
              ",FROWN"
            ]
          },
          "level_020": {
            "a": 670940,
            "b": "TSEBEH",
            "e": [
              ",BEE",
              ",BET",
              ",SEE",
              ",SET",
              ",SHE",
              ",TEE",
              ",THE",
              ",BESET",
              ",SHEET",
              ",THESE"
            ]
          }
        },
        "m": 1600883,
        "o": 7391488,
        "r": 1600883,
        "t": 0.65,
        "v": 3780022,
        "x": 268435455,
        "y": 0.65
      },
      "set_5": {
        "a": "GRACE",
        "aa": 3057070,
        "cc": 268435455,
        "d": "bg_formations5.jpg",
        "dd": 3057070,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 3057070,
        "k": 268435455,
        "l": 3057070,
        "levels": {
          "level_001": {
            "a": 671267,
            "b": "SATESL",
            "e": [
              ",EAST",
              "B,LAST",
              ",LATE",
              ",LESS",
              ",LEST",
              ",SALE",
              ",SALT",
              ",SEAL",
              ",SEAT",
              ",SLAT",
              ",TALE",
              ",TASSEL"
            ]
          },
          "level_002": {
            "a": 671258,
            "b": "DITOSL",
            "e": [
              ",IDOL",
              ",LIST",
              ",LOST",
              ",SILO",
              ",SILT",
              ",SLID",
              ",SLIT",
              ",SLOT",
              ",SOIL",
              ",SOLD",
              ",TOIL",
              ",TOLD"
            ]
          },
          "level_003": {
            "a": 671273,
            "b": "EHSRAK",
            "e": [
              ",SHAKE",
              ",SHARE",
              ",SHARK",
              ",SHEAR",
              ",SHAKER"
            ]
          },
          "level_004": {
            "a": 671270,
            "b": "OECATV",
            "e": [
              ",CAVE",
              ",COAT",
              ",COVE",
              ",TACO",
              ",VETO",
              ",VOTE",
              ",COVET",
              ",OCTAVE"
            ]
          },
          "level_005": {
            "a": 671274,
            "b": "EGARND",
            "e": [
              ",ANGER",
              ",GRADE",
              ",GRAND",
              ",RAGED",
              ",RANGE",
              ",DANGER",
              "B,GANDER",
              ",GARDEN",
              ",RANGED"
            ]
          },
          "level_006": {
            "a": 671264,
            "b": "MRTEIC",
            "e": [
              ",ICE",
              "B,IRE",
              ",MET",
              ",REM",
              ",RIM",
              ",TIC",
              ",TIE",
              ",METRIC"
            ]
          },
          "level_007": {
            "a": 671275,
            "b": "RFDEYA",
            "e": [
              ",DARE",
              ",DEAF",
              ",DEAR",
              ",DEFY",
              ",FADE",
              ",FARE",
              ",FEAR",
              ",FRAY",
              ",READ",
              ",YARD",
              ",YEAR"
            ]
          },
          "level_008": {
            "a": 671269,
            "b": "ERIYNF",
            "e": [
              ",FERN",
              ",FINE",
              ",FIRE",
              ",REIN",
              ",RIFE",
              ",FIERY",
              ",FINER",
              ",INFER"
            ]
          },
          "level_009": {
            "a": 671271,
            "b": "GDMSYU",
            "e": [
              ",DUG",
              "B,GUM",
              ",GUY",
              ",GYM",
              ",MUD",
              ",MUG",
              ",SUM",
              ",YUM",
              ",SMUG"
            ]
          },
          "level_010": {
            "a": 671261,
            "b": "RHEEIT",
            "e": [
              ",HEIR",
              ",HERE",
              ",HIRE",
              ",RITE",
              ",THEE",
              ",TIER",
              ",TIRE",
              ",TREE",
              ",ETHER",
              "B,THEIR",
              ",THERE",
              ",THREE"
            ]
          },
          "level_011": {
            "a": 671259,
            "b": "UTLFRA",
            "e": [
              ",FLAT",
              ",FRAT",
              ",RAFT",
              ",TURF",
              ",FAULT",
              ",ULTRA"
            ]
          },
          "level_012": {
            "a": 671266,
            "b": "ERWSVE",
            "e": [
              ",EVER",
              ",SEER",
              ",VEER",
              ",WERE",
              ",SERVE",
              ",SEVER",
              ",SEWER",
              ",VERSE"
            ]
          },
          "level_013": {
            "a": 671262,
            "b": "GNUUPL",
            "e": [
              ",GUN",
              ",LUG",
              ",PUG",
              ",PUN",
              ",GULP",
              ",LUNG",
              ",PLUG"
            ]
          },
          "level_014": {
            "a": 671263,
            "b": "THCAEC",
            "e": [
              ",CACHE",
              ",CATCH",
              ",CHEAT",
              ",TEACH",
              ",CACHET"
            ]
          },
          "level_015": {
            "a": 671272,
            "b": "NIEXSU",
            "e": [
              ",NIX",
              ",SEX",
              ",SIN",
              ",SIX",
              ",SUE",
              ",SUN",
              ",USE",
              ",NEXUS"
            ]
          },
          "level_016": {
            "a": 671276,
            "b": "TYMCHI",
            "e": [
              ",CITY",
              ",ITCH",
              ",MYTH",
              ",MYTHIC"
            ]
          },
          "level_017": {
            "a": 671268,
            "b": "YTPO",
            "e": [
              ",OPT",
              ",POT",
              ",TOP",
              ",TOY",
              ",TYPO"
            ]
          },
          "level_018": {
            "a": 671265,
            "b": "TDEAIL",
            "e": [
              ",DEALT",
              ",DELTA",
              ",IDEAL",
              ",TIDAL",
              ",TILED",
              ",DETAIL",
              ",DILATE",
              ",TAILED"
            ]
          },
          "level_019": {
            "a": 671260,
            "b": "KDEHI",
            "e": [
              ",HID",
              ",KID",
              ",HIDE",
              ",HIKE",
              ",HIKED"
            ]
          },
          "level_020": {
            "a": 671277,
            "b": "RARETG",
            "e": [
              ",GATE",
              "B,GEAR",
              ",RAGE",
              ",RARE",
              ",RATE",
              ",REAR",
              ",TEAR",
              ",GRATER"
            ]
          }
        },
        "m": 1074539,
        "o": 16462080,
        "r": 4009835,
        "t": 0.65,
        "v": 3057070,
        "x": 268435455,
        "y": 0.7000000000000001
      }
    }
  },
  "WS 05": {
    "a": "MIST",
    "b": "grad_white",
    "c": "grp_mist",
    "d": 0.75,
    "e": 634893,
    "f": 48013,
    "sets": {
      "set_1": {
        "a": "RAY",
        "aa": 634893,
        "d": "bg_mist1.jpg",
        "dd": 634893,
        "e": 0.2,
        "j": 634893,
        "l": 634893,
        "levels": {
          "level_001": {
            "a": 672039,
            "b": "NIEGLEA",
            "e": [
              ",AGILE",
              "B,ALIEN",
              ",ALIGN",
              ",ANGEL",
              ",ANGLE",
              ",EAGLE"
            ]
          },
          "level_002": {
            "a": 672040,
            "b": "NAPHAXL",
            "e": [
              ",AHA",
              ",LAP",
              ",LAX",
              ",NAP",
              ",PAL",
              ",PAN",
              ",PLAN",
              ",ALPHA"
            ]
          },
          "level_003": {
            "a": 672038,
            "b": "ECTACN",
            "e": [
              ",ACE",
              ",ACT",
              ",ANT",
              ",ATE",
              ",CAN",
              ",CAT",
              ",EAT",
              ",NET",
              ",TAN",
              ",TEA",
              ",TEN",
              ",ACCENT"
            ]
          },
          "level_004": {
            "a": 672045,
            "b": "SESURIN",
            "e": [
              ",ISSUE",
              ",NURSE",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SINUS",
              ",SIREN",
              ",SUNRISE"
            ]
          },
          "level_005": {
            "a": 672036,
            "b": "OYARRM",
            "e": [
              ",ARM",
              ",MAR",
              ",MAY",
              ",OAR",
              ",RAM",
              ",RAY",
              ",YAM",
              ",ARMY",
              "B,ROAM",
              ",ROAR"
            ]
          },
          "level_006": {
            "a": 672043,
            "b": "CSRADDI",
            "e": [
              ",ACID",
              "B,ARID",
              ",CARD",
              ",DISC",
              ",RAID",
              ",SAID",
              ",SCAR",
              ",DISCARD"
            ]
          },
          "level_007": {
            "a": 672034,
            "b": "IDEEPM",
            "e": [
              ",DIM",
              ",DIP",
              ",IMP",
              ",MID",
              ",PIE",
              ",DEEP",
              ",DIME",
              ",IMPEDE"
            ]
          },
          "level_008": {
            "a": 672048,
            "b": "TTAWRH",
            "e": [
              ",ART",
              ",HAT",
              ",RAT",
              ",RAW",
              ",TAR",
              ",WAR",
              ",WRATH",
              ",THWART"
            ]
          },
          "level_009": {
            "a": 672037,
            "b": "ORFSAEK",
            "e": [
              ",AROSE",
              ",FAKER",
              ",FREAK",
              ",SAFER"
            ]
          },
          "level_010": {
            "a": 672044,
            "b": "LBHPSIU",
            "e": [
              ",BUSH",
              ",LISP",
              ",LUSH",
              ",PLUS",
              ",PUSH",
              ",SHIP",
              ",SLIP",
              ",BLUSH",
              ",PLUSH"
            ]
          },
          "level_011": {
            "a": 672035,
            "b": "AEHDY",
            "e": [
              ",AYE",
              ",DAY",
              ",DYE",
              ",HAD",
              ",HAY",
              ",HEY",
              ",HEAD",
              ",YEAH",
              ",HEADY"
            ]
          },
          "level_012": {
            "a": 672049,
            "b": "GEDOVL",
            "e": [
              ",DOVE",
              ",GOLD",
              ",LODE",
              ",LOVE",
              ",GLOVE",
              "B,LODGE",
              ",LOVED",
              ",GLOVED"
            ]
          },
          "level_013": {
            "a": 672030,
            "b": "EEAMINX",
            "e": [
              ",AMEN",
              ",EXAM",
              ",MAIN",
              ",MANE",
              ",MEAN",
              ",MINE",
              ",NAME",
              ",EXAMINE"
            ]
          },
          "level_014": {
            "a": 672042,
            "b": "ISESRTO",
            "e": [
              ",STORE",
              ",TRIES",
              ",RESIST",
              ",SISTER"
            ]
          },
          "level_015": {
            "a": 672033,
            "b": "SAYPO",
            "e": [
              ",PAY",
              "B,SAP",
              ",SAY",
              ",SOP",
              ",SOY",
              ",SPA",
              ",SPY",
              ",SOAP"
            ]
          },
          "level_016": {
            "a": 672047,
            "b": "YIFTSH",
            "e": [
              ",FIT",
              ",HIS",
              ",HIT",
              ",ITS",
              ",SHY",
              ",SIT",
              ",THY",
              ",TIS",
              ",SHIFT",
              ",SHIFTY"
            ]
          },
          "level_017": {
            "a": 672032,
            "b": "FIOEBRX",
            "e": [
              ",BOXER",
              ",BRIEF",
              ",FIBER",
              ",FIXER",
              ",BOXIER"
            ]
          },
          "level_018": {
            "a": 672041,
            "b": "AINMCRE",
            "e": [
              ",CRANE",
              ",CREAM",
              ",CRIME",
              ",MANIC",
              ",MINCE",
              ",MINER",
              ",NICER",
              ",CINEMA",
              ",MARINE",
              ",REMAIN"
            ]
          },
          "level_019": {
            "a": 672031,
            "b": "NWYTRI",
            "e": [
              ",NIT",
              ",TIN",
              ",TRY",
              ",WIN",
              ",WIT",
              ",WRY",
              ",TINY",
              ",TWIN",
              ",WIRY"
            ]
          },
          "level_020": {
            "a": 672046,
            "b": "SSOYRLG",
            "e": [
              ",LOSS",
              ",ROSY",
              ",SLOG",
              ",GLORY",
              "B,GLOSS",
              ",GROSS",
              ",GLOSSY",
              ",GROSSLY"
            ]
          }
        },
        "m": 617485,
        "o": 50687,
        "r": 617485,
        "t": 0.55,
        "u": 16580605,
        "v": 634893,
        "y": 0.55,
        "z": 16580605
      },
      "set_2": {
        "a": "AZURE",
        "aa": 438829,
        "d": "bg_mist2.jpg",
        "dd": 438829,
        "e": 0.2,
        "j": 438829,
        "l": 438829,
        "levels": {
          "level_001": {
            "a": 672901,
            "b": "RECVALE",
            "e": [
              ",CARVE",
              ",CLEAR",
              ",CRAVE",
              ",LEAVE",
              ",LEVER",
              ",CEREAL",
              ",CLEVER",
              ",REVEAL"
            ]
          },
          "level_002": {
            "a": 672903,
            "b": "HERSAO",
            "e": [
              ",HARE",
              ",HEAR",
              ",HERO",
              ",HOSE",
              ",RASH",
              ",ROSE",
              ",SEAR",
              ",SHOE",
              ",SOAR",
              ",SORE",
              ",ASHORE",
              "B,HOARSE"
            ]
          },
          "level_003": {
            "a": 672896,
            "b": "GTEIDW",
            "e": [
              ",DIET",
              ",EDIT",
              ",TIDE",
              ",TIED",
              ",TWIG",
              ",WIDE"
            ]
          },
          "level_004": {
            "a": 672911,
            "b": "BETADSD",
            "e": [
              ",BASE",
              ",BEAD",
              ",BEAT",
              ",BEST",
              ",BETA",
              ",DATE",
              ",DEAD",
              ",DEBT",
              ",EAST",
              ",SEAT",
              ",STAB"
            ]
          },
          "level_005": {
            "a": 672904,
            "b": "FNCOER",
            "e": [
              ",CONE",
              ",CORE",
              ",CORN",
              ",FERN",
              ",FORE",
              ",ONCE",
              ",CRONE",
              ",FORCE"
            ]
          },
          "level_006": {
            "a": 672908,
            "b": "FEILDD",
            "e": [
              ",DELI",
              ",DIED",
              ",FILE",
              ",FLED",
              ",IDLE",
              ",LIED",
              ",LIFE",
              ",FIDDLE"
            ]
          },
          "level_007": {
            "a": 672900,
            "b": "MDAAME",
            "e": [
              ",DAM",
              ",MAD",
              ",DAME",
              "B,MADE",
              ",MAMA",
              ",MEAD",
              ",MADAM",
              ",MADAME"
            ]
          },
          "level_008": {
            "a": 672913,
            "b": "ARDEBOF",
            "e": [
              ",ADOBE",
              "B,ADORE",
              ",BARED",
              ",BEARD",
              ",BOARD",
              ",BORED",
              ",BREAD",
              ",BROAD",
              ",FARED"
            ]
          },
          "level_009": {
            "a": 672894,
            "b": "VEWTEL",
            "e": [
              ",EVE",
              ",EWE",
              ",LET",
              ",TEE",
              ",VET",
              ",WEE",
              ",WET",
              ",TWELVE"
            ]
          },
          "level_010": {
            "a": 672907,
            "b": "TRBSOCH",
            "e": [
              ",BOTH",
              ",COST",
              ",HOST",
              ",SHOT",
              ",SORT",
              ",BROTH",
              "B,SHORT",
              ",THROB",
              ",TORCH"
            ]
          },
          "level_011": {
            "a": 672902,
            "b": "RTYDUS",
            "e": [
              ",DUST",
              ",DUTY",
              ",RUST",
              ",STUD",
              ",DUSTY",
              ",RUSTY",
              ",STUDY",
              ",STURDY"
            ]
          },
          "level_012": {
            "a": 672910,
            "b": "NTGSRI",
            "e": [
              ",GRIN",
              "B,GRIT",
              ",RING",
              ",SIGN",
              ",SING",
              ",STIR",
              ",STING",
              ",STRING"
            ]
          },
          "level_013": {
            "a": 672898,
            "b": "EGNEIUN",
            "e": [
              ",GENE",
              ",NINE",
              ",ENGINE",
              ",GENUINE"
            ]
          },
          "level_014": {
            "a": 672905,
            "b": "WIDLE",
            "e": [
              ",DEW",
              ",LED",
              ",LID",
              ",LIE",
              ",WIELD"
            ]
          },
          "level_015": {
            "a": 672895,
            "b": "UOTER",
            "e": [
              ",ORE",
              ",OUR",
              ",OUT",
              ",ROT",
              ",RUE",
              ",RUT",
              ",TOE",
              ",OUTER",
              ",ROUTE"
            ]
          },
          "level_016": {
            "a": 672909,
            "b": "CECAURS",
            "e": [
              ",CAUSE",
              ",CURSE",
              ",SAUCE",
              ",SCARE",
              ",ACCUSE",
              ",SAUCER",
              ",SCARCE",
              ",ACCUSER"
            ]
          },
          "level_017": {
            "a": 672897,
            "b": "BEHMLU",
            "e": [
              ",ELM",
              ",EMU",
              ",HEM",
              ",HUB",
              ",HUE",
              ",HUM",
              ",BLUE",
              "B,HELM",
              ",LUBE",
              ",MULE"
            ]
          },
          "level_018": {
            "a": 672906,
            "b": "UHOGFT",
            "e": [
              ",THUG",
              ",TOFU",
              ",OUGHT",
              ",TOUGH"
            ]
          },
          "level_019": {
            "a": 672899,
            "b": "AVERDNA",
            "e": [
              ",AND",
              ",ARE",
              ",DEN",
              ",EAR",
              ",END",
              ",ERA",
              ",RAD",
              ",RAN",
              ",RED",
              ",VAN",
              ",VERANDA"
            ]
          },
          "level_020": {
            "a": 672912,
            "b": "UAEDGG",
            "e": [
              ",AGE",
              ",DUE",
              ",DUG",
              ",EGG",
              ",GAG",
              ",GAUGED"
            ]
          }
        },
        "m": 422930,
        "o": 3655952,
        "r": 422930,
        "t": 0.6,
        "v": 438829,
        "y": 0.6
      },
      "set_3": {
        "a": "TOAD",
        "aa": 308557,
        "d": "bg_mist3.jpg",
        "dd": 308557,
        "e": 0.2,
        "g": 0.79,
        "j": 308557,
        "l": 308557,
        "levels": {
          "level_001": {
            "a": 673965,
            "b": "SEEIRL",
            "e": [
              ",ELSE",
              ",ISLE",
              ",LEER",
              ",REEL",
              ",RILE",
              ",RISE",
              ",SEER",
              ",RELIES"
            ]
          },
          "level_002": {
            "a": 673973,
            "b": "INESFUI",
            "e": [
              ",FIN",
              ",FUN",
              ",SIN",
              ",SUE",
              ",SUN",
              ",USE",
              ",FINE",
              "B,FUSE"
            ]
          },
          "level_003": {
            "a": 673961,
            "b": "EHSEAR",
            "e": [
              ",ERASE",
              ",SHARE",
              ",SHEAR",
              ",SHEER"
            ]
          },
          "level_004": {
            "a": 673975,
            "b": "EDSAWEE",
            "e": [
              ",EASE",
              ",SEED",
              ",WADE",
              ",WEED",
              ",EASED",
              ",SAWED",
              ",SEWED",
              ",SEAWEED"
            ]
          },
          "level_005": {
            "a": 673966,
            "b": "TNWSEE",
            "e": [
              ",NEST",
              "B,SEEN",
              ",SENT",
              ",SEWN",
              ",STEW",
              ",TEEN",
              ",WENT",
              ",WEST"
            ]
          },
          "level_006": {
            "a": 673970,
            "b": "AENNCHL",
            "e": [
              ",ACHE",
              ",ACNE",
              ",CANE",
              ",CLAN",
              ",EACH",
              ",HEAL",
              ",LACE",
              ",LANE",
              ",LEAN",
              ",CHANNEL"
            ]
          },
          "level_007": {
            "a": 673968,
            "b": "SUTESID",
            "e": [
              ",ISSUE",
              ",SITED",
              ",SUITE",
              ",DUTIES",
              ",ISSUED",
              ",SUITED",
              ",TISSUE",
              ",STUDIES"
            ]
          },
          "level_008": {
            "a": 673979,
            "b": "THYSLGO",
            "e": [
              ",GOT",
              ",HOG",
              ",HOT",
              ",LOG",
              ",LOT",
              ",SHY",
              ",SLY",
              ",SOY",
              ",THY",
              ",TOY",
              ",GHOST",
              "B,HOTLY"
            ]
          },
          "level_009": {
            "a": 673967,
            "b": "TARIET",
            "e": [
              ",RATE",
              ",RITE",
              ",TART",
              ",TEAR",
              ",TIER",
              ",TIRE",
              ",TRAIT",
              ",TREAT",
              ",TRITE"
            ]
          },
          "level_010": {
            "a": 673972,
            "b": "SIRDDOC",
            "e": [
              ",COD",
              ",DID",
              ",DOC",
              ",ODD",
              ",RID",
              ",ROD",
              ",SIR",
              ",SOD",
              ",CORD",
              ",DISC"
            ]
          },
          "level_011": {
            "a": 673964,
            "b": "NLADRHE",
            "e": [
              ",HEARD",
              ",LADEN",
              ",LEARN",
              ",RENAL",
              ",HANDLE",
              ",HARDEN",
              ",HERALD",
              ",LANDER",
              ",HANDLER"
            ]
          },
          "level_012": {
            "a": 673978,
            "b": "NEDESCT",
            "e": [
              ",DENSE",
              ",SCENE",
              ",SCENT",
              ",TENSE",
              ",DECENT",
              ",NESTED",
              ",TENSED",
              ",DESCENT",
              ",SCENTED"
            ]
          },
          "level_013": {
            "a": 673962,
            "b": "LSALEAW",
            "e": [
              ",ALE",
              ",ALL",
              ",AWE",
              ",LAW",
              ",SAW",
              ",SEA",
              ",SEW",
              ",WAS",
              ",SWELL"
            ]
          },
          "level_014": {
            "a": 673974,
            "b": "PONCOH",
            "e": [
              ",CON",
              ",COO",
              ",COP",
              ",HOP",
              ",OOH",
              ",CHOP",
              ",COOP",
              ",HOOP"
            ]
          },
          "level_015": {
            "a": 673969,
            "b": "AAEPCAN",
            "e": [
              ",ACE",
              "B,APE",
              ",CAN",
              ",CAP",
              ",NAP",
              ",PAN",
              ",PEA",
              ",PEN",
              ",PECAN"
            ]
          },
          "level_016": {
            "a": 673976,
            "b": "YAOPLJ",
            "e": [
              ",JAY",
              ",JOY",
              ",LAP",
              ",LAY",
              ",PAL",
              ",PAY",
              ",PLY",
              ",PLAY",
              "B,PLOY"
            ]
          },
          "level_017": {
            "a": 673960,
            "b": "KCEBTU",
            "e": [
              ",BET",
              ",BUT",
              ",CUB",
              ",CUE",
              ",CUT",
              ",TUB",
              ",BECK",
              ",BUCK",
              ",CUBE",
              ",CUTE",
              ",TUBE",
              ",TUCK"
            ]
          },
          "level_018": {
            "a": 673971,
            "b": "AAPILRT",
            "e": [
              ",ALTAR",
              ",APART",
              ",TRAIL",
              ",TRIAL"
            ]
          },
          "level_019": {
            "a": 673963,
            "b": "YSUGT",
            "e": [
              ",GUT",
              "B,GUY",
              ",TUG",
              ",GUST"
            ]
          },
          "level_020": {
            "a": 673977,
            "b": "IHLYRC",
            "e": [
              ",CHI",
              ",CRY",
              ",ICY",
              ",LYRIC",
              ",RICHLY"
            ]
          }
        },
        "m": 293685,
        "o": 15488838,
        "r": 293685,
        "t": 0.6,
        "v": 308557,
        "y": 0.6
      },
      "set_4": {
        "a": "BROOK",
        "aa": 178285,
        "d": "bg_mist4.jpg",
        "dd": 178285,
        "e": 0.2,
        "j": 178285,
        "l": 178285,
        "levels": {
          "level_001": {
            "a": 674873,
            "b": "ADOROWY",
            "e": [
              ",DOOR",
              "B,DRAW",
              ",ODOR",
              ",ROAD",
              ",WARD",
              ",WARY",
              ",WOOD",
              ",WORD",
              ",YARD"
            ]
          },
          "level_002": {
            "a": 674884,
            "b": "ORTHESM",
            "e": [
              ",ETHOS",
              ",HOMER",
              ",HORSE",
              ",METRO",
              ",OTHER",
              ",SHORE",
              ",SHORT",
              ",STORE",
              ",STORM",
              ",THOSE",
              ",MOTHER"
            ]
          },
          "level_003": {
            "a": 674875,
            "b": "AGNT",
            "e": [
              ",ANT",
              ",NAG",
              ",TAG",
              ",TAN",
              ",TANG"
            ]
          },
          "level_004": {
            "a": 674889,
            "b": "TNCENOT",
            "e": [
              ",CENT",
              "B,CONE",
              ",NEON",
              ",NONE",
              ",NOTE",
              ",ONCE",
              ",TENT",
              ",TONE",
              ",CONTENT"
            ]
          },
          "level_005": {
            "a": 674870,
            "b": "EYREOBW",
            "e": [
              ",BEER",
              ",BORE",
              ",BREW",
              ",BROW",
              ",OBEY",
              ",ROBE",
              ",WERE",
              ",WORE",
              ",EYEBROW"
            ]
          },
          "level_006": {
            "a": 674882,
            "b": "PBUML",
            "e": [
              ",PUB",
              ",BUMP",
              ",LUMP",
              ",PLUM",
              ",PLUMB"
            ]
          },
          "level_007": {
            "a": 674879,
            "b": "URAAULG",
            "e": [
              ",GAL",
              ",LAG",
              ",LUG",
              ",RAG",
              ",RUG",
              ",AURA",
              "B,GALA",
              ",GURU"
            ]
          },
          "level_008": {
            "a": 674886,
            "b": "SDCNIRE",
            "e": [
              ",CIDER",
              "B,CRIED",
              ",CRIES",
              ",DINER",
              ",DRIES",
              ",NICER",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SINCE",
              ",SIREN"
            ]
          },
          "level_009": {
            "a": 674876,
            "b": "NVAALLI",
            "e": [
              ",LAVA",
              ",NAIL",
              ",VAIN",
              ",VIAL",
              ",AVIAN",
              "B,NAVAL",
              ",VILLA",
              ",VANILLA"
            ]
          },
          "level_010": {
            "a": 674883,
            "b": "ANERCTU",
            "e": [
              ",ACUTE",
              "B,CATER",
              ",CRANE",
              ",CRATE",
              ",CUTER",
              ",ENACT",
              ",REACT",
              ",TRACE",
              ",TRUCE",
              ",TUNER"
            ]
          },
          "level_011": {
            "a": 674878,
            "b": "AWSRGEG",
            "e": [
              ",GEAR",
              ",GREW",
              ",RAGE",
              ",SAGE",
              ",SEAR",
              ",SWAG",
              ",WAGE",
              ",WEAR",
              ",SWAGGER"
            ]
          },
          "level_012": {
            "a": 674888,
            "b": "OTYSRP",
            "e": [
              ",PORT",
              ",POST",
              ",ROSY",
              ",SORT",
              ",SPOT",
              ",SPRY",
              ",STOP",
              ",TYPO"
            ]
          },
          "level_013": {
            "a": 674877,
            "b": "IREDFG",
            "e": [
              ",DIRE",
              ",FIRE",
              ",GRID",
              ",RIDE",
              ",RIFE",
              ",FIRED",
              ",FRIED",
              ",GRIEF",
              ",RIDGE"
            ]
          },
          "level_014": {
            "a": 674881,
            "b": "RDCZAE",
            "e": [
              ",CADRE",
              ",CARED",
              ",CEDAR",
              ",CRAZE",
              ",RACED",
              ",RAZED",
              ",CRAZED"
            ]
          },
          "level_015": {
            "a": 674871,
            "b": "INDLYBL",
            "e": [
              ",BILL",
              ",BIND",
              ",DILL",
              ",IDLY",
              ",LILY",
              ",BLINDLY"
            ]
          },
          "level_016": {
            "a": 674885,
            "b": "VLFYREO",
            "e": [
              ",FLYER",
              ",FOYER",
              ",LOVER",
              ",OVERLY"
            ]
          },
          "level_017": {
            "a": 674874,
            "b": "REARDE",
            "e": [
              ",DARE",
              ",DEAR",
              ",DEER",
              ",RARE",
              ",READ",
              ",REAR",
              ",REED",
              ",READER",
              ",REARED"
            ]
          },
          "level_018": {
            "a": 674880,
            "b": "HSTETRC",
            "e": [
              ",HER",
              ",SET",
              ",SHE",
              ",THE",
              ",ETCH",
              ",REST",
              ",SECT",
              ",TECH",
              ",TEST",
              ",STRETCH"
            ]
          },
          "level_019": {
            "a": 674872,
            "b": "ETUIN",
            "e": [
              ",NET",
              ",NIT",
              ",NUT",
              ",TEN",
              ",TIE",
              ",TIN",
              ",TUNE",
              ",UNIT"
            ]
          },
          "level_020": {
            "a": 674887,
            "b": "KOESP",
            "e": [
              ",SOP",
              ",POKE",
              ",POSE",
              ",SPOKE"
            ]
          }
        },
        "m": 162137,
        "r": 162137,
        "t": 0.65,
        "u": 16776703,
        "v": 178285,
        "y": 0.65,
        "z": 16776703
      },
      "set_5": {
        "a": "LEAF",
        "aa": 48013,
        "d": "bg_mist5.jpg",
        "dd": 48013,
        "e": 0.2,
        "j": 48013,
        "l": 48013,
        "levels": {
          "level_001": {
            "a": 675964,
            "b": "GLSANO",
            "e": [
              ",ALONG",
              ",ANGLO",
              ",SALON",
              ",SLANG"
            ]
          },
          "level_002": {
            "a": 675971,
            "b": "URDON",
            "e": [
              ",DUO",
              ",NOD",
              ",NOR",
              ",OUR",
              ",ROD",
              ",RUN",
              ",URN",
              ",ROUND"
            ]
          },
          "level_003": {
            "a": 675966,
            "b": "NDCEFEE",
            "e": [
              ",DEN",
              ",END",
              ",FED",
              ",FEE",
              ",FEED",
              "B,FEND",
              ",NEED",
              ",FENCE"
            ]
          },
          "level_004": {
            "a": 675979,
            "b": "BREEAV",
            "e": [
              ",ARE",
              "B,BAR",
              ",BEE",
              ",BRA",
              ",EAR",
              ",ERA",
              ",EVE",
              ",BRAVE",
              ",BEAVER"
            ]
          },
          "level_005": {
            "a": 675967,
            "b": "IDAM",
            "e": [
              ",AID",
              ",AIM",
              ",DAM",
              ",DIM",
              ",MAD",
              ",MID",
              ",AMID",
              ",MAID"
            ]
          },
          "level_006": {
            "a": 675974,
            "b": "BEDLEH",
            "e": [
              ",HEED",
              ",HEEL",
              ",HELD",
              ",BLEED"
            ]
          },
          "level_007": {
            "a": 675965,
            "b": "ELCRTEE",
            "e": [
              ",LET",
              ",TEE",
              ",LEER",
              ",REEL",
              ",TREE",
              ",ELECT",
              ",ERECT",
              ",REELECT"
            ]
          },
          "level_008": {
            "a": 675976,
            "b": "AAWPYHT",
            "e": [
              ",AHA",
              "B,APT",
              ",HAT",
              ",HAY",
              ",PAT",
              ",PAW",
              ",PAY",
              ",TAP",
              ",THY",
              ",WAY",
              ",WHY",
              ",APATHY"
            ]
          },
          "level_009": {
            "a": 675968,
            "b": "DTARY",
            "e": [
              ",ART",
              ",DAY",
              ",DRY",
              ",RAD",
              ",RAT",
              ",RAY",
              ",TAD",
              ",TAR",
              ",TRY",
              ",TARDY"
            ]
          },
          "level_010": {
            "a": 675972,
            "b": "ATIGASN",
            "e": [
              ",AGAIN",
              ",ANGST",
              ",GIANT",
              ",SAINT",
              ",SATIN",
              ",STAIN",
              ",STING",
              ",AGAINST"
            ]
          },
          "level_011": {
            "a": 675960,
            "b": "HRICEP",
            "e": [
              ",CHIP",
              ",EPIC",
              ",HEIR",
              ",HIRE",
              ",PIER",
              ",RICE",
              ",RICH",
              ",RIPE",
              ",PERCH",
              ",PRICE"
            ]
          },
          "level_012": {
            "a": 675975,
            "b": "YNISEW",
            "e": [
              ",NEW",
              ",SEW",
              ",SIN",
              ",WIN",
              ",YEN",
              ",YES",
              ",YEW",
              ",SWINE"
            ]
          },
          "level_013": {
            "a": 675970,
            "b": "EULESRI",
            "e": [
              ",LIE",
              ",RUE",
              ",SEE",
              ",SIR",
              ",SUE",
              ",USE",
              ",RELIES",
              ",LEISURE"
            ]
          },
          "level_014": {
            "a": 675973,
            "b": "RAIAGSN",
            "e": [
              ",GAIN",
              "B,GRIN",
              ",RAIN",
              ",RANG",
              ",RING",
              ",SAGA",
              ",SANG",
              ",SIGN",
              ",SING"
            ]
          },
          "level_015": {
            "a": 675969,
            "b": "GENBIN",
            "e": [
              ",BEG",
              "B,BIG",
              ",BIN",
              ",GIN",
              ",INN",
              ",NINE"
            ]
          },
          "level_016": {
            "a": 675977,
            "b": "AMREEG",
            "e": [
              ",AGREE",
              ",EAGER",
              ",GAMER",
              ",MERGE",
              ",MEAGER"
            ]
          },
          "level_017": {
            "a": 675961,
            "b": "URSIUPT",
            "e": [
              ",RUST",
              ",SPIT",
              ",SPUR",
              ",STIR",
              ",SUIT",
              ",TRIP"
            ]
          },
          "level_018": {
            "a": 675963,
            "b": "MPDEIL",
            "e": [
              ",DELI",
              ",DIME",
              ",IDLE",
              ",LIED",
              ",LIME",
              ",LIMP",
              ",MELD",
              ",MILD",
              ",MILE",
              ",PILE",
              ",DIMPLE",
              "B,LIMPED"
            ]
          },
          "level_019": {
            "a": 675962,
            "b": "LUEGBD",
            "e": [
              ",BLUE",
              ",DUEL",
              ",GLUE",
              ",LUBE",
              ",BUDGE",
              ",BUGLE",
              ",BULGE",
              ",GLUED"
            ]
          },
          "level_020": {
            "a": 675978,
            "b": "RMAIMDE",
            "e": [
              ",AIMED",
              ",AIRED",
              ",ARMED",
              ",DREAM",
              ",MEDIA",
              ",ADMIRE",
              ",DIMMER",
              ",RAMMED",
              ",RIMMED"
            ]
          }
        },
        "m": 30554,
        "o": 16752897,
        "r": 30554,
        "t": 0.6,
        "v": 48013,
        "y": 0.6
      }
    }
  },
  "WS 06": {
    "a": "HILLS",
    "b": "grad_white",
    "c": "grp_hills",
    "d": 0.75,
    "e": 16711680,
    "f": 12517376,
    "sets": {
      "set_1": {
        "a": "REACH",
        "aa": 16711680,
        "d": "bg_hills1.jpg",
        "dd": 16711680,
        "e": 0,
        "j": 16711680,
        "l": 16711680,
        "levels": {
          "level_001": {
            "a": 676215,
            "b": "RPYPPE",
            "e": [
              ",PEP",
              ",PER",
              ",PRY",
              ",REP",
              ",RYE",
              ",YEP",
              ",PREP",
              ",PREY",
              ",PREPPY"
            ]
          },
          "level_002": {
            "a": 676221,
            "b": "TYRTOHA",
            "e": [
              ",OATH",
              ",TART",
              ",THAT",
              ",TORT",
              ",TRAY",
              ",TROT",
              ",THROAT",
              ",THROATY"
            ]
          },
          "level_003": {
            "a": 676228,
            "b": "ALOTT",
            "e": [
              ",LOT",
              ",OAT",
              ",TOT",
              ",TOTAL"
            ]
          },
          "level_004": {
            "a": 676233,
            "b": "LIISOCT",
            "e": [
              ",CLOT",
              "B,COIL",
              ",COLT",
              ",COST",
              ",LIST",
              ",LOST",
              ",SILO",
              ",SILT",
              ",SLIT",
              ",SLOT",
              ",SOIL",
              ",TOIL"
            ]
          },
          "level_005": {
            "a": 676220,
            "b": "EUTRFU",
            "e": [
              ",FRET",
              "B,TRUE",
              ",TURF",
              ",FUTURE"
            ]
          },
          "level_006": {
            "a": 676230,
            "b": "ERIFEN",
            "e": [
              ",FERN",
              "B,FINE",
              ",FIRE",
              ",FREE",
              ",REEF",
              ",REIN",
              ",RIFE",
              ",REFINE"
            ]
          },
          "level_007": {
            "a": 676217,
            "b": "BMOCO",
            "e": [
              ",BOO",
              ",COB",
              ",COO",
              ",MOB",
              ",MOO",
              ",BOOM",
              "B,COMB",
              ",COMBO"
            ]
          },
          "level_008": {
            "a": 676232,
            "b": "LDPEED",
            "e": [
              ",DEED",
              ",DEEP",
              ",PEEL",
              ",PLED"
            ]
          },
          "level_009": {
            "a": 676222,
            "b": "RPNSAO",
            "e": [
              ",SNAP",
              ",SOAP",
              ",SOAR",
              ",SPAN",
              ",SPAR",
              ",APRON",
              ",ARSON",
              ",SONAR"
            ]
          },
          "level_010": {
            "a": 676229,
            "b": "RULEAN",
            "e": [
              ",EARL",
              ",EARN",
              ",LANE",
              ",LEAN",
              ",LURE",
              ",NEAR",
              ",REAL",
              ",RULE",
              ",NEURAL",
              ",UNREAL"
            ]
          },
          "level_011": {
            "a": 676214,
            "b": "KHUECLC",
            "e": [
              ",CUE",
              ",ELK",
              ",HUE",
              ",CLUE",
              ",HULK",
              ",LUCK",
              ",CHECK",
              ",CHUCK"
            ]
          },
          "level_012": {
            "a": 676231,
            "b": "APKCAGE",
            "e": [
              ",CAGE",
              ",CAKE",
              ",CAPE",
              ",GAPE",
              ",PACE",
              ",PACK",
              ",PAGE",
              ",PEAK",
              ",PECK",
              ",PACKAGE"
            ]
          },
          "level_013": {
            "a": 676224,
            "b": "JOGNHAM",
            "e": [
              ",AGO",
              ",HAG",
              ",HAM",
              ",HOG",
              ",JAG",
              ",JAM",
              ",JOG",
              ",MAG",
              ",MAN",
              ",NAG",
              ",HANG",
              ",MOAN"
            ]
          },
          "level_014": {
            "a": 676226,
            "b": "RECDTI",
            "e": [
              ",CIDER",
              ",CITED",
              ",CRIED",
              ",EDICT",
              ",TIRED",
              ",TRIED",
              ",CREDIT",
              ",DIRECT"
            ]
          },
          "level_015": {
            "a": 676216,
            "b": "ATDVIUC",
            "e": [
              ",ACID",
              ",AVID",
              ",DIVA",
              ",DUCT",
              ",AUDIT"
            ]
          },
          "level_016": {
            "a": 676227,
            "b": "SPLASHY",
            "e": [
              ",ASHY",
              ",LASH",
              ",PLAY",
              ",SASH",
              ",SLAP",
              ",SLAY",
              ",PALSY",
              "B,SLASH",
              ",SPLASH"
            ]
          },
          "level_017": {
            "a": 676225,
            "b": "DDEIVRI",
            "e": [
              ",DIVER",
              ",DRIED",
              ",DRIVE",
              ",DIVIDE"
            ]
          },
          "level_018": {
            "a": 676218,
            "b": "LTHICG",
            "e": [
              ",CHI",
              ",GIT",
              ",HIT",
              ",LIT",
              ",TIC",
              ",TIL",
              ",GILT",
              ",HILT",
              ",ITCH",
              ",LIGHT"
            ]
          },
          "level_019": {
            "a": 676223,
            "b": "ILDBIO",
            "e": [
              ",BID",
              ",BIO",
              ",BOD",
              ",LID",
              ",LOB",
              ",OIL",
              ",OLD",
              ",BOIL",
              "B,BOLD",
              ",IDOL"
            ]
          },
          "level_020": {
            "a": 676219,
            "b": "UGCSEOR",
            "e": [
              ",CURSE",
              ",ROGUE",
              ",ROUGE",
              ",ROUSE",
              ",SCORE",
              ",SCOUR",
              ",SURGE",
              ",COURSE",
              ",GROUSE",
              ",SOURCE"
            ]
          }
        },
        "m": 7733248,
        "o": 16741120,
        "r": 8997376,
        "t": 0.74,
        "v": 16711680,
        "y": 0.74
      },
      "set_2": {
        "a": "SKY",
        "aa": 15204352,
        "cc": 4294967295,
        "d": "bg_hills2.jpg",
        "dd": 15204352,
        "e": 0,
        "ee": 4294967295,
        "i": 4294967295,
        "j": 15204352,
        "k": 4294967295,
        "l": 15204352,
        "levels": {
          "level_001": {
            "a": 676472,
            "b": "AGLEL",
            "e": [
              ",AGE",
              ",ALE",
              ",ALL",
              ",GAL",
              ",GEL",
              ",LAG",
              ",LEG",
              ",GALE",
              ",GALL"
            ]
          },
          "level_002": {
            "a": 676483,
            "b": "CLARHO",
            "e": [
              ",CAROL",
              ",CORAL",
              ",ROACH",
              ",CHORAL"
            ]
          },
          "level_003": {
            "a": 676488,
            "b": "ESXTA",
            "e": [
              ",ATE",
              "B,AXE",
              ",EAT",
              ",SAT",
              ",SAX",
              ",SEA",
              ",SET",
              ",SEX",
              ",TAX",
              ",TEA",
              ",TAXES"
            ]
          },
          "level_004": {
            "a": 676491,
            "b": "WOORDDE",
            "e": [
              ",DOOR",
              "B,DREW",
              ",ODOR",
              ",OWED",
              ",REDO",
              ",RODE",
              ",WOOD",
              ",WORD",
              ",WORE",
              ",REDWOOD"
            ]
          },
          "level_005": {
            "a": 676489,
            "b": "PBYRUET",
            "e": [
              ",BRUTE",
              ",BUYER",
              ",ERUPT",
              ",TUBER",
              ",PUBERTY"
            ]
          },
          "level_006": {
            "a": 676481,
            "b": "DORIHR",
            "e": [
              ",HID",
              "B,RID",
              ",ROD",
              ",HORRID"
            ]
          },
          "level_007": {
            "a": 676473,
            "b": "EEVALET",
            "e": [
              ",LEAVE",
              ",LEVEE",
              ",VALET",
              ",ELEVATE"
            ]
          },
          "level_008": {
            "a": 676486,
            "b": "AYKNSE",
            "e": [
              ",EASY",
              ",SAKE",
              ",SANE",
              ",SANK",
              ",YANK",
              ",SNAKE",
              ",SNEAK",
              ",SNEAKY"
            ]
          },
          "level_009": {
            "a": 676476,
            "b": "RWOEDN",
            "e": [
              ",DRONE",
              ",DROWN",
              ",ENDOW",
              ",OWNED",
              ",OWNER",
              ",ROWED"
            ]
          },
          "level_010": {
            "a": 676480,
            "b": "CANDEEC",
            "e": [
              ",ACE",
              ",AND",
              ",CAD",
              ",CAN",
              ",DEN",
              ",END",
              ",ACNE",
              ",CANE",
              ",CEDE",
              ",DEAN",
              ",NEED",
              ",CADENCE"
            ]
          },
          "level_011": {
            "a": 676482,
            "b": "IAFFRM",
            "e": [
              ",AIM",
              ",AIR",
              ",ARM",
              ",FAR",
              ",FIR",
              ",MAR",
              ",RAM",
              ",RIM",
              ",FAIR",
              ",FARM",
              ",FIRM",
              ",RIFF"
            ]
          },
          "level_012": {
            "a": 676474,
            "b": "TSUPMY",
            "e": [
              ",PUT",
              ",SPY",
              ",SUM",
              ",SUP",
              ",UPS",
              ",YUM",
              ",YUP",
              ",MUSTY",
              ",STUMP",
              ",STUMPY"
            ]
          },
          "level_013": {
            "a": 676479,
            "b": "YLNAIM",
            "e": [
              ",LAIN",
              ",MAIL",
              ",MAIN",
              ",MANY",
              ",NAIL",
              ",MANLY"
            ]
          },
          "level_014": {
            "a": 676475,
            "b": "OEHNIRE",
            "e": [
              ",HEN",
              ",HER",
              ",HOE",
              ",ION",
              ",IRE",
              ",NOR",
              ",ONE",
              ",ORE",
              ",HERON",
              "B,RHINO",
              ",HEREIN"
            ]
          },
          "level_015": {
            "a": 676478,
            "b": "BSREICA",
            "e": [
              ",ARISE",
              "B,BASIC",
              ",BRACE",
              ",CRIES",
              ",RAISE",
              ",SABER",
              ",SABRE",
              ",SCARE"
            ]
          },
          "level_016": {
            "a": 676484,
            "b": "NAMTUNH",
            "e": [
              ",AUNT",
              ",HUNT",
              ",MATH",
              ",THAN",
              ",TUNA",
              ",HAUNT",
              ",HUMAN",
              ",MANHUNT"
            ]
          },
          "level_017": {
            "a": 676490,
            "b": "MSEODK",
            "e": [
              ",DEMO",
              ",DESK",
              ",DOME",
              ",DOSE",
              ",MODE",
              ",SOME",
              ",SMOKE",
              ",SMOKED"
            ]
          },
          "level_018": {
            "a": 676485,
            "b": "OYEDC",
            "e": [
              ",COD",
              ",COY",
              ",DOC",
              ",DOE",
              ",DYE",
              ",ODE",
              ",CODE",
              "B,COED"
            ]
          },
          "level_019": {
            "a": 676477,
            "b": "VRBARYE",
            "e": [
              ",BARE",
              ",BEAR",
              ",BEVY",
              ",RARE",
              ",RAVE",
              ",REAR",
              ",VARY",
              ",VERB",
              ",VERY",
              ",YEAR"
            ]
          },
          "level_020": {
            "a": 676487,
            "b": "RETCTRI",
            "e": [
              ",CITE",
              ",RICE",
              ",RITE",
              ",TIER",
              ",TIRE",
              ",CRIER",
              ",TRITE",
              ",CRITTER"
            ]
          }
        },
        "m": 7733248,
        "o": 234929562,
        "r": 8997376,
        "t": 0.76,
        "v": 15204352,
        "x": 4294967295,
        "y": 0.76
      },
      "set_3": {
        "a": "SOUND",
        "aa": 13697024,
        "bb": 16777215,
        "cc": 4294967295,
        "d": "bg_hills3.jpg",
        "dd": 13697024,
        "e": 0,
        "ee": 4294967295,
        "g": 0.92,
        "i": 4294967295,
        "j": 13697024,
        "k": 4294967295,
        "l": 13697024,
        "levels": {
          "level_001": {
            "a": 676747,
            "b": "YGRUHN",
            "e": [
              ",GUN",
              ",GUY",
              ",HUG",
              ",RUG",
              ",RUN",
              ",UGH",
              ",URN",
              ",HUNG",
              "B,RUNG"
            ]
          },
          "level_002": {
            "a": 676752,
            "b": "ORFFET",
            "e": [
              ",FORE",
              ",FORT",
              ",FRET",
              ",ROTE",
              ",TORE",
              ",FORTE",
              ",OFFER",
              ",EFFORT"
            ]
          },
          "level_003": {
            "a": 676756,
            "b": "CATAEUH",
            "e": [
              ",ACHE",
              ",CHAT",
              ",CUTE",
              ",EACH",
              ",ETCH",
              ",HATE",
              ",HEAT",
              ",TECH",
              ",ACUTE",
              ",CHEAT",
              ",CHUTE",
              ",TEACH"
            ]
          },
          "level_004": {
            "a": 676761,
            "b": "MCAOHMK",
            "e": [
              ",CAM",
              ",HAM",
              ",MAM",
              ",MOM",
              ",OAK",
              ",COMMA",
              ",MACHO",
              ",HAMMOCK"
            ]
          },
          "level_005": {
            "a": 676757,
            "b": "YLRTAYO",
            "e": [
              ",ORAL",
              "B,TRAY",
              ",ROYAL",
              ",ROYALTY"
            ]
          },
          "level_006": {
            "a": 676744,
            "b": "SOTMHO",
            "e": [
              ",HOOT",
              ",HOST",
              ",MOOT",
              ",MOST",
              ",MOTH",
              ",SHOO",
              ",SHOT",
              ",SOOT"
            ]
          },
          "level_007": {
            "a": 676760,
            "b": "HRADS",
            "e": [
              ",ADS",
              ",ASH",
              ",HAD",
              ",HAS",
              ",RAD",
              ",SAD",
              ",DASH",
              "B,HARD",
              ",RASH",
              ",SHARD"
            ]
          },
          "level_008": {
            "a": 676759,
            "b": "EDESUDC",
            "e": [
              ",SUEDE",
              ",DEDUCE",
              ",SEDUCE",
              ",SEDUCED"
            ]
          },
          "level_009": {
            "a": 676748,
            "b": "PTORO",
            "e": [
              ",OPT",
              ",POT",
              ",PRO",
              ",ROT",
              ",TOO",
              ",TOP",
              ",POOR",
              ",PORT",
              ",ROOT",
              ",TROOP"
            ]
          },
          "level_010": {
            "a": 676750,
            "b": "EFADET",
            "e": [
              ",DATE",
              "B,DEAF",
              ",DEFT",
              ",FADE",
              ",FATE",
              ",FEAT",
              ",FEED",
              ",FEET",
              ",FETA",
              ",FATED"
            ]
          },
          "level_011": {
            "a": 676758,
            "b": "ILEBFE",
            "e": [
              ",BEE",
              ",EEL",
              ",ELF",
              ",FEE",
              ",LIE",
              ",BEEF",
              ",BILE",
              ",FEEL",
              ",FILE",
              ",FLEE",
              ",LIFE"
            ]
          },
          "level_012": {
            "a": 676746,
            "b": "MACTRA",
            "e": [
              ",CART",
              ",CRAM",
              ",MART",
              ",TRAM",
              ",TARMAC"
            ]
          },
          "level_013": {
            "a": 676749,
            "b": "YBOU",
            "e": [
              ",BOY",
              ",BUY",
              ",YOU",
              ",BUOY"
            ]
          },
          "level_014": {
            "a": 676755,
            "b": "EFABHL",
            "e": [
              ",ABLE",
              ",BALE",
              ",BLAH",
              ",FLAB",
              ",FLEA",
              ",HALF",
              ",HEAL",
              ",LEAF",
              ",FABLE"
            ]
          },
          "level_015": {
            "a": 676751,
            "b": "FRULETA",
            "e": [
              ",AFTER",
              ",ALERT",
              ",ALTER",
              ",FAULT",
              ",FERAL",
              ",FETAL",
              ",FLARE",
              ",FLUTE",
              ",LATER",
              ",ULTRA"
            ]
          },
          "level_016": {
            "a": 676762,
            "b": "LTCIOPI",
            "e": [
              ",CLIP",
              ",CLOT",
              ",COIL",
              ",COLT",
              ",PLOT",
              ",TOIL",
              ",OPTIC",
              ",PILOT",
              ",TOPIC",
              ",POLITIC"
            ]
          },
          "level_017": {
            "a": 676753,
            "b": "UEESQZE",
            "e": [
              ",SEE",
              "B,SUE",
              ",USE",
              ",SQUEEZE"
            ]
          },
          "level_018": {
            "a": 676763,
            "b": "FIEDREB",
            "e": [
              ",BREED",
              "B,BRIDE",
              ",BRIEF",
              ",DEFER",
              ",FIBER",
              ",FIRED",
              ",FREED",
              ",FRIED"
            ]
          },
          "level_019": {
            "a": 676745,
            "b": "IVNKSE",
            "e": [
              ",INK",
              ",KIN",
              ",SIN",
              ",SKI",
              ",VIE",
              ",SINK",
              ",SKIN",
              ",VEIN",
              ",VINE",
              ",KNIVES"
            ]
          },
          "level_020": {
            "a": 676754,
            "b": "OUNPDUR",
            "e": [
              ",DOUR",
              ",DROP",
              ",POND",
              ",POUR",
              ",PROD",
              ",UNDO",
              ",UPON",
              ",ROUNDUP"
            ]
          }
        },
        "m": 7733248,
        "o": 48538,
        "r": 8997376,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 13697024,
        "w": 16777215,
        "x": 4294967295,
        "y": 0.7000000000000001,
        "z": 0
      },
      "set_4": {
        "a": "EARTH",
        "aa": 13565952,
        "cc": 268435455,
        "d": "bg_hills4.jpg",
        "dd": 13565952,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 13565952,
        "k": 268435455,
        "l": 13565952,
        "levels": {
          "level_001": {
            "a": 676952,
            "b": "LNOGOM",
            "e": [
              ",GOO",
              "B,LOG",
              ",MOO",
              ",GLOOM"
            ]
          },
          "level_002": {
            "a": 676954,
            "b": "GUTMA",
            "e": [
              ",GUM",
              ",GUT",
              ",MAG",
              ",MAT",
              ",MUG",
              ",TAG",
              ",TAU",
              ",TUG",
              ",GAMUT"
            ]
          },
          "level_003": {
            "a": 676957,
            "b": "ARTTSE",
            "e": [
              ",EAST",
              ",RATE",
              ",REST",
              ",SEAR",
              ",SEAT",
              ",STAR",
              ",STAT",
              ",TART",
              ",TEAR",
              ",TEST"
            ]
          },
          "level_004": {
            "a": 676964,
            "b": "ETTOESR",
            "e": [
              ",OTTER",
              ",RESET",
              ",STEER",
              ",STORE",
              ",TERSE",
              ",SETTER",
              ",STEREO",
              ",STREET",
              ",TESTER"
            ]
          },
          "level_005": {
            "a": 676947,
            "b": "WBOR",
            "e": [
              ",BOW",
              ",BRO",
              ",ORB",
              ",ROB",
              ",ROW",
              ",BROW"
            ]
          },
          "level_006": {
            "a": 676960,
            "b": "TPEDOS",
            "e": [
              ",DEPOT",
              ",OPTED",
              ",PESTO",
              ",POSED",
              ",DESPOT",
              ",POSTED"
            ]
          },
          "level_007": {
            "a": 676959,
            "b": "DNAKART",
            "e": [
              ",DANK",
              "B,DARK",
              ",DARN",
              ",DART",
              ",DATA",
              ",RANK",
              ",RANT",
              ",TANK",
              ",DRANK"
            ]
          },
          "level_008": {
            "a": 676950,
            "b": "IOWNFL",
            "e": [
              ",FLOW",
              ",FOIL",
              ",FOWL",
              ",INFO",
              ",LION",
              ",LOIN",
              ",WOLF",
              ",FLOWN",
              ",INFLOW"
            ]
          },
          "level_009": {
            "a": 676962,
            "b": "CLAPAE",
            "e": [
              ",ACE",
              "B,ALE",
              ",APE",
              ",CAP",
              ",LAP",
              ",PAL",
              ",PEA",
              ",PLACE",
              ",PALACE"
            ]
          },
          "level_010": {
            "a": 676963,
            "b": "ATRPES",
            "e": [
              ",PASTE",
              ",SPARE",
              ",SPATE",
              ",SPEAR",
              ",STARE",
              ",STRAP",
              ",STREP",
              ",TAPER"
            ]
          },
          "level_011": {
            "a": 676953,
            "b": "SHOYW",
            "e": [
              ",HOW",
              ",SHY",
              ",SOW",
              ",SOY",
              ",WHO",
              ",WHY",
              ",SHOW",
              ",SHOWY"
            ]
          },
          "level_012": {
            "a": 676961,
            "b": "DRESSEN",
            "e": [
              ",DENSE",
              ",DRESS",
              ",SENSE",
              ",SNEER",
              ",DENSER",
              ",SENDER",
              ",SENSED",
              ",REDNESS"
            ]
          },
          "level_013": {
            "a": 676948,
            "b": "ARWNB",
            "e": [
              ",BAN",
              ",BAR",
              ",BRA",
              ",NAB",
              ",NAW",
              ",RAN",
              ",RAW",
              ",WAR",
              ",BARN",
              ",BRAN",
              ",WARN"
            ]
          },
          "level_014": {
            "a": 676951,
            "b": "DMRUMER",
            "e": [
              ",DUE",
              ",EMU",
              ",ERR",
              ",MUD",
              ",MUM",
              ",RED",
              ",REM",
              ",RUE",
              ",RUM",
              ",UMM",
              ",DRUM",
              ",RUDE"
            ]
          },
          "level_015": {
            "a": 676949,
            "b": "ALLYAHW",
            "e": [
              ",ALLY",
              "B,AWAY",
              ",HALL",
              ",WALL"
            ]
          },
          "level_016": {
            "a": 676956,
            "b": "REBHTEY",
            "e": [
              ",BERET",
              ",BERTH",
              ",ETHER",
              ",THERE",
              ",THREE",
              ",THEREBY"
            ]
          },
          "level_017": {
            "a": 676955,
            "b": "CMEIND",
            "e": [
              ",DICE",
              "B,DIME",
              ",DINE",
              ",ICED",
              ",MEND",
              ",MICE",
              ",MIND",
              ",MINE",
              ",NICE"
            ]
          },
          "level_018": {
            "a": 676965,
            "b": "YSLREMI",
            "e": [
              ",SLIME",
              "B,SLIMY",
              ",SMILE",
              ",MISERY"
            ]
          },
          "level_019": {
            "a": 676946,
            "b": "HSIGT",
            "e": [
              ",GIT",
              ",HIS",
              ",HIT",
              ",ITS",
              ",SIT",
              ",TIS",
              ",GIST",
              ",SIGH",
              ",THIS"
            ]
          },
          "level_020": {
            "a": 676958,
            "b": "OEECCDR",
            "e": [
              ",CODER",
              ",CORED",
              ",CREDO",
              ",CREED",
              ",DECOR",
              ",ERODE",
              ",COERCED"
            ]
          }
        },
        "m": 7733248,
        "o": 7391488,
        "r": 7733248,
        "t": 0.65,
        "v": 13565952,
        "x": 268435455,
        "y": 0.65
      },
      "set_5": {
        "a": "BE",
        "aa": 12517376,
        "cc": 268435455,
        "d": "bg_hills5.jpg",
        "dd": 12517376,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 12517376,
        "k": 268435455,
        "l": 12517376,
        "levels": {
          "level_001": {
            "a": 677256,
            "b": "PMECHIA",
            "e": [
              ",CHAMP",
              "B,CHEAP",
              ",CHIME",
              ",CHIMP",
              ",PEACH"
            ]
          },
          "level_002": {
            "a": 677259,
            "b": "OCDEED",
            "e": [
              ",COD",
              ",DOC",
              ",DOE",
              ",ODD",
              ",ODE",
              ",CEDE",
              "B,CODE",
              ",COED",
              ",DEED"
            ]
          },
          "level_003": {
            "a": 677257,
            "b": "LAYELRG",
            "e": [
              ",ALLEY",
              ",EARLY",
              ",GLARE",
              ",LAGER",
              ",LARGE",
              ",LAYER",
              ",LEGAL",
              ",RALLY",
              ",REGAL",
              ",RELAY",
              ",GALLEY",
              ",REALLY"
            ]
          },
          "level_004": {
            "a": 677264,
            "b": "VRLIEE",
            "e": [
              ",EVER",
              ",EVIL",
              ",LEER",
              ",LIVE",
              ",REEL",
              ",RILE",
              ",VEER",
              ",VEIL",
              ",VILE"
            ]
          },
          "level_005": {
            "a": 677267,
            "b": "SOCALLU",
            "e": [
              ",ALSO",
              ",CALL",
              ",COAL",
              ",COLA",
              ",CULL",
              ",SOUL",
              ",LOCAL",
              ",LOCUS"
            ]
          },
          "level_006": {
            "a": 677258,
            "b": "IUSBBRH",
            "e": [
              ",BUSH",
              ",RUSH",
              ",HUBRIS",
              ",RUBBISH"
            ]
          },
          "level_007": {
            "a": 677252,
            "b": "EPARPAL",
            "e": [
              ",APPLE",
              ",PALER",
              ",PAPAL",
              ",PAPER",
              ",PEARL",
              ",APPEAL",
              ",APPEAR",
              ",APPAREL"
            ]
          },
          "level_008": {
            "a": 677268,
            "b": "OSUTUHT",
            "e": [
              ",HOT",
              ",HUT",
              ",OUT",
              ",TOT",
              ",SHOUT",
              ",SOUTH",
              ",STOUT",
              ",SHUTOUT"
            ]
          },
          "level_009": {
            "a": 677251,
            "b": "RENDIV",
            "e": [
              ",DINER",
              ",DIVER",
              ",DRIVE",
              ",DRIVEN"
            ]
          },
          "level_010": {
            "a": 677254,
            "b": "WKELAY",
            "e": [
              ",KALE",
              ",LAKE",
              ",LEAK",
              ",WAKE",
              ",WALK",
              ",WEAK",
              ",LEAKY",
              ",WEAKLY"
            ]
          },
          "level_011": {
            "a": 677253,
            "b": "XTENAT",
            "e": [
              ",ANT",
              "B,ATE",
              ",AXE",
              ",EAT",
              ",NET",
              ",TAN",
              ",TAX",
              ",TEA",
              ",TEN",
              ",EXTANT"
            ]
          },
          "level_012": {
            "a": 677263,
            "b": "TUEODSI",
            "e": [
              ",SITED",
              ",SUITE",
              ",DUTIES",
              ",OUSTED",
              ",STUDIO",
              ",SUITED",
              ",OUTSIDE",
              "B,TEDIOUS"
            ]
          },
          "level_013": {
            "a": 677266,
            "b": "BYAEB",
            "e": [
              ",AYE",
              ",BAY",
              ",BYE",
              ",EBB",
              ",YEA",
              ",BABE",
              "B,BABY",
              ",ABBEY"
            ]
          },
          "level_014": {
            "a": 677260,
            "b": "MEROBDO",
            "e": [
              ",BORED",
              ",BROOD",
              ",BROOM",
              ",RODEO",
              ",BOOMED",
              ",BOOMER",
              ",MOORED",
              ",BEDROOM",
              ",BOREDOM"
            ]
          },
          "level_015": {
            "a": 677262,
            "b": "ELGBO",
            "e": [
              ",BLOG",
              ",GLOB",
              ",LOBE",
              ",GLOBE"
            ]
          },
          "level_016": {
            "a": 677269,
            "b": "FRGULA",
            "e": [
              ",FAR",
              ",FLU",
              ",FUR",
              ",GAL",
              ",LAG",
              ",LUG",
              ",RAG",
              ",RUG",
              ",FLAG",
              "B,GULF",
              ",FRUGAL"
            ]
          },
          "level_017": {
            "a": 677255,
            "b": "TEYVNSE",
            "e": [
              ",ENVY",
              ",EVEN",
              ",NEST",
              ",SEEN",
              ",SENT",
              ",TEEN",
              ",VENT",
              ",VEST",
              ",SEVENTY"
            ]
          },
          "level_018": {
            "a": 677250,
            "b": "PLUTPI",
            "e": [
              ",LIP",
              ",LIT",
              ",PIT",
              ",PUP",
              ",PUT",
              ",TIL",
              ",TIP",
              ",PULP",
              ",PUPIL",
              ",TULIP"
            ]
          },
          "level_019": {
            "a": 677261,
            "b": "EYTHM",
            "e": [
              ",HEM",
              ",HEY",
              ",MET",
              ",THE",
              ",THY",
              ",YET",
              ",MYTH",
              ",THEM",
              ",THEY"
            ]
          },
          "level_020": {
            "a": 677265,
            "b": "OTUQRE",
            "e": [
              ",EURO",
              ",ROTE",
              ",ROUT",
              ",TORE",
              ",TOUR",
              ",TRUE",
              ",OUTER",
              ",QUOTE",
              ",ROUTE",
              ",TORQUE"
            ]
          }
        },
        "m": 7733248,
        "o": 16462080,
        "r": 7733248,
        "t": 0.75,
        "v": 12517376,
        "x": 268435455,
        "y": 0.75
      }
    }
  },
  "WS 07": {
    "a": "TWILIGHT",
    "b": "grad_white",
    "c": "grp_timber",
    "d": 0.75,
    "e": 5586657,
    "f": 8126683,
    "sets": {
      "set_1": {
        "a": "MOIST",
        "aa": 5586657,
        "d": "bg_twilight1.jpg",
        "dd": 5586657,
        "e": 0.1,
        "j": 5586657,
        "l": 5586657,
        "levels": {
          "level_001": {
            "a": 677442,
            "b": "YTIFSE",
            "e": [
              ",FIST",
              ",SIFT",
              ",SITE",
              ",FEISTY"
            ]
          },
          "level_002": {
            "a": 677438,
            "b": "RNDEUED",
            "e": [
              ",DEN",
              ",DUD",
              ",DUE",
              ",DUN",
              ",END",
              ",RED",
              ",RUE",
              ",RUN",
              ",URN",
              ",ENDURED"
            ]
          },
          "level_003": {
            "a": 677430,
            "b": "TWASH",
            "e": [
              ",ASH",
              "B,HAS",
              ",HAT",
              ",SAT",
              ",SAW",
              ",WAS",
              ",SWATH"
            ]
          },
          "level_004": {
            "a": 677431,
            "b": "ROSEEEV",
            "e": [
              ",SERVE",
              ",SERVO",
              ",SEVER",
              ",VERSE"
            ]
          },
          "level_005": {
            "a": 677443,
            "b": "CIXTSOE",
            "e": [
              ",COT",
              "B,ICE",
              ",ITS",
              ",SET",
              ",SEX",
              ",SIT",
              ",SIX",
              ",TIC",
              ",TIE",
              ",TIS",
              ",TOE",
              ",EXOTIC"
            ]
          },
          "level_006": {
            "a": 677428,
            "b": "RUEGA",
            "e": [
              ",GEAR",
              ",RAGE",
              ",URGE",
              ",ARGUE",
              ",AUGER"
            ]
          },
          "level_007": {
            "a": 677436,
            "b": "NAKTS",
            "e": [
              ",SANK",
              ",TANK",
              ",TASK",
              ",STANK"
            ]
          },
          "level_008": {
            "a": 677441,
            "b": "MPUAKR",
            "e": [
              ",AMP",
              ",ARK",
              ",ARM",
              ",MAP",
              ",MAR",
              ",PAR",
              ",RAM",
              ",RAP",
              ",RUM",
              ",MARKUP"
            ]
          },
          "level_009": {
            "a": 677435,
            "b": "YTSFOL",
            "e": [
              ",FLY",
              ",LOT",
              ",OFT",
              ",SLY",
              ",SOY",
              ",TOY",
              ",LOFT",
              ",LOST",
              ",SLOT",
              ",SOFT",
              ",LOFTY",
              ",SOFTLY"
            ]
          },
          "level_010": {
            "a": 677439,
            "b": "LEYDPE",
            "e": [
              ",DEEP",
              ",EYED",
              ",PEEL",
              ",PLED",
              ",YELP"
            ]
          },
          "level_011": {
            "a": 677437,
            "b": "EARSC",
            "e": [
              ",ACE",
              "B,ARC",
              ",ARE",
              ",CAR",
              ",EAR",
              ",ERA",
              ",SAC",
              ",SEA",
              ",SCARE"
            ]
          },
          "level_012": {
            "a": 677434,
            "b": "TUTSREE",
            "e": [
              ",RESET",
              ",REUSE",
              ",STEER",
              ",STRUT",
              ",TERSE",
              ",TRUST",
              ",SETTER",
              ",STREET",
              ",TESTER",
              ",TRUEST"
            ]
          },
          "level_013": {
            "a": 677440,
            "b": "ADRAEC",
            "e": [
              ",ACRE",
              "B,AREA",
              ",CARD",
              ",CARE",
              ",DARE",
              ",DEAR",
              ",RACE",
              ",READ"
            ]
          },
          "level_014": {
            "a": 677429,
            "b": "IOBDUSU",
            "e": [
              ",BID",
              ",BIO",
              ",BOD",
              ",BUD",
              ",BUS",
              ",DUB",
              ",DUO",
              ",SOB",
              ",SOD",
              ",SUB",
              ",DUBIOUS"
            ]
          },
          "level_015": {
            "a": 677425,
            "b": "ABEANSM",
            "e": [
              ",AMEN",
              ",BANE",
              ",BASE",
              ",BEAM",
              ",BEAN",
              ",MANE",
              ",MEAN",
              ",MESA",
              ",NAME",
              ",SAME",
              ",SANE",
              ",SEAM"
            ]
          },
          "level_016": {
            "a": 677432,
            "b": "NARUETD",
            "e": [
              ",RATED",
              ",TRADE",
              ",TREAD",
              ",TREND",
              ",TUNED",
              ",TUNER",
              ",UNDER",
              ",ARDENT",
              ",NATURE",
              ",RANTED",
              ",TUNDRA",
              ",TURNED"
            ]
          },
          "level_017": {
            "a": 677426,
            "b": "WSPIY",
            "e": [
              ",SIP",
              ",SPY",
              ",WISP",
              ",WISPY"
            ]
          },
          "level_018": {
            "a": 677424,
            "b": "AYPVRCI",
            "e": [
              ",AIRY",
              ",CARP",
              ",PAIR",
              ",PRAY",
              ",RACY",
              ",VARY",
              ",PRIVY",
              ",PRIVACY"
            ]
          },
          "level_019": {
            "a": 677433,
            "b": "YSOLSG",
            "e": [
              ",LOSS",
              "B,SLOG",
              ",GLOSS",
              ",GLOSSY"
            ]
          },
          "level_020": {
            "a": 677427,
            "b": "KSCATBE",
            "e": [
              ",BASTE",
              ",BEAST",
              ",CASTE",
              ",SKATE",
              ",STACK",
              ",STAKE",
              ",STEAK",
              ",BASKET",
              "B,CASKET",
              ",SETBACK"
            ]
          }
        },
        "m": 3090059,
        "o": 50527,
        "r": 3090059,
        "t": 0.7000000000000001,
        "v": 5586657,
        "y": 0.7000000000000001
      },
      "set_2": {
        "a": "WARM",
        "aa": 6172383,
        "d": "bg_twilight2.jpg",
        "dd": 6172383,
        "e": 0.1,
        "j": 6172383,
        "l": 6172383,
        "levels": {
          "level_001": {
            "a": 677672,
            "b": "ASUITH",
            "e": [
              ",SHUT",
              "B,SUIT",
              ",THIS",
              ",THUS",
              ",HIATUS"
            ]
          },
          "level_002": {
            "a": 677677,
            "b": "EQUYILT",
            "e": [
              ",LITE",
              ",LUTE",
              ",QUIT",
              ",TILE",
              ",QUIET",
              ",QUILT",
              ",QUITE",
              ",EQUITY"
            ]
          },
          "level_003": {
            "a": 677682,
            "b": "UATNT",
            "e": [
              ",AUNT",
              "B,TAUT",
              ",TUNA",
              ",TAUNT"
            ]
          },
          "level_004": {
            "a": 677683,
            "b": "HBMAECR",
            "e": [
              ",AMBER",
              ",BEACH",
              ",BRACE",
              ",CHARM",
              ",CREAM",
              ",HAREM",
              ",MARCH",
              ",REACH",
              ",REHAB",
              ",CHAMBER"
            ]
          },
          "level_005": {
            "a": 677675,
            "b": "PLOW",
            "e": [
              ",LOW",
              "B,OWL",
              ",POW",
              ",PLOW"
            ]
          },
          "level_006": {
            "a": 677674,
            "b": "LCSADAN",
            "e": [
              ",CLAD",
              ",CLAN",
              ",LAND",
              ",SAND",
              ",SCAN",
              ",CANAL",
              ",NASAL",
              ",SALAD",
              ",SANDAL",
              ",SCANDAL"
            ]
          },
          "level_007": {
            "a": 677673,
            "b": "FETTRI",
            "e": [
              ",FIRE",
              ",FRET",
              ",RIFE",
              ",RIFT",
              ",RITE",
              ",TIER",
              ",TIRE"
            ]
          },
          "level_008": {
            "a": 677685,
            "b": "REINTE",
            "e": [
              ",ENTER",
              "B,INERT",
              ",INTER",
              ",ENTIRE"
            ]
          },
          "level_009": {
            "a": 677669,
            "b": "NGEVRAE",
            "e": [
              ",AGREE",
              "B,ANGER",
              ",EAGER",
              ",GENRE",
              ",GRAVE",
              ",GREEN",
              ",NERVE",
              ",NEVER",
              ",RANGE",
              ",RAVEN",
              ",VEGAN",
              ",VERGE"
            ]
          },
          "level_010": {
            "a": 677679,
            "b": "MOALRLY",
            "e": [
              ",ALLY",
              "B,ARMY",
              ",LOAM",
              ",MALL",
              ",ORAL",
              ",ROAM",
              ",ROLL",
              ",ORALLY",
              ",MORALLY"
            ]
          },
          "level_011": {
            "a": 677667,
            "b": "MNEROEF",
            "e": [
              ",FERN",
              ",FORE",
              ",FORM",
              ",FREE",
              ",FROM",
              ",MERE",
              ",MORE",
              ",NORM",
              ",OMEN",
              ",REEF"
            ]
          },
          "level_012": {
            "a": 677681,
            "b": "LNVYAI",
            "e": [
              ",AIL",
              ",ANY",
              ",IVY",
              ",LAY",
              ",NAY",
              ",NIL",
              ",VAN",
              ",VIA",
              ",YIN",
              ",VAINLY"
            ]
          },
          "level_013": {
            "a": 677668,
            "b": "HYTTLGI",
            "e": [
              ",GILT",
              ",HILT",
              ",TILT",
              ",LIGHT",
              ",TIGHT"
            ]
          },
          "level_014": {
            "a": 677666,
            "b": "NEFILE",
            "e": [
              ",FEEL",
              ",FILE",
              ",FINE",
              ",FLEE",
              ",LIEN",
              ",LIFE",
              ",LINE",
              ",FELINE"
            ]
          },
          "level_015": {
            "a": 677671,
            "b": "RLEHSI",
            "e": [
              ",HER",
              ",HIS",
              ",IRE",
              ",LIE",
              ",SHE",
              ",SIR",
              ",HEIR",
              ",HIRE",
              ",ISLE",
              ",RILE",
              ",RISE",
              ",SIRE"
            ]
          },
          "level_016": {
            "a": 677680,
            "b": "REHAILN",
            "e": [
              ",ALIEN",
              ",LEARN",
              ",LINER",
              ",RENAL",
              ",HERNIA",
              ",INHALE",
              ",LINEAR",
              ",INHALER"
            ]
          },
          "level_017": {
            "a": 677670,
            "b": "TBOMOT",
            "e": [
              ",BOOM",
              ",BOOT",
              ",MOOT",
              ",TOMB",
              ",BOTTOM"
            ]
          },
          "level_018": {
            "a": 677676,
            "b": "SPOEER",
            "e": [
              ",OPS",
              ",ORE",
              ",PER",
              ",PRO",
              ",REP",
              ",SEE",
              ",SOP",
              ",REPOSE"
            ]
          },
          "level_019": {
            "a": 677678,
            "b": "VOPELED",
            "e": [
              ",DOE",
              ",EEL",
              ",EVE",
              ",LED",
              ",ODE",
              ",OLD",
              ",POD",
              ",DEVELOP"
            ]
          },
          "level_020": {
            "a": 677684,
            "b": "HHCAEET",
            "e": [
              ",ACHE",
              ",CHAT",
              ",EACH",
              ",ETCH",
              ",HATE",
              ",HEAT",
              ",TECH",
              ",THEE",
              ",CHEAT",
              ",HATCH",
              ",TEACH"
            ]
          }
        },
        "m": 3090061,
        "o": 13434986,
        "r": 3090061,
        "t": 0.8,
        "v": 6172383,
        "y": 0.75
      },
      "set_3": {
        "a": "LOVE",
        "aa": 6823902,
        "d": "bg_twilight3.jpg",
        "dd": 6823902,
        "e": 0.1,
        "j": 6823902,
        "l": 6823902,
        "levels": {
          "level_001": {
            "a": 677865,
            "b": "NDGEEAG",
            "e": [
              ",AGED",
              "B,DEAN",
              ",EDGE",
              ",GANG",
              ",GENE",
              ",NEED"
            ]
          },
          "level_002": {
            "a": 677878,
            "b": "LHSWA",
            "e": [
              ",ASH",
              ",HAS",
              ",LAW",
              ",SAW",
              ",WAS",
              ",LASH",
              "B,SLAW",
              ",WASH"
            ]
          },
          "level_003": {
            "a": 677870,
            "b": "EEHALXD",
            "e": [
              ",HEXED",
              ",EXHALE",
              ",HEALED",
              ",EXHALED"
            ]
          },
          "level_004": {
            "a": 677881,
            "b": "RSTERAT",
            "e": [
              ",ARREST",
              ",RAREST",
              ",RESTART",
              "B,STARTER"
            ]
          },
          "level_005": {
            "a": 677872,
            "b": "TRAREET",
            "e": [
              ",RARE",
              ",RATE",
              ",REAR",
              ",TART",
              ",TEAR",
              ",TREE"
            ]
          },
          "level_006": {
            "a": 677876,
            "b": "TCHOUY",
            "e": [
              ",COT",
              ",COY",
              ",CUT",
              ",HOT",
              ",HUT",
              ",OUT",
              ",THY",
              ",TOY",
              ",YOU",
              ",TOUCH",
              ",YOUTH"
            ]
          },
          "level_007": {
            "a": 677874,
            "b": "NPTI",
            "e": [
              ",NIP",
              ",NIT",
              ",PIN",
              ",PIT",
              ",TIN",
              ",TIP",
              ",PINT"
            ]
          },
          "level_008": {
            "a": 677880,
            "b": "TFIFAR",
            "e": [
              ",AFT",
              ",AIR",
              ",ART",
              ",FAR",
              ",FAT",
              ",FIR",
              ",FIT",
              ",RAT",
              ",TAR",
              ",TARIFF"
            ]
          },
          "level_009": {
            "a": 677863,
            "b": "MLBALNE",
            "e": [
              ",ALE",
              ",ALL",
              ",BAM",
              ",BAN",
              ",ELM",
              ",LAB",
              ",LAM",
              ",MAN",
              ",MEN",
              ",NAB",
              ",BLAME",
              ",LABEL"
            ]
          },
          "level_010": {
            "a": 677877,
            "b": "NNTSEIE",
            "e": [
              ",NEST",
              ",NINE",
              ",SEEN",
              ",SENT",
              ",SINE",
              ",SITE",
              ",TEEN",
              ",TENNIS"
            ]
          },
          "level_011": {
            "a": 677867,
            "b": "TXEATRC",
            "e": [
              ",CATER",
              ",CRATE",
              ",EXACT",
              ",EXTRA",
              ",REACT",
              ",TAXER",
              ",TRACE",
              ",TRACT",
              ",TREAT"
            ]
          },
          "level_012": {
            "a": 677871,
            "b": "NISCREE",
            "e": [
              ",CRIES",
              "B,NICER",
              ",NIECE",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SCENE",
              ",SCREE",
              ",SINCE",
              ",SIREN",
              ",SNEER",
              ",SCREEN"
            ]
          },
          "level_013": {
            "a": 677862,
            "b": "FCINOF",
            "e": [
              ",CON",
              ",FIN",
              ",ION",
              ",OFF",
              ",COIN",
              ",ICON",
              ",INFO",
              ",COFFIN"
            ]
          },
          "level_014": {
            "a": 677875,
            "b": "FNTO",
            "e": [
              ",NOT",
              "B,OFT",
              ",TON",
              ",FONT"
            ]
          },
          "level_015": {
            "a": 677866,
            "b": "MELAC",
            "e": [
              ",CALM",
              ",CAME",
              ",CLAM",
              ",LACE",
              ",LAME",
              ",MACE",
              ",MALE",
              ",MEAL"
            ]
          },
          "level_016": {
            "a": 677869,
            "b": "UCEPTA",
            "e": [
              ",CAPE",
              ",CUTE",
              ",PACE",
              ",PACT",
              ",PATE",
              ",PEAT",
              ",TAPE",
              ",TEACUP"
            ]
          },
          "level_017": {
            "a": 677864,
            "b": "AOUURDS",
            "e": [
              ",DOUR",
              ",ROAD",
              ",SOAR",
              ",SODA",
              ",SOUR"
            ]
          },
          "level_018": {
            "a": 677873,
            "b": "IDILPEM",
            "e": [
              ",DELI",
              ",DIME",
              ",IDLE",
              ",LIED",
              ",LIME",
              ",LIMP",
              ",MELD",
              ",MILD",
              ",MILE",
              ",PILE",
              ",PLED"
            ]
          },
          "level_019": {
            "a": 677868,
            "b": "MCIYST",
            "e": [
              ",ICY",
              ",ITS",
              ",SIM",
              ",SIT",
              ",TIC",
              ",TIS",
              ",CITY",
              "B,CYST",
              ",MIST"
            ]
          },
          "level_020": {
            "a": 677879,
            "b": "DINEED",
            "e": [
              ",DEN",
              ",DID",
              ",DIN",
              ",END",
              ",DINED",
              ",ENDED",
              ",DENIED",
              ",INDEED"
            ]
          }
        },
        "m": 3801748,
        "o": 16753152,
        "r": 3801748,
        "t": 0.8,
        "v": 6823902,
        "y": 0.8
      },
      "set_4": {
        "a": "LONE",
        "aa": 7475164,
        "d": "bg_twilight4.jpg",
        "dd": 7475164,
        "e": 0.1,
        "j": 7475164,
        "l": 7475164,
        "levels": {
          "level_001": {
            "a": 678093,
            "b": "IFLAR",
            "e": [
              ",FAIL",
              ",FAIR",
              ",LAIR",
              ",LIAR",
              ",RAIL",
              ",FLAIR",
              "B,FRAIL"
            ]
          },
          "level_002": {
            "a": 678095,
            "b": "EELDUG",
            "e": [
              ",ELUDE",
              ",GLUED",
              ",LEDGE",
              ",DELUGE"
            ]
          },
          "level_003": {
            "a": 678099,
            "b": "CRSOMAA",
            "e": [
              ",ARC",
              ",ARM",
              ",CAM",
              ",CAR",
              ",MAR",
              ",OAR",
              ",RAM",
              ",SAC",
              ",AROMA",
              ",MACRO"
            ]
          },
          "level_004": {
            "a": 678089,
            "b": "RPGSNIY",
            "e": [
              ",GRIN",
              ",GRIP",
              ",PING",
              ",RING",
              ",SIGN",
              ",SING",
              ",SNIP",
              ",SPIN",
              ",SPRY",
              ",SPRINGY"
            ]
          },
          "level_005": {
            "a": 678101,
            "b": "KUSCT",
            "e": [
              ",SUCK",
              ",TUCK",
              ",TUSK",
              ",STUCK"
            ]
          },
          "level_006": {
            "a": 678100,
            "b": "SBIOLBE",
            "e": [
              ",BILE",
              "B,BLOB",
              ",BOIL",
              ",ISLE",
              ",LOBE",
              ",LOSE",
              ",SILO",
              ",SLOB",
              ",SOIL",
              ",SOLE"
            ]
          },
          "level_007": {
            "a": 678084,
            "b": "ALCRPEP",
            "e": [
              ",APPLE",
              ",CAPER",
              ",CLEAR",
              ",PALER",
              ",PAPER",
              ",PEARL",
              ",PLACE",
              ",RECAP",
              ",PARCEL"
            ]
          },
          "level_008": {
            "a": 678088,
            "b": "EBAONDM",
            "e": [
              ",ABODE",
              ",ADOBE",
              ",AMEND",
              ",BONED",
              ",DEMON",
              ",NAMED",
              ",NOMAD",
              ",MOANED"
            ]
          },
          "level_009": {
            "a": 678085,
            "b": "FTLYNI",
            "e": [
              ",LIFT",
              ",LINT",
              ",TINY",
              ",FLINT",
              ",NIFTY"
            ]
          },
          "level_010": {
            "a": 678096,
            "b": "EEUKBR",
            "e": [
              ",BEE",
              ",EEK",
              ",EKE",
              ",RUB",
              ",RUE",
              ",BEER",
              ",REEK",
              ",REBUKE"
            ]
          },
          "level_011": {
            "a": 678086,
            "b": "BULENLP",
            "e": [
              ",BUN",
              ",NUB",
              ",PEN",
              ",PUB",
              ",PUN",
              ",BELL",
              ",BLUE",
              ",BULL",
              ",LUBE",
              ",NULL",
              ",PULL"
            ]
          },
          "level_012": {
            "a": 678103,
            "b": "TORBELU",
            "e": [
              ",BLURT",
              "B,BRUTE",
              ",OUTER",
              ",ROUTE",
              ",RUBLE",
              ",TUBER",
              ",TURBO",
              ",BUTLER"
            ]
          },
          "level_013": {
            "a": 678094,
            "b": "ONRTE",
            "e": [
              ",NOTE",
              ",RENT",
              ",ROTE",
              ",TERN",
              ",TONE",
              ",TORE",
              ",TORN",
              ",TENOR",
              ",TONER"
            ]
          },
          "level_014": {
            "a": 678102,
            "b": "NEIRDF",
            "e": [
              ",DINER",
              ",FIEND",
              ",FINED",
              ",FINER",
              ",FIRED",
              ",FRIED",
              ",INFER",
              ",FINDER",
              ",FRIEND"
            ]
          },
          "level_015": {
            "a": 678092,
            "b": "RUOICER",
            "e": [
              ",CORE",
              ",CURE",
              ",EURO",
              ",RICE",
              ",COURIER"
            ]
          },
          "level_016": {
            "a": 678090,
            "b": "LOVSEBA",
            "e": [
              ",ABOVE",
              "B,BLASE",
              ",SABLE",
              ",SALVE",
              ",SALVO",
              ",SOLVE",
              ",LOAVES",
              ",ABSOLVE"
            ]
          },
          "level_017": {
            "a": 678097,
            "b": "NTIRBAV",
            "e": [
              ",ANTI",
              "B,BAIT",
              ",BARN",
              ",BRAN",
              ",BRAT",
              ",RAIN",
              ",RANT",
              ",VAIN",
              ",VIBRANT"
            ]
          },
          "level_018": {
            "a": 678098,
            "b": "EIETCRH",
            "e": [
              ",CHEER",
              ",ERECT",
              ",ETHER",
              ",ETHIC",
              ",THEIR",
              ",THERE",
              ",THREE",
              ",HERETIC"
            ]
          },
          "level_019": {
            "a": 678087,
            "b": "ADEZLZ",
            "e": [
              ",DAZE",
              "B,DEAL",
              ",LEAD",
              ",ZEAL",
              ",DAZZLE"
            ]
          },
          "level_020": {
            "a": 678091,
            "b": "LEATTSH",
            "e": [
              ",HASTE",
              ",LATHE",
              ",LATTE",
              ",LEASH",
              ",LEAST",
              ",SHALE",
              ",SLATE",
              ",STALE",
              ",STATE",
              ",STEAL",
              ",TASTE",
              ",THETA"
            ]
          }
        },
        "m": 3801748,
        "o": 47103,
        "r": 3801748,
        "t": 0.65,
        "v": 7475164,
        "y": 0.65
      },
      "set_5": {
        "a": "ONE",
        "aa": 8126683,
        "d": "bg_twilight5.jpg",
        "dd": 8126683,
        "e": 0.1,
        "j": 8126683,
        "l": 8126683,
        "levels": {
          "level_001": {
            "a": 678288,
            "b": "EGRATAT",
            "e": [
              ",AREA",
              ",GATE",
              ",GEAR",
              ",RAGE",
              ",RATE",
              ",TART",
              ",TEAR",
              ",GRATE",
              ",GREAT",
              ",TREAT"
            ]
          },
          "level_002": {
            "a": 678294,
            "b": "REMNGEA",
            "e": [
              ",AGREE",
              ",ANGER",
              ",EAGER",
              ",GAMER",
              ",GENRE",
              ",GREEN",
              ",MERGE",
              ",RANGE"
            ]
          },
          "level_003": {
            "a": 678279,
            "b": "RHDAE",
            "e": [
              ",DARE",
              "B,DEAR",
              ",HARD",
              ",HARE",
              ",HEAD",
              ",HEAR",
              ",HERD",
              ",READ"
            ]
          },
          "level_004": {
            "a": 678289,
            "b": "VEIVDRE",
            "e": [
              ",DEER",
              ",DIRE",
              ",DIVE",
              ",EVER",
              ",REED",
              ",RIDE",
              ",VEER",
              ",VIED",
              ",DERIVE",
              "B,REVIVE",
              ",REVVED",
              ",REVIVED"
            ]
          },
          "level_005": {
            "a": 678284,
            "b": "YTRID",
            "e": [
              ",DRY",
              ",RID",
              ",TRY",
              ",DIRTY"
            ]
          },
          "level_006": {
            "a": 678292,
            "b": "LGAONA",
            "e": [
              ",AGO",
              ",GAL",
              ",LAG",
              ",LOG",
              ",NAG",
              ",ALONG",
              "B,ANGLO"
            ]
          },
          "level_007": {
            "a": 678285,
            "b": "HYSAFL",
            "e": [
              ",ASH",
              "B,FLY",
              ",HAS",
              ",HAY",
              ",LAY",
              ",SAY",
              ",SHY",
              ",SLY",
              ",FLASHY"
            ]
          },
          "level_008": {
            "a": 678278,
            "b": "ATNGINE",
            "e": [
              ",AGENT",
              ",GIANT",
              ",INANE",
              ",TINGE",
              ",EATING",
              ",INNATE",
              ",ANTIGEN"
            ]
          },
          "level_009": {
            "a": 678290,
            "b": "TUDSIPE",
            "e": [
              ",DUTIES",
              ",SUITED",
              ",UPSIDE",
              ",DISPUTE"
            ]
          },
          "level_010": {
            "a": 678295,
            "b": "RGUEYSR",
            "e": [
              ",GREY",
              ",RUSE",
              ",SURE",
              ",URGE",
              ",USER",
              ",SURER",
              "B,SURGE",
              ",SURGERY"
            ]
          },
          "level_011": {
            "a": 678286,
            "b": "THTUGOH",
            "e": [
              ",GOT",
              ",GUT",
              ",HOG",
              ",HOT",
              ",HUG",
              ",HUH",
              ",HUT",
              ",OUT",
              ",TOT",
              ",TUG",
              ",UGH",
              ",THOUGHT"
            ]
          },
          "level_012": {
            "a": 678276,
            "b": "SUPARL",
            "e": [
              ",LAP",
              ",PAL",
              ",PAR",
              ",PUS",
              ",RAP",
              ",SAP",
              ",SPA",
              ",SUP",
              ",UPS",
              ",PULSAR"
            ]
          },
          "level_013": {
            "a": 678282,
            "b": "RQUEALR",
            "e": [
              ",EARL",
              ",LURE",
              ",RARE",
              ",REAL",
              ",REAR",
              ",RULE",
              ",EQUAL",
              "B,RULER",
              ",RURAL"
            ]
          },
          "level_014": {
            "a": 678291,
            "b": "XBETIHI",
            "e": [
              ",BET",
              ",BIT",
              ",HEX",
              ",HIT",
              ",THE",
              ",TIE",
              ",BITE",
              ",EXIT",
              ",EXHIBIT"
            ]
          },
          "level_015": {
            "a": 678287,
            "b": "ADVI",
            "e": [
              ",AID",
              ",VIA",
              ",AVID",
              ",DIVA"
            ]
          },
          "level_016": {
            "a": 678277,
            "b": "PIETRS",
            "e": [
              ",SPIRE",
              ",SPITE",
              ",STREP",
              ",STRIP",
              ",TRIES",
              ",PRIEST",
              ",SPRITE",
              ",STRIPE"
            ]
          },
          "level_017": {
            "a": 678283,
            "b": "EAEDHR",
            "e": [
              ",ARE",
              ",EAR",
              ",ERA",
              ",HAD",
              ",HER",
              ",RAD",
              ",RED",
              ",HEARD"
            ]
          },
          "level_018": {
            "a": 678281,
            "b": "SESRPWO",
            "e": [
              ",POSSE",
              ",POWER",
              ",PRESS",
              ",PROSE",
              ",SPORE",
              ",SWORE",
              ",WORSE",
              ",PROWESS"
            ]
          },
          "level_019": {
            "a": 678280,
            "b": "CLKLHOI",
            "e": [
              ",COIL",
              ",HICK",
              ",HILL",
              ",HOCK",
              ",KILL",
              ",LICK",
              ",LOCK"
            ]
          },
          "level_020": {
            "a": 678293,
            "b": "NGORUD",
            "e": [
              ",DOUR",
              ",DRUG",
              ",DUNG",
              ",RUNG",
              ",UNDO",
              ",GOURD",
              ",ROUND",
              ",GROUND"
            ]
          }
        },
        "m": 5308557,
        "o": 16738922,
        "r": 5308557,
        "t": 0.7000000000000001,
        "v": 8126683,
        "y": 0.7000000000000001
      }
    }
  },
  "WS 08": {
    "a": "FROST",
    "b": "grad_white",
    "c": "grp_frost",
    "d": 0.75,
    "e": 41193,
    "f": 4151011,
    "sets": {
      "set_1": {
        "a": "WHITE",
        "aa": 41193,
        "bb": 16777215,
        "d": "bg_frost1.jpg",
        "dd": 41193,
        "e": 0.1,
        "j": 41193,
        "l": 41193,
        "levels": {
          "level_001": {
            "a": 678414,
            "b": "MROTRA",
            "e": [
              ",ARM",
              ",ART",
              ",MAR",
              ",MAT",
              ",OAR",
              ",OAT",
              ",RAM",
              ",RAT",
              ",ROT",
              ",TAR",
              ",ARMOR"
            ]
          },
          "level_002": {
            "a": 678421,
            "b": "ODSVHE",
            "e": [
              ",DOE",
              ",HOE",
              ",ODE",
              ",SHE",
              ",SOD",
              ",HOSED",
              ",SHOVE",
              ",SHOVED"
            ]
          },
          "level_003": {
            "a": 678422,
            "b": "MLMEBU",
            "e": [
              ",BUM",
              ",ELM",
              ",EMU",
              ",MUM",
              ",UMM",
              ",BLUE",
              "B,LUBE",
              ",MULE",
              ",MUMBLE"
            ]
          },
          "level_004": {
            "a": 678407,
            "b": "CUTELT",
            "e": [
              ",CUE",
              ",CUT",
              ",LET",
              ",CLUE",
              ",CULT",
              ",CUTE",
              ",LUTE",
              ",CUTLET"
            ]
          },
          "level_005": {
            "a": 678425,
            "b": "SIEPAR",
            "e": [
              ",PAIR",
              "B,PARE",
              ",PEAR",
              ",PIER",
              ",RASP",
              ",REAP",
              ",RIPE",
              ",RISE",
              ",SEAR",
              ",SIRE",
              ",SPAR"
            ]
          },
          "level_006": {
            "a": 678419,
            "b": "LEOJAUS",
            "e": [
              ",ALOE",
              "B,ALSO",
              ",LOSE",
              ",SALE",
              ",SEAL",
              ",SOLE",
              ",SOUL",
              ",LOUSE"
            ]
          },
          "level_007": {
            "a": 678406,
            "b": "CEAEDD",
            "e": [
              ",ACE",
              ",ADD",
              ",CAD",
              ",DAD",
              ",ACED",
              ",CEDE",
              ",DEAD",
              ",DEED",
              ",DECADE"
            ]
          },
          "level_008": {
            "a": 678416,
            "b": "SHEWITT",
            "e": [
              ",HEIST",
              ",TWIST",
              ",WHITE",
              ",WHITEST"
            ]
          },
          "level_009": {
            "a": 678408,
            "b": "LEMEYD",
            "e": [
              ",DEEM",
              ",EYED",
              ",MELD",
              ",MEDLEY"
            ]
          },
          "level_010": {
            "a": 678417,
            "b": "VGRALE",
            "e": [
              ",GAVEL",
              ",GLARE",
              ",GRAVE",
              ",LAGER",
              ",LARGE",
              ",RAVEL",
              ",REGAL",
              ",GRAVEL"
            ]
          },
          "level_011": {
            "a": 678423,
            "b": "SWTRI",
            "e": [
              ",ITS",
              ",SIR",
              ",SIT",
              ",TIS",
              ",WIT",
              ",STIR",
              ",WRIT",
              ",WRIST"
            ]
          },
          "level_012": {
            "a": 678418,
            "b": "TSYLNAI",
            "e": [
              ",ANTSY",
              ",INLAY",
              ",LAITY",
              ",NASTY",
              ",SAINT",
              ",SALTY",
              ",SATIN",
              ",SILTY",
              ",SLAIN",
              ",SLANT",
              ",SNAIL",
              ",STAIN"
            ]
          },
          "level_013": {
            "a": 678412,
            "b": "IRLVEEE",
            "e": [
              ",EEL",
              ",EVE",
              ",IRE",
              ",LIE",
              ",VIE",
              ",EERIE",
              "B,LEVEE",
              ",LEVER",
              ",LIVER",
              ",REVEL",
              ",RELIEVE"
            ]
          },
          "level_014": {
            "a": 678420,
            "b": "OSNERPA",
            "e": [
              ",PARSON",
              ",PERSON",
              ",REASON",
              ",PERSONA"
            ]
          },
          "level_015": {
            "a": 678409,
            "b": "IDFITEC",
            "e": [
              ",CITE",
              "B,DEFT",
              ",DICE",
              ",DIET",
              ",EDIT",
              ",ICED",
              ",TIDE",
              ",TIED",
              ",DEFICIT"
            ]
          },
          "level_016": {
            "a": 678411,
            "b": "ENLTSUI",
            "e": [
              ",INLET",
              ",INSET",
              ",ISLET",
              ",SUITE",
              ",UNITE",
              ",UNLIT",
              ",UNTIE",
              ",UNTIL"
            ]
          },
          "level_017": {
            "a": 678415,
            "b": "AMEDNE",
            "e": [
              ",AND",
              "B,DAM",
              ",DEN",
              ",END",
              ",MAD",
              ",MAN",
              ",MEN",
              ",DEMEAN"
            ]
          },
          "level_018": {
            "a": 678413,
            "b": "YRLFIEF",
            "e": [
              ",FIERY",
              ",FLIER",
              ",FLYER",
              ",RIFLE",
              ",FIREFLY"
            ]
          },
          "level_019": {
            "a": 678424,
            "b": "RTEDAI",
            "e": [
              ",AIRED",
              ",IRATE",
              ",RATED",
              ",TIRED",
              ",TRADE",
              ",TREAD",
              ",TRIAD",
              ",TRIED"
            ]
          },
          "level_020": {
            "a": 678410,
            "b": "CDAICAR",
            "e": [
              ",ACID",
              ",ARID",
              ",CARD",
              ",RAID",
              ",ACRID",
              ",CIRCA",
              ",CICADA",
              ",CARDIAC"
            ]
          }
        },
        "m": 22957,
        "o": 45048,
        "r": 22957,
        "t": 0.6,
        "u": 0,
        "v": 41193,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      },
      "set_2": {
        "a": "VALLEY",
        "aa": 1019367,
        "bb": 16777215,
        "d": "bg_frost2.jpg",
        "dd": 1019367,
        "e": 0.1,
        "j": 1019367,
        "l": 1019367,
        "levels": {
          "level_001": {
            "a": 678569,
            "b": "LSRRUAE",
            "e": [
              ",LASER",
              ",RULER",
              ",RURAL",
              ",SURER",
              ",SURREAL"
            ]
          },
          "level_002": {
            "a": 678560,
            "b": "EBNNISU",
            "e": [
              ",BIN",
              ",BUN",
              ",BUS",
              ",INN",
              ",NUB",
              ",NUN",
              ",SIN",
              ",SUB",
              ",SUE",
              ",SUN",
              ",USE",
              ",BUNNIES"
            ]
          },
          "level_003": {
            "a": 678563,
            "b": "IGLLOAC",
            "e": [
              ",LILAC",
              ",LOCAL",
              ",LOGIC",
              ",LOGICAL"
            ]
          },
          "level_004": {
            "a": 678568,
            "b": "ACRONYM",
            "e": [
              ",ACORN",
              "B,CORNY",
              ",CRONY",
              ",MACRO",
              ",MANOR",
              ",MAYOR",
              ",MORAY",
              ",RAYON",
              ",ROMAN",
              ",CRAYON",
              ",ACRONYM"
            ]
          },
          "level_005": {
            "a": 678561,
            "b": "VDEARIR",
            "e": [
              ",ARRIVE",
              "B,DRIVER",
              ",RAIDER",
              ",VARIED",
              ",ARRIVED"
            ]
          },
          "level_006": {
            "a": 678557,
            "b": "ETCAATH",
            "e": [
              ",ACHE",
              ",CHAT",
              ",EACH",
              ",ETCH",
              ",HATE",
              ",HEAT",
              ",TACT",
              ",TECH",
              ",THAT",
              ",ATTACH",
              ",ATTACHE"
            ]
          },
          "level_007": {
            "a": 678566,
            "b": "RFNUOSO",
            "e": [
              ",FOUR",
              ",ONUS",
              ",ROOF",
              ",SOON",
              ",SOUR",
              ",SURF"
            ]
          },
          "level_008": {
            "a": 678570,
            "b": "UMSEDAS",
            "e": [
              ",DAME",
              ",MADE",
              ",MEAD",
              ",MESA",
              ",MESS",
              ",MUSE",
              ",SAME",
              ",SEAM",
              ",SUDS",
              ",SUED",
              ",USED",
              ",ASSUMED"
            ]
          },
          "level_009": {
            "a": 678567,
            "b": "YPTEM",
            "e": [
              ",MET",
              ",PET",
              ",YEP",
              ",YET",
              ",EMPTY"
            ]
          },
          "level_010": {
            "a": 678552,
            "b": "BNEGOY",
            "e": [
              ",BONE",
              ",BONG",
              ",BONY",
              ",GONE",
              ",OBEY",
              ",BOGEY",
              ",BONEY",
              ",EBONY"
            ]
          },
          "level_011": {
            "a": 678554,
            "b": "AIPRTOT",
            "e": [
              ",PATIO",
              ",RATIO",
              ",TAROT",
              ",TRAIT"
            ]
          },
          "level_012": {
            "a": 678558,
            "b": "UMOLHOD",
            "e": [
              ",DUH",
              "B,DUO",
              ",HUM",
              ",MOO",
              ",MUD",
              ",OHM",
              ",OLD",
              ",OOH",
              ",HOODLUM"
            ]
          },
          "level_013": {
            "a": 678553,
            "b": "OLPMCY",
            "e": [
              ",COP",
              ",COY",
              ",MOP",
              ",PLY",
              ",COMP",
              ",COPY",
              ",PLOY",
              ",POLY",
              ",COMPLY"
            ]
          },
          "level_014": {
            "a": 678564,
            "b": "LARWCS",
            "e": [
              ",ARC",
              ",CAR",
              ",LAW",
              ",RAW",
              ",SAC",
              ",SAW",
              ",WAR",
              ",WAS",
              ",CRAWL",
              ",SCRAWL"
            ]
          },
          "level_015": {
            "a": 678571,
            "b": "OSINPAS",
            "e": [
              ",PAIN",
              ",SNAP",
              ",SNIP",
              ",SOAP",
              ",SPAN",
              ",SPIN",
              ",OASIS",
              "B,PIANO"
            ]
          },
          "level_016": {
            "a": 678562,
            "b": "TOOLUWB",
            "e": [
              ",BLOT",
              ",BLOW",
              ",BOLO",
              ",BOLT",
              ",BOOT",
              ",BOUT",
              ",BOWL",
              ",LOOT",
              ",LOUT",
              ",TOOL",
              ",WOOL",
              ",BLOWOUT"
            ]
          },
          "level_017": {
            "a": 678559,
            "b": "YRPISC",
            "e": [
              ",SPRY",
              ",CRISP",
              ",SPICY",
              ",CRISPY"
            ]
          },
          "level_018": {
            "a": 678565,
            "b": "OAPMADR",
            "e": [
              ",DAMP",
              "B,DORM",
              ",DRAM",
              ",DROP",
              ",PARA",
              ",PROD",
              ",PROM",
              ",RAMP",
              ",ROAD",
              ",ROAM",
              ",ROMP"
            ]
          },
          "level_019": {
            "a": 678556,
            "b": "ZAGED",
            "e": [
              ",AGED",
              ",DAZE",
              ",GAZE",
              ",GAZED"
            ]
          },
          "level_020": {
            "a": 678555,
            "b": "AVSTUEG",
            "e": [
              ",EAST",
              "B,GATE",
              ",GAVE",
              ",GUST",
              ",SAGE",
              ",SAVE",
              ",SEAT",
              ",STAG",
              ",VASE",
              ",VAST",
              ",VEST",
              ",VAGUEST"
            ]
          }
        },
        "m": 22957,
        "o": 45048,
        "r": 22957,
        "t": 0.6,
        "u": 0,
        "v": 1019367,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      },
      "set_3": {
        "a": "LAKE",
        "aa": 2063334,
        "d": "bg_frost3.jpg",
        "dd": 2063334,
        "e": 0.11,
        "j": 2063334,
        "l": 2063334,
        "levels": {
          "level_001": {
            "a": 678685,
            "b": "YUPSH",
            "e": [
              ",PUS",
              ",SHY",
              ",SPY",
              ",SUP",
              ",UPS",
              ",YUP",
              ",PUSHY"
            ]
          },
          "level_002": {
            "a": 678673,
            "b": "EPNTI",
            "e": [
              ",PENT",
              ",PINE",
              ",PINT",
              ",TINE",
              ",INEPT"
            ]
          },
          "level_003": {
            "a": 678681,
            "b": "PIAHOB",
            "e": [
              ",BAH",
              "B,BIO",
              ",BOA",
              ",BOP",
              ",HIP",
              ",HOP",
              ",PHI",
              ",PHOBIA"
            ]
          },
          "level_004": {
            "a": 678680,
            "b": "RCDEAUC",
            "e": [
              ",CADRE",
              ",CARED",
              ",CEDAR",
              ",CRUDE",
              ",CURED",
              ",RACED",
              ",ACCRUE",
              ",ACCRUED"
            ]
          },
          "level_005": {
            "a": 678684,
            "b": "IHARNE",
            "e": [
              ",EARN",
              "B,HAIR",
              ",HARE",
              ",HEAR",
              ",HEIR",
              ",HIRE",
              ",NEAR",
              ",RAIN",
              ",REIN",
              ",HERNIA"
            ]
          },
          "level_006": {
            "a": 678678,
            "b": "FYLAACL",
            "e": [
              ",ALL",
              ",CAY",
              ",FLY",
              ",LAY",
              ",ALLY",
              ",CALF",
              ",CALL",
              ",CLAY",
              ",FALL",
              ",FLAY",
              ",LACY",
              ",FALLACY"
            ]
          },
          "level_007": {
            "a": 678675,
            "b": "SUONUTE",
            "e": [
              ",ONSET",
              ",SNOUT",
              ",STONE",
              ",TENUOUS"
            ]
          },
          "level_008": {
            "a": 678674,
            "b": "RTNAPO",
            "e": [
              ",ATOP",
              ",PANT",
              ",PART",
              ",PORT",
              ",RANT",
              ",RAPT",
              ",ROAN",
              ",TARP",
              ",TORN",
              ",TRAP",
              ",PATRON",
              "B,TARPON"
            ]
          },
          "level_009": {
            "a": 678687,
            "b": "OCRD",
            "e": [
              ",COD",
              "B,DOC",
              ",ROD",
              ",CORD"
            ]
          },
          "level_010": {
            "a": 678676,
            "b": "LREBON",
            "e": [
              ",BRO",
              ",LOB",
              ",NOR",
              ",ONE",
              ",ORB",
              ",ORE",
              ",ROB",
              ",NOBLER"
            ]
          },
          "level_011": {
            "a": 678672,
            "b": "IALGTDI",
            "e": [
              ",DIAL",
              ",GAIT",
              ",GILT",
              ",GLAD",
              ",LAID",
              ",TAIL",
              ",DIGIT",
              ",TIDAL",
              ",DIGITAL"
            ]
          },
          "level_012": {
            "a": 678677,
            "b": "HORGEP",
            "e": [
              ",GORE",
              "B,HERO",
              ",HOPE",
              ",OGRE",
              ",PORE",
              ",REPO",
              ",ROPE",
              ",GROPE",
              ",GOPHER"
            ]
          },
          "level_013": {
            "a": 678683,
            "b": "VWELO",
            "e": [
              ",LOW",
              ",OWE",
              ",OWL",
              ",VOW",
              ",WOE",
              ",LOVE",
              ",VOLE",
              ",WOVE"
            ]
          },
          "level_014": {
            "a": 678668,
            "b": "OOMTERP",
            "e": [
              ",METRO",
              ",MOTOR",
              ",PROMO",
              ",TEMPO",
              ",TROMP",
              ",TROOP",
              ",TROPE",
              ",PROMOTE"
            ]
          },
          "level_015": {
            "a": 678679,
            "b": "DGEOGL",
            "e": [
              ",DOLE",
              ",GOLD",
              ",LODE",
              ",OGLE"
            ]
          },
          "level_016": {
            "a": 678669,
            "b": "SNEEUDR",
            "e": [
              ",DENSE",
              ",ENSUE",
              ",NURSE",
              ",REUSE",
              ",SNEER",
              ",SUEDE",
              ",UNDER",
              ",ENSURED"
            ]
          },
          "level_017": {
            "a": 678682,
            "b": "IKERT",
            "e": [
              ",IRE",
              ",KIT",
              ",TIE",
              ",KITE",
              ",RITE",
              ",TIER",
              ",TIRE",
              ",TREK"
            ]
          },
          "level_018": {
            "a": 678686,
            "b": "EDYASRA",
            "e": [
              ",AREA",
              ",DARE",
              ",DEAR",
              ",EASY",
              ",READ",
              ",SEAR",
              ",YARD",
              ",YEAR",
              ",READY",
              ",DARESAY"
            ]
          },
          "level_019": {
            "a": 678670,
            "b": "DESIL",
            "e": [
              ",DELI",
              ",IDLE",
              ",ISLE",
              ",LIED",
              ",SIDE",
              ",SLED",
              ",SLID",
              ",SLIDE"
            ]
          },
          "level_020": {
            "a": 678671,
            "b": "IUBAFL",
            "e": [
              ",AIL",
              ",FAB",
              ",FLU",
              ",LAB",
              ",BAIL",
              "B,FAIL",
              ",FLAB",
              ",FIBULA"
            ]
          }
        },
        "m": 22957,
        "o": 52843,
        "r": 22957,
        "t": 0.7000000000000001,
        "v": 2063334,
        "y": 0.7000000000000001
      },
      "set_4": {
        "a": "ICEY",
        "aa": 3107044,
        "d": "bg_frost4.jpg",
        "dd": 3107044,
        "e": 0.1,
        "h": "wscapes_snow",
        "j": 3107044,
        "l": 3107044,
        "levels": {
          "level_001": {
            "a": 678823,
            "b": "CNAON",
            "e": [
              ",CAN",
              ",CON",
              ",NAN",
              ",CANON"
            ]
          },
          "level_002": {
            "a": 678811,
            "b": "OCFFKOO",
            "e": [
              ",COO",
              "B,OFF",
              ",COOK",
              ",COOKOFF"
            ]
          },
          "level_003": {
            "a": 678821,
            "b": "RICDPE",
            "e": [
              ",CIDER",
              "B,CRIED",
              ",PRICE",
              ",PRIDE",
              ",PRIED"
            ]
          },
          "level_004": {
            "a": 678826,
            "b": "RYEELDL",
            "e": [
              ",DEER",
              ",DELL",
              ",EYED",
              ",LEER",
              ",LYRE",
              ",REED",
              ",REEL",
              ",RELY",
              ",YELL",
              ",ELDER",
              ",LEERY",
              ",REEDY"
            ]
          },
          "level_005": {
            "a": 678816,
            "b": "LNAKP",
            "e": [
              ",LAP",
              ",NAP",
              ",PAL",
              ",PAN",
              ",LANK",
              ",PLAN"
            ]
          },
          "level_006": {
            "a": 678814,
            "b": "DWOETUI",
            "e": [
              ",DIET",
              "B,DOTE",
              ",DUET",
              ",EDIT",
              ",OWED",
              ",TIDE",
              ",TIED",
              ",WIDE",
              ",TOWED"
            ]
          },
          "level_007": {
            "a": 678813,
            "b": "ISCSCLA",
            "e": [
              ",SAIL",
              ",CLASS",
              ",SISAL",
              ",CLASSIC"
            ]
          },
          "level_008": {
            "a": 678815,
            "b": "TAOLF",
            "e": [
              ",AFT",
              ",ALT",
              ",FAT",
              ",LAT",
              ",LOT",
              ",OAT",
              ",OFT",
              ",ALTO",
              ",FLAT",
              ",FOAL",
              ",LOAF",
              ",LOFT"
            ]
          },
          "level_009": {
            "a": 678810,
            "b": "RSEOTR",
            "e": [
              ",REST",
              ",ROSE",
              ",ROTE",
              ",SORE",
              ",SORT",
              ",TORE",
              ",RETRO",
              ",STORE",
              ",RESORT",
              ",ROSTER",
              ",SORTER"
            ]
          },
          "level_010": {
            "a": 678817,
            "b": "RWAELB",
            "e": [
              ",ABLE",
              "B,BALE",
              ",BARE",
              ",BAWL",
              ",BEAR",
              ",BLEW",
              ",BREW",
              ",EARL",
              ",REAL",
              ",WEAR"
            ]
          },
          "level_011": {
            "a": 678824,
            "b": "RTIAN",
            "e": [
              ",AIR",
              "B,ANT",
              ",ART",
              ",NIT",
              ",RAN",
              ",RAT",
              ",TAN",
              ",TAR",
              ",TIN",
              ",TRAIN"
            ]
          },
          "level_012": {
            "a": 678812,
            "b": "EIKPRPS",
            "e": [
              ",PERK",
              ",PIER",
              ",PIKE",
              ",PIPE",
              ",PREP",
              ",RIPE",
              ",RISE",
              ",RISK",
              ",SIRE",
              ",SKIP",
              ",SPIKER",
              ",SKIPPER"
            ]
          },
          "level_013": {
            "a": 678819,
            "b": "SSEEAM",
            "e": [
              ",SEA",
              ",SEE",
              ",EASE",
              ",MESA",
              ",MESS",
              ",SAME",
              ",SEAM",
              ",SEEM",
              ",SESAME"
            ]
          },
          "level_014": {
            "a": 678827,
            "b": "ENASALT",
            "e": [
              ",ATLAS",
              "B,LEAST",
              ",NASAL",
              ",SLANT",
              ",SLATE",
              ",STALE",
              ",STEAL"
            ]
          },
          "level_015": {
            "a": 678825,
            "b": "ETDBU",
            "e": [
              ",BED",
              ",BET",
              ",BUD",
              ",BUT",
              ",DUB",
              ",DUE",
              ",TUB",
              ",DEBUT",
              ",TUBED"
            ]
          },
          "level_016": {
            "a": 678820,
            "b": "OREERVM",
            "e": [
              ",EVER",
              ",MERE",
              ",MORE",
              ",MOVE",
              ",OVER",
              ",ROVE",
              ",VEER",
              ",MOVER",
              ",ROVER",
              ",REMOVE",
              ",REMOVER"
            ]
          },
          "level_017": {
            "a": 678818,
            "b": "MHASC",
            "e": [
              ",CASH",
              ",MASH",
              ",SCAM",
              ",SHAM",
              ",CHASM"
            ]
          },
          "level_018": {
            "a": 678808,
            "b": "UNTHAG",
            "e": [
              ",AUNT",
              ",GNAT",
              ",HANG",
              ",HUNG",
              ",HUNT",
              ",TANG",
              ",THAN",
              ",THUG",
              ",TUNA",
              ",NAUGHT"
            ]
          },
          "level_019": {
            "a": 678809,
            "b": "ANAIV",
            "e": [
              ",VAN",
              ",VIA",
              ",VAIN",
              ",AVIAN"
            ]
          },
          "level_020": {
            "a": 678822,
            "b": "URLAEGR",
            "e": [
              ",ARGUE",
              ",AUGER",
              ",GLARE",
              ",GRUEL",
              ",LAGER",
              ",LARGE",
              ",REGAL",
              ",RULER",
              ",RURAL"
            ]
          }
        },
        "m": 15506,
        "o": 45048,
        "r": 15506,
        "t": 0.75,
        "v": 3107044,
        "y": 0.7000000000000001
      },
      "set_5": {
        "a": "SHINE",
        "aa": 4151011,
        "d": "bg_frost5.jpg",
        "dd": 4151011,
        "e": 0.1,
        "j": 4151011,
        "l": 4151011,
        "levels": {
          "level_001": {
            "a": 678931,
            "b": "LHTI",
            "e": [
              ",HIT",
              ",LIT",
              ",TIL",
              ",HILT"
            ]
          },
          "level_002": {
            "a": 678945,
            "b": "OPRTOIC",
            "e": [
              ",COOPT",
              "B,OPTIC",
              ",TOPIC",
              ",TROOP"
            ]
          },
          "level_003": {
            "a": 678941,
            "b": "TNTENI",
            "e": [
              ",NINE",
              ",TENT",
              ",TINE",
              ",TINT"
            ]
          },
          "level_004": {
            "a": 678934,
            "b": "ODEUGSR",
            "e": [
              ",DOUSE",
              ",GOURD",
              ",ROGUE",
              ",ROUGE",
              ",ROUSE",
              ",SURGE",
              ",URGED",
              ",GROUSED"
            ]
          },
          "level_005": {
            "a": 678930,
            "b": "IMOSDW",
            "e": [
              ",DIM",
              ",DOW",
              ",MID",
              ",MOW",
              ",SIM",
              ",SOD",
              ",SOW",
              ",SWIM"
            ]
          },
          "level_006": {
            "a": 678926,
            "b": "INPMIEG",
            "e": [
              ",GEM",
              ",GIN",
              ",IMP",
              ",MEG",
              ",MEN",
              ",NIP",
              ",PEG",
              ",PEN",
              ",PIE",
              ",PIG",
              ",PIN",
              ",IMPINGE"
            ]
          },
          "level_007": {
            "a": 678932,
            "b": "UTYHO",
            "e": [
              ",HOT",
              "B,HUT",
              ",OUT",
              ",THY",
              ",TOY",
              ",YOU",
              ",THOU",
              ",YOUTH"
            ]
          },
          "level_008": {
            "a": 678937,
            "b": "CETITAL",
            "e": [
              ",CITE",
              ",LACE",
              ",LATE",
              ",LICE",
              ",LITE",
              ",TACT",
              ",TAIL",
              ",TALC",
              ",TALE",
              ",TEAL",
              ",TILE",
              ",TILT"
            ]
          },
          "level_009": {
            "a": 678928,
            "b": "OUFWRR",
            "e": [
              ",FOR",
              ",FRO",
              ",FUR",
              ",OUR",
              ",ROW",
              ",FOUR",
              ",FUROR"
            ]
          },
          "level_010": {
            "a": 678929,
            "b": "OTEANLP",
            "e": [
              ",ALONE",
              "B,ATONE",
              ",LEAPT",
              ",PANEL",
              ",PENAL",
              ",PETAL",
              ",PLANE",
              ",PLANT",
              ",PLATE",
              ",TALON",
              ",TONAL"
            ]
          },
          "level_011": {
            "a": 678935,
            "b": "ATGRET",
            "e": [
              ",GATE",
              ",GEAR",
              ",RAGE",
              ",RATE",
              ",TART",
              ",TEAR",
              ",GRATE",
              "B,GREAT",
              ",TREAT"
            ]
          },
          "level_012": {
            "a": 678943,
            "b": "TSYRKEA",
            "e": [
              ",ARTSY",
              ",SKATE",
              ",STAKE",
              ",STARE",
              ",STARK",
              ",STEAK",
              ",STRAY",
              ",TAKER",
              ",TEARY",
              ",YEAST",
              ",STREAKY"
            ]
          },
          "level_013": {
            "a": 678944,
            "b": "UMBLEJ",
            "e": [
              ",BUM",
              ",ELM",
              ",EMU",
              ",BLUE",
              ",LUBE",
              ",MULE"
            ]
          },
          "level_014": {
            "a": 678933,
            "b": "DOBERR",
            "e": [
              ",BODE",
              ",BORE",
              ",BRED",
              ",DOER",
              ",REDO",
              ",ROBE",
              ",RODE",
              ",BORDER"
            ]
          },
          "level_015": {
            "a": 678938,
            "b": "TRFIAD",
            "e": [
              ",DRAFT",
              ",DRIFT",
              ",TRIAD",
              ",ADRIFT"
            ]
          },
          "level_016": {
            "a": 678939,
            "b": "ANITRO",
            "e": [
              ",ANTI",
              "B,INTO",
              ",IOTA",
              ",IRON",
              ",RAIN",
              ",RANT",
              ",RIOT",
              ",ROAN",
              ",TORN",
              ",TRIO",
              ",RATION"
            ]
          },
          "level_017": {
            "a": 678927,
            "b": "FNRLUEA",
            "e": [
              ",FERAL",
              ",FLARE",
              ",LEARN",
              ",LUNAR",
              ",RENAL"
            ]
          },
          "level_018": {
            "a": 678940,
            "b": "SEXEPSR",
            "e": [
              ",EXES",
              ",PEER",
              ",SEEP",
              ",SEER",
              ",PRESS",
              ",SEXES",
              ",SPREE"
            ]
          },
          "level_019": {
            "a": 678942,
            "b": "HRAOB",
            "e": [
              ",BAH",
              "B,BAR",
              ",BOA",
              ",BRA",
              ",BRO",
              ",OAR",
              ",ORB",
              ",ROB",
              ",BOAR",
              ",ABHOR"
            ]
          },
          "level_020": {
            "a": 678936,
            "b": "MCYRUM",
            "e": [
              ",CRY",
              ",CUR",
              ",MUM",
              ",RUM",
              ",UMM",
              ",YUM",
              ",RUMMY",
              ",CRUMMY"
            ]
          }
        },
        "m": 15506,
        "o": 45048,
        "r": 15506,
        "t": 0.75,
        "v": 4151011,
        "y": 0.75
      }
    }
  },
  "WS 09": {
    "a": "MARSH",
    "b": "grad_white",
    "c": "grp_autumn",
    "d": 0.75,
    "e": 16752640,
    "f": 16740096,
    "sets": {
      "set_1": {
        "a": "LIFE",
        "aa": 16752640,
        "bb": 16777215,
        "d": "bg_marsh1.jpg",
        "dd": 16752640,
        "e": 0.12,
        "j": 16752640,
        "l": 16752640,
        "levels": {
          "level_001": {
            "a": 679085,
            "b": "CYHAPE",
            "e": [
              ",ACHE",
              ",ACHY",
              ",CAPE",
              ",CHAP",
              ",EACH",
              ",HEAP",
              ",HYPE",
              ",PACE",
              ",YEAH",
              ",CHEAP",
              ",PEACH",
              ",PEACHY"
            ]
          },
          "level_002": {
            "a": 679074,
            "b": "PUKEPE",
            "e": [
              ",EEK",
              ",EKE",
              ",PEP",
              ",PUP",
              ",KEEP",
              "B,PEEK",
              ",PEEP",
              ",UPKEEP"
            ]
          },
          "level_003": {
            "a": 679080,
            "b": "AMTSR",
            "e": [
              ",ARM",
              ",ART",
              ",MAR",
              ",MAT",
              ",RAM",
              ",RAT",
              ",SAT",
              ",TAR",
              ",SMART"
            ]
          },
          "level_004": {
            "a": 679068,
            "b": "POUSRTP",
            "e": [
              ",ROUST",
              ",SPORT",
              ",SPOUT",
              ",SPURT",
              ",TORUS",
              ",SPROUT",
              ",STUPOR",
              ",SUPPORT"
            ]
          },
          "level_005": {
            "a": 679083,
            "b": "INTSIS",
            "e": [
              ",ITS",
              ",NIT",
              ",SIN",
              ",SIS",
              ",SIT",
              ",TIN",
              ",TIS",
              ",INSIST"
            ]
          },
          "level_006": {
            "a": 679075,
            "b": "NTOCTO",
            "e": [
              ",COOT",
              ",ONTO",
              ",TOON",
              ",TOOT"
            ]
          },
          "level_007": {
            "a": 679072,
            "b": "OLODNE",
            "e": [
              ",DEN",
              ",DOE",
              ",DON",
              ",END",
              ",LED",
              ",NOD",
              ",ODE",
              ",OLD",
              ",ONE",
              ",OLDEN",
              ",NOODLE"
            ]
          },
          "level_008": {
            "a": 679081,
            "b": "TLATRES",
            "e": [
              ",LATEST",
              ",LATTER",
              ",RATTLE",
              ",TASTER",
              ",STARLET",
              "B,STARTLE"
            ]
          },
          "level_009": {
            "a": 679086,
            "b": "GIBGER",
            "e": [
              ",BEG",
              ",BIG",
              ",EGG",
              ",GIG",
              ",IRE",
              ",RIB",
              ",RIG",
              ",BIGGER"
            ]
          },
          "level_010": {
            "a": 679084,
            "b": "SAAUSGE",
            "e": [
              ",AGE",
              ",GAS",
              ",SAG",
              ",SEA",
              ",SUE",
              ",USE",
              ",ASSUAGE",
              "B,SAUSAGE"
            ]
          },
          "level_011": {
            "a": 679071,
            "b": "PIERDZ",
            "e": [
              ",PRIDE",
              "B,PRIED",
              ",PRIZE",
              ",PRIZED"
            ]
          },
          "level_012": {
            "a": 679087,
            "b": "ODTICIN",
            "e": [
              ",IONIC",
              "B,TONIC",
              ",INDICT",
              ",DICTION"
            ]
          },
          "level_013": {
            "a": 679078,
            "b": "ECLFIK",
            "e": [
              ",ELF",
              ",ELK",
              ",ICE",
              ",ILK",
              ",LIE",
              ",FICKLE"
            ]
          },
          "level_014": {
            "a": 679079,
            "b": "RGAMOL",
            "e": [
              ",GLAM",
              ",GOAL",
              ",GRAM",
              ",LOAM",
              ",ORAL",
              ",ROAM",
              ",MOLAR",
              ",MORAL",
              ",GLAMOR"
            ]
          },
          "level_015": {
            "a": 679073,
            "b": "UTDSIAM",
            "e": [
              ",AMID",
              ",DUST",
              ",MAID",
              ",MAST",
              ",MIST",
              ",MUST",
              ",SAID",
              ",SMUT",
              ",STUD",
              ",SUIT",
              ",AMIDST",
              ",AUTISM"
            ]
          },
          "level_016": {
            "a": 679082,
            "b": "NGLUEID",
            "e": [
              ",DEIGN",
              ",GLIDE",
              ",GLUED",
              ",GUIDE",
              ",GUILD",
              ",GUILE",
              ",LINED",
              ",LUNGE",
              ",NUDGE"
            ]
          },
          "level_017": {
            "a": 679070,
            "b": "AEDSNSS",
            "e": [
              ",DEAN",
              ",SAND",
              ",SANE",
              ",SASS",
              ",SEND",
              ",SEDAN"
            ]
          },
          "level_018": {
            "a": 679069,
            "b": "WTDYRA",
            "e": [
              ",ARTY",
              ",AWRY",
              ",DART",
              ",DRAW",
              ",TRAY",
              ",WARD",
              ",WART",
              ",WARY",
              ",YARD",
              ",TARDY",
              ",TAWDRY"
            ]
          },
          "level_019": {
            "a": 679076,
            "b": "EBENLAU",
            "e": [
              ",ALE",
              ",BAN",
              ",BEE",
              ",BUN",
              ",EEL",
              ",LAB",
              ",NAB",
              ",NUB",
              ",ENABLE",
              ",NEBULA",
              ",UNABLE"
            ]
          },
          "level_020": {
            "a": 679077,
            "b": "OGANOBL",
            "e": [
              ",ALONG",
              ",ANGLO",
              ",BONGO",
              ",LAGOON",
              "B,OBLONG",
              ",BOLOGNA"
            ]
          }
        },
        "m": 11165184,
        "o": 34047,
        "r": 11165184,
        "t": 0.5,
        "u": 0,
        "v": 16752640,
        "w": 16646135,
        "x": 10957312,
        "y": 0.5,
        "z": 0
      },
      "set_2": {
        "a": "BEGIN",
        "aa": 16749312,
        "bb": 16777215,
        "cc": 10957312,
        "d": "bg_marsh2.jpg",
        "dd": 16749312,
        "e": 0.12,
        "ee": 10957312,
        "j": 16749312,
        "l": 16749312,
        "levels": {
          "level_001": {
            "a": 679225,
            "b": "ORRTDI",
            "e": [
              ",DOT",
              ",RID",
              ",ROD",
              ",ROT",
              ",TORRID"
            ]
          },
          "level_002": {
            "a": 679231,
            "b": "TALWLO",
            "e": [
              ",ALL",
              ",ALT",
              ",LAT",
              ",LAW",
              ",LOT",
              ",LOW",
              ",OAT",
              ",OWL",
              ",TOW",
              ",TWO",
              ",ALLOW",
              ",ATOLL"
            ]
          },
          "level_003": {
            "a": 679240,
            "b": "UIRVAOS",
            "e": [
              ",SOAR",
              ",SOUR",
              ",VISA",
              ",SAVOR",
              "B,VIRUS",
              ",VISOR",
              ",SAVIOR",
              ",VARIOUS"
            ]
          },
          "level_004": {
            "a": 679235,
            "b": "OURDBEL",
            "e": [
              ",BLUER",
              ",BORED",
              ",LURED",
              ",OLDER",
              ",RUBLE",
              ",RULED"
            ]
          },
          "level_005": {
            "a": 679229,
            "b": "ZODNE",
            "e": [
              ",DONE",
              ",DOZE",
              ",NODE",
              ",ZONE"
            ]
          },
          "level_006": {
            "a": 679227,
            "b": "WHCREN",
            "e": [
              ",HEN",
              ",HER",
              ",HEW",
              ",NEW",
              ",CHEW",
              "B,CREW",
              ",HEWN",
              ",WHEN",
              ",WREN"
            ]
          },
          "level_007": {
            "a": 679243,
            "b": "YENLACL",
            "e": [
              ",ALLEY",
              "B,CLEAN",
              ",LANCE",
              ",CLEANLY"
            ]
          },
          "level_008": {
            "a": 679238,
            "b": "UMATET",
            "e": [
              ",MATE",
              ",MEAT",
              ",MUTE",
              ",MUTT",
              ",TAME",
              ",TAUT",
              ",TEAM",
              ",MATTE",
              ",MUTATE"
            ]
          },
          "level_009": {
            "a": 679241,
            "b": "MHPISR",
            "e": [
              ",HIM",
              ",HIP",
              ",HIS",
              ",IMP",
              ",PHI",
              ",RIM",
              ",RIP",
              ",SIM",
              ",SIP",
              ",SIR",
              ",PRISM"
            ]
          },
          "level_010": {
            "a": 679233,
            "b": "AZSCEIR",
            "e": [
              ",ACRE",
              "B,CARE",
              ",CASE",
              ",CZAR",
              ",RACE",
              ",RAZE",
              ",RICE",
              ",RISE",
              ",SCAR",
              ",SEAR",
              ",SIRE",
              ",SIZE"
            ]
          },
          "level_011": {
            "a": 679224,
            "b": "CONSEEL",
            "e": [
              ",CONE",
              ",ELSE",
              ",LENS",
              ",LONE",
              ",LOSE",
              ",NOEL",
              ",NOSE",
              ",ONCE",
              ",SEEN",
              ",SOLE"
            ]
          },
          "level_012": {
            "a": 679242,
            "b": "RILYNKC",
            "e": [
              ",ICKY",
              ",INKY",
              ",LICK",
              ",LINK",
              ",NICK",
              ",RINK",
              ",CLINK",
              ",LYRIC"
            ]
          },
          "level_013": {
            "a": 679234,
            "b": "IALM",
            "e": [
              ",AIL",
              ",AIM",
              ",LAM",
              ",MIL",
              ",MAIL"
            ]
          },
          "level_014": {
            "a": 679239,
            "b": "EADELSP",
            "e": [
              ",ASLEEP",
              ",ELAPSE",
              ",LAPSED",
              ",LEAPED",
              ",LEASED",
              ",PLEASE",
              ",SEALED"
            ]
          },
          "level_015": {
            "a": 679230,
            "b": "DINRDE",
            "e": [
              ",DIED",
              "B,DINE",
              ",DIRE",
              ",NERD",
              ",REIN",
              ",REND",
              ",RIDE",
              ",RIND"
            ]
          },
          "level_016": {
            "a": 679228,
            "b": "FEYRRIT",
            "e": [
              ",FIRE",
              ",FRET",
              ",RIFE",
              ",RIFT",
              ",RITE",
              ",TIER",
              ",TIRE",
              ",YETI",
              ",FERRY",
              ",FIERY",
              ",FRYER",
              ",RETRY"
            ]
          },
          "level_017": {
            "a": 679237,
            "b": "ODVIED",
            "e": [
              ",DIODE",
              ",DIVED",
              ",VIDEO",
              ",DEVOID",
              "B,VOIDED"
            ]
          },
          "level_018": {
            "a": 679226,
            "b": "RMDEEY",
            "e": [
              ",DRY",
              ",DYE",
              ",EYE",
              ",RED",
              ",REM",
              ",RYE",
              ",EMERY",
              ",REEDY"
            ]
          },
          "level_019": {
            "a": 679232,
            "b": "IEKNFD",
            "e": [
              ",FIEND",
              ",FINED",
              ",INKED",
              ",KNIFE"
            ]
          },
          "level_020": {
            "a": 679236,
            "b": "ECALOV",
            "e": [
              ",ALOE",
              ",CAVE",
              ",COAL",
              ",COLA",
              ",COVE",
              ",LACE",
              ",LOVE",
              ",OVAL",
              ",VALE",
              ",VEAL",
              ",VOLE",
              ",ALCOVE"
            ]
          }
        },
        "m": 10957312,
        "o": 34047,
        "q": 10957312,
        "r": 16777215,
        "s": 0,
        "t": 0.6,
        "u": 0,
        "v": 16749312,
        "w": 16777215,
        "x": 10957312,
        "y": 0.6,
        "z": 0
      },
      "set_3": {
        "a": "HOME",
        "aa": 16746240,
        "bb": 16777215,
        "d": "bg_marsh3.jpg",
        "dd": 16746240,
        "e": 0,
        "j": 16746240,
        "l": 16746240,
        "levels": {
          "level_001": {
            "a": 679393,
            "b": "OAPTRS",
            "e": [
              ",ROAST",
              ",SPORT",
              ",STRAP",
              ",PASTOR"
            ]
          },
          "level_002": {
            "a": 679389,
            "b": "POTEEU",
            "e": [
              ",OPT",
              ",OUT",
              ",PET",
              ",POT",
              ",PUT",
              ",TEE",
              ",TOE",
              ",TOP",
              ",TOUPEE"
            ]
          },
          "level_003": {
            "a": 679405,
            "b": "KYTSOC",
            "e": [
              ",COT",
              ",COY",
              ",SKY",
              ",SOY",
              ",TOY",
              ",COST",
              ",CYST",
              ",SOCK",
              ",STOCK"
            ]
          },
          "level_004": {
            "a": 679407,
            "b": "TELNLI",
            "e": [
              ",LENT",
              "B,LIEN",
              ",LILT",
              ",LINE",
              ",LINT",
              ",LITE",
              ",TELL",
              ",TILE",
              ",TILL",
              ",TINE"
            ]
          },
          "level_005": {
            "a": 679388,
            "b": "BIESKTR",
            "e": [
              ",BIKER",
              ",BRISK",
              ",SKIER",
              ",SKIRT",
              ",TRIBE",
              ",TRIES",
              ",TRIKE",
              ",STRIKE"
            ]
          },
          "level_006": {
            "a": 679390,
            "b": "LUACYTF",
            "e": [
              ",CALF",
              ",CLAY",
              ",CULT",
              ",FACT",
              ",FLAT",
              ",FLAY",
              ",LACY",
              ",TALC"
            ]
          },
          "level_007": {
            "a": 679403,
            "b": "UJNLGE",
            "e": [
              ",GEL",
              ",GNU",
              ",GUN",
              ",JUG",
              ",LEG",
              ",LUG",
              ",GLEN",
              ",GLUE",
              ",LUGE",
              ",LUNG",
              ",JUNGLE"
            ]
          },
          "level_008": {
            "a": 679397,
            "b": "OEDLEPP",
            "e": [
              ",DEEP",
              "B,DOLE",
              ",DOPE",
              ",LODE",
              ",LOPE",
              ",PEEL",
              ",PEEP",
              ",PLED",
              ",PLOP",
              ",POLE",
              ",POPE",
              ",PEOPLED"
            ]
          },
          "level_009": {
            "a": 679396,
            "b": "BSJCUTE",
            "e": [
              ",BEST",
              ",BUST",
              ",CUBE",
              ",CUTE",
              ",JEST",
              ",JUST",
              ",SECT",
              ",STUB",
              ",TUBE"
            ]
          },
          "level_010": {
            "a": 679406,
            "b": "EEPLRA",
            "e": [
              ",LEPER",
              ",PALER",
              ",PEARL",
              ",REPEL",
              ",LEAPER",
              ",REPEAL"
            ]
          },
          "level_011": {
            "a": 679400,
            "b": "HCOMO",
            "e": [
              ",COO",
              ",MOO",
              ",OHM",
              ",OOH",
              ",MOOCH"
            ]
          },
          "level_012": {
            "a": 679404,
            "b": "UDILCEN",
            "e": [
              ",CLUED",
              ",LINED",
              ",LUCID",
              ",UNCLE",
              ",INDUCE",
              "B,NUCLEI"
            ]
          },
          "level_013": {
            "a": 679398,
            "b": "ASOEMEW",
            "e": [
              ",EASE",
              ",MEOW",
              ",MESA",
              ",SAME",
              ",SEAM",
              ",SEEM",
              ",SOME",
              ",SWAM"
            ]
          },
          "level_014": {
            "a": 679394,
            "b": "AAGSSPE",
            "e": [
              ",GAPE",
              ",GASP",
              ",PAGE",
              ",SAGA",
              ",SAGE",
              ",AGAPE",
              "B,GASES",
              ",PASSE",
              ",PASSAGE"
            ]
          },
          "level_015": {
            "a": 679395,
            "b": "NUSAILR",
            "e": [
              ",LAIN",
              ",LAIR",
              ",LIAR",
              ",NAIL",
              ",RAIL",
              ",RAIN",
              ",RUIN",
              ",SAIL",
              ",SLUR"
            ]
          },
          "level_016": {
            "a": 679399,
            "b": "LRSYIBT",
            "e": [
              ",LIST",
              ",SILT",
              ",SLIT",
              ",STIR",
              ",BITSY",
              ",SILTY"
            ]
          },
          "level_017": {
            "a": 679402,
            "b": "LPLDOO",
            "e": [
              ",OLD",
              ",POD",
              ",DOLL",
              ",LOOP",
              ",POLL",
              ",POLO",
              ",POOL",
              ",DOLLOP"
            ]
          },
          "level_018": {
            "a": 679391,
            "b": "EYGRFRO",
            "e": [
              ",FORE",
              "B,FROG",
              ",GORE",
              ",GORY",
              ",GREY",
              ",OGRE",
              ",YORE"
            ]
          },
          "level_019": {
            "a": 679392,
            "b": "HATBC",
            "e": [
              ",ACT",
              ",BAH",
              ",BAT",
              ",CAB",
              ",CAT",
              ",HAT",
              ",TAB",
              ",BATH",
              ",CHAT"
            ]
          },
          "level_020": {
            "a": 679401,
            "b": "TPEIAO",
            "e": [
              ",ATOP",
              "B,IOTA",
              ",PATE",
              ",PEAT",
              ",PITA",
              ",POET",
              ",TAPE",
              ",OPIATE"
            ]
          }
        },
        "m": 11165184,
        "o": 35583,
        "r": 11165184,
        "s": 0,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 16746240,
        "w": 16777215,
        "y": 0.55,
        "z": 0
      },
      "set_4": {
        "a": "WET",
        "aa": 16743168,
        "bb": 16777215,
        "d": "bg_marsh4.jpg",
        "dd": 16743168,
        "e": 0.14,
        "j": 16743168,
        "l": 16743168,
        "levels": {
          "level_001": {
            "a": 679519,
            "b": "NCEDAR",
            "e": [
              ",CADRE",
              ",CARED",
              ",CEDAR",
              ",CRANE",
              ",DANCE",
              ",RACED",
              ",CRANED",
              "B,DANCER"
            ]
          },
          "level_002": {
            "a": 679521,
            "b": "CRARSEC",
            "e": [
              ",CARER",
              ",RACER",
              ",SCARE",
              ",SCARCER"
            ]
          },
          "level_003": {
            "a": 679514,
            "b": "YDUMM",
            "e": [
              ",MUD",
              ",MUM",
              ",UMM",
              ",YUM",
              ",DUMMY"
            ]
          },
          "level_004": {
            "a": 679512,
            "b": "RFAMOLU",
            "e": [
              ",AFOUL",
              ",FLOUR",
              ",FORUM",
              ",MOLAR",
              ",MORAL",
              ",MURAL",
              ",ARMFUL",
              "B,FORMAL"
            ]
          },
          "level_005": {
            "a": 679510,
            "b": "LIEENS",
            "e": [
              ",EEL",
              ",LIE",
              ",NIL",
              ",SEE",
              ",SIN",
              ",SENILE"
            ]
          },
          "level_006": {
            "a": 679518,
            "b": "OTICLAP",
            "e": [
              ",OPTIC",
              ",PATIO",
              ",PILOT",
              ",TOPIC",
              ",COITAL",
              ",CAPITOL",
              ",OPTICAL",
              ",TOPICAL"
            ]
          },
          "level_007": {
            "a": 679525,
            "b": "RCHTOO",
            "e": [
              ",COOT",
              "B,HOOT",
              ",ROOT",
              ",COHORT"
            ]
          },
          "level_008": {
            "a": 679513,
            "b": "TGLEOAV",
            "e": [
              ",GAVEL",
              ",GLOAT",
              ",GLOVE",
              ",VALET",
              ",GELATO",
              ",VOLTAGE"
            ]
          },
          "level_009": {
            "a": 679523,
            "b": "OHEUDS",
            "e": [
              ",DOE",
              ",DUE",
              ",DUH",
              ",DUO",
              ",HOE",
              ",HUE",
              ",ODE",
              ",SHE",
              ",SOD",
              ",SUE",
              ",USE",
              ",HOUSED"
            ]
          },
          "level_010": {
            "a": 679508,
            "b": "UNPHPAY",
            "e": [
              ",PUNY",
              ",HAPPY",
              ",NAPPY",
              ",UNHAPPY"
            ]
          },
          "level_011": {
            "a": 679520,
            "b": "TTNMAU",
            "e": [
              ",ANT",
              ",MAN",
              ",MAT",
              ",NUT",
              ",TAN",
              ",TAU",
              ",AUNT",
              ",MUTT",
              ",TAUT",
              ",TUNA",
              ",TAUNT"
            ]
          },
          "level_012": {
            "a": 679515,
            "b": "MLEDSIT",
            "e": [
              ",ISLET",
              "B,MIDST",
              ",SITED",
              ",SLIDE",
              ",SLIME",
              ",SMELT",
              ",SMILE",
              ",TILED",
              ",TIMED",
              ",MILDEST"
            ]
          },
          "level_013": {
            "a": 679507,
            "b": "ENOMEMT",
            "e": [
              ",MEET",
              ",MEMO",
              ",MOTE",
              ",NOTE",
              ",OMEN",
              ",TEEN",
              ",TOME",
              ",TONE"
            ]
          },
          "level_014": {
            "a": 679524,
            "b": "NMTAAOB",
            "e": [
              ",ATOM",
              ",BOAT",
              ",MOAN",
              ",MOAT",
              ",TOMB",
              ",BOATMAN"
            ]
          },
          "level_015": {
            "a": 679509,
            "b": "FATLE",
            "e": [
              ",AFT",
              "B,ALE",
              ",ALT",
              ",ATE",
              ",EAT",
              ",ELF",
              ",FAT",
              ",LAT",
              ",LET",
              ",TEA",
              ",FETAL"
            ]
          },
          "level_016": {
            "a": 679516,
            "b": "MURFELF",
            "e": [
              ",FLUE",
              ",FUEL",
              ",LURE",
              ",MULE",
              ",RULE",
              ",FEMUR",
              ",FLUME",
              ",LEMUR"
            ]
          },
          "level_017": {
            "a": 679506,
            "b": "RMGDIAA",
            "e": [
              ",AMID",
              ",ARID",
              ",DRAG",
              ",DRAM",
              ",GRAD",
              ",GRAM",
              ",GRID",
              ",GRIM",
              ",MAID",
              ",RAID"
            ]
          },
          "level_018": {
            "a": 679522,
            "b": "SATSIS",
            "e": [
              ",ITS",
              ",SAT",
              ",SIS",
              ",SIT",
              ",TIS",
              ",SASS",
              ",ASSIST",
              "B,STASIS"
            ]
          },
          "level_019": {
            "a": 679517,
            "b": "ALBDN",
            "e": [
              ",AND",
              ",BAD",
              ",BAN",
              ",DAB",
              ",LAB",
              ",LAD",
              ",NAB",
              ",BLAND"
            ]
          },
          "level_020": {
            "a": 679511,
            "b": "MTOSTOP",
            "e": [
              ",MOOT",
              ",MOST",
              ",OOPS",
              ",POST",
              ",SOOT",
              ",SPOT",
              ",STOP",
              ",TOOT",
              ",MOTTO",
              ",STOMP",
              ",STOOP",
              ",TOPMOST"
            ]
          }
        },
        "m": 8997376,
        "o": 56933,
        "r": 8997376,
        "t": 0.6,
        "u": 0,
        "v": 16743168,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      },
      "set_5": {
        "a": "HIDE",
        "aa": 16740096,
        "bb": 16777215,
        "d": "bg_marsh5.jpg",
        "dd": 16740096,
        "e": 0,
        "j": 16740096,
        "l": 16740096,
        "levels": {
          "level_001": {
            "a": 679659,
            "b": "DLAPDPE",
            "e": [
              ",APPLE",
              ",PALED",
              ",PEDAL",
              ",PLEAD"
            ]
          },
          "level_002": {
            "a": 679671,
            "b": "HTESEDA",
            "e": [
              ",DEATH",
              ",EASED",
              ",HASTE",
              ",HATED",
              ",SATED",
              ",SHADE",
              ",SHEET",
              ",STEAD",
              ",TEASE",
              ",THESE",
              ",HEADSET"
            ]
          },
          "level_003": {
            "a": 679666,
            "b": "HEACNG",
            "e": [
              ",ACE",
              ",AGE",
              ",CAN",
              ",HAG",
              ",HEN",
              ",NAG",
              ",ACHE",
              ",ACNE",
              ",CAGE",
              ",CANE",
              ",EACH",
              ",HANG"
            ]
          },
          "level_004": {
            "a": 679657,
            "b": "AULTBME",
            "e": [
              ",ALBUM",
              ",AMBLE",
              ",BLAME",
              ",METAL",
              ",TABLE",
              ",TUBAL",
              ",AMULET",
              "B,TUMBLE",
              ",MUTABLE"
            ]
          },
          "level_005": {
            "a": 679672,
            "b": "ERTELL",
            "e": [
              ",LEER",
              ",REEL",
              ",TELL",
              ",TREE"
            ]
          },
          "level_006": {
            "a": 679664,
            "b": "HCIETN",
            "e": [
              ",ETHIC",
              ",NICHE",
              ",THINE",
              ",ETHNIC"
            ]
          },
          "level_007": {
            "a": 679656,
            "b": "DIIGNO",
            "e": [
              ",DIG",
              ",DIN",
              ",DOG",
              ",DON",
              ",GIN",
              ",GOD",
              ",ION",
              ",NOD",
              ",DOING"
            ]
          },
          "level_008": {
            "a": 679654,
            "b": "VREACIA",
            "e": [
              ",ACRE",
              ",AREA",
              ",CARE",
              ",CAVE",
              ",RACE",
              ",RAVE",
              ",RICE",
              ",VICE",
              ",AVARICE"
            ]
          },
          "level_009": {
            "a": 679665,
            "b": "RRSIEOW",
            "e": [
              ",RISE",
              ",ROSE",
              ",SIRE",
              ",SORE",
              ",WIRE",
              ",WISE",
              ",WORE",
              ",WORRIES"
            ]
          },
          "level_010": {
            "a": 679658,
            "b": "BYIPOS",
            "e": [
              ",BIO",
              ",BOP",
              ",BOY",
              ",OPS",
              ",SIP",
              ",SOB",
              ",SOP",
              ",SOY",
              ",SPY",
              ",BIOPSY"
            ]
          },
          "level_011": {
            "a": 679663,
            "b": "MPAR",
            "e": [
              ",AMP",
              "B,ARM",
              ",MAP",
              ",MAR",
              ",PAR",
              ",RAM",
              ",RAP",
              ",RAMP"
            ]
          },
          "level_012": {
            "a": 679662,
            "b": "NEGILBO",
            "e": [
              ",BEGIN",
              ",BEING",
              ",BILGE",
              ",BINGE",
              ",BINGO",
              ",BLING",
              ",GLOBE",
              ",LINGO",
              ",LOGIN",
              ",NOBLE",
              ",IGNOBLE"
            ]
          },
          "level_013": {
            "a": 679670,
            "b": "FHLTEYS",
            "e": [
              ",FELT",
              "B,HEFT",
              ",LEFT",
              ",LEST",
              ",SELF",
              ",THEY"
            ]
          },
          "level_014": {
            "a": 679667,
            "b": "PPHOYC",
            "e": [
              ",COP",
              "B,COY",
              ",HOP",
              ",POP",
              ",CHOPPY"
            ]
          },
          "level_015": {
            "a": 679661,
            "b": "NTWO",
            "e": [
              ",NOT",
              ",NOW",
              ",OWN",
              ",TON",
              ",TOW",
              ",TWO",
              ",WON",
              ",TOWN"
            ]
          },
          "level_016": {
            "a": 679660,
            "b": "OERNVTC",
            "e": [
              ",COVEN",
              "B,COVER",
              ",COVET",
              ",CRONE",
              ",OVERT",
              ",RECON",
              ",TENOR",
              ",TONER",
              ",TROVE",
              ",VOTER"
            ]
          },
          "level_017": {
            "a": 679655,
            "b": "CUKHS",
            "e": [
              ",HUSK",
              ",SUCH",
              ",SUCK",
              ",SHUCK"
            ]
          },
          "level_018": {
            "a": 679673,
            "b": "TISIVOR",
            "e": [
              ",IRIS",
              ",RIOT",
              ",SORT",
              ",STIR",
              ",TRIO",
              ",VISIT",
              "B,VISOR",
              ",VISITOR"
            ]
          },
          "level_019": {
            "a": 679669,
            "b": "ZOREF",
            "e": [
              ",FOE",
              ",FOR",
              ",FRO",
              ",ORE",
              ",REF",
              ",FROZE"
            ]
          },
          "level_020": {
            "a": 679668,
            "b": "ELYITAR",
            "e": [
              ",ALERT",
              ",ALTER",
              ",EARLY",
              ",IRATE",
              ",LAITY",
              ",LATER",
              ",LAYER",
              ",LITER",
              ",RELAY",
              ",TEARY",
              ",TRAIL",
              ",TRIAL"
            ]
          }
        },
        "m": 8997376,
        "o": 34047,
        "r": 8997376,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 16740096,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      }
    }
  },
  "WS 10": {
    "a": "WOODS",
    "b": "grad_white",
    "c": "grp_forest",
    "d": 0.75,
    "e": 634893,
    "f": 48013,
    "sets": {
      "set_1": {
        "a": "RAY",
        "aa": 634893,
        "d": "bg_woodland1.jpg",
        "dd": 634893,
        "e": 0.2,
        "j": 634893,
        "l": 634893,
        "levels": {
          "level_001": {
            "a": 679816,
            "b": "NHKIGT",
            "e": [
              ",HINT",
              ",KING",
              ",KNIT",
              ",NIGH",
              ",THIN",
              ",NIGHT",
              ",THING",
              ",THINK"
            ]
          },
          "level_002": {
            "a": 679817,
            "b": "RBYALE",
            "e": [
              ",ABLE",
              "B,ABLY",
              ",BALE",
              ",BARE",
              ",BEAR",
              ",EARL",
              ",LYRE",
              ",REAL",
              ",RELY",
              ",YEAR"
            ]
          },
          "level_003": {
            "a": 679821,
            "b": "OABTB",
            "e": [
              ",BAT",
              "B,BOA",
              ",BOB",
              ",BOT",
              ",OAT",
              ",TAB",
              ",ABBOT"
            ]
          },
          "level_004": {
            "a": 679814,
            "b": "SAORRWP",
            "e": [
              ",PROW",
              "B,RASP",
              ",ROAR",
              ",SOAP",
              ",SOAR",
              ",SPAR",
              ",SWAP",
              ",WARP",
              ",WASP",
              ",WRAP",
              ",SPARROW"
            ]
          },
          "level_005": {
            "a": 679812,
            "b": "SYMAE",
            "e": [
              ",AYE",
              ",MAY",
              ",SAY",
              ",SEA",
              ",YAM",
              ",YEA",
              ",YES",
              ",EASY",
              ",MESA",
              ",SAME",
              ",SEAM",
              ",SEAMY"
            ]
          },
          "level_006": {
            "a": 679818,
            "b": "SREUUN",
            "e": [
              ",RUNE",
              ",RUSE",
              ",SURE",
              ",USER",
              ",UNSURE"
            ]
          },
          "level_007": {
            "a": 679825,
            "b": "LSPEA",
            "e": [
              ",LEAP",
              ",PALE",
              ",PEAL",
              ",PLEA",
              ",SALE",
              ",SEAL",
              ",SLAP",
              ",LAPSE"
            ]
          },
          "level_008": {
            "a": 679823,
            "b": "DLIMIP",
            "e": [
              ",LIMP",
              ",MILD",
              ",LIPID",
              ",LIMPID"
            ]
          },
          "level_009": {
            "a": 679811,
            "b": "OCYDME",
            "e": [
              ",CODE",
              "B,COED",
              ",COME",
              ",DEMO",
              ",DOME",
              ",MODE",
              ",DECOY",
              ",COMEDY"
            ]
          },
          "level_010": {
            "a": 679815,
            "b": "VREUONS",
            "e": [
              ",NURSE",
              ",ROUSE",
              ",SERVO",
              ",SNORE",
              ",NERVOUS"
            ]
          },
          "level_011": {
            "a": 679809,
            "b": "LEALQYU",
            "e": [
              ",ALLEY",
              ",EQUAL",
              ",QUELL",
              ",EQUALLY"
            ]
          },
          "level_012": {
            "a": 679820,
            "b": "IYEALNV",
            "e": [
              ",ALIEN",
              ",ALIVE",
              ",ANVIL",
              ",INLAY",
              ",LIVEN",
              ",NAIVE",
              ",NAVEL",
              ",VENAL",
              ",VINYL"
            ]
          },
          "level_013": {
            "a": 679826,
            "b": "SPRUN",
            "e": [
              ",PUN",
              ",PUS",
              ",RUN",
              ",SUN",
              ",SUP",
              ",UPS",
              ",URN",
              ",SPUN",
              ",SPUR"
            ]
          },
          "level_014": {
            "a": 679827,
            "b": "PRLIAL",
            "e": [
              ",LAIR",
              "B,LIAR",
              ",PAIL",
              ",PAIR",
              ",PALL",
              ",PILL",
              ",RAIL",
              ",PILLAR"
            ]
          },
          "level_015": {
            "a": 679808,
            "b": "RAEDD",
            "e": [
              ",ADD",
              ",ARE",
              ",DAD",
              ",EAR",
              ",ERA",
              ",RAD",
              ",RED",
              ",ADDER",
              ",DARED",
              ",DREAD"
            ]
          },
          "level_016": {
            "a": 679822,
            "b": "ENEGAT",
            "e": [
              ",ANTE",
              ",GATE",
              ",GENE",
              ",GENT",
              ",GNAT",
              ",NEAT",
              ",TANG",
              ",TEEN",
              ",NEGATE"
            ]
          },
          "level_017": {
            "a": 679810,
            "b": "RTUERPU",
            "e": [
              ",ERR",
              ",PER",
              ",PET",
              ",PUT",
              ",REP",
              ",RUE",
              ",RUT",
              ",RUPTURE"
            ]
          },
          "level_018": {
            "a": 679819,
            "b": "NOSUFCE",
            "e": [
              ",CONE",
              ",FUSE",
              ",NOSE",
              ",ONCE",
              ",ONUS",
              ",FOCUS",
              ",OUNCE",
              ",SCONE",
              ",CONFUSE"
            ]
          },
          "level_019": {
            "a": 679813,
            "b": "IRSTFOE",
            "e": [
              ",FIRST",
              ",FORTE",
              ",FRIES",
              ",FROST",
              ",STORE",
              ",TRIES"
            ]
          },
          "level_020": {
            "a": 679824,
            "b": "PLCKREI",
            "e": [
              ",CLERK",
              ",PERIL",
              ",PRICE",
              ",PRICK",
              ",RELIC",
              ",PICKER",
              "B,PICKLE",
              ",PRICKLE"
            ]
          }
        },
        "m": 617485,
        "o": 50687,
        "r": 617485,
        "t": 0.6,
        "u": 16580605,
        "v": 634893,
        "y": 0.52,
        "z": 16580605
      },
      "set_2": {
        "a": "AZURE",
        "aa": 438829,
        "bb": 16777215,
        "d": "bg_woodland2.jpg",
        "dd": 438829,
        "e": 0.2,
        "j": 438829,
        "l": 438829,
        "levels": {
          "level_001": {
            "a": 679947,
            "b": "RINOAD",
            "e": [
              ",ARID",
              "B,DARN",
              ",IRON",
              ",RAID",
              ",RAIN",
              ",RIND",
              ",ROAD",
              ",ROAN"
            ]
          },
          "level_002": {
            "a": 679954,
            "b": "OYDGUH",
            "e": [
              ",DOG",
              ",DUG",
              ",DUH",
              ",DUO",
              ",GOD",
              ",GUY",
              ",HOG",
              ",HUG",
              ",UGH",
              ",YOU",
              ",DOUGHY"
            ]
          },
          "level_003": {
            "a": 679961,
            "b": "NOASIB",
            "e": [
              ",BIAS",
              ",SNOB",
              ",BASIN",
              ",BISON"
            ]
          },
          "level_004": {
            "a": 679957,
            "b": "LEPORP",
            "e": [
              ",LOPE",
              "B,LORE",
              ",PLOP",
              ",POLE",
              ",POPE",
              ",PORE",
              ",PREP",
              ",PROP",
              ",REPO",
              ",ROLE",
              ",ROPE",
              ",PROPEL"
            ]
          },
          "level_005": {
            "a": 679959,
            "b": "MENNELI",
            "e": [
              ",EEL",
              ",ELM",
              ",INN",
              ",LIE",
              ",MEN",
              ",MIL",
              ",NIL",
              ",LINEN"
            ]
          },
          "level_006": {
            "a": 679946,
            "b": "CARAOTB",
            "e": [
              ",BOAR",
              ",BOAT",
              ",BRAT",
              ",CARB",
              ",CART",
              ",COAT",
              ",CRAB",
              ",ORCA",
              ",TACO"
            ]
          },
          "level_007": {
            "a": 679962,
            "b": "EDTCEF",
            "e": [
              ",FED",
              ",FEE",
              ",TEE",
              ",CEDE",
              ",DEFT",
              ",FEED",
              ",FEET",
              ",FETE"
            ]
          },
          "level_008": {
            "a": 679944,
            "b": "ESTRPE",
            "e": [
              ",RESET",
              ",SPREE",
              ",STEEP",
              ",STEER",
              ",STREP",
              ",TERSE",
              ",PESTER",
              ",PRESET"
            ]
          },
          "level_009": {
            "a": 679953,
            "b": "YECRM",
            "e": [
              ",CRY",
              "B,REM",
              ",RYE",
              ",MERCY"
            ]
          },
          "level_010": {
            "a": 679950,
            "b": "RTGNVAA",
            "e": [
              ",ANT",
              "B,ART",
              ",NAG",
              ",RAG",
              ",RAN",
              ",RAT",
              ",TAG",
              ",TAN",
              ",TAR",
              ",VAN",
              ",VAT",
              ",VAGRANT"
            ]
          },
          "level_011": {
            "a": 679958,
            "b": "CMEHES",
            "e": [
              ",HEM",
              ",SEE",
              ",SHE",
              ",MESH",
              ",SEEM",
              ",SCHEME"
            ]
          },
          "level_012": {
            "a": 679949,
            "b": "ASIELLD",
            "e": [
              ",AISLE",
              ",ASIDE",
              ",IDEAL",
              ",LADLE",
              ",SLIDE",
              ",ALLIED",
              ",ALLIES",
              ",LADIES",
              ",SAILED",
              ",DALLIES"
            ]
          },
          "level_013": {
            "a": 679955,
            "b": "NGVEERE",
            "e": [
              ",EVE",
              ",GEE",
              ",GENRE",
              ",GREEN",
              ",NERVE",
              ",NEVER",
              ",VERGE",
              ",REVENGE"
            ]
          },
          "level_014": {
            "a": 679956,
            "b": "OMHBYEO",
            "e": [
              ",BOOM",
              ",HOBO",
              ",HOME",
              ",OBEY",
              ",OBOE",
              ",HOMEY"
            ]
          },
          "level_015": {
            "a": 679951,
            "b": "RDEEEG",
            "e": [
              ",DEER",
              ",EDGE",
              ",REED",
              ",EDGER",
              ",GREED"
            ]
          },
          "level_016": {
            "a": 679963,
            "b": "SKYETHC",
            "e": [
              ",CYST",
              ",ETCH",
              ",SECT",
              ",TECH",
              ",THEY",
              ",SCYTHE",
              "B,SKETCH",
              ",SKETCHY"
            ]
          },
          "level_017": {
            "a": 679960,
            "b": "VLOTESN",
            "e": [
              ",NOVEL",
              "B,ONSET",
              ",SOLVE",
              ",STOLE",
              ",STONE",
              ",STOVE",
              ",STOLEN",
              ",SOLVENT"
            ]
          },
          "level_018": {
            "a": 679945,
            "b": "INYDEK",
            "e": [
              ",DENY",
              ",DIKE",
              ",DINE",
              ",DINK",
              ",INKY",
              ",KIND",
              ",DINKY",
              ",INKED"
            ]
          },
          "level_019": {
            "a": 679948,
            "b": "TERREAC",
            "e": [
              ",CAREER",
              ",CRATER",
              ",CREATE",
              ",TRACER"
            ]
          },
          "level_020": {
            "a": 679952,
            "b": "CKHERO",
            "e": [
              ",COKE",
              ",CORE",
              ",CORK",
              ",ECHO",
              ",HERO",
              ",HOCK",
              ",ROCK",
              ",CHORE",
              ",OCHER",
              ",OCHRE",
              ",CHOKER"
            ]
          }
        },
        "m": 422930,
        "o": 3655952,
        "r": 422930,
        "t": 0.62,
        "u": 0,
        "v": 438829,
        "y": 0.7000000000000001,
        "z": 0
      },
      "set_3": {
        "a": "RISE",
        "aa": 308557,
        "d": "bg_woodland3.jpg",
        "dd": 308557,
        "e": 0.2,
        "g": 0.79,
        "j": 308557,
        "l": 308557,
        "levels": {
          "level_001": {
            "a": 680075,
            "b": "UFTLASE",
            "e": [
              ",FALSE",
              "B,FAULT",
              ",FEAST",
              ",FETAL",
              ",FLUTE",
              ",LEAST",
              ",SLATE",
              ",STALE",
              ",STEAL"
            ]
          },
          "level_002": {
            "a": 680076,
            "b": "IEGALN",
            "e": [
              ",GAIN",
              ",GALE",
              ",GLEN",
              ",LAIN",
              ",LANE",
              ",LEAN",
              ",LIEN",
              ",LINE",
              ",NAIL",
              ",GENIAL"
            ]
          },
          "level_003": {
            "a": 680071,
            "b": "INIUSEC",
            "e": [
              ",NICE",
              ",SINE",
              ",SINCE",
              ",CUISINE"
            ]
          },
          "level_004": {
            "a": 680072,
            "b": "ARINETG",
            "e": [
              ",EATING",
              "B,GAINER",
              ",GARNET",
              ",GRATIN",
              ",RATING",
              ",REGAIN",
              ",RETAIN",
              ",RETINA",
              ",TRIAGE"
            ]
          },
          "level_005": {
            "a": 680077,
            "b": "MMUIINM",
            "e": [
              ",MUM",
              ",UMM",
              ",MINI",
              ",MINIMUM"
            ]
          },
          "level_006": {
            "a": 680069,
            "b": "ENACNEP",
            "e": [
              ",ACNE",
              "B,CANE",
              ",CAPE",
              ",NAPE",
              ",PACE",
              ",PANE",
              ",PENANCE"
            ]
          },
          "level_007": {
            "a": 680073,
            "b": "SAMRH",
            "e": [
              ",ARM",
              ",ASH",
              ",HAM",
              ",HAS",
              ",MAR",
              ",RAM",
              ",HARM",
              ",MASH",
              ",RASH",
              ",SHAM",
              ",MARSH"
            ]
          },
          "level_008": {
            "a": 680079,
            "b": "EUCSOLP",
            "e": [
              ",CLOSE",
              "B,COPSE",
              ",COUPE",
              ",LOCUS",
              ",LOUSE",
              ",PULSE",
              ",SCOPE",
              ",SLOPE"
            ]
          },
          "level_009": {
            "a": 680083,
            "b": "TKSAL",
            "e": [
              ",LAST",
              ",SALT",
              ",SLAT",
              ",TALK",
              ",TASK"
            ]
          },
          "level_010": {
            "a": 680066,
            "b": "EOVMRE",
            "e": [
              ",EVER",
              ",MERE",
              ",MORE",
              ",MOVE",
              ",OVER",
              ",ROVE",
              ",VEER",
              ",MOVER",
              ",REMOVE"
            ]
          },
          "level_011": {
            "a": 680068,
            "b": "VEDITR",
            "e": [
              ",DIET",
              ",DIRE",
              ",DIRT",
              ",DIVE",
              ",EDIT",
              ",RIDE",
              ",RITE",
              ",TIDE",
              ",TIED",
              ",TIER",
              ",TIRE",
              ",VIED"
            ]
          },
          "level_012": {
            "a": 680074,
            "b": "SPINHUG",
            "e": [
              ",SUING",
              ",USING",
              ",GUNSHIP",
              ",PUSHING"
            ]
          },
          "level_013": {
            "a": 680085,
            "b": "ATSETE",
            "e": [
              ",EASE",
              ",EAST",
              ",SEAT",
              ",STAT",
              ",TEST",
              ",STATE",
              "B,TASTE",
              ",TEASE",
              ",ESTATE"
            ]
          },
          "level_014": {
            "a": 680084,
            "b": "COFFTU",
            "e": [
              ",COT",
              ",CUT",
              ",OFF",
              ",OFT",
              ",OUT",
              ",CUFF",
              ",TOFU",
              ",CUTOFF"
            ]
          },
          "level_015": {
            "a": 680081,
            "b": "ECHAP",
            "e": [
              ",ACE",
              ",APE",
              ",CAP",
              ",PEA",
              ",CHEAP",
              ",PEACH"
            ]
          },
          "level_016": {
            "a": 680070,
            "b": "ATLBU",
            "e": [
              ",ALT",
              ",BAT",
              ",BUT",
              ",LAB",
              ",LAT",
              ",TAB",
              ",TAU",
              ",TUB",
              ",ABUT",
              ",TUBA",
              ",TUBAL"
            ]
          },
          "level_017": {
            "a": 680078,
            "b": "IRITPS",
            "e": [
              ",ITS",
              ",PIT",
              ",RIP",
              ",SIP",
              ",SIR",
              ",SIT",
              ",TIP",
              ",TIS",
              ",STRIP",
              ",SPIRIT"
            ]
          },
          "level_018": {
            "a": 680080,
            "b": "ESIKCL",
            "e": [
              ",ISLE",
              ",LICE",
              ",LICK",
              ",LIKE",
              ",SICK",
              ",SILK",
              ",SLICE",
              ",SLICK",
              ",SICKLE"
            ]
          },
          "level_019": {
            "a": 680082,
            "b": "DIOVREC",
            "e": [
              ",COD",
              "B,DOC",
              ",DOE",
              ",ICE",
              ",IRE",
              ",ODE",
              ",ORE",
              ",RED",
              ",RID",
              ",ROD",
              ",VIE",
              ",VOICED"
            ]
          },
          "level_020": {
            "a": 680067,
            "b": "IAYTRGF",
            "e": [
              ",FAIRY",
              ",GRAFT",
              ",RATIFY",
              ",GRATIFY"
            ]
          }
        },
        "m": 293685,
        "o": 15488838,
        "r": 293685,
        "t": 0.78,
        "v": 308557,
        "w": 16777215,
        "y": 0.78
      },
      "set_4": {
        "a": "BROOK",
        "aa": 178285,
        "bb": 16777215,
        "d": "bg_woodland4.jpg",
        "dd": 178285,
        "e": 0.2,
        "j": 178285,
        "l": 178285,
        "levels": {
          "level_001": {
            "a": 680197,
            "b": "YRCA",
            "e": [
              ",ARC",
              "B,CAR",
              ",CAY",
              ",CRY",
              ",RAY",
              ",RACY"
            ]
          },
          "level_002": {
            "a": 680202,
            "b": "RRLYSU",
            "e": [
              ",SLY",
              ",SLUR",
              ",SURLY",
              ",SLURRY"
            ]
          },
          "level_003": {
            "a": 680200,
            "b": "NRATEHO",
            "e": [
              ",ATONE",
              "B,EARTH",
              ",HATER",
              ",HEART",
              ",HERON",
              ",NORTH",
              ",OTHER",
              ",TENOR",
              ",THORN",
              ",TONER"
            ]
          },
          "level_004": {
            "a": 680203,
            "b": "VEDGERI",
            "e": [
              ",DIRGE",
              ",DIVER",
              ",DRIVE",
              ",EDGER",
              ",GIVER",
              ",GREED",
              ",RIDGE",
              ",VERGE",
              ",DIVERGE",
              "B,GRIEVED"
            ]
          },
          "level_005": {
            "a": 680189,
            "b": "CGLAEOL",
            "e": [
              ",CELLO",
              ",LEGAL",
              ",LOCAL",
              ",LOCALE",
              ",COLLAGE"
            ]
          },
          "level_006": {
            "a": 680198,
            "b": "ILEOGBD",
            "e": [
              ",BILGE",
              ",GLIDE",
              ",GLOBE",
              ",LODGE",
              ",OILED",
              ",BOILED",
              ",OBLIGE",
              ",OBLIGED"
            ]
          },
          "level_007": {
            "a": 680195,
            "b": "NYEJO",
            "e": [
              ",JOY",
              ",ONE",
              ",YEN",
              ",YON",
              ",ENJOY"
            ]
          },
          "level_008": {
            "a": 680185,
            "b": "ORCNDO",
            "e": [
              ",CORD",
              ",CORN",
              ",DOOR",
              ",ODOR",
              ",CONDO",
              ",CROON",
              ",DONOR",
              ",CONDOR",
              ",CORDON"
            ]
          },
          "level_009": {
            "a": 680199,
            "b": "ASESPL",
            "e": [
              ",LEAP",
              ",LESS",
              ",PALE",
              ",PEAL",
              ",PLEA",
              ",SALE",
              ",SEAL",
              ",SLAP"
            ]
          },
          "level_010": {
            "a": 680194,
            "b": "OSHTOE",
            "e": [
              ",HOOT",
              ",HOSE",
              ",HOST",
              ",SHOE",
              ",SHOO",
              ",SHOT",
              ",SOOT",
              ",ETHOS",
              ",SHOOT",
              ",SOOTH",
              ",THOSE",
              ",SOOTHE"
            ]
          },
          "level_011": {
            "a": 680187,
            "b": "MYIAFN",
            "e": [
              ",AIM",
              "B,ANY",
              ",FAN",
              ",FIN",
              ",MAN",
              ",MAY",
              ",NAY",
              ",YAM",
              ",YIN",
              ",INFAMY"
            ]
          },
          "level_012": {
            "a": 680196,
            "b": "AVRBTES",
            "e": [
              ",AVERT",
              ",BASTE",
              ",BEAST",
              ",BRAVE",
              ",SABER",
              ",SABRE",
              ",SAVER",
              ",STARE",
              ",STAVE",
              ",BRAVEST"
            ]
          },
          "level_013": {
            "a": 680192,
            "b": "EDAPLDD",
            "e": [
              ",ADDED",
              ",PALED",
              ",PEDAL",
              ",PLEAD",
              ",ADDLED",
              ",PADDED",
              ",PADDLE",
              ",PADDLED"
            ]
          },
          "level_014": {
            "a": 680190,
            "b": "DSBEIED",
            "e": [
              ",BIDE",
              ",DEED",
              ",DIED",
              ",SEED",
              ",SIDE",
              ",BESIDE",
              "B,EDDIES",
              ",BEDSIDE"
            ]
          },
          "level_015": {
            "a": 680184,
            "b": "ORTAHT",
            "e": [
              ",HART",
              ",OATH",
              ",TART",
              ",THAT",
              ",TORT",
              ",TROT",
              ",TAROT",
              ",THROAT"
            ]
          },
          "level_016": {
            "a": 680191,
            "b": "MRLAAOD",
            "e": [
              ",DORM",
              ",DRAM",
              ",LARD",
              ",LOAD",
              ",LOAM",
              ",LORD",
              ",MOLD",
              ",ORAL",
              ",ROAD",
              ",ROAM",
              ",AMORAL",
              ",ARMLOAD"
            ]
          },
          "level_017": {
            "a": 680201,
            "b": "ECAROPM",
            "e": [
              ",CAMEO",
              ",CAPER",
              ",CRAMP",
              ",CREAM",
              ",MACRO",
              ",OPERA",
              ",RECAP",
              ",CAMPER"
            ]
          },
          "level_018": {
            "a": 680193,
            "b": "ICCATL",
            "e": [
              ",TAIL",
              "B,TALC",
              ",CACTI",
              ",LACTIC"
            ]
          },
          "level_019": {
            "a": 680186,
            "b": "POSTR",
            "e": [
              ",PORT",
              ",POST",
              ",SORT",
              ",SPOT",
              ",STOP"
            ]
          },
          "level_020": {
            "a": 680188,
            "b": "NPIOTO",
            "e": [
              ",INTO",
              ",ONTO",
              ",PINT",
              ",TOON",
              ",PINOT",
              ",PINTO",
              ",POINT",
              ",OPTION",
              ",POTION"
            ]
          }
        },
        "m": 162137,
        "r": 16777215,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 178285,
        "w": 16777215,
        "y": 0.58,
        "z": 0
      },
      "set_5": {
        "a": "LEAF",
        "aa": 48013,
        "bb": 16777215,
        "d": "bg_woodland5.jpg",
        "dd": 48013,
        "e": 0.2,
        "j": 48013,
        "l": 48013,
        "levels": {
          "level_001": {
            "a": 680361,
            "b": "IMDEILF",
            "e": [
              ",FIELD",
              ",FILED",
              ",FILMED",
              ",MIDLIFE"
            ]
          },
          "level_002": {
            "a": 680362,
            "b": "UTNDO",
            "e": [
              ",DON",
              "B,DOT",
              ",DUN",
              ",DUO",
              ",NOD",
              ",NOT",
              ",NUT",
              ",OUT",
              ",TON",
              ",DONUT"
            ]
          },
          "level_003": {
            "a": 680365,
            "b": "NNCAFEI",
            "e": [
              ",ACNE",
              "B,CAFE",
              ",CANE",
              ",FACE",
              ",FINE",
              ",NICE",
              ",NINE",
              ",FINANCE"
            ]
          },
          "level_004": {
            "a": 680363,
            "b": "RENELT",
            "e": [
              ",LEER",
              ",LENT",
              ",REEL",
              ",RENT",
              ",TEEN",
              ",TERN",
              ",TREE",
              ",RELENT"
            ]
          },
          "level_005": {
            "a": 680356,
            "b": "WIDMIFE",
            "e": [
              ",DEW",
              ",DIM",
              ",FED",
              ",FEW",
              ",MID",
              ",WED",
              ",DIME",
              ",WIDE",
              ",WIFE"
            ]
          },
          "level_006": {
            "a": 680359,
            "b": "HCNIUR",
            "e": [
              ",CHI",
              ",CUR",
              ",RUN",
              ",URN",
              ",CHIN",
              ",INCH",
              ",RICH",
              ",RUIN",
              ",CHURN",
              "B,INCUR"
            ]
          },
          "level_007": {
            "a": 680358,
            "b": "NERETAL",
            "e": [
              ",ALERT",
              ",ALTER",
              ",EATEN",
              ",EATER",
              ",ENTER",
              ",LATER",
              ",LEARN",
              ",RENAL"
            ]
          },
          "level_008": {
            "a": 680355,
            "b": "SHSVILA",
            "e": [
              ",SISAL",
              "B,SLASH",
              ",LAVISH",
              ",SLAVISH"
            ]
          },
          "level_009": {
            "a": 680357,
            "b": "HMTCA",
            "e": [
              ",ACT",
              ",CAM",
              ",CAT",
              ",HAM",
              ",HAT",
              ",MAT",
              ",CHAT",
              ",MATH"
            ]
          },
          "level_010": {
            "a": 680352,
            "b": "HYELT",
            "e": [
              ",HEY",
              "B,LET",
              ",LYE",
              ",THE",
              ",THY",
              ",YET",
              ",THEY",
              ",ETHYL"
            ]
          },
          "level_011": {
            "a": 680348,
            "b": "NOEECVN",
            "e": [
              ",CONE",
              ",COVE",
              ",EVEN",
              ",NEON",
              ",NONE",
              ",ONCE",
              ",OVEN"
            ]
          },
          "level_012": {
            "a": 680364,
            "b": "RULME",
            "e": [
              ",ELM",
              ",EMU",
              ",REM",
              ",RUE",
              ",RUM",
              ",LURE",
              ",MULE",
              ",RULE",
              ",LEMUR"
            ]
          },
          "level_013": {
            "a": 680353,
            "b": "BROWRO",
            "e": [
              ",BOO",
              ",BOW",
              ",BRO",
              ",ORB",
              ",ROB",
              ",ROW",
              ",WOO",
              ",BROW"
            ]
          },
          "level_014": {
            "a": 680346,
            "b": "BGEARD",
            "e": [
              ",BADGE",
              ",BARED",
              ",BARGE",
              ",BEARD",
              ",BREAD",
              ",GRADE",
              ",RAGED",
              ",BADGER",
              ",BARGED",
              ",GARBED"
            ]
          },
          "level_015": {
            "a": 680360,
            "b": "CEISRU",
            "e": [
              ",CURE",
              ",RICE",
              ",RISE",
              ",RUSE",
              ",SIRE",
              ",SURE",
              ",USER",
              ",CRIES",
              ",CURSE"
            ]
          },
          "level_016": {
            "a": 680349,
            "b": "HVOACNY",
            "e": [
              ",ACHY",
              ",AHOY",
              ",CYAN",
              ",NAVY",
              ",NOVA",
              ",HAVOC",
              "B,NACHO",
              ",ANCHOVY"
            ]
          },
          "level_017": {
            "a": 680354,
            "b": "AIINVLL",
            "e": [
              ",AIL",
              ",ALL",
              ",ILL",
              ",NIL",
              ",VAN",
              ",VIA",
              ",LAIN",
              ",NAIL",
              ",VAIN",
              ",VIAL"
            ]
          },
          "level_018": {
            "a": 680347,
            "b": "ESEUCD",
            "e": [
              ",CUE",
              ",DUE",
              ",SEE",
              ",SUE",
              ",USE",
              ",DEUCE",
              ",SUEDE"
            ]
          },
          "level_019": {
            "a": 680351,
            "b": "BRIBA",
            "e": [
              ",AIR",
              ",BAR",
              ",BIB",
              ",BRA",
              ",RIB",
              ",BARB"
            ]
          },
          "level_020": {
            "a": 680350,
            "b": "TAYLOLT",
            "e": [
              ",ALLY",
              ",ALTO",
              ",TALL",
              ",TOLL",
              ",ALLOY",
              ",ATOLL",
              ",LOYAL",
              ",TALLY",
              ",TOTAL"
            ]
          }
        },
        "m": 30554,
        "o": 16752897,
        "r": 30554,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 48013,
        "y": 0.6,
        "z": 0
      }
    }
  },
  "WS 11": {
    "a": "CELESTIAL",
    "b": "grad_white",
    "c": "grp_sunrise",
    "d": 0.75,
    "e": 12209907,
    "f": 16601734,
    "j": 0.81,
    "sets": {
      "set_1": {
        "a": "COSMO",
        "aa": 12209907,
        "bb": 16777215,
        "d": "bg_celestial1.jpg",
        "dd": 12209907,
        "e": 0,
        "j": 12209907,
        "l": 12209907,
        "levels": {
          "level_001": {
            "a": 680487,
            "b": "AARELDY",
            "e": [
              ",ALDER",
              "B,DELAY",
              ",EARLY",
              ",LAYER",
              ",READY",
              ",RELAY",
              ",DEARLY",
              ",ALREADY"
            ]
          },
          "level_002": {
            "a": 680491,
            "b": "TUEAP",
            "e": [
              ",PATE",
              "B,PEAT",
              ",TAPE",
              ",TAUPE"
            ]
          },
          "level_003": {
            "a": 680482,
            "b": "EGRDSSI",
            "e": [
              ",DIRGE",
              ",DRESS",
              ",DRIES",
              ",RIDGE"
            ]
          },
          "level_004": {
            "a": 680485,
            "b": "HAURRTE",
            "e": [
              ",EARTH",
              ",HATER",
              ",HEART",
              ",RATER",
              ",TERRA",
              ",TRUER",
              ",RATHER",
              ",URETHRA"
            ]
          },
          "level_005": {
            "a": 680490,
            "b": "ETTRAID",
            "e": [
              ",AIRED",
              ",IRATE",
              ",RATED",
              ",TIRED",
              ",TRADE",
              ",TRAIT",
              ",TREAD",
              ",TREAT",
              ",TRIAD",
              ",TRIED",
              ",TRITE"
            ]
          },
          "level_006": {
            "a": 680497,
            "b": "NDOLAU",
            "e": [
              ",DUAL",
              ",LAND",
              ",LAUD",
              ",LOAD",
              ",LOAN",
              ",LOUD",
              ",UNDO",
              ",ALOUD",
              "B,NODAL"
            ]
          },
          "level_007": {
            "a": 680480,
            "b": "TISADM",
            "e": [
              ",AMID",
              ",MAID",
              ",MAST",
              ",MIST",
              ",SAID",
              ",ADMIT",
              ",MIDST",
              ",STAID"
            ]
          },
          "level_008": {
            "a": 680496,
            "b": "SCHNUTA",
            "e": [
              ",CHANT",
              ",HAUNT",
              ",SCANT",
              ",SHUNT",
              ",SNATCH",
              ",STANCH"
            ]
          },
          "level_009": {
            "a": 680479,
            "b": "ESUMO",
            "e": [
              ",MUSE",
              ",SOME",
              ",SUMO",
              ",MOUSE"
            ]
          },
          "level_010": {
            "a": 680492,
            "b": "SSBDIEU",
            "e": [
              ",BIDE",
              ",SIDE",
              ",SUDS",
              ",SUED",
              ",USED",
              ",BUSED",
              ",BUSES",
              ",ISSUE",
              ",BUSIED",
              ",ISSUED"
            ]
          },
          "level_011": {
            "a": 680486,
            "b": "REFEREE",
            "e": [
              ",ERR",
              ",FEE",
              ",REF",
              ",FREE",
              ",REEF",
              ",FREER",
              ",REFER",
              ",REEFER",
              ",REFEREE"
            ]
          },
          "level_012": {
            "a": 680493,
            "b": "TASLBA",
            "e": [
              ",ABS",
              ",ALT",
              ",BAS",
              ",BAT",
              ",LAB",
              ",LAT",
              ",SAT",
              ",TAB",
              ",ATLAS",
              ",BALSA",
              ",BASAL",
              ",BLAST"
            ]
          },
          "level_013": {
            "a": 680488,
            "b": "ROOANHP",
            "e": [
              ",HARP",
              ",HOOP",
              ",HORN",
              ",POOR",
              ",ROAN",
              ",APRON",
              ",ORPHAN",
              ",HARPOON"
            ]
          },
          "level_014": {
            "a": 680489,
            "b": "STSSIAB",
            "e": [
              ",BAIT",
              ",BIAS",
              ",SASS",
              ",STAB",
              ",BASIS",
              ",ASSIST",
              ",STASIS",
              ",BASSIST"
            ]
          },
          "level_015": {
            "a": 680481,
            "b": "CGEADR",
            "e": [
              ",ACE",
              "B,AGE",
              ",ARC",
              ",ARE",
              ",CAD",
              ",CAR",
              ",EAR",
              ",ERA",
              ",RAD",
              ",RAG",
              ",RED",
              ",GRACED"
            ]
          },
          "level_016": {
            "a": 680478,
            "b": "BYOHCTL",
            "e": [
              ",BLOT",
              ",BOLT",
              ",BOTH",
              ",CLOT",
              ",COLT",
              ",HOLY",
              ",BOTCH",
              ",CLOTH",
              ",HOTLY",
              ",BLOTCHY"
            ]
          },
          "level_017": {
            "a": 680495,
            "b": "PAATLSH",
            "e": [
              ",HALT",
              ",LASH",
              ",LAST",
              ",PAST",
              ",PATH",
              ",SALT",
              ",SLAP",
              ",SLAT",
              ",SPAT"
            ]
          },
          "level_018": {
            "a": 680484,
            "b": "DREDDEG",
            "e": [
              ",EDGED",
              "B,EDGER",
              ",GREED",
              ",DREDGE"
            ]
          },
          "level_019": {
            "a": 680494,
            "b": "ISTR",
            "e": [
              ",ITS",
              "B,SIR",
              ",SIT",
              ",TIS",
              ",STIR"
            ]
          },
          "level_020": {
            "a": 680483,
            "b": "THOSLCP",
            "e": [
              ",COP",
              ",COT",
              ",HOP",
              ",HOT",
              ",LOT",
              ",OPS",
              ",OPT",
              ",POT",
              ",SOP",
              ",TOP",
              ",SPLOTCH"
            ]
          }
        },
        "m": 6946935,
        "o": 28671,
        "r": 9240655,
        "t": 0.6,
        "v": 12209907,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      },
      "set_2": {
        "a": "LUNA",
        "aa": 13586687,
        "d": "bg_celestial2.jpg",
        "dd": 13586687,
        "e": 0.1,
        "j": 14373052,
        "l": 14373052,
        "levels": {
          "level_001": {
            "a": 680614,
            "b": "EERIDD",
            "e": [
              ",DEED",
              ",DEER",
              ",DIED",
              ",DIRE",
              ",REED",
              ",RIDE"
            ]
          },
          "level_002": {
            "a": 680620,
            "b": "DRYWOAA",
            "e": [
              ",AWAY",
              ",AWRY",
              ",DRAW",
              ",ROAD",
              ",WARD",
              ",WARY",
              ",WORD",
              ",YARD",
              ",AWARD",
              ",DOWRY",
              ",ROWDY",
              ",WORDY"
            ]
          },
          "level_003": {
            "a": 680625,
            "b": "VRPIY",
            "e": [
              ",IVY",
              "B,PRY",
              ",RIP",
              ",PRIVY"
            ]
          },
          "level_004": {
            "a": 680616,
            "b": "DLEECBI",
            "e": [
              ",BED",
              ",BEE",
              ",BID",
              ",EEL",
              ",ICE",
              ",LED",
              ",LID",
              ",LIE",
              ",BELIED",
              ",EDIBLE",
              ",DECIBEL"
            ]
          },
          "level_005": {
            "a": 680623,
            "b": "UTYTOR",
            "e": [
              ",OUR",
              ",OUT",
              ",ROT",
              ",RUT",
              ",TOT",
              ",TOY",
              ",TRY",
              ",YOU",
              ",TRYOUT"
            ]
          },
          "level_006": {
            "a": 680630,
            "b": "DGLIETH",
            "e": [
              ",EIGHT",
              ",GLIDE",
              ",LEGIT",
              ",LIGHT",
              ",LITHE",
              ",TILED",
              ",DELIGHT",
              ",LIGHTED"
            ]
          },
          "level_007": {
            "a": 680619,
            "b": "FMREOR",
            "e": [
              ",FORE",
              ",FORM",
              ",FROM",
              ",MORE",
              ",FORMER",
              ",REFORM"
            ]
          },
          "level_008": {
            "a": 680618,
            "b": "SRNNIPE",
            "e": [
              ",INNER",
              "B,PRIES",
              ",RESIN",
              ",RINSE",
              ",RIPEN",
              ",RISEN",
              ",SIREN",
              ",SNIPE",
              ",SPINE",
              ",SPIRE",
              ",SPINNER"
            ]
          },
          "level_009": {
            "a": 680628,
            "b": "ONTIPY",
            "e": [
              ",INTO",
              ",PINT",
              ",PITY",
              ",PONY",
              ",TINY",
              ",TYPO",
              ",PINOT",
              "B,PINTO",
              ",POINT"
            ]
          },
          "level_010": {
            "a": 680629,
            "b": "ORFAV",
            "e": [
              ",FAR",
              ",FOR",
              ",FRO",
              ",OAR",
              ",OVA",
              ",AFRO",
              ",FORA",
              ",FAVOR"
            ]
          },
          "level_011": {
            "a": 680624,
            "b": "SOTSEON",
            "e": [
              ",NET",
              ",NOT",
              ",ONE",
              ",SET",
              ",SON",
              ",TEN",
              ",TOE",
              ",TON",
              ",TOO",
              ",SOONEST"
            ]
          },
          "level_012": {
            "a": 680631,
            "b": "URIGALF",
            "e": [
              ",FAIL",
              ",FAIR",
              ",FLAG",
              ",GIRL",
              ",GULF",
              ",LAIR",
              ",LIAR",
              ",RAIL",
              ",FLAIR",
              "B,FRAIL",
              ",GRAIL",
              ",FRUGAL"
            ]
          },
          "level_013": {
            "a": 680615,
            "b": "ROSPE",
            "e": [
              ",PORE",
              ",POSE",
              ",REPO",
              ",ROPE",
              ",ROSE",
              ",SORE",
              ",PROSE",
              "B,SPORE"
            ]
          },
          "level_014": {
            "a": 680621,
            "b": "REQSUTE",
            "e": [
              ",QUEER",
              "B,QUEST",
              ",RESET",
              ",REUSE",
              ",STEER",
              ",TERSE"
            ]
          },
          "level_015": {
            "a": 680622,
            "b": "NTEDFOS",
            "e": [
              ",NOSED",
              ",NOTED",
              ",OFTEN",
              ",ONSET",
              ",STONE",
              ",TONED"
            ]
          },
          "level_016": {
            "a": 680613,
            "b": "PUDELER",
            "e": [
              ",ELDER",
              ",ELUDE",
              ",LEPER",
              ",LURED",
              ",PRUDE",
              ",PUREE",
              ",REPEL",
              ",RULED",
              ",PUREED"
            ]
          },
          "level_017": {
            "a": 680627,
            "b": "OCEAM",
            "e": [
              ",ACME",
              ",CAME",
              ",CAMO",
              ",COMA",
              ",COME",
              ",MACE"
            ]
          },
          "level_018": {
            "a": 680626,
            "b": "UDSNBTI",
            "e": [
              ",BIND",
              ",BUNT",
              ",BUST",
              ",DINT",
              ",DUST",
              ",SNUB",
              ",STUB",
              ",STUD",
              ",STUN",
              ",SUIT",
              ",UNIT"
            ]
          },
          "level_019": {
            "a": 680617,
            "b": "SREKIT",
            "e": [
              ",SKIER",
              ",SKIRT",
              ",TRIES",
              ",TRIKE"
            ]
          },
          "level_020": {
            "a": 680612,
            "b": "TEUAYB",
            "e": [
              ",ABUT",
              ",BEAT",
              ",BEAU",
              ",BETA",
              ",BYTE",
              ",TUBA",
              ",TUBE",
              ",BEAUTY"
            ]
          }
        },
        "m": 9382258,
        "o": 28671,
        "r": 9382258,
        "t": 0.6,
        "v": 13979903,
        "w": 16777215,
        "y": 0.6,
        "z": 16777212
      },
      "set_3": {
        "a": "STRATO",
        "aa": 16601734,
        "d": "bg_celestial3.jpg",
        "dd": 16601734,
        "e": 0.1,
        "j": 16601734,
        "l": 16601734,
        "levels": {
          "level_001": {
            "a": 680750,
            "b": "VIEGAS",
            "e": [
              ",GAVE",
              ",GIVE",
              ",SAGE",
              ",SAVE",
              ",VASE",
              ",VISA",
              ",VISE",
              ",VISAGE"
            ]
          },
          "level_002": {
            "a": 680765,
            "b": "ABCORWR",
            "e": [
              ",BOAR",
              ",BROW",
              ",CARB",
              ",CRAB",
              ",CROW",
              ",ORCA",
              ",ROAR",
              ",CROWBAR"
            ]
          },
          "level_003": {
            "a": 680755,
            "b": "ABURUN",
            "e": [
              ",BAN",
              ",BAR",
              ",BRA",
              ",BUN",
              ",NAB",
              ",NUB",
              ",RAN",
              ",RUB",
              ",RUN",
              ",URN",
              ",AUBURN"
            ]
          },
          "level_004": {
            "a": 680761,
            "b": "ELBRAG",
            "e": [
              ",BAGEL",
              ",BARGE",
              ",BLARE",
              ",GABLE",
              ",GLARE",
              ",LAGER",
              ",LARGE",
              ",REGAL"
            ]
          },
          "level_005": {
            "a": 680766,
            "b": "NGLUOED",
            "e": [
              ",GLUED",
              ",LODGE",
              ",LUNGE",
              ",NUDGE",
              ",OLDEN",
              ",GOLDEN",
              "B,LONGED",
              ",LOUNGE",
              ",LUNGED"
            ]
          },
          "level_006": {
            "a": 680768,
            "b": "ATELT",
            "e": [
              ",LATE",
              ",TALE",
              ",TEAL",
              ",LATTE"
            ]
          },
          "level_007": {
            "a": 680756,
            "b": "EMILPA",
            "e": [
              ",AMPLE",
              "B,EMAIL",
              ",MAPLE",
              ",IMPALE"
            ]
          },
          "level_008": {
            "a": 680753,
            "b": "EPEYPPR",
            "e": [
              ",PEEP",
              ",PEER",
              ",PREP",
              ",PREY",
              ",PYRE",
              ",PEPPY",
              ",PEPPER",
              "B,PREPPY",
              ",PEPPERY"
            ]
          },
          "level_009": {
            "a": 680752,
            "b": "GBIGEI",
            "e": [
              ",BEG",
              ",BIG",
              ",EGG",
              ",GIG",
              ",BIGGIE"
            ]
          },
          "level_010": {
            "a": 680763,
            "b": "FIAFEGR",
            "e": [
              ",AFIRE",
              "B,GAFFE",
              ",GRIEF",
              ",GIRAFFE"
            ]
          },
          "level_011": {
            "a": 680764,
            "b": "LDEVI",
            "e": [
              ",DELI",
              ",DIVE",
              ",EVIL",
              ",IDLE",
              ",LIED",
              ",LIVE",
              ",VEIL",
              ",VIED",
              ",VILE"
            ]
          },
          "level_012": {
            "a": 680767,
            "b": "INMALMA",
            "e": [
              ",AIL",
              ",AIM",
              ",LAM",
              ",MAM",
              ",MAN",
              ",MIL",
              ",NIL",
              ",ANIMA",
              ",MANIA",
              ",ANIMAL",
              ",MAILMAN"
            ]
          },
          "level_013": {
            "a": 680760,
            "b": "TAERUM",
            "e": [
              ",MARE",
              ",MART",
              ",MATE",
              ",MEAT",
              ",MUTE",
              ",RATE",
              ",TAME",
              ",TEAM",
              ",TEAR",
              ",TERM",
              ",TRAM",
              ",TRUE"
            ]
          },
          "level_014": {
            "a": 680754,
            "b": "WPRDEAN",
            "e": [
              ",DRAPE",
              ",DRAWN",
              ",PADRE",
              ",PARED",
              ",PAWED",
              ",PRAWN",
              ",WANED",
              ",PREDAWN"
            ]
          },
          "level_015": {
            "a": 680762,
            "b": "REWRKO",
            "e": [
              ",WOKE",
              ",WORE",
              ",WORK",
              ",REWORK",
              ",WORKER"
            ]
          },
          "level_016": {
            "a": 680757,
            "b": "BKALLYN",
            "e": [
              ",ABLY",
              ",ALLY",
              ",BALK",
              ",BALL",
              ",BANK",
              ",LANK",
              ",YANK",
              ",BALKY",
              ",BLANK",
              ",LANKY"
            ]
          },
          "level_017": {
            "a": 680758,
            "b": "ODULYL",
            "e": [
              ",DOLL",
              ",DULL",
              ",DULY",
              ",LOUD",
              ",DOLLY",
              ",DULLY"
            ]
          },
          "level_018": {
            "a": 680759,
            "b": "SNLIEG",
            "e": [
              ",GLEN",
              "B,ISLE",
              ",LENS",
              ",LIEN",
              ",LINE",
              ",SIGN",
              ",SINE",
              ",SING",
              ",SINGLE"
            ]
          },
          "level_019": {
            "a": 680769,
            "b": "DDDSALE",
            "e": [
              ",DALE",
              "B,DEAD",
              ",DEAL",
              ",LEAD",
              ",SALE",
              ",SEAL",
              ",SLED",
              ",ADDED"
            ]
          },
          "level_020": {
            "a": 680751,
            "b": "ETUCTSL",
            "e": [
              ",CLUE",
              ",CULT",
              ",CUTE",
              ",LEST",
              ",LUST",
              ",LUTE",
              ",SECT",
              ",TEST",
              ",CUTEST",
              ",CUTLET"
            ]
          }
        },
        "m": 9240655,
        "o": 57599,
        "r": 9240655,
        "t": 0.8,
        "v": 16601734,
        "y": 0.8
      },
      "set_4": {
        "a": "POLAR",
        "aa": 16601734,
        "d": "bg_celestial4.jpg",
        "dd": 16601734,
        "e": 0.1,
        "j": 16601734,
        "l": 16601734,
        "levels": {
          "level_001": {
            "a": 680881,
            "b": "UGLIT",
            "e": [
              ",GIT",
              ",GUT",
              ",LIT",
              ",LUG",
              ",TIL",
              ",TUG",
              ",GILT",
              "B,GLUT",
              ",GUILT"
            ]
          },
          "level_002": {
            "a": 680890,
            "b": "IVTMEOE",
            "e": [
              ",EMIT",
              ",ITEM",
              ",MEET",
              ",MITE",
              ",MOTE",
              ",MOVE",
              ",OMIT",
              ",TIME",
              ",TOME",
              ",VETO",
              ",VOTE",
              ",MOTIVE"
            ]
          },
          "level_003": {
            "a": 680884,
            "b": "HUTSXAE",
            "e": [
              ",EAST",
              ",HATE",
              ",HEAT",
              ",SEAT",
              ",SHUT",
              ",THUS",
              ",TUSH",
              ",HASTE",
              ",TAXES"
            ]
          },
          "level_004": {
            "a": 680882,
            "b": "SMSPOOU",
            "e": [
              ",MOO",
              ",MOP",
              ",OPS",
              ",PUS",
              ",SOP",
              ",SUM",
              ",SUP",
              ",UPS",
              ",POSSUM",
              ",OPOSSUM"
            ]
          },
          "level_005": {
            "a": 680886,
            "b": "VSEREE",
            "e": [
              ",EVE",
              ",SEE",
              ",EVER",
              ",SEER",
              ",VEER",
              ",SERVE",
              ",SEVER",
              ",VERSE",
              ",SEVERE"
            ]
          },
          "level_006": {
            "a": 680889,
            "b": "MACKS",
            "e": [
              ",ASK",
              ",CAM",
              ",SAC",
              ",CASK",
              ",MASK",
              ",SACK",
              ",SCAM",
              ",SMACK"
            ]
          },
          "level_007": {
            "a": 680876,
            "b": "EFEELB",
            "e": [
              ",BEE",
              ",EEL",
              ",ELF",
              ",FEE",
              ",BEEF",
              ",FEEL",
              ",FLEE",
              ",FEEBLE"
            ]
          },
          "level_008": {
            "a": 680874,
            "b": "GUTEON",
            "e": [
              ",GENT",
              ",GONE",
              ",GOUT",
              ",NOTE",
              ",TONE",
              ",TONG",
              ",TUNE",
              ",UNTO"
            ]
          },
          "level_009": {
            "a": 680891,
            "b": "ONFFEEC",
            "e": [
              ",CONE",
              "B,ONCE",
              ",FENCE",
              ",COFFEE"
            ]
          },
          "level_010": {
            "a": 680875,
            "b": "EVDTU",
            "e": [
              ",DUE",
              "B,VET",
              ",DUET",
              ",DUVET"
            ]
          },
          "level_011": {
            "a": 680887,
            "b": "RUSEFF",
            "e": [
              ",FUSE",
              ",RUSE",
              ",SURE",
              ",SURF",
              ",USER"
            ]
          },
          "level_012": {
            "a": 680883,
            "b": "TYATCLI",
            "e": [
              ",ATTIC",
              ",CATTY",
              ",LAITY",
              ",TACIT"
            ]
          },
          "level_013": {
            "a": 680873,
            "b": "DOPNU",
            "e": [
              ",DON",
              ",DUN",
              ",DUO",
              ",NOD",
              ",POD",
              ",PUN",
              ",POND",
              ",UNDO",
              ",UPON",
              ",POUND"
            ]
          },
          "level_014": {
            "a": 680878,
            "b": "CEIYTRF",
            "e": [
              ",CITE",
              "B,CITY",
              ",FIRE",
              ",FRET",
              ",RICE",
              ",RIFE",
              ",RIFT",
              ",RITE",
              ",TIER",
              ",TIRE",
              ",YETI"
            ]
          },
          "level_015": {
            "a": 680880,
            "b": "VRTIAGY",
            "e": [
              ",AIRY",
              ",ARTY",
              ",GAIT",
              ",GRAY",
              ",GRIT",
              ",TRAY",
              ",VARY",
              ",GRAVY"
            ]
          },
          "level_016": {
            "a": 680872,
            "b": "RRGCEO",
            "e": [
              ",COG",
              ",EGO",
              ",ERR",
              ",ORE",
              ",CORE",
              ",GORE",
              ",OGRE",
              ",GROCER"
            ]
          },
          "level_017": {
            "a": 680877,
            "b": "FANTI",
            "e": [
              ",AFT",
              ",ANT",
              ",FAN",
              ",FAT",
              ",FIN",
              ",FIT",
              ",NIT",
              ",TAN",
              ",TIN",
              ",FAINT"
            ]
          },
          "level_018": {
            "a": 680888,
            "b": "NIOSUN",
            "e": [
              ",INN",
              ",ION",
              ",NUN",
              ",SIN",
              ",SON",
              ",SUN",
              ",NOUN",
              "B,ONUS",
              ",UNION",
              ",UNISON"
            ]
          },
          "level_019": {
            "a": 680879,
            "b": "EVPRAPO",
            "e": [
              ",OPERA",
              ",PAPER",
              ",PROVE",
              ",VAPOR"
            ]
          },
          "level_020": {
            "a": 680885,
            "b": "NEMOAYR",
            "e": [
              ",MANOR",
              "B,MAYOR",
              ",MONEY",
              ",MORAY",
              ",RAYON",
              ",ROMAN",
              ",YEARN",
              ",YEOMAN",
              ",ANYMORE"
            ]
          }
        },
        "m": 9240655,
        "o": 57599,
        "r": 9240655,
        "t": 0.8,
        "v": 16601734,
        "y": 0.8
      },
      "set_5": {
        "a": "SOLIS",
        "aa": 16601734,
        "d": "bg_celestial5.jpg",
        "dd": 16601734,
        "e": 0.1,
        "j": 16601734,
        "l": 16601734,
        "levels": {
          "level_001": {
            "a": 681017,
            "b": "WIPLLO",
            "e": [
              ",ILL",
              ",LIP",
              ",LOW",
              ",OIL",
              ",OWL",
              ",POW",
              ",PILL",
              ",PLOW",
              ",POLL",
              ",WILL"
            ]
          },
          "level_002": {
            "a": 681012,
            "b": "ELAMAIB",
            "e": [
              ",AIL",
              ",AIM",
              ",ALE",
              ",BAM",
              ",ELM",
              ",LAB",
              ",LAM",
              ",LIE",
              ",MIL",
              ",AMBLE",
              ",BLAME",
              ",EMAIL"
            ]
          },
          "level_003": {
            "a": 681002,
            "b": "DLHAO",
            "e": [
              ",ADO",
              ",HAD",
              ",LAD",
              ",OLD",
              ",HALO",
              ",HOLD",
              ",LOAD",
              ",AHOLD"
            ]
          },
          "level_004": {
            "a": 681016,
            "b": "LEDDDUE",
            "e": [
              ",DEED",
              ",DUDE",
              ",DUEL",
              ",ELUDE",
              ",DELUDE",
              "B,DUELED",
              ",ELUDED",
              ",DELUDED"
            ]
          },
          "level_005": {
            "a": 681003,
            "b": "YTOMSL",
            "e": [
              ",LOT",
              ",SLY",
              ",SOY",
              ",TOY",
              ",LOST",
              "B,MOLT",
              ",MOST",
              ",SLOT",
              ",MOSTLY"
            ]
          },
          "level_006": {
            "a": 681018,
            "b": "NATSG",
            "e": [
              ",GNAT",
              ",SANG",
              ",SNAG",
              ",STAG",
              ",TANG"
            ]
          },
          "level_007": {
            "a": 681013,
            "b": "ODEB",
            "e": [
              ",BED",
              "B,BOD",
              ",DOE",
              ",ODE",
              ",BODE"
            ]
          },
          "level_008": {
            "a": 681008,
            "b": "SPMRIEL",
            "e": [
              ",MISER",
              ",PERIL",
              ",PRIES",
              ",PRIME",
              ",PRISM",
              ",SLIME",
              ",SMILE",
              ",SPERM",
              ",SPIRE",
              ",SIMPLE",
              ",SIMPLER"
            ]
          },
          "level_009": {
            "a": 681005,
            "b": "OGLALN",
            "e": [
              ",AGO",
              ",ALL",
              ",GAL",
              ",LAG",
              ",LOG",
              ",NAG",
              ",GALL",
              ",GOAL",
              ",LOAN",
              ",LONG",
              ",ALONG",
              ",ANGLO"
            ]
          },
          "level_010": {
            "a": 681000,
            "b": "NLTPAEY",
            "e": [
              ",APTLY",
              ",LEAPT",
              ",PANEL",
              ",PANTY",
              ",PENAL",
              ",PETAL",
              ",PLANE",
              ",PLANT",
              ",PLATE",
              ",NEATLY",
              ",PLANET",
              ",PLENTY"
            ]
          },
          "level_011": {
            "a": 681011,
            "b": "UARLT",
            "e": [
              ",ALT",
              ",ART",
              ",LAT",
              ",RAT",
              ",RUT",
              ",TAR",
              ",TAU",
              ",ULTRA"
            ]
          },
          "level_012": {
            "a": 681019,
            "b": "ILESVN",
            "e": [
              ",EVIL",
              "B,ISLE",
              ",LENS",
              ",LIEN",
              ",LINE",
              ",LIVE",
              ",SINE",
              ",VEIL",
              ",VEIN",
              ",VILE",
              ",VINE",
              ",VISE"
            ]
          },
          "level_013": {
            "a": 681009,
            "b": "YAWANY",
            "e": [
              ",ANY",
              ",NAW",
              ",NAY",
              ",WAY",
              ",AWAY",
              "B,YAWN",
              ",ANYWAY"
            ]
          },
          "level_014": {
            "a": 681006,
            "b": "WKDYORE",
            "e": [
              ",DOWRY",
              "B,ROWDY",
              ",ROWED",
              ",WORDY",
              ",WORKED"
            ]
          },
          "level_015": {
            "a": 681010,
            "b": "IGNAML",
            "e": [
              ",GAIN",
              ",GLAM",
              ",LAIN",
              ",MAIL",
              ",MAIN",
              ",NAIL"
            ]
          },
          "level_016": {
            "a": 681007,
            "b": "OURGETM",
            "e": [
              ",GROUT",
              ",METRO",
              ",OUTER",
              ",ROGUE",
              ",ROUGE",
              ",ROUTE",
              ",MORGUE",
              ",GOURMET"
            ]
          },
          "level_017": {
            "a": 681004,
            "b": "TNDRSA",
            "e": [
              ",DARN",
              ",DART",
              ",RANT",
              ",SAND",
              ",STAR",
              ",STAND"
            ]
          },
          "level_018": {
            "a": 681014,
            "b": "TBOUAIL",
            "e": [
              ",ABOUT",
              ",BLOAT",
              ",BUILT",
              ",TUBAL"
            ]
          },
          "level_019": {
            "a": 681001,
            "b": "DEURG",
            "e": [
              ",DRUG",
              ",RUDE",
              ",URGE",
              ",URGED"
            ]
          },
          "level_020": {
            "a": 681015,
            "b": "RIATENL",
            "e": [
              ",ANTLER",
              ",ENTAIL",
              ",LINEAR",
              ",RENTAL",
              ",RETAIL",
              ",RETAIN",
              ",RETINA",
              ",LATRINE",
              ",RELIANT",
              ",RETINAL"
            ]
          }
        },
        "m": 9240655,
        "o": 57599,
        "r": 9240655,
        "t": 0.8,
        "v": 16601734,
        "y": 0.8
      }
    }
  },
  "WS 12": {
    "a": "FOG",
    "b": "grad_white",
    "c": "grp_winter",
    "d": 0.6,
    "e": 41193,
    "f": 4151011,
    "sets": {
      "set_1": {
        "a": "WOOD",
        "aa": 41193,
        "bb": 16777215,
        "d": "bg_fog1.jpg",
        "dd": 41193,
        "e": 0.1,
        "j": 41193,
        "l": 41193,
        "levels": {
          "level_001": {
            "a": 681122,
            "b": "ESAIST",
            "e": [
              ",ATE",
              ",EAT",
              ",ITS",
              ",SAT",
              ",SEA",
              ",SET",
              ",SIS",
              ",SIT",
              ",TEA",
              ",TIE",
              ",TIS",
              ",ASSET"
            ]
          },
          "level_002": {
            "a": 681120,
            "b": "SEULBT",
            "e": [
              ",BELT",
              ",BEST",
              ",BLUE",
              ",BUST",
              ",LEST",
              ",LUBE",
              ",LUST",
              ",LUTE",
              ",STUB",
              ",TUBE",
              ",BUSTLE",
              ",SUBTLE"
            ]
          },
          "level_003": {
            "a": 681128,
            "b": "SLEEV",
            "e": [
              ",EEL",
              ",EVE",
              ",SEE",
              ",ELVES"
            ]
          },
          "level_004": {
            "a": 681112,
            "b": "CCDOONR",
            "e": [
              ",COCO",
              ",CORD",
              ",CORN",
              ",CROC",
              ",DOOR",
              ",ODOR",
              ",CONDO",
              ",CROON",
              ",DONOR",
              ",CONDOR",
              ",CORDON"
            ]
          },
          "level_005": {
            "a": 681119,
            "b": "TILLS",
            "e": [
              ",LILT",
              "B,LIST",
              ",SILL",
              ",SILT",
              ",SLIT",
              ",TILL"
            ]
          },
          "level_006": {
            "a": 681124,
            "b": "NATRIST",
            "e": [
              ",SAINT",
              ",SATIN",
              ",STAIN",
              ",STAIR",
              ",START",
              ",STINT",
              ",TAINT",
              ",TITAN",
              ",TRAIN",
              ",TRAIT"
            ]
          },
          "level_007": {
            "a": 681116,
            "b": "NSDIIER",
            "e": [
              ",DINER",
              "B,DRIES",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SIREN",
              ",SNIDE",
              ",INSIDER"
            ]
          },
          "level_008": {
            "a": 681114,
            "b": "EIESTRL",
            "e": [
              ",ELITE",
              ",ISLET",
              ",LITER",
              ",RESET",
              ",SLEET",
              ",STEEL",
              ",STEER",
              ",TERSE",
              ",TRIES",
              ",RELIES",
              ",STERILE"
            ]
          },
          "level_009": {
            "a": 681129,
            "b": "GHNIT",
            "e": [
              ",GIN",
              ",GIT",
              ",HIT",
              ",NIT",
              ",TIN",
              ",HINT",
              ",NIGH",
              ",THIN",
              ",NIGHT",
              "B,THING"
            ]
          },
          "level_010": {
            "a": 681127,
            "b": "PALESSH",
            "e": [
              ",HASSLE",
              ",LASHES",
              ",PASSEL",
              ",SPLASH",
              ",HAPLESS"
            ]
          },
          "level_011": {
            "a": 681117,
            "b": "EOSTRER",
            "e": [
              ",REST",
              ",ROSE",
              ",ROTE",
              ",SEER",
              ",SORE",
              ",SORT",
              ",TORE",
              ",TREE"
            ]
          },
          "level_012": {
            "a": 681126,
            "b": "TINKER",
            "e": [
              ",KITE",
              "B,KNIT",
              ",REIN",
              ",RENT",
              ",RINK",
              ",RITE",
              ",TERN",
              ",TIER",
              ",TINE",
              ",TIRE",
              ",TREK",
              ",TINKER"
            ]
          },
          "level_013": {
            "a": 681113,
            "b": "HMOCA",
            "e": [
              ",CAMO",
              ",COMA",
              ",MACHO",
              "B,MOCHA"
            ]
          },
          "level_014": {
            "a": 681115,
            "b": "BBAUTHT",
            "e": [
              ",ABUT",
              ",BATH",
              ",BUTT",
              ",TAUT",
              ",THAT",
              ",TUBA",
              ",BATHTUB"
            ]
          },
          "level_015": {
            "a": 681125,
            "b": "FOPRO",
            "e": [
              ",FOR",
              ",FRO",
              ",PRO",
              ",POOF",
              ",POOR",
              ",ROOF"
            ]
          },
          "level_016": {
            "a": 681118,
            "b": "NDYARGL",
            "e": [
              ",ANGRY",
              ",GLAND",
              ",GNARL",
              ",GRAND",
              ",RANDY",
              ",RANGY",
              ",GNARLY",
              ",GRANDLY"
            ]
          },
          "level_017": {
            "a": 681121,
            "b": "PSTHA",
            "e": [
              ",PAST",
              ",PATH",
              ",SPAT",
              ",STAPH"
            ]
          },
          "level_018": {
            "a": 681123,
            "b": "OEUYLG",
            "e": [
              ",GLUE",
              "B,LUGE",
              ",OGLE",
              ",UGLY",
              ",EULOGY"
            ]
          },
          "level_019": {
            "a": 681111,
            "b": "TIHSES",
            "e": [
              ",SITE",
              ",THIS",
              ",HEIST",
              ",THESIS"
            ]
          },
          "level_020": {
            "a": 681110,
            "b": "POHEPRW",
            "e": [
              ",HERO",
              ",HOPE",
              ",PHEW",
              ",POPE",
              ",PORE",
              ",PREP",
              ",PROP",
              ",PROW",
              ",REPO",
              ",ROPE",
              ",WORE",
              ",HOPPER"
            ]
          }
        },
        "m": 22957,
        "o": 45048,
        "r": 22957,
        "t": 0.45,
        "u": 0,
        "v": 41193,
        "w": 16777215,
        "y": 0.45,
        "z": 0
      },
      "set_2": {
        "a": "VALLEY",
        "aa": 1019367,
        "bb": 16777215,
        "d": "bg_fog2.jpg",
        "dd": 1019367,
        "e": 0.1,
        "j": 1019367,
        "l": 1019367,
        "levels": {
          "level_001": {
            "a": 681266,
            "b": "LUNOFRG",
            "e": [
              ",FOUL",
              ",FOUR",
              ",FROG",
              ",GOLF",
              ",GULF",
              ",LONG",
              ",LUNG",
              ",RUNG"
            ]
          },
          "level_002": {
            "a": 681271,
            "b": "RUENR",
            "e": [
              ",ERR",
              "B,RUE",
              ",RUN",
              ",URN",
              ",RERUN"
            ]
          },
          "level_003": {
            "a": 681261,
            "b": "EAIWLH",
            "e": [
              ",AIL",
              ",ALE",
              ",AWE",
              ",HEW",
              ",LAW",
              ",LIE",
              ",WHALE",
              "B,WHILE"
            ]
          },
          "level_004": {
            "a": 681268,
            "b": "EARWOVS",
            "e": [
              ",AROSE",
              "B,SAVER",
              ",SAVOR",
              ",SERVO",
              ",SWEAR",
              ",SWORE",
              ",WAVER",
              ",WORSE",
              ",OVERSAW"
            ]
          },
          "level_005": {
            "a": 681257,
            "b": "EDUGF",
            "e": [
              ",DUE",
              ",DUG",
              ",FED",
              ",FUDGE"
            ]
          },
          "level_006": {
            "a": 681262,
            "b": "RABIES",
            "e": [
              ",ARISE",
              ",RAISE",
              ",SABER",
              ",SABRE",
              ",RABIES"
            ]
          },
          "level_007": {
            "a": 681252,
            "b": "EEWDG",
            "e": [
              ",DEW",
              ",EWE",
              ",GEE",
              ",WED",
              ",WEE",
              ",EDGE",
              ",WEED",
              ",WEDGE"
            ]
          },
          "level_008": {
            "a": 681269,
            "b": "EWRASN",
            "e": [
              ",ANEW",
              ",EARN",
              ",NEAR",
              ",SANE",
              ",SEAR",
              ",SEWN",
              ",SWAN",
              ",WANE",
              ",WARN",
              ",WEAN",
              ",WEAR",
              ",WREN"
            ]
          },
          "level_009": {
            "a": 681256,
            "b": "NORHT",
            "e": [
              ",HOT",
              ",NOR",
              ",NOT",
              ",ROT",
              ",TON",
              ",HORN",
              ",TORN",
              ",NORTH",
              ",THORN"
            ]
          },
          "level_010": {
            "a": 681254,
            "b": "OENSTN",
            "e": [
              ",NEON",
              ",NEST",
              ",NONE",
              ",NOSE",
              ",NOTE",
              ",SENT",
              ",SNOT",
              ",TONE",
              ",ONSET",
              ",STONE",
              ",SONNET"
            ]
          },
          "level_011": {
            "a": 681258,
            "b": "DIDASNI",
            "e": [
              ",ADD",
              "B,ADS",
              ",AID",
              ",AND",
              ",DAD",
              ",DID",
              ",DIN",
              ",SAD",
              ",SIN",
              ",DISDAIN"
            ]
          },
          "level_012": {
            "a": 681263,
            "b": "PERSIAD",
            "e": [
              ",ASPIRE",
              ",DIAPER",
              ",PAIRED",
              ",PARSED",
              ",PRAISE",
              ",RAISED",
              ",RASPED",
              ",REPAID",
              ",SPARED",
              ",SPIDER",
              ",SPREAD"
            ]
          },
          "level_013": {
            "a": 681255,
            "b": "LSHFA",
            "e": [
              ",ASH",
              ",HAS",
              ",HALF",
              "B,LASH",
              ",FLASH"
            ]
          },
          "level_014": {
            "a": 681267,
            "b": "IPERM",
            "e": [
              ",MIRE",
              ",PERM",
              ",PIER",
              ",PRIM",
              ",RIPE",
              ",PRIME"
            ]
          },
          "level_015": {
            "a": 681264,
            "b": "MIYTNU",
            "e": [
              ",MINT",
              ",TINY",
              ",UNIT",
              ",MINTY",
              ",UNITY"
            ]
          },
          "level_016": {
            "a": 681260,
            "b": "LTAMEHR",
            "e": [
              ",ALERT",
              ",ALTER",
              ",EARTH",
              ",HAREM",
              ",HATER",
              ",HEART",
              ",LATER",
              ",LATHE",
              ",METAL",
              ",REALM",
              ",TAMER"
            ]
          },
          "level_017": {
            "a": 681253,
            "b": "AWELSE",
            "e": [
              ",EASE",
              ",ELSE",
              ",SALE",
              ",SEAL",
              ",SLAW",
              ",SLEW",
              ",EASEL",
              ",LEASE"
            ]
          },
          "level_018": {
            "a": 681270,
            "b": "ADEPSU",
            "e": [
              ",DUPE",
              ",SPED",
              ",SPUD",
              ",SUED",
              ",USED"
            ]
          },
          "level_019": {
            "a": 681259,
            "b": "BTELTO",
            "e": [
              ",BET",
              ",BOT",
              ",LET",
              ",LOB",
              ",LOT",
              ",TOE",
              ",TOT",
              ",BOTTLE"
            ]
          },
          "level_020": {
            "a": 681265,
            "b": "ACIPNT",
            "e": [
              ",ANTI",
              ",PACT",
              ",PAIN",
              ",PANT",
              ",PINT",
              ",PITA",
              ",ANTIC",
              "B,PAINT",
              ",PANIC",
              ",CATNIP"
            ]
          }
        },
        "m": 22957,
        "o": 45048,
        "r": 22957,
        "t": 0.55,
        "u": 0,
        "v": 1019367,
        "w": 16777215,
        "y": 0.55,
        "z": 0
      },
      "set_3": {
        "a": "LAKE",
        "aa": 2063334,
        "d": "bg_fog3.jpg",
        "dd": 2063334,
        "e": 0.11,
        "j": 2063334,
        "l": 2063334,
        "levels": {
          "level_001": {
            "a": 681399,
            "b": "TPIOA",
            "e": [
              ",APT",
              ",OAT",
              ",OPT",
              ",PAT",
              ",PIT",
              ",POT",
              ",TAP",
              ",TIP",
              ",TOP",
              ",PATIO"
            ]
          },
          "level_002": {
            "a": 681402,
            "b": "AIMTEYD",
            "e": [
              ",ADMIT",
              ",AIMED",
              ",AMITY",
              ",DEITY",
              ",MATED",
              ",MEATY",
              ",MEDIA",
              ",TAMED",
              ",TIMED",
              ",DAYTIME"
            ]
          },
          "level_003": {
            "a": 681386,
            "b": "PHRTGIU",
            "e": [
              ",GRIP",
              ",GRIT",
              ",HURT",
              ",THRU",
              ",THUG",
              ",TRIP",
              ",GIRTH",
              ",RIGHT",
              ",UPRIGHT"
            ]
          },
          "level_004": {
            "a": 681385,
            "b": "TSEINAV",
            "e": [
              ",INVEST",
              ",NATIVE",
              ",NAVIES",
              ",VAINEST"
            ]
          },
          "level_005": {
            "a": 681388,
            "b": "HPSIBO",
            "e": [
              ",BIO",
              ",BOP",
              ",HIP",
              ",HIS",
              ",HOP",
              ",OPS",
              ",PHI",
              ",SIP",
              ",SOB",
              ",SOP",
              ",BISHOP"
            ]
          },
          "level_006": {
            "a": 681396,
            "b": "AONEABL",
            "e": [
              ",ALONE",
              ",BANAL",
              ",NOBLE",
              ",ABALONE"
            ]
          },
          "level_007": {
            "a": 681400,
            "b": "AHMRC",
            "e": [
              ",ARC",
              ",ARM",
              ",CAM",
              ",CAR",
              ",HAM",
              ",MAR",
              ",RAM",
              ",CHARM",
              "B,MARCH"
            ]
          },
          "level_008": {
            "a": 681393,
            "b": "TDENRUE",
            "e": [
              ",ENDURE",
              "B,NEUTER",
              ",RENTED",
              ",TENDER",
              ",TENURE",
              ",TUREEN",
              ",TURNED",
              ",TENURED"
            ]
          },
          "level_009": {
            "a": 681395,
            "b": "OUCPYC",
            "e": [
              ",COP",
              ",COY",
              ",CUP",
              ",YOU",
              ",YUP",
              ",COPY",
              ",COUP",
              ",OCCUPY"
            ]
          },
          "level_010": {
            "a": 681389,
            "b": "EHNCW",
            "e": [
              ",CHEW",
              ",HEWN",
              ",WHEN",
              ",WENCH"
            ]
          },
          "level_011": {
            "a": 681397,
            "b": "SHTEE",
            "e": [
              ",SEE",
              ",SET",
              ",SHE",
              ",TEE",
              ",THE",
              ",THEE",
              ",SHEET",
              "B,THESE"
            ]
          },
          "level_012": {
            "a": 681387,
            "b": "LEYPABA",
            "e": [
              ",ABLE",
              "B,ABLY",
              ",BALE",
              ",LEAP",
              ",PALE",
              ",PEAL",
              ",PLAY",
              ",PLEA",
              ",YELP",
              ",PAYABLE"
            ]
          },
          "level_013": {
            "a": 681392,
            "b": "FLTAA",
            "e": [
              ",AFT",
              ",ALT",
              ",FAT",
              ",LAT",
              ",FATAL"
            ]
          },
          "level_014": {
            "a": 681391,
            "b": "HIATRW",
            "e": [
              ",HAIR",
              ",HART",
              ",THAW",
              ",WAIT",
              ",WART",
              ",WHAT",
              ",WHIR",
              ",WHIT",
              ",WITH",
              ",WRIT"
            ]
          },
          "level_015": {
            "a": 681401,
            "b": "ESENRE",
            "e": [
              ",SEEN",
              ",SEER",
              ",SNEER",
              ",SERENE"
            ]
          },
          "level_016": {
            "a": 681403,
            "b": "ILSETDW",
            "e": [
              ",DWELT",
              ",ISLET",
              ",SITED",
              ",SLIDE",
              ",TILED",
              ",WIELD",
              ",LISTED",
              "B,WIDEST",
              ",WILTED",
              ",WILDEST"
            ]
          },
          "level_017": {
            "a": 681398,
            "b": "OTDRBEU",
            "e": [
              ",BORED",
              ",BRUTE",
              ",DEBUT",
              ",DOUBT",
              ",OUTER",
              ",ROUTE",
              ",TUBED",
              ",TUBER",
              ",TURBO"
            ]
          },
          "level_018": {
            "a": 681394,
            "b": "KENLIAG",
            "e": [
              ",AGILE",
              ",ALIEN",
              ",ALIGN",
              ",ALIKE",
              ",ANGEL",
              ",ANGLE",
              ",ANKLE",
              ",GLEAN",
              ",LIKEN",
              ",GENIAL"
            ]
          },
          "level_019": {
            "a": 681384,
            "b": "CALNBH",
            "e": [
              ",BAH",
              ",BAN",
              ",CAB",
              ",CAN",
              ",LAB",
              ",NAB",
              ",BLAH",
              ",CLAN",
              ",BLANCH"
            ]
          },
          "level_020": {
            "a": 681390,
            "b": "ALENARS",
            "e": [
              ",ARENA",
              "B,LASER",
              ",LEARN",
              ",NASAL",
              ",RENAL",
              ",SANER",
              ",SNARE",
              ",SNARL",
              ",ARSENAL"
            ]
          }
        },
        "m": 22957,
        "o": 52843,
        "r": 22957,
        "t": 0.6,
        "v": 2063334,
        "y": 0.6
      },
      "set_4": {
        "a": "RANGE",
        "aa": 3107044,
        "d": "bg_fog4.jpg",
        "dd": 3107044,
        "e": 0.1,
        "h": "wscapes_snow",
        "j": 3107044,
        "l": 3107044,
        "levels": {
          "level_001": {
            "a": 681509,
            "b": "OEATCN",
            "e": [
              ",ATONE",
              "B,CANOE",
              ",ENACT",
              ",OCEAN"
            ]
          },
          "level_002": {
            "a": 681516,
            "b": "DVAETRN",
            "e": [
              ",AVERT",
              ",RATED",
              ",RAVED",
              ",RAVEN",
              ",TRADE",
              ",TREAD",
              ",TREND",
              ",VERDANT"
            ]
          },
          "level_003": {
            "a": 681518,
            "b": "DIVAO",
            "e": [
              ",AVID",
              ",DIVA",
              ",VOID",
              ",AVOID"
            ]
          },
          "level_004": {
            "a": 681520,
            "b": "ERYOLS",
            "e": [
              ",LORE",
              ",LOSE",
              ",LYRE",
              ",RELY",
              ",ROLE",
              ",ROSE",
              ",ROSY",
              ",SOLE",
              ",SORE",
              ",YORE",
              ",LOSER",
              ",SORELY"
            ]
          },
          "level_005": {
            "a": 681521,
            "b": "TTRAC",
            "e": [
              ",CART",
              ",TACT",
              ",TART",
              ",TRACT"
            ]
          },
          "level_006": {
            "a": 681511,
            "b": "RECETSE",
            "e": [
              ",CREST",
              ",ERECT",
              ",RESET",
              ",SCREE",
              ",STEER",
              ",TERSE"
            ]
          },
          "level_007": {
            "a": 681514,
            "b": "ECBOHTI",
            "e": [
              ",BITE",
              ",BOTH",
              ",CITE",
              ",ECHO",
              ",ETCH",
              ",ITCH",
              ",TECH"
            ]
          },
          "level_008": {
            "a": 681512,
            "b": "LIREPFP",
            "e": [
              ",ELF",
              "B,FIR",
              ",IRE",
              ",LIE",
              ",LIP",
              ",PEP",
              ",PER",
              ",PIE",
              ",REF",
              ",REP",
              ",RIP",
              ",FLIPPER"
            ]
          },
          "level_009": {
            "a": 681519,
            "b": "EHINDB",
            "e": [
              ",BED",
              "B,BID",
              ",BIN",
              ",DEN",
              ",DIN",
              ",END",
              ",HEN",
              ",HID",
              ",BEHIND"
            ]
          },
          "level_010": {
            "a": 681525,
            "b": "NETIS",
            "e": [
              ",NEST",
              "B,SENT",
              ",SINE",
              ",SITE",
              ",TINE"
            ]
          },
          "level_011": {
            "a": 681510,
            "b": "UINLFYL",
            "e": [
              ",FIN",
              ",FLU",
              ",FLY",
              ",FUN",
              ",ILL",
              ",NIL",
              ",YIN",
              ",FILL",
              ",FULL",
              ",LILY",
              ",NULL"
            ]
          },
          "level_012": {
            "a": 681513,
            "b": "URMUOH",
            "e": [
              ",HUM",
              ",OHM",
              ",OUR",
              ",RUM",
              ",HUMOUR"
            ]
          },
          "level_013": {
            "a": 681515,
            "b": "AGADVER",
            "e": [
              ",AGED",
              "B,AREA",
              ",DARE",
              ",DEAR",
              ",DRAG",
              ",GAVE",
              ",GEAR",
              ",GRAD",
              ",RAGE",
              ",RAVE",
              ",READ",
              ",RAVAGED"
            ]
          },
          "level_014": {
            "a": 681507,
            "b": "CCALOMI",
            "e": [
              ",CLAIM",
              ",COMIC",
              ",CALICO",
              ",COMICAL"
            ]
          },
          "level_015": {
            "a": 681523,
            "b": "DLGDEO",
            "e": [
              ",DOLE",
              ",GOLD",
              ",LODE",
              ",OGLE",
              ",LODGED"
            ]
          },
          "level_016": {
            "a": 681524,
            "b": "PREOD",
            "e": [
              ",DOER",
              ",DOPE",
              ",DROP",
              ",PORE",
              ",PROD",
              ",REDO",
              ",REPO",
              ",RODE",
              ",ROPE",
              ",ROPED"
            ]
          },
          "level_017": {
            "a": 681508,
            "b": "IATNMRG",
            "e": [
              ",GIANT",
              ",GRAIN",
              ",GRANT",
              ",TRAIN",
              ",ARMING",
              ",GRATIN",
              ",MARGIN",
              ",MATING",
              ",RATING",
              ",TAMING",
              ",MIGRANT"
            ]
          },
          "level_018": {
            "a": 681506,
            "b": "TRUJIS",
            "e": [
              ",ITS",
              ",JUS",
              ",JUT",
              ",RUT",
              ",SIR",
              ",SIT",
              ",TIS",
              ",JUST",
              ",RUST",
              ",STIR",
              ",SUIT",
              ",JURIST"
            ]
          },
          "level_019": {
            "a": 681517,
            "b": "EASCPIT",
            "e": [
              ",CASTE",
              ",PASTE",
              ",SPACE",
              ",SPATE",
              ",SPICE",
              ",SPITE"
            ]
          },
          "level_020": {
            "a": 681522,
            "b": "FEACDH",
            "e": [
              ",ACED",
              "B,ACHE",
              ",CAFE",
              ",CHAD",
              ",CHEF",
              ",DEAF",
              ",EACH",
              ",FACE",
              ",FADE",
              ",HEAD",
              ",CHAFED"
            ]
          }
        },
        "m": 15506,
        "o": 45048,
        "r": 15506,
        "t": 0.75,
        "v": 3107044,
        "y": 0.7000000000000001
      },
      "set_5": {
        "a": "RIVER",
        "aa": 4151011,
        "d": "bg_fog5.jpg",
        "dd": 4151011,
        "e": 0.1,
        "j": 4151011,
        "l": 4151011,
        "levels": {
          "level_001": {
            "a": 681692,
            "b": "DLTMIIY",
            "e": [
              ",DIM",
              ",LID",
              ",LIT",
              ",MID",
              ",MIL",
              ",TIL",
              ",IDLY",
              ",MILD",
              ",TIDY"
            ]
          },
          "level_002": {
            "a": 681695,
            "b": "CEDMINE",
            "e": [
              ",CEDE",
              "B,DEEM",
              ",DICE",
              ",DIME",
              ",DINE",
              ",ICED",
              ",MEND",
              ",MICE",
              ",MIND",
              ",MINE",
              ",NEED",
              ",NICE"
            ]
          },
          "level_003": {
            "a": 681702,
            "b": "TEYMA",
            "e": [
              ",ATE",
              ",AYE",
              ",EAT",
              ",MAT",
              ",MAY",
              ",MET",
              ",TEA",
              ",YAM",
              ",YEA",
              ",YET",
              ",MEATY"
            ]
          },
          "level_004": {
            "a": 681707,
            "b": "DERREHI",
            "e": [
              ",DRIER",
              ",ERRED",
              ",HIRED",
              ",RIDER",
              ",HERDER",
              ",REHIRED"
            ]
          },
          "level_005": {
            "a": 681694,
            "b": "GMPORAR",
            "e": [
              ",GRAM",
              ",PROM",
              ",RAMP",
              ",ROAM",
              ",ROAR",
              ",ROMP",
              ",ARMOR",
              ",PROGRAM"
            ]
          },
          "level_006": {
            "a": 681708,
            "b": "ITWTCHY",
            "e": [
              ",CHI",
              ",HIT",
              ",ICY",
              ",THY",
              ",TIC",
              ",WHY",
              ",WIT",
              ",ITCHY",
              "B,WITCH",
              ",WITTY",
              ",TWITCHY"
            ]
          },
          "level_007": {
            "a": 681701,
            "b": "CALARI",
            "e": [
              ",AIL",
              ",AIR",
              ",ARC",
              ",CAR",
              ",LAIR",
              "B,LIAR",
              ",RAIL",
              ",RACIAL"
            ]
          },
          "level_008": {
            "a": 681706,
            "b": "CDEOERD",
            "e": [
              ",CEDED",
              ",CODED",
              ",CODER",
              ",CORED",
              ",CREDO",
              ",CREED",
              ",DECOR",
              ",ERODE",
              ",ODDER",
              ",CORDED",
              ",DECODE",
              ",ERODED"
            ]
          },
          "level_009": {
            "a": 681705,
            "b": "EEVTN",
            "e": [
              ",EVE",
              ",NET",
              ",TEE",
              ",TEN",
              ",VET",
              ",EVEN",
              "B,TEEN",
              ",VENT"
            ]
          },
          "level_010": {
            "a": 681697,
            "b": "TUEYNCR",
            "e": [
              ",CENT",
              ",CURE",
              ",CURT",
              ",CUTE",
              ",RENT",
              ",RUNE",
              ",RUNT",
              ",TERN",
              ",TRUE",
              ",TUNE",
              ",TURN",
              ",CENTURY"
            ]
          },
          "level_011": {
            "a": 681710,
            "b": "TBAERR",
            "e": [
              ",BARE",
              ",BEAR",
              ",BEAT",
              ",BETA",
              ",BRAT",
              ",RARE",
              ",RATE",
              ",REAR",
              ",TEAR"
            ]
          },
          "level_012": {
            "a": 681699,
            "b": "NYORA",
            "e": [
              ",NARY",
              ",ROAN",
              ",YARN",
              ",RAYON"
            ]
          },
          "level_013": {
            "a": 681711,
            "b": "EOKNMY",
            "e": [
              ",KEY",
              ",MEN",
              ",ONE",
              ",YEN",
              ",YON",
              ",MONK",
              "B,OMEN",
              ",YOKE",
              ",MONEY",
              ",MONKEY"
            ]
          },
          "level_014": {
            "a": 681703,
            "b": "EYAPSNS",
            "e": [
              ",ASPEN",
              ",ESSAY",
              ",PANSY",
              ",PASSE"
            ]
          },
          "level_015": {
            "a": 681696,
            "b": "GYOLD",
            "e": [
              ",DOG",
              ",GOD",
              ",LOG",
              ",OLD",
              ",GODLY"
            ]
          },
          "level_016": {
            "a": 681704,
            "b": "ELLTSUD",
            "e": [
              ",DUE",
              ",LED",
              ",LET",
              ",SET",
              ",SUE",
              ",USE",
              ",LUSTED",
              ",DULLEST"
            ]
          },
          "level_017": {
            "a": 681698,
            "b": "BEREL",
            "e": [
              ",BEE",
              ",EEL",
              ",BEER",
              "B,LEER",
              ",REEL",
              ",REBEL"
            ]
          },
          "level_018": {
            "a": 681709,
            "b": "DUSABR",
            "e": [
              ",BARD",
              ",DRAB",
              ",DRUB",
              ",ABSURD"
            ]
          },
          "level_019": {
            "a": 681700,
            "b": "CUPLENA",
            "e": [
              ",CLEAN",
              ",LANCE",
              ",PANEL",
              ",PECAN",
              ",PENAL",
              ",PLACE",
              ",PLANE",
              ",UNCLE",
              ",CLEANUP"
            ]
          },
          "level_020": {
            "a": 681693,
            "b": "ANEPTIT",
            "e": [
              ",INEPT",
              ",PAINT",
              ",PETIT",
              ",TAINT",
              ",TITAN",
              ",PATENT"
            ]
          }
        },
        "m": 15506,
        "o": 45048,
        "r": 15506,
        "t": 0.75,
        "v": 4151011,
        "y": 0.75
      }
    }
  },
  "WS 13": {
    "a": "BEACH",
    "b": "grad_white",
    "c": "grp_tropic",
    "d": 1,
    "e": 16763153,
    "f": 16711476,
    "g": 2451,
    "h": 147,
    "i": true,
    "j": 0.45,
    "sets": {
      "set_1": {
        "a": "FRESH",
        "aa": 16763153,
        "cc": 204947,
        "d": "bg_beach1.jpg",
        "dd": 16763153,
        "e": 0.1,
        "ee": 204947,
        "g": 0.93,
        "i": 204947,
        "j": 16763153,
        "k": 204947,
        "l": 16763153,
        "levels": {
          "level_001": {
            "a": 681875,
            "b": "STERGGA",
            "e": [
              ",GRATE",
              ",GREAT",
              ",STAGE",
              ",STARE"
            ]
          },
          "level_002": {
            "a": 681872,
            "b": "MSMDIUE",
            "e": [
              ",MIMED",
              ",MUSED",
              ",MEDIUM",
              ",SUMMED",
              ",DUMMIES"
            ]
          },
          "level_003": {
            "a": 681867,
            "b": "SLBUOE",
            "e": [
              ",BLUE",
              "B,LOBE",
              ",LOSE",
              ",LUBE",
              ",SLOB",
              ",SOLE",
              ",SOUL",
              ",BLOUSE"
            ]
          },
          "level_004": {
            "a": 681865,
            "b": "DDLUALE",
            "e": [
              ",LADLE",
              ",ALLUDE",
              ",DULLED",
              ",LAUDED",
              ",ALLUDED"
            ]
          },
          "level_005": {
            "a": 681876,
            "b": "IAHTINB",
            "e": [
              ",ANTI",
              ",BAIT",
              ",BATH",
              ",HINT",
              ",THAN",
              ",THIN",
              ",HABIT",
              ",TIBIA",
              ",INHABIT"
            ]
          },
          "level_006": {
            "a": 681877,
            "b": "AEBOLNT",
            "e": [
              ",ALONE",
              "B,ATONE",
              ",BATON",
              ",BLOAT",
              ",NOBLE",
              ",TABLE",
              ",TALON",
              ",TONAL"
            ]
          },
          "level_007": {
            "a": 681860,
            "b": "SACDEH",
            "e": [
              ",ACE",
              ",ADS",
              ",ASH",
              ",CAD",
              ",HAD",
              ",HAS",
              ",SAC",
              ",SAD",
              ",SEA",
              ",SHE",
              ",CASHED",
              ",CHASED"
            ]
          },
          "level_008": {
            "a": 681870,
            "b": "ABDLEM",
            "e": [
              ",AMBLE",
              ",BLADE",
              ",BLAME",
              ",LAMED",
              ",MEDAL",
              ",AMBLED",
              ",BEDLAM",
              ",BLAMED"
            ]
          },
          "level_009": {
            "a": 681863,
            "b": "OBOUIVS",
            "e": [
              ",BIO",
              ",BOO",
              ",BUS",
              ",SOB",
              ",SUB",
              ",OBVIOUS"
            ]
          },
          "level_010": {
            "a": 681873,
            "b": "IDVPA",
            "e": [
              ",AID",
              ",DIP",
              ",PAD",
              ",VIA",
              ",AVID",
              ",DIVA",
              ",PAID",
              ",VAPID"
            ]
          },
          "level_011": {
            "a": 681874,
            "b": "NEGRCAA",
            "e": [
              ",ACNE",
              "B,ACRE",
              ",AREA",
              ",CAGE",
              ",CANE",
              ",CARE",
              ",EARN",
              ",GEAR",
              ",NEAR",
              ",RACE",
              ",RAGE",
              ",RANG"
            ]
          },
          "level_012": {
            "a": 681862,
            "b": "GUONTAH",
            "e": [
              ",GAUNT",
              ",GUANO",
              ",HAUNT",
              ",OUGHT",
              ",TANGO",
              ",THONG",
              ",TOUGH"
            ]
          },
          "level_013": {
            "a": 681859,
            "b": "WNLDTEA",
            "e": [
              ",DEALT",
              ",DELTA",
              ",DWELT",
              ",LADEN",
              ",WANED",
              ",DENTAL",
              ",WANTED"
            ]
          },
          "level_014": {
            "a": 681861,
            "b": "INHYDG",
            "e": [
              ",DING",
              ",HIND",
              ",NIGH",
              ",DINGY",
              "B,DYING",
              ",DINGHY"
            ]
          },
          "level_015": {
            "a": 681871,
            "b": "UREBRBY",
            "e": [
              ",BUY",
              ",BYE",
              ",EBB",
              ",ERR",
              ",RUB",
              ",RUE",
              ",RYE",
              ",BERRY",
              "B,BUYER",
              ",RUBBER"
            ]
          },
          "level_016": {
            "a": 681864,
            "b": "SEERTT",
            "e": [
              ",REST",
              ",SEER",
              ",TEST",
              ",TREE",
              ",RESET",
              ",STEER",
              ",TERSE",
              ",RETEST",
              "B,SETTER",
              ",STREET",
              ",TESTER"
            ]
          },
          "level_017": {
            "a": 681868,
            "b": "ATLTNAB",
            "e": [
              ",ALT",
              ",ANT",
              ",BAN",
              ",BAT",
              ",LAB",
              ",LAT",
              ",NAB",
              ",TAB",
              ",TAN",
              ",BANAL"
            ]
          },
          "level_018": {
            "a": 681869,
            "b": "NYNAC",
            "e": [
              ",ANY",
              ",CAN",
              ",CAY",
              ",NAN",
              ",NAY",
              ",CANNY"
            ]
          },
          "level_019": {
            "a": 681866,
            "b": "OCISN",
            "e": [
              ",CON",
              ",ION",
              ",SIN",
              ",SON",
              ",COIN",
              ",ICON",
              ",SCION",
              ",SONIC"
            ]
          },
          "level_020": {
            "a": 681858,
            "b": "EDDSRIE",
            "e": [
              ",DRIED",
              ",DRIES",
              ",SIDED",
              ",DERIDE",
              ",DESIRE",
              ",EDDIES",
              ",RESIDE",
              ",DESIRED",
              ",RESIDED"
            ]
          }
        },
        "m": 10586447,
        "o": 32511,
        "r": 7757884,
        "t": 0.7000000000000001,
        "u": 16777211,
        "v": 16763153,
        "x": 204947,
        "y": 0.7000000000000001,
        "z": 16777211
      },
      "set_2": {
        "a": "SHELL",
        "aa": 16700953,
        "cc": 204947,
        "d": "bg_beach2.jpg",
        "dd": 16700953,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16700953,
        "k": 204947,
        "l": 16700953,
        "levels": {
          "level_001": {
            "a": 682028,
            "b": "ROMDOMU",
            "e": [
              ",DOOM",
              "B,DOOR",
              ",DORM",
              ",DOUR",
              ",DRUM",
              ",MOOD",
              ",MOOR",
              ",ODOR",
              ",ROOM"
            ]
          },
          "level_002": {
            "a": 682037,
            "b": "LASAIM",
            "e": [
              ",AIL",
              ",AIM",
              ",LAM",
              ",MIL",
              ",SIM",
              ",ALMS",
              ",MAIL",
              ",SAIL",
              ",SLAM",
              ",SLIM",
              ",SALAMI"
            ]
          },
          "level_003": {
            "a": 682026,
            "b": "DDEISAD",
            "e": [
              ",AIDE",
              ",DEAD",
              ",DIED",
              ",IDEA",
              ",SAID",
              ",SIDE"
            ]
          },
          "level_004": {
            "a": 682035,
            "b": "FYNTALI",
            "e": [
              ",FAINT",
              ",FINAL",
              ",FLINT",
              ",INLAY",
              ",LAITY",
              ",NIFTY",
              ",FLINTY",
              "B,LITANY"
            ]
          },
          "level_005": {
            "a": 682038,
            "b": "DYEW",
            "e": [
              ",DEW",
              "B,DYE",
              ",WED",
              ",YEW",
              ",DEWY"
            ]
          },
          "level_006": {
            "a": 682022,
            "b": "ONIOLT",
            "e": [
              ",INTO",
              ",LINT",
              ",LION",
              ",LOIN",
              ",LOON",
              ",LOOT",
              ",ONTO",
              ",TOIL",
              ",TOOL",
              ",TOON",
              ",LOTION"
            ]
          },
          "level_007": {
            "a": 682039,
            "b": "JOSLET",
            "e": [
              ",JET",
              ",JOT",
              ",LET",
              ",LOT",
              ",SET",
              ",TOE",
              ",STOLE",
              ",JOSTLE"
            ]
          },
          "level_008": {
            "a": 682025,
            "b": "EDMUATN",
            "e": [
              ",AMEND",
              "B,DATUM",
              ",MATED",
              ",MEANT",
              ",MUTED",
              ",NAMED",
              ",TAMED",
              ",TUNED",
              ",UNMET",
              ",UNTAMED"
            ]
          },
          "level_009": {
            "a": 682027,
            "b": "LAINEH",
            "e": [
              ",HAIL",
              ",HEAL",
              ",LAIN",
              ",LANE",
              ",LEAN",
              ",LIEN",
              ",LINE",
              ",NAIL",
              ",ALIEN"
            ]
          },
          "level_010": {
            "a": 682023,
            "b": "HOINLTE",
            "e": [
              ",HOTEL",
              ",INLET",
              ",LITHE",
              ",THINE"
            ]
          },
          "level_011": {
            "a": 682030,
            "b": "RANHBC",
            "e": [
              ",ARCH",
              ",BARN",
              ",BRAN",
              ",CARB",
              ",CHAR",
              ",CRAB",
              ",RANCH",
              ",BRANCH"
            ]
          },
          "level_012": {
            "a": 682036,
            "b": "TNINAYU",
            "e": [
              ",AUNTY",
              ",TINNY",
              ",UNITY",
              ",ANNUITY"
            ]
          },
          "level_013": {
            "a": 682034,
            "b": "OEOPTSI",
            "e": [
              ",OOPS",
              ",PEST",
              ",POET",
              ",POSE",
              ",POST",
              ",SITE",
              ",SOOT",
              ",SPIT",
              ",SPOT",
              ",STEP",
              ",STOP"
            ]
          },
          "level_014": {
            "a": 682031,
            "b": "LREVEDI",
            "e": [
              ",DELVE",
              "B,DEVIL",
              ",DIVER",
              ",DRIVE",
              ",ELDER",
              ",LEVER",
              ",LIVED",
              ",LIVER",
              ",REVEL",
              ",RILED"
            ]
          },
          "level_015": {
            "a": 682029,
            "b": "MEPRS",
            "e": [
              ",PER",
              ",REM",
              ",REP",
              ",PERM"
            ]
          },
          "level_016": {
            "a": 682033,
            "b": "UERFSTI",
            "e": [
              ",FIRST",
              ",FRIES",
              ",FRUIT",
              ",SUITE",
              ",TRIES",
              ",FURIES",
              ",SIFTER",
              ",STRIFE",
              ",SURFEIT"
            ]
          },
          "level_017": {
            "a": 682024,
            "b": "IRDSDO",
            "e": [
              ",DID",
              ",ODD",
              ",RID",
              ",ROD",
              ",SIR",
              ",SOD",
              ",DROID",
              ",SORDID"
            ]
          },
          "level_018": {
            "a": 682032,
            "b": "IELTRCK",
            "e": [
              ",CLERK",
              ",LITER",
              ",RELIC",
              ",TRICK",
              ",TRIKE",
              ",TICKER",
              ",TICKLE",
              ",TRICKLE"
            ]
          },
          "level_019": {
            "a": 682041,
            "b": "RSYAT",
            "e": [
              ",ART",
              ",RAT",
              ",RAY",
              ",SAT",
              ",SAY",
              ",TAR",
              ",TRY",
              ",ARTY",
              "B,STAR",
              ",STAY",
              ",TRAY"
            ]
          },
          "level_020": {
            "a": 682040,
            "b": "TSRWAHY",
            "e": [
              ",ARTSY",
              ",HASTY",
              ",STRAW",
              ",STRAY",
              ",SWATH",
              ",TRASH",
              ",WRATH",
              ",SWARTHY"
            ]
          }
        },
        "m": 10386765,
        "o": 32511,
        "r": 9730909,
        "t": 0.7000000000000001,
        "v": 16700953,
        "x": 204947,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "WASH",
        "aa": 16704546,
        "cc": 204947,
        "d": "bg_beach3.jpg",
        "dd": 16704546,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16704546,
        "k": 204947,
        "l": 16704546,
        "levels": {
          "level_001": {
            "a": 682196,
            "b": "IKNPSIH",
            "e": [
              ",PINK",
              "B,SHIN",
              ",SHIP",
              ",SINK",
              ",SKIN",
              ",SKIP",
              ",SNIP",
              ",SPIN"
            ]
          },
          "level_002": {
            "a": 682203,
            "b": "CGOYRB",
            "e": [
              ",BOG",
              "B,BOY",
              ",BRO",
              ",COB",
              ",COG",
              ",COY",
              ",CRY",
              ",ORB",
              ",ROB",
              ",GORY"
            ]
          },
          "level_003": {
            "a": 682208,
            "b": "COHTU",
            "e": [
              ",COT",
              ",CUT",
              ",HOT",
              ",HUT",
              ",OUT",
              ",OUCH",
              ",THOU",
              ",TOUCH"
            ]
          },
          "level_004": {
            "a": 682209,
            "b": "DEEORCN",
            "e": [
              ",CODER",
              "B,CORED",
              ",CREDO",
              ",CREED",
              ",CRONE",
              ",DECOR",
              ",DRONE",
              ",ERODE",
              ",RECON"
            ]
          },
          "level_005": {
            "a": 682192,
            "b": "CYCNLOE",
            "e": [
              ",CONE",
              ",LONE",
              ",NOEL",
              ",ONCE",
              ",ONLY",
              ",CLONE",
              ",CYCLE"
            ]
          },
          "level_006": {
            "a": 682191,
            "b": "IEVSAR",
            "e": [
              ",RAVE",
              ",RISE",
              ",SAVE",
              ",SEAR",
              ",SIRE",
              ",VASE",
              ",VISA",
              ",VISE"
            ]
          },
          "level_007": {
            "a": 682195,
            "b": "NCIERG",
            "e": [
              ",GIN",
              ",ICE",
              ",IRE",
              ",RIG",
              ",GRIN",
              ",NICE",
              ",REIN",
              ",RICE",
              ",RING",
              ",NICER",
              ",REIGN"
            ]
          },
          "level_008": {
            "a": 682199,
            "b": "KPUWRO",
            "e": [
              ",OUR",
              ",POW",
              ",PRO",
              ",ROW",
              ",WOK",
              ",PORK",
              "B,POUR",
              ",PROW",
              ",WORK",
              ",WORKUP"
            ]
          },
          "level_009": {
            "a": 682206,
            "b": "DABVRAO",
            "e": [
              ",BOARD",
              "B,BRAVO",
              ",BROAD",
              ",BRAVADO"
            ]
          },
          "level_010": {
            "a": 682205,
            "b": "TSIPL",
            "e": [
              ",ITS",
              ",LIP",
              ",LIT",
              ",PIT",
              ",SIP",
              ",SIT",
              ",TIL",
              ",TIP",
              ",TIS",
              ",SPILT",
              ",SPLIT"
            ]
          },
          "level_011": {
            "a": 682204,
            "b": "GLARN",
            "e": [
              ",GAL",
              ",LAG",
              ",NAG",
              ",RAG",
              ",RAN",
              ",RANG"
            ]
          },
          "level_012": {
            "a": 682194,
            "b": "BULODDE",
            "e": [
              ",BLED",
              ",BLUE",
              ",BODE",
              ",BOLD",
              ",DOLE",
              ",DUDE",
              ",DUEL",
              ",LOBE",
              ",LODE",
              ",LOUD",
              ",LUBE"
            ]
          },
          "level_013": {
            "a": 682207,
            "b": "LCUAES",
            "e": [
              ",CASE",
              ",CLUE",
              ",LACE",
              ",SALE",
              ",SEAL",
              ",CAUSE",
              ",SAUCE",
              ",SCALE",
              ",CLAUSE"
            ]
          },
          "level_014": {
            "a": 682200,
            "b": "SCPROE",
            "e": [
              ",COPSE",
              ",CORPS",
              ",PROSE",
              ",SCOPE",
              ",SCORE",
              ",SPORE"
            ]
          },
          "level_015": {
            "a": 682202,
            "b": "LDIAT",
            "e": [
              ",DIAL",
              ",LAID",
              ",TAIL",
              ",TIDAL"
            ]
          },
          "level_016": {
            "a": 682201,
            "b": "UNNEOD",
            "e": [
              ",DEN",
              ",DOE",
              ",DON",
              ",DUE",
              ",DUN",
              ",DUO",
              ",END",
              ",NOD",
              ",NUN",
              ",ODE",
              ",ONE",
              ",UNDONE"
            ]
          },
          "level_017": {
            "a": 682193,
            "b": "DIOEIN",
            "e": [
              ",DINE",
              "B,DONE",
              ",NODE",
              ",IODINE"
            ]
          },
          "level_018": {
            "a": 682197,
            "b": "IFHTRTY",
            "e": [
              ",RIFT",
              ",THIRTY",
              ",THRIFT",
              ",THRIFTY"
            ]
          },
          "level_019": {
            "a": 682198,
            "b": "PYSCEH",
            "e": [
              ",HEY",
              ",SHE",
              ",SHY",
              ",SPY",
              ",YEP",
              ",YES",
              ",HYPE",
              ",SPEC",
              ",PSYCHE"
            ]
          },
          "level_020": {
            "a": 682190,
            "b": "ETUGNR",
            "e": [
              ",GENT",
              ",RENT",
              ",RUNE",
              ",RUNG",
              ",RUNT",
              ",TERN",
              ",TRUE",
              ",TUNE",
              ",TURN",
              ",URGE"
            ]
          }
        },
        "m": 11174743,
        "o": 32511,
        "r": 9072707,
        "t": 0.75,
        "v": 16704546,
        "x": 204947,
        "y": 0.75
      },
      "set_4": {
        "a": "AQUA",
        "aa": 16707883,
        "bb": 16777215,
        "cc": 204947,
        "d": "bg_beach4.jpg",
        "dd": 16707883,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16707883,
        "k": 204947,
        "l": 16707883,
        "levels": {
          "level_001": {
            "a": 682368,
            "b": "LAOERTD",
            "e": [
              ",ADORE",
              ",ALDER",
              ",ALERT",
              ",ALTER",
              ",DEALT",
              ",DELTA",
              ",LATER",
              ",OLDER",
              ",RATED",
              ",TRADE",
              ",TREAD",
              ",LEOTARD"
            ]
          },
          "level_002": {
            "a": 682363,
            "b": "TELLAW",
            "e": [
              ",LATE",
              "B,TALE",
              ",TALL",
              ",TEAL",
              ",TELL",
              ",WALL",
              ",WELL",
              ",WELT"
            ]
          },
          "level_003": {
            "a": 682364,
            "b": "INBD",
            "e": [
              ",BID",
              ",BIN",
              ",DIN",
              ",BIND"
            ]
          },
          "level_004": {
            "a": 682350,
            "b": "AENCDES",
            "e": [
              ",CEASE",
              ",DANCE",
              ",DENSE",
              ",EASED",
              ",SCENE",
              ",SEDAN",
              ",ASCEND",
              ",CEASED",
              ",SEANCE",
              ",ENCASED"
            ]
          },
          "level_005": {
            "a": 682352,
            "b": "OHOCP",
            "e": [
              ",COO",
              ",COP",
              ",HOP",
              ",OOH",
              ",CHOP",
              ",COOP",
              ",HOOP",
              ",POOCH"
            ]
          },
          "level_006": {
            "a": 682367,
            "b": "EOEGAP",
            "e": [
              ",AGE",
              ",AGO",
              ",APE",
              ",EGO",
              ",GAP",
              ",GEE",
              ",PEA",
              ",PEG",
              ",APOGEE"
            ]
          },
          "level_007": {
            "a": 682365,
            "b": "IMATITE",
            "e": [
              ",EMIT",
              ",ITEM",
              ",MATE",
              ",MEAT",
              ",MITE",
              ",MITT",
              ",TAME",
              ",TEAM",
              ",TIME",
              ",IMITATE"
            ]
          },
          "level_008": {
            "a": 682356,
            "b": "CUTOSNL",
            "e": [
              ",CLOUT",
              ",COUNT",
              ",LOCUS",
              ",LOTUS",
              ",SCOUT",
              ",SNOUT",
              ",CONSUL",
              "B,LOCUST"
            ]
          },
          "level_009": {
            "a": 682357,
            "b": "DSETKA",
            "e": [
              ",DATE",
              ",DESK",
              ",EAST",
              ",SAKE",
              ",SEAT",
              ",TAKE",
              ",TASK",
              ",TEAK"
            ]
          },
          "level_010": {
            "a": 682361,
            "b": "EGMMLRI",
            "e": [
              ",GERM",
              ",GIRL",
              ",GRIM",
              ",LIME",
              ",MILE",
              ",MIME",
              ",MIRE",
              ",RILE"
            ]
          },
          "level_011": {
            "a": 682355,
            "b": "ADYUG",
            "e": [
              ",DAY",
              ",DUG",
              ",GUY",
              ",GAUDY"
            ]
          },
          "level_012": {
            "a": 682362,
            "b": "RENBITU",
            "e": [
              ",BRINE",
              ",BRUNT",
              ",BRUTE",
              ",BURNT",
              ",INERT",
              ",INTER",
              ",INURE",
              ",TRIBE",
              ",TUBER",
              ",TUNER",
              ",UNITE",
              ",UNTIE"
            ]
          },
          "level_013": {
            "a": 682366,
            "b": "MOSTIOK",
            "e": [
              ",MIST",
              "B,MOOT",
              ",MOST",
              ",OMIT",
              ",SKIM",
              ",SKIT",
              ",SOOT",
              ",TOOK"
            ]
          },
          "level_014": {
            "a": 682369,
            "b": "PEECYR",
            "e": [
              ",PEER",
              "B,PREY",
              ",PYRE",
              ",CREEPY"
            ]
          },
          "level_015": {
            "a": 682351,
            "b": "NGAROS",
            "e": [
              ",ARGON",
              ",ARSON",
              ",GROAN",
              ",ORGAN",
              ",SONAR"
            ]
          },
          "level_016": {
            "a": 682359,
            "b": "OEDUTV",
            "e": [
              ",DOTE",
              ",DOVE",
              ",DUET",
              ",VETO",
              ",VOTE",
              ",DUVET",
              "B,VOTED",
              ",DEVOUT"
            ]
          },
          "level_017": {
            "a": 682358,
            "b": "EBADK",
            "e": [
              ",BAD",
              ",BED",
              ",DAB",
              ",BADE",
              ",BAKE",
              ",BEAD",
              ",BEAK",
              ",BAKED"
            ]
          },
          "level_018": {
            "a": 682354,
            "b": "NFTVREE",
            "e": [
              ",EVE",
              ",FEE",
              ",FEN",
              ",NET",
              ",REF",
              ",TEE",
              ",TEN",
              ",VET",
              ",FERVENT"
            ]
          },
          "level_019": {
            "a": 682353,
            "b": "UEXLAS",
            "e": [
              ",ALE",
              "B,AXE",
              ",LAX",
              ",SAX",
              ",SEA",
              ",SEX",
              ",SUE",
              ",USE",
              ",SEXUAL"
            ]
          },
          "level_020": {
            "a": 682360,
            "b": "NEMASUR",
            "e": [
              ",AMUSE",
              ",NURSE",
              ",SANER",
              ",SERUM",
              ",SMEAR",
              ",SNARE",
              ",MANURE",
              ",SURNAME"
            ]
          }
        },
        "m": 12025910,
        "o": 32511,
        "r": 7490864,
        "t": 0.35000000000000003,
        "u": 0,
        "v": 16707883,
        "w": 16777215,
        "x": 204947,
        "y": 0.35000000000000003,
        "z": 0
      },
      "set_5": {
        "a": "PEBBLE",
        "aa": 16711476,
        "cc": 204947,
        "d": "bg_beach5.jpg",
        "dd": 16711476,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16711476,
        "k": 204947,
        "l": 16711476,
        "levels": {
          "level_001": {
            "a": 682506,
            "b": "EVNERE",
            "e": [
              ",EVEN",
              ",EVER",
              ",VEER",
              ",NERVE",
              ",NEVER"
            ]
          },
          "level_002": {
            "a": 682497,
            "b": "BWLDBOE",
            "e": [
              ",BELOW",
              ",BOWED",
              ",DOWEL",
              ",ELBOW",
              ",BOWLED",
              ",LOBBED",
              ",WOBBLE"
            ]
          },
          "level_003": {
            "a": 682511,
            "b": "GOUCH",
            "e": [
              ",COG",
              ",HOG",
              ",HUG",
              ",UGH",
              ",CHUG",
              "B,OUCH",
              ",COUGH"
            ]
          },
          "level_004": {
            "a": 682508,
            "b": "OWLUBP",
            "e": [
              ",BLOW",
              "B,BOWL",
              ",PLOW",
              ",BLOWUP"
            ]
          },
          "level_005": {
            "a": 682495,
            "b": "TYRFO",
            "e": [
              ",FOR",
              "B,FRO",
              ",FRY",
              ",OFT",
              ",ROT",
              ",TOY",
              ",TRY",
              ",FORT",
              ",FORTY"
            ]
          },
          "level_006": {
            "a": 682498,
            "b": "AEVDED",
            "e": [
              ",DEAD",
              "B,DEED",
              ",EVADE",
              ",EVADED"
            ]
          },
          "level_007": {
            "a": 682494,
            "b": "EBUTML",
            "e": [
              ",BET",
              ",BUM",
              ",BUT",
              ",ELM",
              ",EMU",
              ",LET",
              ",MET",
              ",TUB",
              ",TUMBLE"
            ]
          },
          "level_008": {
            "a": 682499,
            "b": "MPCUHAT",
            "e": [
              ",CAMP",
              ",CHAP",
              ",CHAT",
              ",CHUM",
              ",HUMP",
              ",MATH",
              ",MUCH",
              ",PACT",
              ",PATH",
              ",PUMA",
              ",TAMP"
            ]
          },
          "level_009": {
            "a": 682509,
            "b": "LTTSALE",
            "e": [
              ",LATTE",
              ",LEAST",
              ",SLATE",
              ",STALE",
              ",STALL",
              ",STATE",
              ",STEAL",
              ",TASTE",
              ",TALLEST"
            ]
          },
          "level_010": {
            "a": 682507,
            "b": "RRLAEEN",
            "e": [
              ",EARL",
              ",EARN",
              ",LANE",
              ",LEAN",
              ",LEER",
              ",NEAR",
              ",RARE",
              ",REAL",
              ",REAR",
              ",REEL",
              ",LEARNER",
              ",RELEARN"
            ]
          },
          "level_011": {
            "a": 682510,
            "b": "NACTSH",
            "e": [
              ",ACT",
              ",ANT",
              ",ASH",
              ",CAN",
              ",CAT",
              ",HAS",
              ",HAT",
              ",SAC",
              ",SAT",
              ",TAN",
              ",CHANT",
              ",SCANT"
            ]
          },
          "level_012": {
            "a": 682501,
            "b": "IGVUDLE",
            "e": [
              ",DEVIL",
              "B,GLIDE",
              ",GLUED",
              ",GUIDE",
              ",GUILD",
              ",GUILE",
              ",LIVED",
              ",DIVULGE"
            ]
          },
          "level_013": {
            "a": 682496,
            "b": "LEIDY",
            "e": [
              ",DYE",
              ",LED",
              ",LID",
              ",LIE",
              ",LYE",
              ",DELI",
              ",IDLE",
              ",IDLY",
              ",LIED",
              ",YIELD"
            ]
          },
          "level_014": {
            "a": 682502,
            "b": "LILTNIS",
            "e": [
              ",LILT",
              ",LINT",
              ",LIST",
              ",SILL",
              ",SILT",
              ",SLIT",
              ",TILL",
              ",STILL"
            ]
          },
          "level_015": {
            "a": 682493,
            "b": "BWSA",
            "e": [
              ",ABS",
              ",BAS",
              ",SAW",
              ",WAS",
              ",SWAB"
            ]
          },
          "level_016": {
            "a": 682500,
            "b": "OPUMSPO",
            "e": [
              ",OOPS",
              ",OPUS",
              ",POMP",
              ",POOP",
              ",PUMP",
              ",SOUP",
              ",SUMO",
              ",SUMP"
            ]
          },
          "level_017": {
            "a": 682505,
            "b": "IBAGNRA",
            "e": [
              ",BANG",
              "B,BARN",
              ",BRAG",
              ",BRAN",
              ",BRIG",
              ",GAIN",
              ",GARB",
              ",GRAB",
              ",GRIN",
              ",RAIN",
              ",RANG",
              ",RING"
            ]
          },
          "level_018": {
            "a": 682503,
            "b": "ADERGED",
            "e": [
              ",ADDER",
              ",AGREE",
              ",DARED",
              ",DREAD",
              ",EAGER",
              ",EDGED",
              ",EDGER",
              ",GRADE",
              ",GREED",
              ",RAGED"
            ]
          },
          "level_019": {
            "a": 682504,
            "b": "ISARVO",
            "e": [
              ",SOAR",
              ",VISA",
              ",SAVOR",
              ",VISOR"
            ]
          },
          "level_020": {
            "a": 682492,
            "b": "IANLY",
            "e": [
              ",AIL",
              ",ANY",
              ",LAY",
              ",NAY",
              ",NIL",
              ",YIN",
              ",LAIN",
              ",NAIL",
              ",INLAY"
            ]
          }
        },
        "m": 9793072,
        "o": 32511,
        "r": 9198123,
        "t": 0.7000000000000001,
        "v": 16711476,
        "x": 204947,
        "y": 0.7000000000000001
      }
    }
  },
  "WS 14": {
    "a": "CLIFF",
    "b": "grad_white",
    "c": "grp_mountain",
    "d": 1,
    "e": 5586657,
    "f": 8126683,
    "sets": {
      "set_1": {
        "a": "RIFT",
        "aa": 5586657,
        "d": "bg_cliff1.jpg",
        "dd": 5586657,
        "e": 0.1,
        "j": 5586657,
        "l": 5586657,
        "levels": {
          "level_001": {
            "a": 682652,
            "b": "AFRM",
            "e": [
              ",ARM",
              ",FAR",
              ",MAR",
              ",RAM",
              ",FARM"
            ]
          },
          "level_002": {
            "a": 682645,
            "b": "FEAUPC",
            "e": [
              ",CAFE",
              ",CAPE",
              ",FACE",
              ",PACE",
              ",FACEUP"
            ]
          },
          "level_003": {
            "a": 682660,
            "b": "ESILADB",
            "e": [
              ",BAILED",
              "B,BIASED",
              ",LADIES",
              ",SAILED",
              ",DISABLE"
            ]
          },
          "level_004": {
            "a": 682651,
            "b": "OEDLRPE",
            "e": [
              ",ELDER",
              ",ELOPE",
              ",ERODE",
              ",LEPER",
              ",LOPED",
              ",OLDER",
              ",REPEL",
              ",ROPED",
              ",ELOPED",
              ",DEPLORE"
            ]
          },
          "level_005": {
            "a": 682659,
            "b": "DRROEER",
            "e": [
              ",DOE",
              ",ERR",
              ",ODE",
              ",ORE",
              ",RED",
              ",ROD",
              ",DEER",
              ",DOER",
              ",REDO",
              ",REED",
              ",RODE"
            ]
          },
          "level_006": {
            "a": 682650,
            "b": "ONWMSNA",
            "e": [
              ",MOAN",
              ",MOWN",
              ",SNOW",
              ",SWAM",
              ",SWAN",
              ",MASON",
              "B,WOMAN",
              ",SNOWMAN"
            ]
          },
          "level_007": {
            "a": 682648,
            "b": "STLPA",
            "e": [
              ",LAST",
              ",PAST",
              ",SALT",
              ",SLAP",
              ",SLAT",
              ",SPAT"
            ]
          },
          "level_008": {
            "a": 682663,
            "b": "RTNEOTR",
            "e": [
              ",OTTER",
              ",RETRO",
              ",TENOR",
              ",TONER",
              ",TORTE",
              ",RETORT",
              "B,ROTTEN",
              ",TORRENT"
            ]
          },
          "level_009": {
            "a": 682649,
            "b": "YNTMLOH",
            "e": [
              ",HOLY",
              ",HYMN",
              ",MOLT",
              ",MOTH",
              ",MYTH",
              ",ONLY",
              ",HOTLY",
              ",MONTH"
            ]
          },
          "level_010": {
            "a": 682661,
            "b": "BBELDAB",
            "e": [
              ",ABLE",
              ",BABE",
              ",BADE",
              ",BALD",
              ",BALE",
              ",BEAD",
              ",BLED",
              ",DALE",
              ",DEAL",
              ",LEAD"
            ]
          },
          "level_011": {
            "a": 682657,
            "b": "USGDER",
            "e": [
              ",DRUG",
              ",RUDE",
              ",RUSE",
              ",SUED",
              ",SURE",
              ",URGE",
              ",USED",
              ",USER",
              ",SURGE",
              "B,URGED"
            ]
          },
          "level_012": {
            "a": 682654,
            "b": "LRUTBA",
            "e": [
              ",ABUT",
              ",BLUR",
              ",BRAT",
              ",TUBA",
              ",BLURT",
              ",TUBAL",
              ",ULTRA",
              ",BRUTAL"
            ]
          },
          "level_013": {
            "a": 682646,
            "b": "LAZDRI",
            "e": [
              ",ARID",
              ",DIAL",
              ",LAID",
              ",LAIR",
              ",LARD",
              ",LIAR",
              ",RAID",
              ",RAIL",
              ",LIZARD"
            ]
          },
          "level_014": {
            "a": 682656,
            "b": "ERPOT",
            "e": [
              ",PERT",
              ",POET",
              ",PORE",
              ",PORT",
              ",REPO",
              ",ROPE",
              ",ROTE",
              ",TORE"
            ]
          },
          "level_015": {
            "a": 682644,
            "b": "TALWR",
            "e": [
              ",ALT",
              ",ART",
              ",LAT",
              ",LAW",
              ",RAT",
              ",RAW",
              ",TAR",
              ",WAR",
              ",WART",
              ",TRAWL"
            ]
          },
          "level_016": {
            "a": 682655,
            "b": "YILOFGR",
            "e": [
              ",FOIL",
              ",FROG",
              ",GIRL",
              ",GOLF",
              ",GORY",
              ",OILY",
              ",ROIL",
              ",YOGI",
              ",GLORIFY"
            ]
          },
          "level_017": {
            "a": 682653,
            "b": "SDIEEPS",
            "e": [
              ",DEEP",
              ",SEED",
              ",SEEP",
              ",SIDE",
              ",SPED",
              ",SPEED",
              "B,SPIED",
              ",SPIES"
            ]
          },
          "level_018": {
            "a": 682658,
            "b": "IMCYAPR",
            "e": [
              ",CAMPY",
              ",CRAMP",
              ",CRIMP",
              ",PRIMA",
              ",PIRACY",
              ",PRIMACY"
            ]
          },
          "level_019": {
            "a": 682662,
            "b": "SBFULAH",
            "e": [
              ",BLUSH",
              ",FLASH",
              ",FLUSH",
              ",BASHFUL"
            ]
          },
          "level_020": {
            "a": 682647,
            "b": "ATTRYN",
            "e": [
              ",ARTY",
              ",NARY",
              ",RANT",
              ",TART",
              ",TRAY",
              ",YARN",
              ",NATTY",
              "B,RATTY",
              ",TYRANT"
            ]
          }
        },
        "m": 3090059,
        "o": 50527,
        "r": 3090059,
        "t": 0.7000000000000001,
        "v": 5586657,
        "y": 0.7000000000000001
      },
      "set_2": {
        "a": "SURGE",
        "aa": 6172383,
        "d": "bg_cliff2.jpg",
        "dd": 6172383,
        "e": 0.1,
        "j": 6172383,
        "l": 6172383,
        "levels": {
          "level_001": {
            "a": 682739,
            "b": "CSOFERP",
            "e": [
              ",COPSE",
              ",CORPS",
              ",FORCE",
              ",PROSE",
              ",SCOPE",
              ",SCORE",
              ",SPORE"
            ]
          },
          "level_002": {
            "a": 682750,
            "b": "OLYLAYT",
            "e": [
              ",ALLY",
              ",ALTO",
              ",TALL",
              ",TOLL",
              ",ALLOY",
              ",ATOLL",
              ",LOYAL",
              ",TALLY"
            ]
          },
          "level_003": {
            "a": 682755,
            "b": "AYHSD",
            "e": [
              ",ADS",
              ",ASH",
              ",DAY",
              ",HAD",
              ",HAS",
              ",HAY",
              ",SAD",
              ",SAY",
              ",SHY",
              ",ASHY",
              ",DASH"
            ]
          },
          "level_004": {
            "a": 682748,
            "b": "NINKESM",
            "e": [
              ",MINE",
              ",MINK",
              ",NINE",
              ",SEMI",
              ",SINE",
              ",SINK",
              ",SKIM",
              ",SKIN",
              ",KINSMEN"
            ]
          },
          "level_005": {
            "a": 682752,
            "b": "TISECN",
            "e": [
              ",INSET",
              ",SCENT",
              ",SINCE",
              ",INSECT",
              ",NICEST"
            ]
          },
          "level_006": {
            "a": 682743,
            "b": "IRYWEN",
            "e": [
              ",REIN",
              ",WINE",
              ",WIRE",
              ",WIRY",
              ",WREN",
              ",WINERY"
            ]
          },
          "level_007": {
            "a": 682753,
            "b": "ILDGE",
            "e": [
              ",DELI",
              ",IDLE",
              ",LIED",
              ",GLIDE"
            ]
          },
          "level_008": {
            "a": 682744,
            "b": "YRCWAHA",
            "e": [
              ",ACHY",
              "B,ARCH",
              ",AWAY",
              ",AWRY",
              ",CHAR",
              ",RACY",
              ",WARY",
              ",ARCHWAY"
            ]
          },
          "level_009": {
            "a": 682749,
            "b": "BEOLW",
            "e": [
              ",BOW",
              ",LOB",
              ",LOW",
              ",OWE",
              ",OWL",
              ",WEB",
              ",WOE",
              ",BELOW",
              ",ELBOW"
            ]
          },
          "level_010": {
            "a": 682756,
            "b": "SSTIBSU",
            "e": [
              ",BIT",
              ",BUS",
              ",BUT",
              ",ITS",
              ",SIS",
              ",SIT",
              ",SUB",
              ",TIS",
              ",TUB",
              ",SUBSIST"
            ]
          },
          "level_011": {
            "a": 682757,
            "b": "AUEDBS",
            "e": [
              ",ABUSE",
              "B,BASED",
              ",BUSED",
              ",ABUSED"
            ]
          },
          "level_012": {
            "a": 682745,
            "b": "ROAUGLM",
            "e": [
              ",ALUM",
              ",GLAM",
              ",GLUM",
              ",GOAL",
              ",GRAM",
              ",LOAM",
              ",MAUL",
              ",ORAL",
              ",ROAM",
              ",GLAMOR",
              ",GLAMOUR"
            ]
          },
          "level_013": {
            "a": 682738,
            "b": "ANDUPI",
            "e": [
              ",AID",
              ",AND",
              ",DIN",
              ",DIP",
              ",DUN",
              ",NAP",
              ",NIP",
              ",PAD",
              ",PAN",
              ",PIN",
              ",PUN",
              ",UNPAID"
            ]
          },
          "level_014": {
            "a": 682746,
            "b": "UECKCAP",
            "e": [
              ",ACE",
              ",APE",
              ",CAP",
              ",CUE",
              ",CUP",
              ",PEA",
              ",CUPCAKE"
            ]
          },
          "level_015": {
            "a": 682740,
            "b": "OARCN",
            "e": [
              ",CORN",
              ",ORCA",
              ",ROAN",
              ",ACORN"
            ]
          },
          "level_016": {
            "a": 682742,
            "b": "ENERTPE",
            "e": [
              ",NET",
              ",PEN",
              ",PER",
              ",PET",
              ",REP",
              ",TEE",
              ",TEN",
              ",ENTREE",
              ",REPENT",
              ",PRETEEN"
            ]
          },
          "level_017": {
            "a": 682751,
            "b": "HERDTA",
            "e": [
              ",DEATH",
              ",EARTH",
              ",HATED",
              ",HATER",
              ",HEARD",
              ",HEART",
              ",RATED",
              ",TRADE",
              ",TREAD",
              ",DEARTH",
              "B,HATRED",
              ",THREAD"
            ]
          },
          "level_018": {
            "a": 682754,
            "b": "REGAITF",
            "e": [
              ",AFIRE",
              "B,AFTER",
              ",GRAFT",
              ",GRATE",
              ",GREAT",
              ",GRIEF",
              ",IRATE",
              ",TIGER"
            ]
          },
          "level_019": {
            "a": 682747,
            "b": "AWYEIRL",
            "e": [
              ",EARLY",
              "B,LAYER",
              ",RELAY",
              ",WEARY"
            ]
          },
          "level_020": {
            "a": 682741,
            "b": "UOFRNYD",
            "e": [
              ",DOUR",
              "B,FOND",
              ",FORD",
              ",FOUR",
              ",FUND",
              ",FURY",
              ",UNDO",
              ",YOUR",
              ",FOUNDRY"
            ]
          }
        },
        "m": 3090061,
        "o": 13434986,
        "r": 3090061,
        "t": 0.8,
        "v": 6172383,
        "y": 0.75
      },
      "set_3": {
        "a": "STRIVE",
        "aa": 6823902,
        "d": "bg_cliff3.jpg",
        "dd": 6823902,
        "e": 0.1,
        "j": 6823902,
        "l": 6823902,
        "levels": {
          "level_001": {
            "a": 682877,
            "b": "CDLSEO",
            "e": [
              ",COD",
              ",DOC",
              ",DOE",
              ",LED",
              ",ODE",
              ",OLD",
              ",SOD",
              ",CLOSE",
              ",SCOLD",
              ",CLOSED"
            ]
          },
          "level_002": {
            "a": 682878,
            "b": "DOTEMH",
            "e": [
              ",DEMO",
              ",DOME",
              ",DOTE",
              ",HOME",
              ",MODE",
              ",MOTE",
              ",MOTH",
              ",THEM",
              ",TOME"
            ]
          },
          "level_003": {
            "a": 682873,
            "b": "GAEDGR",
            "e": [
              ",AGED",
              ",DARE",
              ",DEAR",
              ",DRAG",
              ",GEAR",
              ",GRAD",
              ",RAGE",
              ",READ",
              ",GRADE",
              ",RAGED"
            ]
          },
          "level_004": {
            "a": 682870,
            "b": "UHCONTU",
            "e": [
              ",HUNT",
              ",OUCH",
              ",THOU",
              ",UNTO",
              ",COUNT",
              ",NOTCH",
              ",TOUCH",
              ",UNCUT",
              ",UNCOUTH"
            ]
          },
          "level_005": {
            "a": 682875,
            "b": "HINETCK",
            "e": [
              ",ETHIC",
              ",NICHE",
              ",THICK",
              ",THINE",
              ",THINK",
              ",ETHNIC",
              ",KITCHEN",
              "B,THICKEN"
            ]
          },
          "level_006": {
            "a": 682885,
            "b": "COTNIGS",
            "e": [
              ",COIN",
              "B,COST",
              ",GIST",
              ",ICON",
              ",INTO",
              ",SIGN",
              ",SING",
              ",SNOT",
              ",SONG",
              ",TONG"
            ]
          },
          "level_007": {
            "a": 682876,
            "b": "ESEWD",
            "e": [
              ",DEW",
              ",EWE",
              ",SEE",
              ",SEW",
              ",WED",
              ",WEE",
              ",SEWED",
              ",SWEDE"
            ]
          },
          "level_008": {
            "a": 682881,
            "b": "MORYASN",
            "e": [
              ",ARSON",
              ",MANOR",
              ",MASON",
              ",MAYOR",
              ",MORAY",
              ",RAYON",
              ",ROMAN",
              ",SONAR",
              ",RANSOM"
            ]
          },
          "level_009": {
            "a": 682866,
            "b": "OYPLOR",
            "e": [
              ",PLY",
              ",PRO",
              ",PRY",
              ",LOOP",
              ",PLOY",
              ",POLO",
              ",POLY",
              ",POOL",
              ",POOR"
            ]
          },
          "level_010": {
            "a": 682871,
            "b": "UNUDGEL",
            "e": [
              ",DUEL",
              ",DUNE",
              ",DUNG",
              ",GLEN",
              ",GLUE",
              ",LEND",
              ",LUGE",
              ",LUNG",
              ",NUDE",
              ",LUNGED"
            ]
          },
          "level_011": {
            "a": 682879,
            "b": "ECIDTP",
            "e": [
              ",CITE",
              "B,DICE",
              ",DIET",
              ",EDIT",
              ",EPIC",
              ",ICED",
              ",TIDE",
              ",TIED"
            ]
          },
          "level_012": {
            "a": 682869,
            "b": "MGYLUL",
            "e": [
              ",GUM",
              "B,GUY",
              ",GYM",
              ",LUG",
              ",MUG",
              ",YUM",
              ",GULLY",
              ",GLUMLY"
            ]
          },
          "level_013": {
            "a": 682867,
            "b": "OTOCP",
            "e": [
              ",COO",
              ",COP",
              ",COT",
              ",OPT",
              ",POT",
              ",TOO",
              ",TOP",
              ",COOPT"
            ]
          },
          "level_014": {
            "a": 682872,
            "b": "KCEATR",
            "e": [
              ",CATER",
              "B,CRATE",
              ",CREAK",
              ",REACT",
              ",TAKER",
              ",TRACE",
              ",TRACK",
              ",RACKET"
            ]
          },
          "level_015": {
            "a": 682874,
            "b": "ELIP",
            "e": [
              ",LIE",
              ",LIP",
              ",PIE",
              ",PILE"
            ]
          },
          "level_016": {
            "a": 682884,
            "b": "EOSLHT",
            "e": [
              ",ETHOS",
              ",HOTEL",
              ",SLOTH",
              ",STOLE",
              ",THOSE",
              ",HOSTEL"
            ]
          },
          "level_017": {
            "a": 682868,
            "b": "NSORE",
            "e": [
              ",NOSE",
              ",ROSE",
              ",SORE",
              ",SNORE"
            ]
          },
          "level_018": {
            "a": 682880,
            "b": "OEOCTL",
            "e": [
              ",CLOT",
              ",COLT",
              ",COOL",
              ",COOT",
              ",LOOT",
              ",TOOL"
            ]
          },
          "level_019": {
            "a": 682882,
            "b": "IBREDD",
            "e": [
              ",BED",
              "B,BID",
              ",DID",
              ",IRE",
              ",RED",
              ",RIB",
              ",RID",
              ",BIDDER"
            ]
          },
          "level_020": {
            "a": 682883,
            "b": "BEMABRL",
            "e": [
              ",AMBER",
              ",AMBLE",
              ",BLAME",
              ",BLARE",
              ",REALM",
              ",MARBLE",
              ",RABBLE",
              ",RAMBLE",
              ",BRAMBLE"
            ]
          }
        },
        "m": 3801748,
        "o": 16753152,
        "r": 3801748,
        "t": 0.8,
        "v": 6823902,
        "y": 0.8
      },
      "set_4": {
        "a": "HEAL",
        "aa": 7475164,
        "d": "bg_cliff4.jpg",
        "dd": 7475164,
        "e": 0.1,
        "j": 7475164,
        "l": 7475164,
        "levels": {
          "level_001": {
            "a": 683037,
            "b": "TIUSIBC",
            "e": [
              ",BUST",
              ",STUB",
              ",SUIT",
              ",BISCUIT"
            ]
          },
          "level_002": {
            "a": 683034,
            "b": "LESBA",
            "e": [
              ",ABLE",
              ",BALE",
              ",BASE",
              ",SALE",
              ",SEAL",
              ",SLAB",
              ",BLASE",
              ",SABLE"
            ]
          },
          "level_003": {
            "a": 683027,
            "b": "DAWFR",
            "e": [
              ",FAD",
              ",FAR",
              ",RAD",
              ",RAW",
              ",WAD",
              ",WAR",
              ",DRAW",
              ",WARD",
              ",DWARF"
            ]
          },
          "level_004": {
            "a": 683038,
            "b": "STREIEV",
            "e": [
              ",RESET",
              "B,RIVET",
              ",SERVE",
              ",SEVER",
              ",SIEVE",
              ",STEER",
              ",TERSE",
              ",TRIES",
              ",VERSE"
            ]
          },
          "level_005": {
            "a": 683040,
            "b": "YSUHB",
            "e": [
              ",BUS",
              ",BUY",
              ",HUB",
              ",SHY",
              ",SUB",
              ",BUSH",
              ",BUSY",
              ",BUSHY"
            ]
          },
          "level_006": {
            "a": 683031,
            "b": "ENEDODT",
            "e": [
              ",DOTED",
              ",ENDED",
              ",NOTED",
              ",TONED",
              ",DENOTE",
              "B,DENTED",
              ",TENDED",
              ",DENOTED"
            ]
          },
          "level_007": {
            "a": 683032,
            "b": "TUUMAQN",
            "e": [
              ",ANT",
              ",MAN",
              ",MAT",
              ",NUT",
              ",TAN",
              ",TAU",
              ",AUTUMN",
              ",QUANTUM"
            ]
          },
          "level_008": {
            "a": 683035,
            "b": "AEIUNT",
            "e": [
              ",ANTE",
              ",ANTI",
              ",AUNT",
              ",NEAT",
              ",TINE",
              ",TUNA",
              ",TUNE",
              ",UNIT",
              ",UNITE",
              "B,UNTIE"
            ]
          },
          "level_009": {
            "a": 683041,
            "b": "YCELALR",
            "e": [
              ",ALLEY",
              ",CLEAR",
              ",EARLY",
              ",LAYER",
              ",RALLY",
              ",RELAY",
              ",CALLER",
              "B,CELLAR",
              ",REALLY",
              ",RECALL",
              ",CLEARLY"
            ]
          },
          "level_010": {
            "a": 683028,
            "b": "EMIYDRA",
            "e": [
              ",AIMED",
              "B,AIRED",
              ",ARMED",
              ",DAIRY",
              ",DIARY",
              ",DREAM",
              ",MEDIA",
              ",MIRED",
              ",READY",
              ",MIDYEAR"
            ]
          },
          "level_011": {
            "a": 683036,
            "b": "AMESUS",
            "e": [
              ",EMU",
              ",SEA",
              ",SUE",
              ",SUM",
              ",USE",
              ",AMUSE",
              ",ASSUME"
            ]
          },
          "level_012": {
            "a": 683029,
            "b": "DTEOPTI",
            "e": [
              ",DEPOT",
              ",DITTO",
              ",OPTED",
              ",PETIT",
              ",TEPID",
              ",TIPTOED"
            ]
          },
          "level_013": {
            "a": 683030,
            "b": "BRONO",
            "e": [
              ",BOO",
              ",BRO",
              ",NOR",
              ",ORB",
              ",ROB",
              ",BOON",
              ",BORN",
              ",BORON"
            ]
          },
          "level_014": {
            "a": 683025,
            "b": "PROCADI",
            "e": [
              ",ACRID",
              "B,RADIO",
              ",RAPID",
              ",PARODIC"
            ]
          },
          "level_015": {
            "a": 683024,
            "b": "AMLEY",
            "e": [
              ",ALE",
              ",AYE",
              ",ELM",
              ",LAM",
              ",LAY",
              ",LYE",
              ",MAY",
              ",YAM",
              ",YEA",
              ",MEALY"
            ]
          },
          "level_016": {
            "a": 683023,
            "b": "FLRPUEA",
            "e": [
              ",FERAL",
              ",FLARE",
              ",PALER",
              ",PEARL",
              ",EARFUL",
              ",FLAREUP"
            ]
          },
          "level_017": {
            "a": 683039,
            "b": "TRIDPO",
            "e": [
              ",DIRT",
              ",DRIP",
              ",DROP",
              ",PORT",
              ",PROD",
              ",RIOT",
              ",TRIO",
              ",TRIP",
              ",TROD"
            ]
          },
          "level_018": {
            "a": 683026,
            "b": "ANSNMKI",
            "e": [
              ",AKIN",
              ",MAIN",
              ",MASK",
              ",MINK",
              ",SANK",
              ",SINK",
              ",SKIM",
              ",SKIN",
              ",KINSMAN"
            ]
          },
          "level_019": {
            "a": 683022,
            "b": "AGSEEMS",
            "e": [
              ",EASE",
              ",GAME",
              ",MAGE",
              ",MEGA",
              ",MESA",
              ",MESS",
              ",SAGE",
              ",SAME",
              ",SEAM",
              ",SEEM"
            ]
          },
          "level_020": {
            "a": 683033,
            "b": "AEICDND",
            "e": [
              ",AIDED",
              ",DANCE",
              ",DICED",
              ",DINED",
              ",CADDIE",
              ",CANDID",
              ",DANCED",
              ",CANDIED"
            ]
          }
        },
        "m": 3801748,
        "o": 47103,
        "r": 3801748,
        "t": 0.55,
        "v": 7475164,
        "y": 0.55
      },
      "set_5": {
        "a": "DIVINE",
        "aa": 8126683,
        "d": "bg_cliff5.jpg",
        "dd": 8126683,
        "e": 0.1,
        "j": 8126683,
        "l": 8126683,
        "levels": {
          "level_001": {
            "a": 683180,
            "b": "CLOIRGW",
            "e": [
              ",COG",
              ",COW",
              ",LOG",
              ",LOW",
              ",OIL",
              ",OWL",
              ",RIG",
              ",ROW",
              ",WIG",
              ",GROWL",
              ",LOGIC",
              ",COWGIRL"
            ]
          },
          "level_002": {
            "a": 683197,
            "b": "YURSPY",
            "e": [
              ",PRY",
              ",PUS",
              ",SPY",
              ",SUP",
              ",UPS",
              ",YUP",
              ",SYRUP",
              ",SYRUPY"
            ]
          },
          "level_003": {
            "a": 683181,
            "b": "BHOTO",
            "e": [
              ",BOOT",
              ",BOTH",
              ",HOBO",
              ",HOOT"
            ]
          },
          "level_004": {
            "a": 683196,
            "b": "YTPARS",
            "e": [
              ",ARTSY",
              "B,PARTY",
              ",PASTY",
              ",PATSY",
              ",RASPY",
              ",SPRAY",
              ",STRAP",
              ",STRAY"
            ]
          },
          "level_005": {
            "a": 683184,
            "b": "NEDEXT",
            "e": [
              ",DEN",
              ",END",
              ",NET",
              ",TEE",
              ",TEN",
              ",DENT",
              ",NEED",
              ",NEXT",
              ",TEEN",
              ",TEND"
            ]
          },
          "level_006": {
            "a": 683193,
            "b": "NOMDOAR",
            "e": [
              ",ADORN",
              ",DONOR",
              ",MANOR",
              ",NOMAD",
              ",RADON",
              ",ROMAN",
              ",MAROON",
              "B,RANDOM"
            ]
          },
          "level_007": {
            "a": 683188,
            "b": "YNTRAUI",
            "e": [
              ",AUNTY",
              ",RAINY",
              ",TRAIN",
              ",UNITY"
            ]
          },
          "level_008": {
            "a": 683185,
            "b": "GUERUSP",
            "e": [
              ",GURU",
              ",PURE",
              ",RUSE",
              ",SPUR",
              ",SURE",
              ",URGE",
              ",USER",
              ",UPSURGE"
            ]
          },
          "level_009": {
            "a": 683199,
            "b": "AEBTA",
            "e": [
              ",ATE",
              ",BAT",
              ",BET",
              ",EAT",
              ",TAB",
              ",TEA",
              ",BEAT",
              "B,BETA"
            ]
          },
          "level_010": {
            "a": 683198,
            "b": "LAPFI",
            "e": [
              ",AIL",
              ",LAP",
              ",LIP",
              ",PAL",
              ",FAIL",
              ",FLAP",
              ",FLIP",
              ",PAIL",
              ",PILAF"
            ]
          },
          "level_011": {
            "a": 683189,
            "b": "KPMNIUP",
            "e": [
              ",IMP",
              "B,INK",
              ",KIN",
              ",NIP",
              ",PIN",
              ",PUN",
              ",PUP",
              ",PUMPKIN"
            ]
          },
          "level_012": {
            "a": 683190,
            "b": "OIMTRUS",
            "e": [
              ",MOIST",
              ",ROUST",
              ",STORM",
              ",STRUM",
              ",TORUS",
              ",SUITOR",
              ",TRUISM",
              ",TOURISM"
            ]
          },
          "level_013": {
            "a": 683194,
            "b": "SNNEESW",
            "e": [
              ",EWE",
              ",NEW",
              ",SEE",
              ",SEW",
              ",WEE",
              ",SEEN",
              ",SEWN",
              ",SENSE"
            ]
          },
          "level_014": {
            "a": 683195,
            "b": "PPERHO",
            "e": [
              ",HERO",
              ",HOPE",
              ",POPE",
              ",PORE",
              ",PREP",
              ",PROP",
              ",REPO",
              ",ROPE",
              ",HOPPER"
            ]
          },
          "level_015": {
            "a": 683186,
            "b": "SLAHL",
            "e": [
              ",ALL",
              ",ASH",
              ",HAS",
              ",HALL",
              "B,LASH",
              ",SHALL"
            ]
          },
          "level_016": {
            "a": 683187,
            "b": "AICTPAO",
            "e": [
              ",ATOP",
              ",COAT",
              ",IOTA",
              ",PACT",
              ",PITA",
              ",TACO",
              ",OPTIC",
              ",PATIO",
              ",TOPIC",
              ",CAPITA",
              ",TAPIOCA"
            ]
          },
          "level_017": {
            "a": 683183,
            "b": "ACINH",
            "e": [
              ",CAN",
              ",CHI",
              ",CHIN",
              "B,INCH"
            ]
          },
          "level_018": {
            "a": 683182,
            "b": "STSEKCI",
            "e": [
              ",ICE",
              ",ITS",
              ",KIT",
              ",SET",
              ",SIS",
              ",SIT",
              ",SKI",
              ",TIC",
              ",TIE",
              ",TIS",
              ",SICKEST"
            ]
          },
          "level_019": {
            "a": 683192,
            "b": "RODBE",
            "e": [
              ",BODE",
              ",BORE",
              ",BRED",
              ",DOER",
              ",REDO",
              ",ROBE",
              ",RODE",
              ",BORED"
            ]
          },
          "level_020": {
            "a": 683191,
            "b": "PISEUD",
            "e": [
              ",DUPE",
              ",SIDE",
              ",SPED",
              ",SPUD",
              ",SUED",
              ",USED",
              ",SPIED",
              ",UPSIDE"
            ]
          }
        },
        "m": 5308557,
        "o": 16738922,
        "r": 5308557,
        "t": 0.65,
        "v": 8126683,
        "y": 0.65
      }
    }
  },
  "WS 15": {
    "a": "VISTA",
    "b": "grad_white",
    "c": "grp_rainbow",
    "d": 0.75,
    "e": 16711680,
    "f": 12517376,
    "sets": {
      "set_1": {
        "a": "CLIMB",
        "aa": 16711680,
        "d": "bg_rainbow1.jpg",
        "dd": 16711680,
        "e": 0,
        "j": 16711680,
        "l": 16711680,
        "levels": {
          "level_001": {
            "a": 683326,
            "b": "ESUGIN",
            "e": [
              ",SIGN",
              "B,SINE",
              ",SING",
              ",SNUG",
              ",SUNG"
            ]
          },
          "level_002": {
            "a": 683324,
            "b": "HYTLOSR",
            "e": [
              ",HOTLY",
              ",SHORT",
              ",SLOTH",
              ",STORY",
              ",SHORTY"
            ]
          },
          "level_003": {
            "a": 683322,
            "b": "DIFUINE",
            "e": [
              ",DINE",
              ",DUNE",
              ",FEND",
              ",FEUD",
              ",FIND",
              ",FINE",
              ",FUND",
              ",NUDE"
            ]
          },
          "level_004": {
            "a": 683320,
            "b": "SDEDEAT",
            "e": [
              ",DATED",
              ",EASED",
              ",SATED",
              ",STEAD",
              ",TEASE",
              ",SEATED",
              ",SEDATE",
              ",TEASED",
              ",SEDATED"
            ]
          },
          "level_005": {
            "a": 683335,
            "b": "PSEAK",
            "e": [
              ",APE",
              ",ASK",
              ",ASP",
              ",PEA",
              ",SAP",
              ",SEA",
              ",SPA",
              ",SPEAK"
            ]
          },
          "level_006": {
            "a": 683330,
            "b": "DYDLEA",
            "e": [
              ",DALE",
              ",DEAD",
              ",DEAL",
              ",DYED",
              ",EDDY",
              ",LADY",
              ",LEAD",
              ",DEADLY"
            ]
          },
          "level_007": {
            "a": 683323,
            "b": "EOSHD",
            "e": [
              ",DOE",
              ",HOE",
              ",ODE",
              ",SHE",
              ",SOD",
              ",DOSE",
              "B,HOSE",
              ",SHED",
              ",SHOE"
            ]
          },
          "level_008": {
            "a": 683337,
            "b": "SEOUVRE",
            "e": [
              ",REUSE",
              ",ROUSE",
              ",SERVE",
              ",SERVO",
              ",SEVER",
              ",VERSE"
            ]
          },
          "level_009": {
            "a": 683331,
            "b": "OYGLHRU",
            "e": [
              ",GORY",
              ",HOLY",
              ",HOUR",
              ",HURL",
              ",UGLY",
              ",YOUR",
              ",GLORY",
              ",ROUGH",
              ",HOURLY",
              ",ROUGHLY"
            ]
          },
          "level_010": {
            "a": 683327,
            "b": "ITTBLER",
            "e": [
              ",BELT",
              ",BILE",
              ",BITE",
              ",BRIE",
              ",LITE",
              ",RILE",
              ",RITE",
              ",TIER",
              ",TILE",
              ",TILT",
              ",TIRE"
            ]
          },
          "level_011": {
            "a": 683334,
            "b": "OLELBWC",
            "e": [
              ",BELOW",
              ",CELLO",
              ",ELBOW",
              ",BELLOW"
            ]
          },
          "level_012": {
            "a": 683328,
            "b": "ETCPOAL",
            "e": [
              ",CLEAT",
              ",LEAPT",
              ",PETAL",
              ",PLACE",
              ",PLATE",
              ",POLECAT"
            ]
          },
          "level_013": {
            "a": 683338,
            "b": "KLAYE",
            "e": [
              ",KALE",
              ",LAKE",
              ",LEAK",
              ",LEAKY"
            ]
          },
          "level_014": {
            "a": 683333,
            "b": "IVEOTM",
            "e": [
              ",EMIT",
              "B,ITEM",
              ",MITE",
              ",MOTE",
              ",MOVE",
              ",OMIT",
              ",TIME",
              ",TOME",
              ",VETO",
              ",VOTE",
              ",MOVIE",
              ",MOTIVE"
            ]
          },
          "level_015": {
            "a": 683329,
            "b": "STWEYA",
            "e": [
              ",EAST",
              "B,EASY",
              ",SEAT",
              ",STAY",
              ",STEW",
              ",SWAT",
              ",SWAY",
              ",WEST",
              ",SWEATY"
            ]
          },
          "level_016": {
            "a": 683321,
            "b": "DLRYWOL",
            "e": [
              ",DOLLY",
              ",DOWRY",
              ",DROLL",
              ",LOWLY",
              ",ROWDY",
              ",WORDY",
              ",WORLD"
            ]
          },
          "level_017": {
            "a": 683325,
            "b": "TWIIHN",
            "e": [
              ",HIT",
              ",NIT",
              ",TIN",
              ",WIN",
              ",WIT",
              ",HINT",
              ",THIN",
              ",TWIN",
              ",WHIT",
              ",WITH",
              ",WITHIN"
            ]
          },
          "level_018": {
            "a": 683332,
            "b": "LECTUET",
            "e": [
              ",CLUE",
              ",CULT",
              ",CUTE",
              ",LUTE",
              ",ELECT",
              ",CUTLET"
            ]
          },
          "level_019": {
            "a": 683336,
            "b": "REBRABG",
            "e": [
              ",BABE",
              "B,BARB",
              ",BARE",
              ",BEAR",
              ",BRAG",
              ",GARB",
              ",GEAR",
              ",GRAB",
              ",RAGE",
              ",RARE",
              ",REAR",
              ",BARBER"
            ]
          },
          "level_020": {
            "a": 683339,
            "b": "LALWUYF",
            "e": [
              ",ALLY",
              "B,FALL",
              ",FLAW",
              ",FLAY",
              ",FULL",
              ",WALL",
              ",LAWFUL",
              ",AWFULLY"
            ]
          }
        },
        "m": 7733248,
        "o": 16741120,
        "r": 8997376,
        "t": 0.74,
        "v": 16711680,
        "y": 0.74
      },
      "set_2": {
        "a": "ABOVE",
        "aa": 15204352,
        "bb": 16777215,
        "cc": 4294967295,
        "d": "bg_rainbow2.jpg",
        "dd": 15204352,
        "e": 0,
        "ee": 4294967295,
        "i": 4294967295,
        "j": 15204352,
        "k": 4294967295,
        "l": 15204352,
        "levels": {
          "level_001": {
            "a": 683457,
            "b": "BKAYACP",
            "e": [
              ",BAY",
              ",CAB",
              ",CAP",
              ",CAY",
              ",PAY",
              ",YAK",
              ",PAYBACK"
            ]
          },
          "level_002": {
            "a": 683469,
            "b": "LGYUNS",
            "e": [
              ",GNU",
              "B,GUN",
              ",GUY",
              ",LUG",
              ",SLY",
              ",SUN",
              ",SLUNG",
              ",SNUGLY"
            ]
          },
          "level_003": {
            "a": 683461,
            "b": "TSLOBDE",
            "e": [
              ",STOLE",
              ",BOLTED",
              ",OLDEST",
              ",BOLDEST"
            ]
          },
          "level_004": {
            "a": 683467,
            "b": "ILYTEST",
            "e": [
              ",ISLET",
              ",SILTY",
              ",STILT",
              ",STYLE",
              ",TESTY",
              ",TITLE",
              ",TESTILY"
            ]
          },
          "level_005": {
            "a": 683475,
            "b": "ATTNINS",
            "e": [
              ",ANTI",
              "B,STAT",
              ",TINT",
              ",INSTANT"
            ]
          },
          "level_006": {
            "a": 683470,
            "b": "TORSITO",
            "e": [
              ",RIOT",
              ",ROOT",
              ",SOOT",
              ",SORT",
              ",STIR",
              ",TOOT",
              ",TORT",
              ",TRIO",
              ",TROT",
              ",ROOST",
              ",TORSO"
            ]
          },
          "level_007": {
            "a": 683459,
            "b": "KUEERA",
            "e": [
              ",ARE",
              ",ARK",
              ",EAR",
              ",EEK",
              ",EKE",
              ",ERA",
              ",RUE",
              ",RAKE",
              "B,REEK"
            ]
          },
          "level_008": {
            "a": 683462,
            "b": "RSPPINA",
            "e": [
              ",PAIN",
              "B,PAIR",
              ",RAIN",
              ",RASP",
              ",SNAP",
              ",SNIP",
              ",SPAN",
              ",SPAR",
              ",SPIN",
              ",SPRAIN",
              ",PARSNIP"
            ]
          },
          "level_009": {
            "a": 683456,
            "b": "FALEURF",
            "e": [
              ",EARL",
              ",FARE",
              ",FEAR",
              ",FLEA",
              ",FLUE",
              ",FUEL",
              ",LEAF",
              ",LURE",
              ",REAL",
              ",RULE"
            ]
          },
          "level_010": {
            "a": 683463,
            "b": "LEJWREY",
            "e": [
              ",JEER",
              ",LEER",
              ",LYRE",
              ",REEL",
              ",RELY",
              ",WERE",
              ",JEWELRY"
            ]
          },
          "level_011": {
            "a": 683464,
            "b": "RREHUSI",
            "e": [
              ",HEIR",
              ",HIRE",
              ",RISE",
              ",RUSE",
              ",RUSH",
              ",SIRE",
              ",SURE",
              ",USER",
              ",RUSHER"
            ]
          },
          "level_012": {
            "a": 683460,
            "b": "UIETRON",
            "e": [
              ",INERT",
              ",INTER",
              ",INTRO",
              ",INURE",
              ",OUTER",
              ",ROUTE",
              ",TENOR",
              ",TONER",
              ",TUNER",
              ",UNITE",
              ",UNTIE",
              ",ORIENT"
            ]
          },
          "level_013": {
            "a": 683471,
            "b": "IPLTYO",
            "e": [
              ",OILY",
              ",PITY",
              ",PLOT",
              ",PLOY",
              ",POLY",
              ",TOIL",
              ",TYPO",
              ",PILOT"
            ]
          },
          "level_014": {
            "a": 683474,
            "b": "YUAAWNR",
            "e": [
              ",AURA",
              ",AWAY",
              ",AWRY",
              ",NARY",
              ",WARN",
              ",WARY",
              ",YARN",
              ",YAWN"
            ]
          },
          "level_015": {
            "a": 683458,
            "b": "NNTEILE",
            "e": [
              ",ELITE",
              ",INLET",
              ",LINEN",
              ",LENIENT"
            ]
          },
          "level_016": {
            "a": 683473,
            "b": "NBTLYOA",
            "e": [
              ",ABLY",
              ",ALTO",
              ",BLOT",
              ",BOAT",
              ",BOLA",
              ",BOLT",
              ",BONY",
              ",LOAN",
              ",ONLY",
              ",BOTANY"
            ]
          },
          "level_017": {
            "a": 683472,
            "b": "MNFAOD",
            "e": [
              ",FOAM",
              "B,FOND",
              ",MOAN",
              ",FANDOM"
            ]
          },
          "level_018": {
            "a": 683468,
            "b": "AEEDPVR",
            "e": [
              ",DRAPE",
              ",EVADE",
              ",PADRE",
              ",PARED",
              ",PAVED",
              ",RAVED"
            ]
          },
          "level_019": {
            "a": 683465,
            "b": "TGOA",
            "e": [
              ",AGO",
              ",GOT",
              ",OAT",
              ",TAG",
              ",GOAT",
              "B,TOGA"
            ]
          },
          "level_020": {
            "a": 683466,
            "b": "CPERETS",
            "e": [
              ",CREEP",
              ",CREPE",
              ",CREPT",
              ",CREST",
              ",ERECT",
              ",RESET",
              ",SCREE",
              ",SPREE",
              ",STEEP",
              ",STEER",
              ",STREP",
              ",TERSE"
            ]
          }
        },
        "m": 7733248,
        "o": 48538,
        "r": 8997376,
        "t": 0.76,
        "u": 0,
        "v": 15204352,
        "w": 16777215,
        "x": 4294967295,
        "y": 0.76,
        "z": 0
      },
      "set_3": {
        "a": "FALL",
        "aa": 13697024,
        "bb": 16777215,
        "cc": 4294967295,
        "d": "bg_rainbow3.jpg",
        "dd": 13697024,
        "e": 0,
        "ee": 4294967295,
        "g": 0.92,
        "i": 4294967295,
        "j": 13697024,
        "k": 4294967295,
        "l": 13697024,
        "levels": {
          "level_001": {
            "a": 683582,
            "b": "NWDOWLO",
            "e": [
              ",DON",
              ",DOW",
              ",LOW",
              ",NOD",
              ",NOW",
              ",OLD",
              ",OWL",
              ",OWN",
              ",WON",
              ",WOO",
              ",WOW",
              ",LOWDOWN"
            ]
          },
          "level_002": {
            "a": 683600,
            "b": "ENACFDI",
            "e": [
              ",DANCE",
              ",DECAF",
              ",FACED",
              ",FIEND",
              ",FINED"
            ]
          },
          "level_003": {
            "a": 683592,
            "b": "SATAMH",
            "e": [
              ",AAH",
              ",AHA",
              ",ASH",
              ",HAM",
              ",HAS",
              ",HAT",
              ",MAT",
              ",SAT",
              ",ASTHMA"
            ]
          },
          "level_004": {
            "a": 683594,
            "b": "AHTCTRE",
            "e": [
              ",HATTER",
              ",THREAT",
              ",CHATTER",
              ",RATCHET"
            ]
          },
          "level_005": {
            "a": 683586,
            "b": "GELEY",
            "e": [
              ",EEL",
              ",EYE",
              ",GEE",
              ",GEL",
              ",LEG",
              ",LYE",
              ",ELEGY"
            ]
          },
          "level_006": {
            "a": 683598,
            "b": "BRPROEV",
            "e": [
              ",BORE",
              "B,OVER",
              ",PORE",
              ",REPO",
              ",ROBE",
              ",ROPE",
              ",ROVE",
              ",VERB",
              ",PROVERB"
            ]
          },
          "level_007": {
            "a": 683591,
            "b": "INNOO",
            "e": [
              ",INN",
              "B,ION",
              ",NOON",
              ",ONION"
            ]
          },
          "level_008": {
            "a": 683596,
            "b": "MTUTIEO",
            "e": [
              ",EMIT",
              ",ITEM",
              ",MITE",
              ",MITT",
              ",MOTE",
              ",MUTE",
              ",MUTT",
              ",OMIT",
              ",TIME",
              ",TOME",
              ",TOTE",
              ",TOUT"
            ]
          },
          "level_009": {
            "a": 683587,
            "b": "ZPNUI",
            "e": [
              ",NIP",
              ",PIN",
              ",PUN",
              ",ZIP",
              ",UNZIP"
            ]
          },
          "level_010": {
            "a": 683590,
            "b": "ENEHWP",
            "e": [
              ",EWE",
              ",HEN",
              ",HEW",
              ",NEW",
              ",PEN",
              ",PEW",
              ",WEE",
              ",HEWN",
              ",PHEW",
              ",WEEP",
              ",WHEN"
            ]
          },
          "level_011": {
            "a": 683597,
            "b": "AHRIOM",
            "e": [
              ",HAIR",
              ",HARM",
              ",ROAM",
              ",MOHAIR"
            ]
          },
          "level_012": {
            "a": 683589,
            "b": "RNGEGU",
            "e": [
              ",RUNE",
              ",RUNG",
              ",URGE",
              ",GRUNGE"
            ]
          },
          "level_013": {
            "a": 683593,
            "b": "AGEILME",
            "e": [
              ",GALE",
              ",GAME",
              ",GLAM",
              ",GLEE",
              ",LAME",
              ",LIME",
              ",MAGE",
              ",MAIL",
              ",MALE",
              ",MEAL",
              ",MEGA",
              ",MILE"
            ]
          },
          "level_014": {
            "a": 683601,
            "b": "EALARIG",
            "e": [
              ",AGILE",
              "B,ALGAE",
              ",GLARE",
              ",GRAIL",
              ",LAGER",
              ",LARGE",
              ",REGAL",
              ",REGALIA"
            ]
          },
          "level_015": {
            "a": 683585,
            "b": "PRUBLA",
            "e": [
              ",BAR",
              "B,BRA",
              ",LAB",
              ",LAP",
              ",PAL",
              ",PAR",
              ",PUB",
              ",RAP",
              ",RUB",
              ",BURLAP"
            ]
          },
          "level_016": {
            "a": 683595,
            "b": "BUIQELB",
            "e": [
              ",BIB",
              ",EBB",
              ",LIE",
              ",BILE",
              "B,BLUE",
              ",BULB",
              ",LUBE",
              ",QUIBBLE"
            ]
          },
          "level_017": {
            "a": 683588,
            "b": "VRLATII",
            "e": [
              ",LAIR",
              ",LIAR",
              ",RAIL",
              ",TAIL",
              ",VIAL",
              ",RIVAL",
              "B,TRAIL",
              ",TRIAL",
              ",VIRAL",
              ",VITAL",
              ",TRIVIA",
              ",TRIVIAL"
            ]
          },
          "level_018": {
            "a": 683584,
            "b": "DAFROF",
            "e": [
              ",AFRO",
              ",FORA",
              ",FORD",
              ",ROAD",
              ",AFFORD"
            ]
          },
          "level_019": {
            "a": 683599,
            "b": "ADVIYL",
            "e": [
              ",AID",
              ",AIL",
              ",DAY",
              ",IVY",
              ",LAD",
              ",LAY",
              ",LID",
              ",VIA",
              ",DAILY",
              ",VALID"
            ]
          },
          "level_020": {
            "a": 683583,
            "b": "XLIOBPL",
            "e": [
              ",BILL",
              ",BLIP",
              ",BOIL",
              ",BOLL",
              ",PILL",
              ",POLL",
              ",PILLBOX"
            ]
          }
        },
        "m": 7733248,
        "o": 48538,
        "r": 8997376,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 13697024,
        "w": 16777215,
        "x": 4294967295,
        "y": 0.7000000000000001,
        "z": 0
      },
      "set_4": {
        "a": "BELOW",
        "aa": 12189696,
        "bb": 16777215,
        "cc": 268435455,
        "d": "bg_rainbow4.jpg",
        "dd": 12189696,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 12189696,
        "k": 268435455,
        "l": 12189696,
        "levels": {
          "level_001": {
            "a": 683758,
            "b": "SABYPS",
            "e": [
              ",ABS",
              ",ASP",
              ",BAS",
              ",BAY",
              ",PAY",
              ",SAP",
              ",SAY",
              ",SPA",
              ",SPY",
              ",BYPASS"
            ]
          },
          "level_002": {
            "a": 683761,
            "b": "DEUSCXE",
            "e": [
              ",CUE",
              ",DUE",
              ",SEE",
              ",SEX",
              ",SUE",
              ",USE",
              ",EXCUSE",
              ",SEDUCE"
            ]
          },
          "level_003": {
            "a": 683771,
            "b": "JCTAKE",
            "e": [
              ",CAKE",
              ",JACK",
              ",TACK",
              ",TAKE",
              ",TEAK",
              ",JACKET"
            ]
          },
          "level_004": {
            "a": 683772,
            "b": "ASLCPEL",
            "e": [
              ",CLASP",
              "B,LAPEL",
              ",LAPSE",
              ",PLACE",
              ",SCALE",
              ",SCALP",
              ",SPACE",
              ",SPELL",
              ",SCALPEL"
            ]
          },
          "level_005": {
            "a": 683759,
            "b": "IMEEDPT",
            "e": [
              ",DIM",
              "B,DIP",
              ",IMP",
              ",MET",
              ",MID",
              ",PET",
              ",PIE",
              ",PIT",
              ",TEE",
              ",TIE",
              ",TIP",
              ",EMPTIED"
            ]
          },
          "level_006": {
            "a": 683765,
            "b": "RETNERE",
            "e": [
              ",RENT",
              ",TEEN",
              ",TERN",
              ",TREE",
              ",ENTER",
              ",ENTREE",
              "B,RENTER",
              ",REENTER"
            ]
          },
          "level_007": {
            "a": 683766,
            "b": "IFTSH",
            "e": [
              ",FIT",
              ",HIS",
              ",HIT",
              ",ITS",
              ",SIT",
              ",TIS",
              ",FISH",
              ",FIST",
              ",SIFT",
              ",THIS"
            ]
          },
          "level_008": {
            "a": 683768,
            "b": "REUSOD",
            "e": [
              ",DOUSE",
              ",ROUSE",
              ",ROUSED",
              ",SOURED"
            ]
          },
          "level_009": {
            "a": 683774,
            "b": "YASLSG",
            "e": [
              ",SLAY",
              ",GASSY",
              ",GLASS",
              ",GLASSY"
            ]
          },
          "level_010": {
            "a": 683770,
            "b": "NTATFE",
            "e": [
              ",ANTE",
              ",FATE",
              ",FEAT",
              ",FETA",
              ",NEAT",
              ",TENT",
              ",FATTEN"
            ]
          },
          "level_011": {
            "a": 683757,
            "b": "GLGBOE",
            "e": [
              ",BLOG",
              ",GLOB",
              ",LOBE",
              ",OGLE",
              ",GLOBE"
            ]
          },
          "level_012": {
            "a": 683773,
            "b": "URFALM",
            "e": [
              ",ARM",
              ",FAR",
              ",FLU",
              ",FUR",
              ",LAM",
              ",MAR",
              ",RAM",
              ",RUM",
              ",ALUM",
              ",FARM",
              ",MAUL",
              ",ARMFUL"
            ]
          },
          "level_013": {
            "a": 683767,
            "b": "ERFNNOI",
            "e": [
              ",FERN",
              ",FINE",
              ",FIRE",
              ",FORE",
              ",INFO",
              ",IRON",
              ",NEON",
              ",NINE",
              ",NONE",
              ",REIN",
              ",RIFE"
            ]
          },
          "level_014": {
            "a": 683769,
            "b": "SRIEPEC",
            "e": [
              ",EPIC",
              "B,PEER",
              ",PIER",
              ",RICE",
              ",RIPE",
              ",RISE",
              ",SEEP",
              ",SEER",
              ",SIRE",
              ",SPEC",
              ",RECIPE",
              ",PRECISE"
            ]
          },
          "level_015": {
            "a": 683764,
            "b": "CRCNAE",
            "e": [
              ",ACNE",
              ",ACRE",
              ",CANE",
              ",CARE",
              ",EARN",
              ",NEAR",
              ",RACE",
              ",CANCER"
            ]
          },
          "level_016": {
            "a": 683760,
            "b": "SAUTRMD",
            "e": [
              ",DATUM",
              ",SMART",
              ",STRUM",
              ",MUSTARD"
            ]
          },
          "level_017": {
            "a": 683775,
            "b": "TAERT",
            "e": [
              ",ARE",
              ",ART",
              ",ATE",
              ",EAR",
              ",EAT",
              ",ERA",
              ",RAT",
              ",TAR",
              ",TEA",
              ",RATE",
              "B,TART",
              ",TEAR"
            ]
          },
          "level_018": {
            "a": 683763,
            "b": "NNSMYOY",
            "e": [
              ",SON",
              ",SOY",
              ",YON",
              ",SYNONYM"
            ]
          },
          "level_019": {
            "a": 683762,
            "b": "ANGEDA",
            "e": [
              ",AGE",
              ",AND",
              ",DEN",
              ",END",
              ",NAG",
              ",AGED",
              "B,DEAN",
              ",ADAGE",
              ",AGENDA"
            ]
          },
          "level_020": {
            "a": 683756,
            "b": "MEDAIML",
            "e": [
              ",AIMED",
              ",EMAIL",
              ",IDEAL",
              ",LAMED",
              ",LEMMA",
              ",MEDAL",
              ",MEDIA",
              ",MIMED",
              ",DILEMMA"
            ]
          }
        },
        "m": 7733248,
        "o": 7391488,
        "r": 8997376,
        "t": 0.65,
        "u": 0,
        "v": 12189696,
        "w": 16777215,
        "x": 268435455,
        "y": 0.65,
        "z": 0
      },
      "set_5": {
        "a": "ARRIVE",
        "aa": 12517376,
        "bb": 16777215,
        "cc": 268435455,
        "d": "bg_rainbow5.jpg",
        "dd": 12517376,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 12517376,
        "k": 268435455,
        "l": 12517376,
        "levels": {
          "level_001": {
            "a": 683991,
            "b": "EALEXMP",
            "e": [
              ",AMPLE",
              ",EXPEL",
              ",MAPLE",
              ",EXAMPLE"
            ]
          },
          "level_002": {
            "a": 683993,
            "b": "EASUCD",
            "e": [
              ",ACED",
              ",CASE",
              ",CUED",
              ",SCUD",
              ",SUED",
              ",USED",
              ",CAUSE",
              ",SAUCE",
              ",CAUSED"
            ]
          },
          "level_003": {
            "a": 683992,
            "b": "VILENOV",
            "e": [
              ",ION",
              ",LIE",
              ",NIL",
              ",OIL",
              ",ONE",
              ",VIE",
              ",LIVEN",
              "B,NOVEL",
              ",OLIVE",
              ",INVOLVE"
            ]
          },
          "level_004": {
            "a": 683988,
            "b": "OSMUSP",
            "e": [
              ",MOP",
              ",OPS",
              ",PUS",
              ",SOP",
              ",SUM",
              ",SUP",
              ",UPS",
              ",OPUS",
              ",SOUP",
              ",SUMO",
              ",SUMP"
            ]
          },
          "level_005": {
            "a": 683986,
            "b": "DAGAMNR",
            "e": [
              ",DARN",
              ",DRAG",
              ",DRAM",
              ",GRAD",
              ",GRAM",
              ",RANG"
            ]
          },
          "level_006": {
            "a": 683990,
            "b": "TORECPJ",
            "e": [
              ",COPE",
              ",CORE",
              ",CROP",
              ",PERT",
              ",POET",
              ",PORE",
              ",PORT",
              ",REPO",
              ",ROPE",
              ",ROTE",
              ",TORE"
            ]
          },
          "level_007": {
            "a": 683994,
            "b": "HIEMCNA",
            "e": [
              ",CHAIN",
              ",CHIME",
              ",CHINA",
              ",MANIC",
              ",MINCE",
              ",NICHE",
              ",MACHINE"
            ]
          },
          "level_008": {
            "a": 683976,
            "b": "GHUSON",
            "e": [
              ",GOSH",
              ",GUSH",
              ",HUNG",
              ",ONUS",
              ",SHUN",
              ",SNUG",
              ",SONG",
              ",SUNG",
              ",SHOGUN"
            ]
          },
          "level_009": {
            "a": 683983,
            "b": "BTYOEIS",
            "e": [
              ",BEST",
              ",BITE",
              ",BYTE",
              ",OBEY",
              ",SITE",
              ",YETI",
              ",BITSY",
              ",OBESITY"
            ]
          },
          "level_010": {
            "a": 683979,
            "b": "TGBUHRO",
            "e": [
              ",BOUGH",
              "B,BROTH",
              ",GROUT",
              ",OUGHT",
              ",ROUGH",
              ",THROB",
              ",TOUGH",
              ",TURBO",
              ",BROUGHT"
            ]
          },
          "level_011": {
            "a": 683980,
            "b": "EELDTRA",
            "e": [
              ",ALDER",
              ",ALERT",
              ",ALTER",
              ",DEALT",
              ",DELTA",
              ",DETER",
              ",EATER",
              ",ELDER",
              ",LATER",
              ",RATED",
              ",TRADE",
              ",TREAD"
            ]
          },
          "level_012": {
            "a": 683985,
            "b": "TSMILIE",
            "e": [
              ",ISLET",
              "B,LIMIT",
              ",SLIME",
              ",SMELT",
              ",SMILE",
              ",ELITISM"
            ]
          },
          "level_013": {
            "a": 683982,
            "b": "SELOU",
            "e": [
              ",LOSE",
              "B,SOLE",
              ",SOUL",
              ",LOUSE"
            ]
          },
          "level_014": {
            "a": 683978,
            "b": "EENIDFR",
            "e": [
              ",DEFER",
              ",DINER",
              ",FIEND",
              ",FINED",
              ",FINER",
              ",FIRED",
              ",FREED",
              ",FRIED",
              ",INFER",
              ",REFINED"
            ]
          },
          "level_015": {
            "a": 683977,
            "b": "LKCYNU",
            "e": [
              ",LUCK",
              ",YUCK",
              ",CLUNK",
              ",LUCKY"
            ]
          },
          "level_016": {
            "a": 683995,
            "b": "EDYAREN",
            "e": [
              ",NEEDY",
              ",NERDY",
              ",RANDY",
              ",READY",
              ",REEDY",
              ",YEARN",
              ",EARNED",
              ",ENDEAR",
              ",NEARED",
              ",YEAREND",
              "B,YEARNED"
            ]
          },
          "level_017": {
            "a": 683987,
            "b": "TOTSTHE",
            "e": [
              ",HOSE",
              ",HOST",
              ",SHOE",
              ",SHOT",
              ",TEST",
              ",TOTE",
              ",ETHOS",
              ",THOSE",
              ",HOTTEST"
            ]
          },
          "level_018": {
            "a": 683984,
            "b": "DSEEAT",
            "e": [
              ",DATE",
              ",EASE",
              ",EAST",
              ",SEAT",
              ",SEED",
              ",EASED",
              ",SATED",
              ",STEAD",
              ",TEASE",
              ",SEATED",
              ",SEDATE",
              ",TEASED"
            ]
          },
          "level_019": {
            "a": 683981,
            "b": "RWADA",
            "e": [
              ",RAD",
              ",RAW",
              ",WAD",
              ",WAR",
              ",DRAW",
              ",WARD",
              ",AWARD"
            ]
          },
          "level_020": {
            "a": 683989,
            "b": "ITRMEGA",
            "e": [
              ",IMAGER",
              "B,MIRAGE",
              ",TRIAGE",
              ",MIGRATE"
            ]
          }
        },
        "m": 7733248,
        "o": 16462080,
        "r": 7733248,
        "t": 0.65,
        "u": 0,
        "v": 12517376,
        "w": 16777215,
        "x": 268435455,
        "y": 0.65,
        "z": 0
      }
    }
  },
  "WS 16": {
    "a": "LAKE",
    "b": "grad_white",
    "c": "grp_lakes",
    "d": 0.75,
    "e": 6080206,
    "f": 3057070,
    "sets": {
      "set_1": {
        "a": "CALM",
        "aa": 6080206,
        "d": "bg_lake1.jpg",
        "dd": 6080206,
        "e": 0,
        "j": 6080206,
        "l": 6080206,
        "levels": {
          "level_001": {
            "a": 684134,
            "b": "CYLSIK",
            "e": [
              ",ICY",
              ",ILK",
              ",SKI",
              ",SKY",
              ",SLY",
              ",ICKY",
              ",LICK",
              ",SICK",
              ",SILK",
              ",SILKY",
              ",SLICK"
            ]
          },
          "level_002": {
            "a": 684132,
            "b": "EEHETS",
            "e": [
              ",SEE",
              ",SET",
              ",SHE",
              ",TEE",
              ",THE",
              ",THEE",
              ",SHEET",
              ",THESE",
              ",SEETHE"
            ]
          },
          "level_003": {
            "a": 684131,
            "b": "MODESL",
            "e": [
              ",DOE",
              ",ELM",
              ",LED",
              ",ODE",
              ",OLD",
              ",SOD",
              ",MODEL",
              ",SELDOM"
            ]
          },
          "level_004": {
            "a": 684142,
            "b": "ENRGEGO",
            "e": [
              ",GENE",
              ",GONE",
              ",GONG",
              ",GORE",
              ",OGRE",
              ",GENRE",
              ",GONER",
              ",GORGE",
              ",GREEN",
              ",ENGORGE"
            ]
          },
          "level_005": {
            "a": 684130,
            "b": "TSHAF",
            "e": [
              ",AFT",
              ",ASH",
              ",FAT",
              ",HAS",
              ",HAT",
              ",SAT",
              ",FAST",
              "B,HAFT",
              ",SHAFT"
            ]
          },
          "level_006": {
            "a": 684126,
            "b": "WRATH",
            "e": [
              ",HART",
              ",THAW",
              ",WART",
              ",WHAT",
              ",WRATH"
            ]
          },
          "level_007": {
            "a": 684128,
            "b": "ARTTFEL",
            "e": [
              ",FALTER",
              ",FATTER",
              ",LATTER",
              ",RATTLE"
            ]
          },
          "level_008": {
            "a": 684140,
            "b": "NAEAWK",
            "e": [
              ",ANEW",
              ",KNEW",
              ",WAKE",
              ",WANE",
              ",WEAK",
              ",WEAN",
              ",AWAKE",
              "B,WAKEN"
            ]
          },
          "level_009": {
            "a": 684137,
            "b": "MEHUAN",
            "e": [
              ",AHEM",
              "B,AMEN",
              ",MANE",
              ",MEAN",
              ",MENU",
              ",NAME",
              ",HUMAN",
              ",HUMANE"
            ]
          },
          "level_010": {
            "a": 684129,
            "b": "ASTEWR",
            "e": [
              ",STARE",
              ",STRAW",
              ",SWEAR",
              ",SWEAT",
              ",WASTE",
              ",WATER",
              ",WREST",
              ",RAWEST"
            ]
          },
          "level_011": {
            "a": 684136,
            "b": "OARDE",
            "e": [
              ",DARE",
              ",DEAR",
              ",DOER",
              ",READ",
              ",REDO",
              ",ROAD",
              ",RODE",
              ",ADORE"
            ]
          },
          "level_012": {
            "a": 684124,
            "b": "MLBUICI",
            "e": [
              ",BUM",
              ",CUB",
              ",MIL",
              ",CLUB",
              ",LIMB",
              ",CLIMB",
              ",LIMBIC",
              ",BULIMIC"
            ]
          },
          "level_013": {
            "a": 684125,
            "b": "HREEOVW",
            "e": [
              ",EVER",
              ",HERE",
              ",HERO",
              ",OVER",
              ",ROVE",
              ",VEER",
              ",WERE",
              ",WORE",
              ",WOVE"
            ]
          },
          "level_014": {
            "a": 684143,
            "b": "LRASCHO",
            "e": [
              ",CAROL",
              "B,CLASH",
              ",CORAL",
              ",CRASH",
              ",ROACH",
              ",SHOAL",
              ",SOLAR",
              ",SCHOLAR"
            ]
          },
          "level_015": {
            "a": 684141,
            "b": "LRCUE",
            "e": [
              ",CUE",
              ",CUR",
              ",RUE",
              ",CLUE",
              ",CURE",
              ",CURL",
              ",LURE",
              ",RULE"
            ]
          },
          "level_016": {
            "a": 684139,
            "b": "RNSFOFA",
            "e": [
              ",AFRO",
              ",FORA",
              ",ROAN",
              ",SOAR",
              ",SOFA",
              ",ARSON",
              ",SONAR",
              ",SAFFRON"
            ]
          },
          "level_017": {
            "a": 684135,
            "b": "YTNISG",
            "e": [
              ",GIST",
              ",SIGN",
              ",SING",
              ",TINY",
              ",STINGY"
            ]
          },
          "level_018": {
            "a": 684138,
            "b": "COFLNA",
            "e": [
              ",CALF",
              ",CLAN",
              ",COAL",
              ",COLA",
              ",FLAN",
              ",FOAL",
              ",LOAF",
              ",LOAN"
            ]
          },
          "level_019": {
            "a": 684133,
            "b": "ETCXIO",
            "e": [
              ",COT",
              ",ICE",
              ",TIC",
              ",TIE",
              ",TOE",
              ",CITE",
              "B,EXIT",
              ",EXOTIC"
            ]
          },
          "level_020": {
            "a": 684127,
            "b": "TRUNOCO",
            "e": [
              ",COOT",
              "B,CORN",
              ",CURT",
              ",ONTO",
              ",ROOT",
              ",ROUT",
              ",RUNT",
              ",TOON",
              ",TORN",
              ",TOUR",
              ",TURN",
              ",UNTO"
            ]
          }
        },
        "m": 3057070,
        "o": 16741120,
        "r": 6639281,
        "t": 0.74,
        "v": 6080206,
        "y": 0.74
      },
      "set_2": {
        "a": "SET",
        "aa": 5291462,
        "cc": 4294967295,
        "d": "bg_lake2.jpg",
        "dd": 5291462,
        "e": 0,
        "ee": 4294967295,
        "i": 4294967295,
        "j": 5291462,
        "k": 4294967295,
        "l": 5291462,
        "levels": {
          "level_001": {
            "a": 684251,
            "b": "DAIEM",
            "e": [
              ",AID",
              ",AIM",
              ",DAM",
              ",DIM",
              ",MAD",
              ",MID",
              ",AIMED",
              ",MEDIA"
            ]
          },
          "level_002": {
            "a": 684268,
            "b": "APTEUD",
            "e": [
              ",ADEPT",
              ",TAPED",
              ",TAUPE",
              ",UPDATE"
            ]
          },
          "level_003": {
            "a": 684269,
            "b": "HTUOSG",
            "e": [
              ",GOT",
              "B,GUT",
              ",HOG",
              ",HOT",
              ",HUG",
              ",HUT",
              ",OUT",
              ",TUG",
              ",UGH",
              ",SOUGHT"
            ]
          },
          "level_004": {
            "a": 684262,
            "b": "UPITRS",
            "e": [
              ",RUST",
              ",SPIT",
              ",SPUR",
              ",STIR",
              ",SUIT",
              ",TRIP",
              ",SPURT",
              ",STRIP",
              ",PURIST"
            ]
          },
          "level_005": {
            "a": 684256,
            "b": "YAMEMH",
            "e": [
              ",AYE",
              "B,HAM",
              ",HAY",
              ",HEM",
              ",HEY",
              ",MAM",
              ",MAY",
              ",YAM",
              ",YEA",
              ",MAYHEM"
            ]
          },
          "level_006": {
            "a": 684266,
            "b": "ULSBLEI",
            "e": [
              ",BELL",
              "B,BILE",
              ",BILL",
              ",BLUE",
              ",BULL",
              ",ISLE",
              ",LUBE",
              ",SELL",
              ",SILL",
              ",LIBEL"
            ]
          },
          "level_007": {
            "a": 684260,
            "b": "MTDLUBE",
            "e": [
              ",DEBUT",
              ",MUTED",
              ",TUBED",
              ",TUMBLE",
              ",TUMBLED"
            ]
          },
          "level_008": {
            "a": 684253,
            "b": "TICUSON",
            "e": [
              ",COUNT",
              "B,SCION",
              ",SCOUT",
              ",SNOUT",
              ",SONIC",
              ",STOIC",
              ",TONIC",
              ",TUNIC",
              ",COUSIN",
              ",SUCTION"
            ]
          },
          "level_009": {
            "a": 684255,
            "b": "MEEZYN",
            "e": [
              ",EYE",
              ",MEN",
              ",YEN",
              ",ENEMY",
              ",ENZYME"
            ]
          },
          "level_010": {
            "a": 684263,
            "b": "ICFNTAR",
            "e": [
              ",ANTIC",
              "B,CAIRN",
              ",CRAFT",
              ",FAINT",
              ",TRAIN"
            ]
          },
          "level_011": {
            "a": 684264,
            "b": "MCLALY",
            "e": [
              ",ALLY",
              ",CALL",
              ",CALM",
              ",CLAM",
              ",CLAY",
              ",LACY",
              ",MALL",
              ",CALMLY"
            ]
          },
          "level_012": {
            "a": 684261,
            "b": "AOUSPYT",
            "e": [
              ",PASTY",
              ",PATSY",
              ",POUTY",
              ",SOAPY",
              ",SOUPY",
              ",SPOUT",
              ",AUTOPSY"
            ]
          },
          "level_013": {
            "a": 684257,
            "b": "EEMTELN",
            "e": [
              ",LENT",
              ",MEET",
              ",MELT",
              ",TEEN",
              ",MELEE"
            ]
          },
          "level_014": {
            "a": 684254,
            "b": "PEKIIN",
            "e": [
              ",INK",
              ",KIN",
              ",NIP",
              ",PEN",
              ",PIE",
              ",PIN",
              ",PIKE",
              ",PINE",
              ",PINK",
              ",PINKIE"
            ]
          },
          "level_015": {
            "a": 684259,
            "b": "DYPREIS",
            "e": [
              ",DIRE",
              "B,DRIP",
              ",PIER",
              ",PREY",
              ",PYRE",
              ",RIDE",
              ",RIPE",
              ",RISE",
              ",SIDE",
              ",SIRE",
              ",SPED",
              ",SPRY"
            ]
          },
          "level_016": {
            "a": 684267,
            "b": "LSUEAB",
            "e": [
              ",ABS",
              ",ALE",
              ",BAS",
              ",BUS",
              ",LAB",
              ",SEA",
              ",SUB",
              ",SUE",
              ",USE",
              ",ABUSE",
              ",BLASE",
              ",SABLE"
            ]
          },
          "level_017": {
            "a": 684252,
            "b": "EHALVYI",
            "e": [
              ",ALIVE",
              ",HALVE",
              ",HEAVY",
              ",HEAVILY"
            ]
          },
          "level_018": {
            "a": 684265,
            "b": "RLMYEE",
            "e": [
              ",LEER",
              ",LYRE",
              ",MERE",
              ",REEL",
              ",RELY",
              ",EMERY",
              ",LEERY",
              ",MERELY"
            ]
          },
          "level_019": {
            "a": 684250,
            "b": "EWLOLB",
            "e": [
              ",BOW",
              ",LOB",
              ",LOW",
              ",OWE",
              ",OWL",
              ",WEB",
              ",WOE",
              ",BELOW",
              ",ELBOW",
              ",BELLOW"
            ]
          },
          "level_020": {
            "a": 684258,
            "b": "OEEPDRC",
            "e": [
              ",CODER",
              ",COPED",
              ",CORED",
              ",CREDO",
              ",CREED",
              ",CREEP",
              ",CREPE",
              ",DECOR",
              ",ERODE",
              ",ROPED"
            ]
          }
        },
        "m": 2395798,
        "o": 48538,
        "r": 5981855,
        "t": 0.76,
        "v": 5291462,
        "x": 4294967295,
        "y": 0.76
      },
      "set_3": {
        "a": "SERENE",
        "aa": 4568510,
        "bb": 16777215,
        "cc": 4294967295,
        "d": "bg_lake3.jpg",
        "dd": 4568510,
        "e": 0,
        "ee": 4294967295,
        "g": 0.92,
        "i": 4294967295,
        "j": 4568510,
        "k": 4294967295,
        "l": 4568510,
        "levels": {
          "level_001": {
            "a": 684410,
            "b": "HSUAEKP",
            "e": [
              ",HEAP",
              ",HUSK",
              ",PEAK",
              ",PUSH",
              ",SAKE",
              ",PAUSE",
              "B,PHASE",
              ",SHAKE",
              ",SHAPE",
              ",SPEAK",
              ",SHAKEUP"
            ]
          },
          "level_002": {
            "a": 684411,
            "b": "NKOOS",
            "e": [
              ",SON",
              ",NOOK",
              ",SOON",
              ",SNOOK"
            ]
          },
          "level_003": {
            "a": 684415,
            "b": "HSEDEET",
            "e": [
              ",SEE",
              ",SET",
              ",SHE",
              ",TEE",
              ",THE",
              ",HEED",
              ",SEED",
              ",SHED",
              ",THEE"
            ]
          },
          "level_004": {
            "a": 684412,
            "b": "GAESDRE",
            "e": [
              ",AGREE",
              ",EAGER",
              ",EASED",
              ",EDGER",
              ",ERASE",
              ",GRADE",
              ",GREED",
              ",RAGED",
              ",SEDGE"
            ]
          },
          "level_005": {
            "a": 684419,
            "b": "PKEYR",
            "e": [
              ",KEY",
              ",PER",
              ",PRY",
              ",REP",
              ",RYE",
              ",YEP",
              ",PERKY"
            ]
          },
          "level_006": {
            "a": 684413,
            "b": "EDROSTK",
            "e": [
              ",STOKE",
              ",STORE",
              ",STORK",
              ",SORTED",
              "B,STOKED",
              ",STORED",
              ",STRODE",
              ",STROKE"
            ]
          },
          "level_007": {
            "a": 684407,
            "b": "HTEATRE",
            "e": [
              ",EARTH",
              ",EATER",
              ",ETHER",
              ",HATER",
              ",HEART",
              ",TEETH",
              ",THERE",
              ",THETA",
              ",THREE",
              ",TREAT",
              ",THEATER",
              "B,THEATRE"
            ]
          },
          "level_008": {
            "a": 684422,
            "b": "NCHEWE",
            "e": [
              ",EWE",
              ",HEN",
              ",HEW",
              ",NEW",
              ",WEE",
              ",CHEW",
              ",HEWN",
              ",WHEN",
              ",HENCE",
              ",WENCH",
              ",WHENCE"
            ]
          },
          "level_009": {
            "a": 684423,
            "b": "IGHTL",
            "e": [
              ",GIT",
              ",HIT",
              ",LIT",
              ",TIL",
              ",GILT",
              "B,HILT"
            ]
          },
          "level_010": {
            "a": 684414,
            "b": "EUDISRB",
            "e": [
              ",BRUISE",
              ",BURIED",
              ",BURIES",
              ",BUSIED",
              ",BUSIER",
              ",DEBRIS",
              ",RUBIES",
              ",BRUISED"
            ]
          },
          "level_011": {
            "a": 684405,
            "b": "GBUTHO",
            "e": [
              ",BOUGH",
              ",OUGHT",
              ",TOUGH",
              ",BOUGHT"
            ]
          },
          "level_012": {
            "a": 684404,
            "b": "DYTAUIL",
            "e": [
              ",DIAL",
              ",DUAL",
              ",DULY",
              ",DUTY",
              ",IDLY",
              ",LADY",
              ",LAID",
              ",LAUD",
              ",TAIL",
              ",TIDY",
              ",DUALITY"
            ]
          },
          "level_013": {
            "a": 684418,
            "b": "IRFERMA",
            "e": [
              ",FAIR",
              ",FAME",
              ",FARE",
              ",FARM",
              ",FEAR",
              ",FIRE",
              ",FIRM",
              ",MARE",
              ",MIRE",
              ",RARE",
              ",REAR",
              ",RIFE"
            ]
          },
          "level_014": {
            "a": 684406,
            "b": "NOEILPS",
            "e": [
              ",NOISE",
              ",POISE",
              ",POLIS",
              ",SLOPE",
              ",SNIPE",
              ",SPINE",
              ",SPOIL",
              ",LESION",
              ",PONIES"
            ]
          },
          "level_015": {
            "a": 684416,
            "b": "REOGN",
            "e": [
              ",EGO",
              ",NOR",
              ",ONE",
              ",ORE",
              ",GONE",
              ",GORE",
              ",OGRE",
              ",GONER"
            ]
          },
          "level_016": {
            "a": 684421,
            "b": "ERJCNUO",
            "e": [
              ",CRONE",
              ",OUNCE",
              ",RECON",
              ",CONJURE"
            ]
          },
          "level_017": {
            "a": 684417,
            "b": "IMVARTN",
            "e": [
              ",ANTI",
              "B,MAIN",
              ",MART",
              ",MINT",
              ",RAIN",
              ",RANT",
              ",TRAM",
              ",TRIM",
              ",VAIN"
            ]
          },
          "level_018": {
            "a": 684408,
            "b": "TRREUNU",
            "e": [
              ",RERUN",
              ",TRUER",
              ",TUNER",
              ",RETURN",
              ",UNTRUE"
            ]
          },
          "level_019": {
            "a": 684409,
            "b": "DMSAAEH",
            "e": [
              ",AHEAD",
              ",SHADE",
              ",SHAME",
              ",MASHED",
              ",SHAMED"
            ]
          },
          "level_020": {
            "a": 684420,
            "b": "TEBCAAR",
            "e": [
              ",ABATE",
              "B,BRACE",
              ",CARAT",
              ",CATER",
              ",CRATE",
              ",REACT",
              ",TRACE",
              ",CABARET"
            ]
          }
        },
        "m": 2063748,
        "o": 48538,
        "r": 5390222,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 4568510,
        "w": 16777215,
        "x": 4294967295,
        "y": 0.7000000000000001,
        "z": 0
      },
      "set_4": {
        "a": "AIR",
        "aa": 3780022,
        "bb": 16777215,
        "cc": 268435455,
        "d": "bg_lake4.jpg",
        "dd": 3780022,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 3780022,
        "k": 268435455,
        "l": 3780022,
        "levels": {
          "level_001": {
            "a": 684554,
            "b": "YECTOO",
            "e": [
              ",COO",
              ",COT",
              ",COY",
              ",TOE",
              ",TOO",
              ",TOY",
              ",YET",
              ",COYOTE"
            ]
          },
          "level_002": {
            "a": 684568,
            "b": "UERSCA",
            "e": [
              ",ACRE",
              ",CARE",
              ",CASE",
              ",CURE",
              ",RACE",
              ",RUSE",
              ",SCAR",
              ",SEAR",
              ",SURE",
              ",USER",
              ",SAUCER"
            ]
          },
          "level_003": {
            "a": 684558,
            "b": "RUIETCR",
            "e": [
              ",CUE",
              ",CUR",
              ",CUT",
              ",ERR",
              ",ICE",
              ",IRE",
              ",RUE",
              ",RUT",
              ",TIC",
              ",TIE",
              ",RECRUIT"
            ]
          },
          "level_004": {
            "a": 684571,
            "b": "ONCORAC",
            "e": [
              ",COCO",
              ",CORN",
              ",CROC",
              ",ORCA",
              ",ROAN",
              ",CORONA",
              ",RACOON",
              ",RACCOON"
            ]
          },
          "level_005": {
            "a": 684561,
            "b": "ALLORC",
            "e": [
              ",ALL",
              ",ARC",
              ",CAR",
              ",OAR",
              ",COLLAR"
            ]
          },
          "level_006": {
            "a": 684572,
            "b": "LCACRIY",
            "e": [
              ",AIRY",
              ",CLAY",
              ",LACY",
              ",LAIR",
              ",LIAR",
              ",RACY",
              ",RAIL",
              ",CIRCA",
              ",LYRIC",
              ",ACRYLIC"
            ]
          },
          "level_007": {
            "a": 684564,
            "b": "BWNOR",
            "e": [
              ",BORN",
              ",BROW",
              ",WORN",
              ",BROWN"
            ]
          },
          "level_008": {
            "a": 684570,
            "b": "ITLEAGN",
            "e": [
              ",EATING",
              "B,ENTAIL",
              ",GENIAL",
              ",TANGLE",
              ",TINGLE"
            ]
          },
          "level_009": {
            "a": 684560,
            "b": "ELOD",
            "e": [
              ",DOE",
              ",LED",
              ",ODE",
              ",OLD",
              ",DOLE",
              "B,LODE"
            ]
          },
          "level_010": {
            "a": 684559,
            "b": "IEHRNIT",
            "e": [
              ",HEIR",
              ",HINT",
              ",HIRE",
              ",REIN",
              ",RENT",
              ",RITE",
              ",TERN",
              ",THEN",
              ",THIN",
              ",TIER",
              ",TINE",
              ",TIRE"
            ]
          },
          "level_011": {
            "a": 684567,
            "b": "TANNET",
            "e": [
              ",ANTE",
              "B,NEAT",
              ",TENT",
              ",TENANT"
            ]
          },
          "level_012": {
            "a": 684569,
            "b": "SYRAUPP",
            "e": [
              ",PRAY",
              ",RASP",
              ",SPAR",
              ",SPRY",
              ",SPUR",
              ",RASPY",
              ",SAPPY",
              ",SPRAY",
              ",SYRUP"
            ]
          },
          "level_013": {
            "a": 684566,
            "b": "MLSINU",
            "e": [
              ",MIL",
              ",NIL",
              ",SIM",
              ",SIN",
              ",SUM",
              ",SUN",
              ",SLIM",
              ",SLUM",
              ",MINUS"
            ]
          },
          "level_014": {
            "a": 684562,
            "b": "OMHTU",
            "e": [
              ",HOT",
              ",HUM",
              ",HUT",
              ",OHM",
              ",OUT",
              ",MOTH",
              ",THOU",
              ",MOUTH"
            ]
          },
          "level_015": {
            "a": 684557,
            "b": "ETNEAMI",
            "e": [
              ",EATEN",
              "B,MEANT",
              ",INMATE",
              ",MATINEE"
            ]
          },
          "level_016": {
            "a": 684563,
            "b": "ULRYBMC",
            "e": [
              ",BLUR",
              ",BURY",
              ",CLUB",
              ",CURB",
              ",CURL",
              ",RUBY",
              ",BURLY",
              "B,CRUMB",
              ",CURLY",
              ",CRUMBLY"
            ]
          },
          "level_017": {
            "a": 684555,
            "b": "SOYRCER",
            "e": [
              ",CORE",
              ",ROSE",
              ",ROSY",
              ",SORE",
              ",YORE",
              ",SCORE",
              ",SORRY",
              ",SCORER"
            ]
          },
          "level_018": {
            "a": 684565,
            "b": "RLVNEA",
            "e": [
              ",EARL",
              ",EARN",
              ",LANE",
              ",LEAN",
              ",NAVE",
              ",NEAR",
              ",RAVE",
              ",REAL",
              ",VALE",
              ",VANE",
              ",VEAL"
            ]
          },
          "level_019": {
            "a": 684556,
            "b": "ISPGYSO",
            "e": [
              ",OPS",
              ",PIG",
              ",SIP",
              ",SIS",
              ",SOP",
              ",SOY",
              ",SPY",
              ",GOSSIP",
              ",GOSSIPY"
            ]
          },
          "level_020": {
            "a": 684573,
            "b": "EDDIFDL",
            "e": [
              ",DELI",
              ",DIED",
              ",FILE",
              ",FLED",
              ",IDLE",
              ",LIED",
              ",LIFE",
              ",FIELD",
              "B,FILED",
              ",IDLED",
              ",FIDDLED"
            ]
          }
        },
        "m": 1600883,
        "o": 7391488,
        "r": 4667004,
        "t": 0.65,
        "u": 0,
        "v": 3780022,
        "w": 16777215,
        "x": 268435455,
        "y": 0.65,
        "z": 0
      },
      "set_5": {
        "a": "GRACE",
        "aa": 3057070,
        "cc": 268435455,
        "d": "bg_lake5.jpg",
        "dd": 3057070,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 3057070,
        "k": 268435455,
        "l": 3057070,
        "levels": {
          "level_001": {
            "a": 684711,
            "b": "ANRWD",
            "e": [
              ",AND",
              ",NAW",
              ",RAD",
              ",RAN",
              ",RAW",
              ",WAD",
              ",WAR",
              ",DRAWN"
            ]
          },
          "level_002": {
            "a": 684708,
            "b": "IRPNUT",
            "e": [
              ",PINT",
              ",PUNT",
              ",RUIN",
              ",RUNT",
              ",TRIP",
              ",TURN",
              ",UNIT",
              ",INPUT",
              ",PRINT",
              ",TURNIP"
            ]
          },
          "level_003": {
            "a": 684703,
            "b": "NGYEER",
            "e": [
              ",GENE",
              ",GREY",
              ",GENRE",
              "B,GREEN",
              ",ENERGY"
            ]
          },
          "level_004": {
            "a": 684701,
            "b": "EIMLCDA",
            "e": [
              ",AIMED",
              ",CAMEL",
              ",CLAIM",
              ",DECAL",
              ",EMAIL",
              ",IDEAL",
              ",LACED",
              ",LAMED",
              ",MEDAL",
              ",MEDIA",
              ",MEDIC"
            ]
          },
          "level_005": {
            "a": 684718,
            "b": "NOCPTEC",
            "e": [
              ",CENT",
              ",CONE",
              ",COPE",
              ",NOPE",
              ",NOTE",
              ",ONCE",
              ",OPEN",
              ",PENT",
              ",PEON",
              ",POET",
              ",TONE",
              ",CONCEPT"
            ]
          },
          "level_006": {
            "a": 684709,
            "b": "PTAERBO",
            "e": [
              ",ABORT",
              "B,OPERA",
              ",PROBE",
              ",TAPER",
              ",TROPE",
              ",PROBATE"
            ]
          },
          "level_007": {
            "a": 684700,
            "b": "TANUY",
            "e": [
              ",ANT",
              ",ANY",
              ",NAY",
              ",NUT",
              ",TAN",
              ",TAU",
              ",AUNT",
              ",TUNA"
            ]
          },
          "level_008": {
            "a": 684714,
            "b": "GTERWUO",
            "e": [
              ",GROUT",
              ",OUTER",
              ",ROGUE",
              ",ROUGE",
              ",ROUTE",
              ",TOWER",
              ",WROTE",
              ",OUTGREW"
            ]
          },
          "level_009": {
            "a": 684710,
            "b": "ARPYLE",
            "e": [
              ",EARLY",
              ",LAYER",
              ",PALER",
              ",PAYER",
              ",PEARL",
              ",RELAY",
              ",REPAY",
              ",REPLY"
            ]
          },
          "level_010": {
            "a": 684706,
            "b": "EEINSRV",
            "e": [
              ",NERVE",
              "B,NEVER",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SERVE",
              ",SEVEN",
              ",SEVER",
              ",SIEVE",
              ",SIREN",
              ",SNEER",
              ",VERSE"
            ]
          },
          "level_011": {
            "a": 684704,
            "b": "ODOWDOG",
            "e": [
              ",DOG",
              ",DOW",
              ",GOD",
              ",GOO",
              ",ODD",
              ",WOO",
              ",GOOD",
              ",WOOD"
            ]
          },
          "level_012": {
            "a": 684705,
            "b": "NLUTGTO",
            "e": [
              ",GLUT",
              ",GOUT",
              ",LONG",
              ",LOUT",
              ",LUNG",
              ",TONG",
              ",TOUT",
              ",UNTO"
            ]
          },
          "level_013": {
            "a": 684707,
            "b": "ZGZRDIA",
            "e": [
              ",ARID",
              ",DRAG",
              ",GRAD",
              ",GRID",
              ",RAID"
            ]
          },
          "level_014": {
            "a": 684702,
            "b": "UNWDSNO",
            "e": [
              ",DOWN",
              ",NOUN",
              ",ONUS",
              ",SNOW",
              ",UNDO",
              ",SOUND",
              ",WOUND"
            ]
          },
          "level_015": {
            "a": 684717,
            "b": "SHLILR",
            "e": [
              ",HIS",
              ",ILL",
              ",SIR",
              ",HILL",
              ",SILL"
            ]
          },
          "level_016": {
            "a": 684713,
            "b": "SRDVIEE",
            "e": [
              ",DERIVE",
              ",DESIRE",
              ",DEVISE",
              ",RESIDE",
              ",REVISE",
              ",SERVED",
              ",VERSED",
              ",DIVERSE",
              "B,REVISED"
            ]
          },
          "level_017": {
            "a": 684715,
            "b": "LIMCCAA",
            "e": [
              ",CALM",
              ",CLAM",
              ",MAIL",
              ",MICA"
            ]
          },
          "level_018": {
            "a": 684712,
            "b": "ASSYBR",
            "e": [
              ",ABS",
              ",BAR",
              ",BAS",
              ",BAY",
              ",BRA",
              ",RAY",
              ",SAY",
              ",BRASSY"
            ]
          },
          "level_019": {
            "a": 684719,
            "b": "DYEES",
            "e": [
              ",DYE",
              ",EYE",
              ",SEE",
              ",YES",
              ",EYED",
              "B,SEED"
            ]
          },
          "level_020": {
            "a": 684716,
            "b": "RENLKE",
            "e": [
              ",EEK",
              ",EEL",
              ",EKE",
              ",ELK",
              ",KEEL",
              "B,KEEN",
              ",KNEE",
              ",LEEK",
              ",LEER",
              ",REEK",
              ",REEL",
              ",KERNEL"
            ]
          }
        },
        "m": 1074539,
        "o": 16462080,
        "r": 4009835,
        "t": 0.65,
        "v": 3057070,
        "x": 268435455,
        "y": 0.65
      }
    }
  },
  "WS 17": {
    "a": "FIELD",
    "b": "grad_white",
    "c": "grp_fields",
    "d": 0.75,
    "e": 7822542,
    "f": 5455510,
    "sets": {
      "set_1": {
        "a": "SAIL",
        "aa": 7822542,
        "bb": 16777215,
        "d": "bg_field1.jpg",
        "dd": 7822542,
        "e": 0,
        "j": 7822542,
        "l": 7822542,
        "levels": {
          "level_001": {
            "a": 684833,
            "b": "WASIJG",
            "e": [
              ",GAS",
              ",JAG",
              ",JAW",
              ",JIG",
              ",SAG",
              ",SAW",
              ",WAG",
              ",WAS",
              ",WIG",
              ",SWAG",
              ",SWIG"
            ]
          },
          "level_002": {
            "a": 684831,
            "b": "TCERLUU",
            "e": [
              ",CRUEL",
              "B,CUTER",
              ",TRUCE",
              ",ULCER"
            ]
          },
          "level_003": {
            "a": 684841,
            "b": "OLEYDM",
            "e": [
              ",DEMO",
              "B,DOLE",
              ",DOME",
              ",LODE",
              ",MELD",
              ",MODE",
              ",MOLD",
              ",MOLE",
              ",MELODY"
            ]
          },
          "level_004": {
            "a": 684824,
            "b": "DNERRAW",
            "e": [
              ",DRAWER",
              ",ERRAND",
              ",REDRAW",
              ",REWARD",
              ",WANDER",
              ",WARDEN",
              ",WARNED",
              ",WARREN"
            ]
          },
          "level_005": {
            "a": 684825,
            "b": "OYTBO",
            "e": [
              ",BOO",
              "B,BOT",
              ",BOY",
              ",TOO",
              ",TOY",
              ",BOOT",
              ",BOOTY"
            ]
          },
          "level_006": {
            "a": 684832,
            "b": "AULLED",
            "e": [
              ",DALE",
              ",DEAL",
              ",DELL",
              ",DUAL",
              ",DUEL",
              ",DULL",
              ",LAUD",
              ",LEAD"
            ]
          },
          "level_007": {
            "a": 684828,
            "b": "TEATLR",
            "e": [
              ",ALERT",
              "B,ALTER",
              ",LATER",
              ",LATTE",
              ",TREAT"
            ]
          },
          "level_008": {
            "a": 684823,
            "b": "ALPUEGD",
            "e": [
              ",GAPED",
              ",GLADE",
              ",GLUED",
              ",PAGED",
              ",PALED",
              ",PEDAL",
              ",PLEAD",
              ",GULPED",
              ",PLAGUE",
              ",PLAGUED"
            ]
          },
          "level_009": {
            "a": 684822,
            "b": "NEIWH",
            "e": [
              ",HEN",
              ",HEW",
              ",NEW",
              ",WIN",
              ",HEWN",
              ",WHEN",
              ",WINE",
              ",WHINE"
            ]
          },
          "level_010": {
            "a": 684829,
            "b": "RAPPED",
            "e": [
              ",DARE",
              ",DEAR",
              ",PARE",
              ",PEAR",
              ",PREP",
              ",READ",
              ",REAP",
              ",DRAPE",
              ",PADRE",
              ",PAPER",
              ",PARED"
            ]
          },
          "level_011": {
            "a": 684840,
            "b": "FESIAIR",
            "e": [
              ",AFIRE",
              ",ARISE",
              ",FRIES",
              ",RAISE",
              ",SAFER"
            ]
          },
          "level_012": {
            "a": 684839,
            "b": "INKHRTE",
            "e": [
              ",HIKER",
              ",INERT",
              ",INTER",
              ",THEIR",
              ",THINE",
              ",THINK",
              ",TRIKE",
              ",TINKER",
              ",RETHINK",
              ",THINKER"
            ]
          },
          "level_013": {
            "a": 684826,
            "b": "EVGORO",
            "e": [
              ",GORE",
              ",OGRE",
              ",OVER",
              ",ROVE",
              ",GROVE",
              ",GROOVE"
            ]
          },
          "level_014": {
            "a": 684834,
            "b": "UETETXR",
            "e": [
              ",TEXT",
              ",TREE",
              ",TRUE",
              ",EXERT",
              ",UTTER"
            ]
          },
          "level_015": {
            "a": 684836,
            "b": "LGEILVA",
            "e": [
              ",AGILE",
              ",ALIVE",
              ",GAVEL",
              ",LEGAL",
              ",VILLA",
              ",VILLAGE"
            ]
          },
          "level_016": {
            "a": 684827,
            "b": "RCSNIMO",
            "e": [
              ",COIN",
              ",CORN",
              ",ICON",
              ",IRON",
              ",NORM",
              ",MICRO",
              ",MINOR",
              ",SCION",
              ",SCORN",
              ",SCRIM",
              ",SONIC",
              ",MICRON"
            ]
          },
          "level_017": {
            "a": 684830,
            "b": "ALGON",
            "e": [
              ",AGO",
              ",GAL",
              ",LAG",
              ",LOG",
              ",NAG",
              ",ALONG",
              ",ANGLO"
            ]
          },
          "level_018": {
            "a": 684838,
            "b": "GUASCMB",
            "e": [
              ",SCAB",
              ",SCAM",
              ",SCUM",
              ",SMUG",
              ",SCUBA",
              "B,SUMAC"
            ]
          },
          "level_019": {
            "a": 684837,
            "b": "DOEEVT",
            "e": [
              ",DOE",
              ",DOT",
              ",EVE",
              ",ODE",
              ",TEE",
              ",TOE",
              ",VET",
              ",VOTED",
              ",DEVOTE",
              ",VETOED"
            ]
          },
          "level_020": {
            "a": 684835,
            "b": "PDNERU",
            "e": [
              ",DUNE",
              ",DUPE",
              ",NERD",
              ",NUDE",
              ",PURE",
              ",REND",
              ",RUDE",
              ",RUNE",
              ",PRUDE",
              "B,PRUNE",
              ",UNDER"
            ]
          }
        },
        "m": 6639281,
        "o": 16741120,
        "r": 6639281,
        "t": 0.6,
        "u": 0,
        "v": 7822542,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      },
      "set_2": {
        "a": "HAZE",
        "aa": 7230656,
        "cc": 4294967295,
        "d": "bg_field2.jpg",
        "dd": 7230656,
        "e": 0,
        "ee": 4294967295,
        "i": 4294967295,
        "j": 7230656,
        "k": 4294967295,
        "l": 7230656,
        "levels": {
          "level_001": {
            "a": 684944,
            "b": "ECRGAEA",
            "e": [
              ",ACE",
              ",AGE",
              ",ARC",
              ",ARE",
              ",CAR",
              ",EAR",
              ",ERA",
              ",GEE",
              ",RAG",
              ",AGREE",
              ",EAGER",
              ",GRACE"
            ]
          },
          "level_002": {
            "a": 684959,
            "b": "SMCONIA",
            "e": [
              ",AIM",
              ",CAM",
              ",CAN",
              ",CON",
              ",ION",
              ",MAN",
              ",SAC",
              ",SIM",
              ",SIN",
              ",SON",
              ",MASONIC"
            ]
          },
          "level_003": {
            "a": 684958,
            "b": "PYLAP",
            "e": [
              ",APP",
              ",LAP",
              ",LAY",
              ",PAL",
              ",PAP",
              ",PAY",
              ",PLY",
              ",PLAY",
              ",APPLY"
            ]
          },
          "level_004": {
            "a": 684962,
            "b": "UEUBMSS",
            "e": [
              ",BUM",
              ",BUS",
              ",EMU",
              ",SUB",
              ",SUE",
              ",SUM",
              ",USE",
              ",MESS",
              ",MUSE",
              ",BUSES",
              ",SUBSUME"
            ]
          },
          "level_005": {
            "a": 684963,
            "b": "RRAPTPO",
            "e": [
              ",ATOP",
              "B,PART",
              ",PORT",
              ",PROP",
              ",RAPT",
              ",ROAR",
              ",TARP",
              ",TRAP",
              ",RAPPORT"
            ]
          },
          "level_006": {
            "a": 684956,
            "b": "NESIMEE",
            "e": [
              ",MINE",
              ",SEEM",
              ",SEEN",
              ",SEMI",
              ",SINE",
              ",ENEMIES"
            ]
          },
          "level_007": {
            "a": 684957,
            "b": "YETSAD",
            "e": [
              ",DATE",
              ",EAST",
              ",EASY",
              ",SEAT",
              ",STAY",
              ",SATED",
              "B,STEAD",
              ",YEAST"
            ]
          },
          "level_008": {
            "a": 684951,
            "b": "UNTLEF",
            "e": [
              ",FELT",
              ",FLUE",
              ",FUEL",
              ",LEFT",
              ",LENT",
              ",LUTE",
              ",TUNE",
              ",FLUENT"
            ]
          },
          "level_009": {
            "a": 684961,
            "b": "SKNNIY",
            "e": [
              ",INKY",
              ",SINK",
              ",SKIN",
              ",SKINNY"
            ]
          },
          "level_010": {
            "a": 684945,
            "b": "LEUOIQB",
            "e": [
              ",BIO",
              ",LIE",
              ",LOB",
              ",OIL",
              ",OBLIQUE"
            ]
          },
          "level_011": {
            "a": 684946,
            "b": "ATUSIM",
            "e": [
              ",MAST",
              ",MIST",
              ",MUST",
              ",SMUT",
              ",SUIT"
            ]
          },
          "level_012": {
            "a": 684947,
            "b": "BLUABE",
            "e": [
              ",ALE",
              ",EBB",
              ",LAB",
              ",ABLE",
              "B,BABE",
              ",BALE",
              ",BEAU",
              ",BLUE",
              ",BULB",
              ",LUBE"
            ]
          },
          "level_013": {
            "a": 684953,
            "b": "VLPIES",
            "e": [
              ",EVIL",
              "B,ISLE",
              ",LISP",
              ",LIVE",
              ",PILE",
              ",SLIP",
              ",VEIL",
              ",VILE",
              ",VISE"
            ]
          },
          "level_014": {
            "a": 684955,
            "b": "URTBOS",
            "e": [
              ",BOUT",
              ",BUST",
              ",OUST",
              ",ROUT",
              ",RUST",
              ",SORT",
              ",SOUR",
              ",STUB",
              ",TOUR",
              ",ROBUST"
            ]
          },
          "level_015": {
            "a": 684950,
            "b": "DEEFR",
            "e": [
              ",FED",
              ",FEE",
              ",RED",
              ",REF",
              ",DEER",
              ",FEED",
              ",FREE",
              ",REED",
              ",REEF",
              ",DEFER",
              "B,FREED"
            ]
          },
          "level_016": {
            "a": 684960,
            "b": "RGCHUO",
            "e": [
              ",CHUG",
              ",HOUR",
              ",OUCH",
              ",COUGH",
              "B,ROUGH",
              ",GROUCH"
            ]
          },
          "level_017": {
            "a": 684948,
            "b": "TBRIE",
            "e": [
              ",BET",
              ",BIT",
              ",IRE",
              ",RIB",
              ",TIE",
              ",BITE",
              ",BRIE",
              ",RITE",
              ",TIER",
              ",TIRE"
            ]
          },
          "level_018": {
            "a": 684954,
            "b": "ELTPSYE",
            "e": [
              ",ELSE",
              ",LEST",
              ",PEEL",
              ",PELT",
              ",PEST",
              ",SEEP",
              ",STEP",
              ",TYPE",
              ",YELP"
            ]
          },
          "level_019": {
            "a": 684952,
            "b": "RLYPAT",
            "e": [
              ",APTLY",
              ",PARTY",
              ",PALTRY",
              ",PARTLY"
            ]
          },
          "level_020": {
            "a": 684949,
            "b": "NTERPSE",
            "e": [
              ",PESTER",
              ",PRESET",
              ",REPENT",
              ",RESENT"
            ]
          }
        },
        "m": 5981855,
        "o": 48538,
        "r": 32512,
        "t": 0.76,
        "v": 7230656,
        "x": 4294967295,
        "y": 0.76
      },
      "set_3": {
        "a": "SOAR",
        "aa": 6639026,
        "cc": 4294967295,
        "d": "bg_field3.jpg",
        "dd": 6639026,
        "e": 0,
        "ee": 4294967295,
        "g": 0.92,
        "i": 4294967295,
        "j": 6639026,
        "k": 4294967295,
        "l": 6639026,
        "levels": {
          "level_001": {
            "a": 685137,
            "b": "AILFL",
            "e": [
              ",FAIL",
              "B,FALL",
              ",FILL",
              ",FLAIL"
            ]
          },
          "level_002": {
            "a": 685152,
            "b": "YWOLO",
            "e": [
              ",LOW",
              ",OWL",
              ",WOO",
              ",WOOL",
              ",YOWL",
              ",WOOLY"
            ]
          },
          "level_003": {
            "a": 685143,
            "b": "BSOTWE",
            "e": [
              ",BEST",
              "B,STEW",
              ",STOW",
              ",WEST",
              ",BESTOW"
            ]
          },
          "level_004": {
            "a": 685138,
            "b": "ETRHSLE",
            "e": [
              ",ETHER",
              ",RESET",
              ",SHEER",
              ",SHEET",
              ",SLEET",
              ",STEEL",
              ",STEER",
              ",TERSE",
              ",THERE",
              ",THESE",
              ",THREE",
              ",SHELTER"
            ]
          },
          "level_005": {
            "a": 685144,
            "b": "ARAMLTI",
            "e": [
              ",LAIR",
              ",LIAR",
              ",MAIL",
              ",MALT",
              ",MART",
              ",RAIL",
              ",TAIL",
              ",TRAM",
              ",TRIM"
            ]
          },
          "level_006": {
            "a": 685142,
            "b": "HYCTA",
            "e": [
              ",ACT",
              ",CAT",
              ",CAY",
              ",HAT",
              ",HAY",
              ",THY",
              ",ACHY",
              ",CHAT",
              ",YACHT"
            ]
          },
          "level_007": {
            "a": 685149,
            "b": "TORMO",
            "e": [
              ",MOO",
              ",ROT",
              ",TOO",
              ",MOOR",
              ",MOOT",
              ",ROOM",
              ",ROOT",
              ",MOTOR"
            ]
          },
          "level_008": {
            "a": 685147,
            "b": "ROSUOP",
            "e": [
              ",OPS",
              "B,OUR",
              ",PRO",
              ",PUS",
              ",SOP",
              ",SUP",
              ",UPS",
              ",SPOOR",
              ",POROUS"
            ]
          },
          "level_009": {
            "a": 685134,
            "b": "ERCRAT",
            "e": [
              ",CARER",
              ",CATER",
              ",CRATE",
              ",RACER",
              ",RATER",
              ",REACT",
              ",TERRA",
              ",TRACE"
            ]
          },
          "level_010": {
            "a": 685153,
            "b": "NPSGIR",
            "e": [
              ",GRIN",
              "B,GRIP",
              ",PING",
              ",RING",
              ",SIGN",
              ",SING",
              ",SNIP",
              ",SPIN",
              ",SPRIG"
            ]
          },
          "level_011": {
            "a": 685141,
            "b": "IUNTL",
            "e": [
              ",LIT",
              ",NIL",
              ",NIT",
              ",NUT",
              ",TIL",
              ",TIN",
              ",LINT",
              ",UNIT"
            ]
          },
          "level_012": {
            "a": 685139,
            "b": "RFYEBLI",
            "e": [
              ",BRIEF",
              ",FIBER",
              ",FIERY",
              ",FLIER",
              ",FLYER",
              ",RIFLE",
              ",BELFRY",
              ",BRIEFLY"
            ]
          },
          "level_013": {
            "a": 685136,
            "b": "CCKTIPO",
            "e": [
              ",COP",
              ",COT",
              ",KIT",
              ",KOI",
              ",OPT",
              ",PIC",
              ",PIT",
              ",POT",
              ",TIC",
              ",TIP",
              ",TOP",
              ",COCKPIT"
            ]
          },
          "level_014": {
            "a": 685151,
            "b": "OAFCINT",
            "e": [
              ",ANTI",
              ",COAT",
              ",COIN",
              ",FACT",
              ",FONT",
              ",ICON",
              ",INFO",
              ",INTO",
              ",IOTA",
              ",TACO"
            ]
          },
          "level_015": {
            "a": 685135,
            "b": "RYLREA",
            "e": [
              ",EARL",
              ",LYRE",
              ",RARE",
              ",REAL",
              ",REAR",
              ",RELY",
              ",YEAR",
              ",RARELY"
            ]
          },
          "level_016": {
            "a": 685146,
            "b": "OBRAHC",
            "e": [
              ",ARCH",
              ",BOAR",
              ",CARB",
              ",CHAR",
              ",CRAB",
              ",ORCA",
              ",ABHOR",
              ",COBRA",
              ",ROACH"
            ]
          },
          "level_017": {
            "a": 685145,
            "b": "RDAOIAM",
            "e": [
              ",AMID",
              ",ARID",
              ",DORM",
              ",DRAM",
              ",MAID",
              ",RAID",
              ",ROAD",
              ",ROAM"
            ]
          },
          "level_018": {
            "a": 685150,
            "b": "GNDAEBA",
            "e": [
              ",AGED",
              "B,BADE",
              ",BAND",
              ",BANE",
              ",BANG",
              ",BEAD",
              ",BEAN",
              ",BEND",
              ",DEAN",
              ",BANDAGE"
            ]
          },
          "level_019": {
            "a": 685140,
            "b": "CJENTI",
            "e": [
              ",CENT",
              "B,CITE",
              ",NICE",
              ",TINE"
            ]
          },
          "level_020": {
            "a": 685148,
            "b": "EIGLNT",
            "e": [
              ",GLINT",
              ",INLET",
              ",LEGIT",
              ",TINGE",
              ",TINGLE"
            ]
          }
        },
        "m": 5390222,
        "o": 48538,
        "r": 32512,
        "t": 0.7000000000000001,
        "v": 6639026,
        "x": 4294967295,
        "y": 0.7000000000000001
      },
      "set_4": {
        "a": "WIND",
        "aa": 6047140,
        "bb": 16777215,
        "cc": 268435455,
        "d": "bg_field4.jpg",
        "dd": 6047140,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 6047140,
        "k": 268435455,
        "l": 6047140,
        "levels": {
          "level_001": {
            "a": 685264,
            "b": "INWSUE",
            "e": [
              ",NEW",
              ",SEW",
              ",SIN",
              ",SUE",
              ",SUN",
              ",USE",
              ",WIN",
              ",SINEW",
              ",SWINE"
            ]
          },
          "level_002": {
            "a": 685252,
            "b": "LEBIEEN",
            "e": [
              ",BEEN",
              ",BILE",
              ",LIEN",
              ",LINE",
              ",BEELINE"
            ]
          },
          "level_003": {
            "a": 685258,
            "b": "MECA",
            "e": [
              ",ACE",
              ",CAM",
              ",ACME",
              ",CAME",
              ",MACE"
            ]
          },
          "level_004": {
            "a": 685256,
            "b": "ADNGMLE",
            "e": [
              ",AMEND",
              "B,ANGEL",
              ",ANGLE",
              ",GLADE",
              ",GLAND",
              ",GLEAM",
              ",GLEAN",
              ",LADEN",
              ",LAMED",
              ",MEDAL",
              ",NAMED",
              ",MANGLED"
            ]
          },
          "level_005": {
            "a": 685260,
            "b": "AHEVRS",
            "e": [
              ",HARE",
              ",HAVE",
              ",HEAR",
              ",RASH",
              ",RAVE",
              ",SAVE",
              ",SEAR",
              ",VASE",
              ",SHAVER"
            ]
          },
          "level_006": {
            "a": 685268,
            "b": "LAVEG",
            "e": [
              ",GALE",
              ",GAVE",
              ",VALE",
              ",VEAL",
              ",GAVEL"
            ]
          },
          "level_007": {
            "a": 685253,
            "b": "EROYMM",
            "e": [
              ",MOM",
              ",ORE",
              ",REM",
              ",RYE",
              ",MEMO",
              "B,MORE",
              ",YORE",
              ",MEMORY"
            ]
          },
          "level_008": {
            "a": 685261,
            "b": "EUOHIDT",
            "e": [
              ",DIET",
              ",DOTE",
              ",DUET",
              ",EDIT",
              ",HIDE",
              ",THOU",
              ",THUD",
              ",TIDE",
              ",TIED"
            ]
          },
          "level_009": {
            "a": 685255,
            "b": "OAABOKZ",
            "e": [
              ",BOA",
              ",BOO",
              ",OAK",
              ",ZOO",
              ",BOOK",
              ",BOZO"
            ]
          },
          "level_010": {
            "a": 685251,
            "b": "ERSLOR",
            "e": [
              ",LORE",
              ",LOSE",
              ",ROLE",
              ",ROSE",
              ",SOLE",
              ",SORE",
              ",LOSER",
              ",SORREL"
            ]
          },
          "level_011": {
            "a": 685250,
            "b": "YTRRAI",
            "e": [
              ",AIR",
              ",ART",
              ",RAT",
              ",RAY",
              ",TAR",
              ",TRY",
              ",AIRY",
              ",ARTY",
              ",TRAY",
              ",RARITY"
            ]
          },
          "level_012": {
            "a": 685266,
            "b": "SIVEGTE",
            "e": [
              ",GIST",
              "B,GIVE",
              ",SITE",
              ",VEST",
              ",VISE",
              ",VESTIGE"
            ]
          },
          "level_013": {
            "a": 685254,
            "b": "TPEARD",
            "e": [
              ",ADEPT",
              ",DRAPE",
              ",PADRE",
              ",PARED",
              ",RATED",
              ",TAPED",
              ",TAPER",
              ",TRADE",
              ",TREAD",
              ",DEPART",
              ",PARTED"
            ]
          },
          "level_014": {
            "a": 685267,
            "b": "EIOSPSD",
            "e": [
              ",DOPE",
              ",DOSE",
              ",POSE",
              ",SIDE",
              ",SPED",
              ",POISE",
              ",POSED",
              ",POSSE",
              ",SPIED",
              ",SPIES",
              ",POISED"
            ]
          },
          "level_015": {
            "a": 685265,
            "b": "NAPSW",
            "e": [
              ",ASP",
              ",NAP",
              ",NAW",
              ",PAN",
              ",PAW",
              ",SAP",
              ",SAW",
              ",SPA",
              ",WAS",
              ",SPAWN"
            ]
          },
          "level_016": {
            "a": 685269,
            "b": "CIDJUE",
            "e": [
              ",CUE",
              ",DUE",
              ",ICE",
              ",CUED",
              "B,DICE",
              ",ICED",
              ",JUICE",
              ",JUICED"
            ]
          },
          "level_017": {
            "a": 685257,
            "b": "OYOECNM",
            "e": [
              ",COME",
              ",CONE",
              ",MONO",
              ",MOON",
              ",OMEN",
              ",ONCE"
            ]
          },
          "level_018": {
            "a": 685262,
            "b": "TDESLOJ",
            "e": [
              ",STOLE",
              ",JOLTED",
              ",JOSTLE",
              ",OLDEST",
              ",JOSTLED"
            ]
          },
          "level_019": {
            "a": 685259,
            "b": "GNGALY",
            "e": [
              ",ANY",
              "B,GAG",
              ",GAL",
              ",LAG",
              ",LAY",
              ",NAG",
              ",NAY",
              ",GANGLY"
            ]
          },
          "level_020": {
            "a": 685263,
            "b": "ETLINMA",
            "e": [
              ",ENTAIL",
              "B,INMATE",
              ",LAMENT",
              ",MANTEL",
              ",MANTLE",
              ",MENIAL",
              ",MENTAL",
              ",AILMENT"
            ]
          }
        },
        "m": 4667004,
        "o": 7391488,
        "r": 16640,
        "t": 0.65,
        "u": 0,
        "v": 6047140,
        "w": 16777215,
        "x": 268435455,
        "y": 0.65,
        "z": 0
      },
      "set_5": {
        "a": "AMBER",
        "aa": 5455510,
        "cc": 268435455,
        "d": "bg_field5.jpg",
        "dd": 5455510,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 5455510,
        "k": 268435455,
        "l": 5455510,
        "levels": {
          "level_001": {
            "a": 685398,
            "b": "PULSEP",
            "e": [
              ",PLUS",
              ",PULP",
              ",PULSE",
              ",SUPPLE"
            ]
          },
          "level_002": {
            "a": 685409,
            "b": "ROTSN",
            "e": [
              ",NOR",
              ",NOT",
              ",ROT",
              ",SON",
              ",TON",
              ",SNOT",
              ",SORT",
              ",TORN",
              ",SNORT"
            ]
          },
          "level_003": {
            "a": 685412,
            "b": "RAENA",
            "e": [
              ",ARE",
              ",EAR",
              ",ERA",
              ",RAN",
              ",AREA",
              ",EARN",
              ",NEAR",
              ",ARENA"
            ]
          },
          "level_004": {
            "a": 685401,
            "b": "USLBMER",
            "e": [
              ",BLUER",
              ",LEMUR",
              ",RUBLE",
              ",SERUM",
              ",UMBER",
              ",LUMBER",
              ",RUMBLE",
              ",SLUMBER"
            ]
          },
          "level_005": {
            "a": 685403,
            "b": "UKMPOC",
            "e": [
              ",COMP",
              "B,COUP",
              ",MOCK",
              ",MUCK",
              ",PUCK"
            ]
          },
          "level_006": {
            "a": 685410,
            "b": "GWLAOLS",
            "e": [
              ",ALSO",
              "B,GALL",
              ",GLOW",
              ",GOAL",
              ",SAGO",
              ",SLAW",
              ",SLOG",
              ",SLOW",
              ",SWAG",
              ",WALL"
            ]
          },
          "level_007": {
            "a": 685404,
            "b": "ETMELP",
            "e": [
              ",EEL",
              ",ELM",
              ",LET",
              ",MET",
              ",PET",
              ",TEE",
              ",MEET",
              ",MELT",
              ",PEEL",
              ",PELT",
              ",TEMP"
            ]
          },
          "level_008": {
            "a": 685394,
            "b": "DLEDGI",
            "e": [
              ",DID",
              ",DIG",
              ",GEL",
              ",LED",
              ",LEG",
              ",LID",
              ",LIE",
              ",GLIDE",
              ",IDLED",
              ",GILDED",
              ",GLIDED"
            ]
          },
          "level_009": {
            "a": 685408,
            "b": "OLVSHE",
            "e": [
              ",HOE",
              ",SHE",
              ",HOVEL",
              ",SHOVE",
              ",SOLVE",
              ",SHOVEL"
            ]
          },
          "level_010": {
            "a": 685405,
            "b": "ETRCEAD",
            "e": [
              ",CARTED",
              ",CREATE",
              ",REDACT",
              ",TEARED",
              ",TRACED",
              ",CATERED",
              ",CREATED",
              ",REACTED"
            ]
          },
          "level_011": {
            "a": 685406,
            "b": "TSHOG",
            "e": [
              ",GOT",
              ",HOG",
              ",HOT",
              ",GOSH",
              ",GOTH",
              ",HOST",
              ",SHOT"
            ]
          },
          "level_012": {
            "a": 685411,
            "b": "IMAMNOA",
            "e": [
              ",AMINO",
              ",ANIMA",
              ",MANIA",
              ",AMMONIA"
            ]
          },
          "level_013": {
            "a": 685399,
            "b": "AYRYOLL",
            "e": [
              ",ALLY",
              ",ORAL",
              ",ROLL",
              ",ALLOY",
              ",LOYAL",
              ",RALLY",
              ",ROYAL",
              ",ORALLY"
            ]
          },
          "level_014": {
            "a": 685407,
            "b": "YKNID",
            "e": [
              ",DIN",
              ",INK",
              ",KID",
              ",KIN",
              ",YIN",
              ",DINK",
              "B,INKY",
              ",KIND",
              ",DINKY"
            ]
          },
          "level_015": {
            "a": 685413,
            "b": "TGEIHH",
            "e": [
              ",GET",
              ",GIT",
              ",HIT",
              ",THE",
              ",TIE",
              ",HIGH",
              ",EIGHT",
              "B,THIGH"
            ]
          },
          "level_016": {
            "a": 685396,
            "b": "TUMISL",
            "e": [
              ",LIST",
              ",LUST",
              ",MIST",
              ",MUST",
              ",SILT",
              ",SLIM",
              ",SLIT",
              ",SLUM",
              ",SMUT",
              ",SUIT",
              ",MULTI"
            ]
          },
          "level_017": {
            "a": 685402,
            "b": "IRPESLP",
            "e": [
              ",ISLE",
              ",LISP",
              ",PIER",
              ",PILE",
              ",PIPE",
              ",PREP",
              ",RILE",
              ",RIPE",
              ",RISE",
              ",SIRE",
              ",SLIP",
              ",RIPPLE"
            ]
          },
          "level_018": {
            "a": 685397,
            "b": "ROEHC",
            "e": [
              ",CORE",
              ",ECHO",
              ",HERO",
              ",CHORE",
              "B,OCHER",
              ",OCHRE"
            ]
          },
          "level_019": {
            "a": 685395,
            "b": "ELIGGGD",
            "e": [
              ",DELI",
              ",IDLE",
              ",LIED",
              ",GIGGLE",
              ",GIGGLED"
            ]
          },
          "level_020": {
            "a": 685400,
            "b": "NATURT",
            "e": [
              ",AUNT",
              "B,RANT",
              ",RUNT",
              ",TART",
              ",TAUT",
              ",TUNA",
              ",TURN",
              ",TRUANT"
            ]
          }
        },
        "m": 4009835,
        "o": 16462080,
        "r": 18953,
        "t": 0.65,
        "v": 5455510,
        "x": 268435455,
        "y": 0.65
      }
    }
  },
  "WS 18": {
    "a": "OCEAN",
    "b": "grad_white",
    "c": "grp_ocean",
    "d": 0.75,
    "e": 32511,
    "f": 21759,
    "sets": {
      "set_1": {
        "a": "VAST",
        "aa": 32511,
        "d": "bg_ocean1.jpg",
        "dd": 32511,
        "e": 0.2,
        "j": 32511,
        "l": 32511,
        "levels": {
          "level_001": {
            "a": 685561,
            "b": "DTDAE",
            "e": [
              ",ADD",
              ",ATE",
              ",DAD",
              ",EAT",
              ",TAD",
              ",TEA",
              ",DATE",
              ",DEAD"
            ]
          },
          "level_002": {
            "a": 685568,
            "b": "INTAIPS",
            "e": [
              ",ANTI",
              ",PAIN",
              ",PANT",
              ",PAST",
              ",PINT",
              ",PITA",
              ",SNAP",
              ",SNIP",
              ",SPAN",
              ",SPAT",
              ",SPIN",
              ",SPIT"
            ]
          },
          "level_003": {
            "a": 685567,
            "b": "EPRADYR",
            "e": [
              ",DREARY",
              ",PRAYED",
              ",PRAYER",
              ",DRAPERY"
            ]
          },
          "level_004": {
            "a": 685572,
            "b": "BIASNOT",
            "e": [
              ",BASIN",
              ",BATON",
              ",BISON",
              ",BOAST",
              ",SAINT",
              ",SATIN",
              ",STAIN",
              ",BONSAI",
              "B,OBTAIN",
              ",BASTION"
            ]
          },
          "level_005": {
            "a": 685560,
            "b": "OLYLCO",
            "e": [
              ",COO",
              ",COY",
              ",COOL",
              ",COOLLY"
            ]
          },
          "level_006": {
            "a": 685570,
            "b": "LYMFOIL",
            "e": [
              ",FLY",
              ",ILL",
              ",MIL",
              ",OIL",
              ",FILL",
              ",FILM",
              ",FOIL",
              ",LILY",
              ",LIMO",
              ",MILL",
              ",OILY",
              ",MOLLIFY"
            ]
          },
          "level_007": {
            "a": 685562,
            "b": "ECTREN",
            "e": [
              ",CENT",
              ",RENT",
              ",TEEN",
              ",TERN",
              ",TREE",
              ",ENTER",
              "B,ERECT",
              ",RECENT"
            ]
          },
          "level_008": {
            "a": 685564,
            "b": "LCYACIN",
            "e": [
              ",CLAN",
              ",CLAY",
              ",CYAN",
              ",LACY",
              ",LAIN",
              ",NAIL",
              ",CYNIC",
              ",INLAY"
            ]
          },
          "level_009": {
            "a": 685575,
            "b": "OLSYLW",
            "e": [
              ",LOW",
              "B,OWL",
              ",SLY",
              ",SOW",
              ",SOY",
              ",SLOWLY"
            ]
          },
          "level_010": {
            "a": 685556,
            "b": "TEROHN",
            "e": [
              ",HERON",
              ",NORTH",
              ",OTHER",
              ",TENOR",
              ",THORN",
              ",TONER",
              ",HORNET",
              ",THRONE"
            ]
          },
          "level_011": {
            "a": 685558,
            "b": "EDLMDDU",
            "e": [
              ",DUDE",
              ",DUEL",
              ",MELD",
              ",MULE",
              ",MUDDLED"
            ]
          },
          "level_012": {
            "a": 685563,
            "b": "BATRRIE",
            "e": [
              ",BRIAR",
              ",IRATE",
              ",RATER",
              ",TERRA",
              ",TRIBE",
              ",BAITER",
              ",BARTER",
              ",ARBITER"
            ]
          },
          "level_013": {
            "a": 685566,
            "b": "AEMGO",
            "e": [
              ",AGE",
              ",AGO",
              ",EGO",
              ",GEM",
              ",MAG",
              ",MEG",
              ",GAME",
              ",MAGE",
              ",MEGA",
              ",OMEGA"
            ]
          },
          "level_014": {
            "a": 685574,
            "b": "FTNICOI",
            "e": [
              ",COIN",
              ",FONT",
              ",ICON",
              ",INFO",
              ",INTO",
              ",IONIC",
              ",TONIC",
              ",FICTION"
            ]
          },
          "level_015": {
            "a": 685571,
            "b": "RMOF",
            "e": [
              ",FOR",
              ",FRO",
              ",FORM",
              ",FROM"
            ]
          },
          "level_016": {
            "a": 685573,
            "b": "SAYLKPR",
            "e": [
              ",LARK",
              ",PARK",
              ",PLAY",
              ",PRAY",
              ",RASP",
              ",SLAP",
              ",SLAY",
              ",SPAR",
              ",SPRY",
              ",SPARKY"
            ]
          },
          "level_017": {
            "a": 685559,
            "b": "FSSTATE",
            "e": [
              ",EAST",
              "B,FAST",
              ",FATE",
              ",FEAT",
              ",FESS",
              ",FETA",
              ",SAFE",
              ",SEAT",
              ",STAT",
              ",TEST",
              ",SAFEST",
              ",FASTEST"
            ]
          },
          "level_018": {
            "a": 685565,
            "b": "CMISUB",
            "e": [
              ",BUM",
              "B,BUS",
              ",CUB",
              ",SIM",
              ",SUB",
              ",SUM",
              ",MUSIC",
              ",CUBISM"
            ]
          },
          "level_019": {
            "a": 685569,
            "b": "ERNPLAT",
            "e": [
              ",ANTLER",
              "B,PARENT",
              ",PLANET",
              ",RENTAL"
            ]
          },
          "level_020": {
            "a": 685557,
            "b": "ZDEFAUN",
            "e": [
              ",DAZE",
              ",DEAF",
              ",DEAN",
              ",DUNE",
              ",FADE",
              ",FAZE",
              ",FEND",
              ",FEUD",
              ",FUND",
              ",NUDE",
              ",UNFAZED"
            ]
          }
        },
        "m": 22453,
        "o": 16626290,
        "r": 22453,
        "t": 0.7000000000000001,
        "v": 32511,
        "y": 0.7000000000000001
      },
      "set_2": {
        "a": "WAVE",
        "aa": 29695,
        "d": "bg_ocean2.jpg",
        "dd": 29695,
        "e": 0.2,
        "j": 29695,
        "l": 29695,
        "levels": {
          "level_001": {
            "a": 685672,
            "b": "HERICHS",
            "e": [
              ",CHI",
              ",HER",
              ",HIS",
              ",ICE",
              ",IRE",
              ",SHE",
              ",SIR",
              ",CRIES",
              ",SHIRE",
              ",RICHES",
              ",CHERISH"
            ]
          },
          "level_002": {
            "a": 685662,
            "b": "CNDEOCE",
            "e": [
              ",COD",
              ",CON",
              ",DEN",
              ",DOC",
              ",DOE",
              ",DON",
              ",END",
              ",NOD",
              ",ODE",
              ",ONE",
              ",ENCODE"
            ]
          },
          "level_003": {
            "a": 685664,
            "b": "LITOLPH",
            "e": [
              ",HILL",
              ",HILT",
              ",LILT",
              ",PILL",
              ",PLOT",
              ",POLL",
              ",TILL",
              ",TOIL",
              ",TOLL",
              ",PILOT",
              ",HILLTOP"
            ]
          },
          "level_004": {
            "a": 685671,
            "b": "ULGIDNA",
            "e": [
              ",ALIGN",
              "B,GLAND",
              ",GUILD",
              ",LANGUID"
            ]
          },
          "level_005": {
            "a": 685666,
            "b": "LJEGNI",
            "e": [
              ",GLEN",
              ",LIEN",
              ",LINE",
              ",JINGLE"
            ]
          },
          "level_006": {
            "a": 685679,
            "b": "ERAFAFN",
            "e": [
              ",ARE",
              ",EAR",
              ",ERA",
              ",FAN",
              ",FAR",
              ",FEN",
              ",RAN",
              ",REF",
              ",FANFARE"
            ]
          },
          "level_007": {
            "a": 685669,
            "b": "AROTRO",
            "e": [
              ",ROAR",
              ",ROOT",
              ",ROTOR",
              ",ORATOR"
            ]
          },
          "level_008": {
            "a": 685665,
            "b": "MROIEVP",
            "e": [
              ",MOVER",
              "B,MOVIE",
              ",PRIME",
              ",PRIMO",
              ",PROVE",
              ",VIPER",
              ",IMPROV"
            ]
          },
          "level_009": {
            "a": 685678,
            "b": "QIUKLCY",
            "e": [
              ",ICY",
              ",ILK",
              ",ICKY",
              ",LICK",
              ",LUCK",
              ",YUCK",
              ",LUCKY",
              "B,QUICK"
            ]
          },
          "level_010": {
            "a": 685681,
            "b": "VELRAT",
            "e": [
              ",EARL",
              "B,LATE",
              ",RATE",
              ",RAVE",
              ",REAL",
              ",TALE",
              ",TEAL",
              ",TEAR",
              ",VALE",
              ",VEAL",
              ",TRAVEL"
            ]
          },
          "level_011": {
            "a": 685670,
            "b": "AVLDI",
            "e": [
              ",AID",
              ",AIL",
              ",LAD",
              ",LID",
              ",VIA",
              ",AVID",
              ",DIAL",
              ",DIVA",
              ",LAID",
              ",VIAL",
              ",VALID"
            ]
          },
          "level_012": {
            "a": 685668,
            "b": "LDBGOUL",
            "e": [
              ",BLOG",
              "B,BOLD",
              ",BOLL",
              ",BULL",
              ",DOLL",
              ",DULL",
              ",GLOB",
              ",GOLD",
              ",GULL",
              ",LOUD",
              ",BULLDOG"
            ]
          },
          "level_013": {
            "a": 685673,
            "b": "NBRAYE",
            "e": [
              ",BANE",
              ",BARE",
              ",BARN",
              ",BEAN",
              ",BEAR",
              ",BRAN",
              ",EARN",
              ",NARY",
              ",NEAR",
              ",YARN",
              ",YEAR",
              ",YEARN"
            ]
          },
          "level_014": {
            "a": 685677,
            "b": "BROEUG",
            "e": [
              ",BORE",
              ",BURG",
              ",EURO",
              ",GORE",
              ",GRUB",
              ",OGRE",
              ",ROBE",
              ",URGE"
            ]
          },
          "level_015": {
            "a": 685674,
            "b": "REVIGOF",
            "e": [
              ",FORGE",
              ",GIVER",
              ",GRIEF",
              ",GROVE",
              ",VIGOR"
            ]
          },
          "level_016": {
            "a": 685680,
            "b": "REHPPI",
            "e": [
              ",HEIR",
              ",HIRE",
              ",PIER",
              ",PIPE",
              ",PREP",
              ",RIPE",
              ",PIPER",
              ",HIPPER"
            ]
          },
          "level_017": {
            "a": 685675,
            "b": "YEWAREF",
            "e": [
              ",FEWER",
              "B,WAFER",
              ",WEARY",
              ",FREEWAY"
            ]
          },
          "level_018": {
            "a": 685676,
            "b": "FRHEURT",
            "e": [
              ",FRET",
              ",HEFT",
              ",HURT",
              ",THRU",
              ",TRUE",
              ",TURF",
              ",TRUER",
              ",FURTHER"
            ]
          },
          "level_019": {
            "a": 685663,
            "b": "OMIAX",
            "e": [
              ",AIM",
              ",MAX",
              ",MIX",
              ",AXIOM"
            ]
          },
          "level_020": {
            "a": 685667,
            "b": "OESUIVD",
            "e": [
              ",DIVE",
              ",DOSE",
              ",DOVE",
              ",SIDE",
              ",SUED",
              ",USED",
              ",VIED",
              ",VISE",
              ",VOID",
              ",DEVIOUS"
            ]
          }
        },
        "m": 607164,
        "o": 16626290,
        "r": 607164,
        "t": 0.7000000000000001,
        "v": 29695,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "STORM",
        "aa": 27135,
        "d": "bg_ocean3.jpg",
        "dd": 27135,
        "e": 0.21,
        "j": 27135,
        "l": 27135,
        "levels": {
          "level_001": {
            "a": 685827,
            "b": "FLIYRM",
            "e": [
              ",FIR",
              ",FLY",
              ",FRY",
              ",MIL",
              ",RIM",
              ",FILM",
              ",FIRM",
              ",FILMY"
            ]
          },
          "level_002": {
            "a": 685839,
            "b": "SLORAPA",
            "e": [
              ",ASP",
              "B,LAP",
              ",OAR",
              ",OPS",
              ",PAL",
              ",PAR",
              ",PRO",
              ",RAP",
              ",SAP",
              ",SOP",
              ",SPA",
              ",PARASOL"
            ]
          },
          "level_003": {
            "a": 685834,
            "b": "CARETEN",
            "e": [
              ",CATER",
              ",CRANE",
              ",CRATE",
              ",EATEN",
              ",EATER",
              ",ENACT",
              ",ENTER",
              ",ERECT",
              ",REACT",
              ",TRACE"
            ]
          },
          "level_004": {
            "a": 685824,
            "b": "FOLAVR",
            "e": [
              ",AFRO",
              ",FOAL",
              ",FORA",
              ",LOAF",
              ",ORAL",
              ",OVAL",
              ",FAVOR",
              ",VALOR",
              ",FLAVOR"
            ]
          },
          "level_005": {
            "a": 685823,
            "b": "OMLYOG",
            "e": [
              ",GOO",
              "B,GYM",
              ",LOG",
              ",MOO",
              ",GLOOM",
              ",GLOOMY"
            ]
          },
          "level_006": {
            "a": 685831,
            "b": "IDTCEE",
            "e": [
              ",CEDE",
              ",CITE",
              ",DICE",
              ",DIET",
              ",EDIT",
              ",ICED",
              ",TIDE",
              ",TIED",
              ",DECEIT"
            ]
          },
          "level_007": {
            "a": 685830,
            "b": "SOESRPP",
            "e": [
              ",POSSE",
              ",PRESS",
              ",PROSE",
              ",SPORE"
            ]
          },
          "level_008": {
            "a": 685822,
            "b": "ROEDNE",
            "e": [
              ",DEER",
              ",DOER",
              ",DONE",
              ",NEED",
              ",NERD",
              ",NODE",
              ",REDO",
              ",REED",
              ",REND",
              ",RODE",
              ",REDONE"
            ]
          },
          "level_009": {
            "a": 685828,
            "b": "OGNPSE",
            "e": [
              ",GOES",
              ",GONE",
              ",NOPE",
              ",NOSE",
              ",OPEN",
              ",PEON",
              ",PONG",
              ",POSE",
              ",SONG",
              ",SPONGE"
            ]
          },
          "level_010": {
            "a": 685825,
            "b": "PDLTEEE",
            "e": [
              ",EEL",
              ",LED",
              ",LET",
              ",PET",
              ",TEE",
              ",TEPEE",
              ",DELETE",
              ",PEELED",
              ",PELTED",
              ",DEPLETE"
            ]
          },
          "level_011": {
            "a": 685826,
            "b": "ORPDALE",
            "e": [
              ",LOADER",
              "B,ORDEAL",
              ",PAROLE",
              ",RELOAD"
            ]
          },
          "level_012": {
            "a": 685832,
            "b": "SPULRPE",
            "e": [
              ",PULSE",
              ",PURSE",
              ",SLURP",
              ",SUPER",
              ",UPPER",
              ",PURPLE",
              ",SUPPER",
              ",SUPPLE"
            ]
          },
          "level_013": {
            "a": 685835,
            "b": "LUNG",
            "e": [
              ",GNU",
              ",GUN",
              ",LUG",
              ",LUNG"
            ]
          },
          "level_014": {
            "a": 685820,
            "b": "KABEL",
            "e": [
              ",ABLE",
              ",BAKE",
              ",BALE",
              ",BALK",
              ",BEAK",
              ",KALE",
              ",LAKE",
              ",LEAK",
              ",BLEAK"
            ]
          },
          "level_015": {
            "a": 685829,
            "b": "SIRENOO",
            "e": [
              ",NOISE",
              ",NOOSE",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SIREN",
              ",SNORE",
              ",SENIOR",
              "B,SOONER",
              ",EROSION"
            ]
          },
          "level_016": {
            "a": 685833,
            "b": "ILNTAY",
            "e": [
              ",ANTI",
              ",LAIN",
              ",LINT",
              ",NAIL",
              ",TAIL",
              ",TINY",
              ",INLAY",
              "B,LAITY"
            ]
          },
          "level_017": {
            "a": 685821,
            "b": "OLSZUEA",
            "e": [
              ",ALE",
              ",SEA",
              ",SUE",
              ",USE",
              ",ZEALOUS"
            ]
          },
          "level_018": {
            "a": 685838,
            "b": "THCEAD",
            "e": [
              ",ACHED",
              ",ACTED",
              ",CADET",
              ",CHEAT",
              ",DEATH",
              ",HATED",
              ",TEACH",
              ",DETACH"
            ]
          },
          "level_019": {
            "a": 685836,
            "b": "LLAYELG",
            "e": [
              ",ALLY",
              ",GALE",
              ",GALL",
              ",YELL",
              ",ALLEY",
              "B,LEGAL",
              ",GALLEY",
              ",LEGALLY"
            ]
          },
          "level_020": {
            "a": 685837,
            "b": "EULMMP",
            "e": [
              ",ELM",
              ",EMU",
              ",MUM",
              ",UMM",
              ",LUMP",
              ",MULE",
              ",PLUM",
              ",PLUME",
              ",PUMMEL"
            ]
          }
        },
        "m": 2373822,
        "o": 16626290,
        "r": 2373822,
        "t": 0.7000000000000001,
        "v": 27135,
        "y": 0.7000000000000001
      },
      "set_4": {
        "a": "BLUE",
        "aa": 24319,
        "bb": 16777215,
        "d": "bg_ocean4.jpg",
        "dd": 24319,
        "e": 0.2,
        "g": 0.45,
        "j": 24319,
        "l": 24319,
        "levels": {
          "level_001": {
            "a": 685967,
            "b": "APXEDN",
            "e": [
              ",AND",
              ",APE",
              ",AXE",
              ",DEN",
              ",END",
              ",NAP",
              ",PAD",
              ",PAN",
              ",PEA",
              ",PEN",
              ",EXPAND"
            ]
          },
          "level_002": {
            "a": 685956,
            "b": "PTNIPES",
            "e": [
              ",INEPT",
              "B,INSET",
              ",SNIPE",
              ",SPENT",
              ",SPINE",
              ",SPITE",
              ",INSTEP",
              ",SNIPPET"
            ]
          },
          "level_003": {
            "a": 685957,
            "b": "SLENGTO",
            "e": [
              ",ONSET",
              ",STOLE",
              ",STONE",
              ",STOLEN",
              ",LONGEST"
            ]
          },
          "level_004": {
            "a": 685952,
            "b": "TLEYRTO",
            "e": [
              ",LORE",
              ",LYRE",
              ",RELY",
              ",ROLE",
              ",ROTE",
              ",TORE",
              ",TORT",
              ",TOTE",
              ",TROT",
              ",YORE",
              ",LOTTERY"
            ]
          },
          "level_005": {
            "a": 685965,
            "b": "YSMIKP",
            "e": [
              ",IMP",
              ",SIM",
              ",SIP",
              ",SKI",
              ",SKY",
              ",SPY",
              ",SKIM",
              ",SKIP",
              ",SKIMP",
              ",SPIKY"
            ]
          },
          "level_006": {
            "a": 685962,
            "b": "RPOTON",
            "e": [
              ",ONTO",
              ",POOR",
              ",PORT",
              ",ROOT",
              ",TOON",
              ",TORN",
              ",TROOP",
              ",PROTON"
            ]
          },
          "level_007": {
            "a": 685968,
            "b": "OSGUAES",
            "e": [
              ",GASES",
              ",GUESS",
              ",OASES",
              ",USAGE"
            ]
          },
          "level_008": {
            "a": 685950,
            "b": "DEESBAD",
            "e": [
              ",BADE",
              ",BASE",
              ",BEAD",
              ",DEAD",
              ",DEED",
              ",EASE",
              ",SEED",
              ",BEADED",
              ",SEABED",
              ",DEBASED"
            ]
          },
          "level_009": {
            "a": 685964,
            "b": "YREMSAT",
            "e": [
              ",MASTER",
              ",STEAMY",
              ",STREAM",
              ",MASTERY"
            ]
          },
          "level_010": {
            "a": 685961,
            "b": "UEDLNB",
            "e": [
              ",BEND",
              ",BLED",
              ",BLUE",
              ",DUEL",
              ",DUNE",
              ",LEND",
              ",LUBE",
              ",NUDE",
              ",BUNDLE"
            ]
          },
          "level_011": {
            "a": 685955,
            "b": "RERFADT",
            "e": [
              ",AFTER",
              ",DRAFT",
              ",FARED",
              ",FATED",
              ",RATED",
              ",RATER",
              ",TERRA",
              ",TRADE",
              ",TREAD"
            ]
          },
          "level_012": {
            "a": 685963,
            "b": "TIROLYG",
            "e": [
              ",GILT",
              "B,GIRL",
              ",GORY",
              ",GRIT",
              ",OILY",
              ",RIOT",
              ",ROIL",
              ",TOIL",
              ",TRIO",
              ",YOGI",
              ",GLORY",
              ",TRILOGY"
            ]
          },
          "level_013": {
            "a": 685959,
            "b": "AOLBT",
            "e": [
              ",ALT",
              "B,BAT",
              ",BOA",
              ",BOT",
              ",LAB",
              ",LAT",
              ",LOB",
              ",LOT",
              ",OAT",
              ",TAB",
              ",BLOAT"
            ]
          },
          "level_014": {
            "a": 685953,
            "b": "GLTOA",
            "e": [
              ",ALTO",
              "B,GOAL",
              ",GOAT",
              ",TOGA",
              ",GLOAT"
            ]
          },
          "level_015": {
            "a": 685958,
            "b": "DREIG",
            "e": [
              ",DIG",
              ",IRE",
              ",RED",
              ",RID",
              ",RIG",
              ",DIRE",
              ",GRID",
              ",RIDE"
            ]
          },
          "level_016": {
            "a": 685951,
            "b": "RUESCE",
            "e": [
              ",CURSE",
              ",REUSE",
              ",SCREE",
              ",RECUSE",
              ",RESCUE",
              ",SECURE"
            ]
          },
          "level_017": {
            "a": 685960,
            "b": "KONW",
            "e": [
              ",NOW",
              ",OWN",
              ",WOK",
              ",WON",
              ",KNOW",
              ",WONK"
            ]
          },
          "level_018": {
            "a": 685954,
            "b": "LSRIPYC",
            "e": [
              ",CLIP",
              ",LISP",
              ",SLIP",
              ",SPRY",
              ",CRISP",
              ",LYRIC",
              ",SPICY",
              ",CRISPLY"
            ]
          },
          "level_019": {
            "a": 685966,
            "b": "GEURS",
            "e": [
              ",RUSE",
              "B,SURE",
              ",URGE",
              ",USER",
              ",SURGE"
            ]
          },
          "level_020": {
            "a": 685969,
            "b": "DARELCA",
            "e": [
              ",ALDER",
              "B,CADRE",
              ",CARED",
              ",CEDAR",
              ",CLEAR",
              ",DECAL",
              ",LACED",
              ",RACED",
              ",CALDERA"
            ]
          }
        },
        "m": 3550641,
        "o": 16626290,
        "r": 3550641,
        "t": 0.6,
        "u": 0,
        "v": 24319,
        "w": 16777215,
        "y": 0.6,
        "z": 0
      },
      "set_5": {
        "a": "DEPTH",
        "aa": 21759,
        "d": "bg_ocean5.jpg",
        "dd": 21759,
        "e": 0.2,
        "j": 21759,
        "l": 21759,
        "levels": {
          "level_001": {
            "a": 686122,
            "b": "ROBBER",
            "e": [
              ",BOB",
              ",BRO",
              ",EBB",
              ",ERR",
              ",ORB",
              ",ORE",
              ",ROB",
              ",ROBBER"
            ]
          },
          "level_002": {
            "a": 686139,
            "b": "TTRNIEA",
            "e": [
              ",ATTIRE",
              ",RETAIN",
              ",RETINA",
              ",NITRATE"
            ]
          },
          "level_003": {
            "a": 686132,
            "b": "ATRANWR",
            "e": [
              ",ANT",
              ",ART",
              ",NAW",
              ",RAN",
              ",RAT",
              ",RAW",
              ",TAN",
              ",TAR",
              ",WAR",
              ",WARRANT"
            ]
          },
          "level_004": {
            "a": 686125,
            "b": "UPSLRUH",
            "e": [
              ",HURL",
              "B,LUSH",
              ",PLUS",
              ",PUSH",
              ",RUSH",
              ",SLUR",
              ",SPUR",
              ",SULPHUR"
            ]
          },
          "level_005": {
            "a": 686137,
            "b": "BDNHAUS",
            "e": [
              ",BAND",
              ",BASH",
              ",BUSH",
              ",DASH",
              ",HAND",
              ",SAND",
              ",SHUN",
              ",SNUB"
            ]
          },
          "level_006": {
            "a": 686138,
            "b": "DEMREG",
            "e": [
              ",DEEM",
              ",DEER",
              ",EDGE",
              ",GERM",
              ",MERE",
              ",REED",
              ",EDGER",
              "B,GREED",
              ",MERGE",
              ",MERGED"
            ]
          },
          "level_007": {
            "a": 686126,
            "b": "BWOBEL",
            "e": [
              ",BLEW",
              ",BLOB",
              ",BLOW",
              ",BOWL",
              ",LOBE",
              ",BELOW",
              ",ELBOW",
              ",WOBBLE"
            ]
          },
          "level_008": {
            "a": 686140,
            "b": "TRUOOP",
            "e": [
              ",OPT",
              ",OUR",
              ",OUT",
              ",POT",
              ",PRO",
              ",PUT",
              ",ROT",
              ",RUT",
              ",TOO",
              ",TOP",
              ",UPROOT"
            ]
          },
          "level_009": {
            "a": 686134,
            "b": "RFRMAEO",
            "e": [
              ",ARMOR",
              ",FRAME",
              ",FARMER",
              ",FORMER",
              ",REFORM",
              ",FOREARM"
            ]
          },
          "level_010": {
            "a": 686130,
            "b": "FEUPOHL",
            "e": [
              ",FLOP",
              ",FLUE",
              ",FOUL",
              ",FUEL",
              ",HELP",
              ",HOLE",
              ",HOPE",
              ",LOPE",
              ",POLE"
            ]
          },
          "level_011": {
            "a": 686141,
            "b": "QEUILC",
            "e": [
              ",CUE",
              "B,ICE",
              ",LIE",
              ",CLIQUE"
            ]
          },
          "level_012": {
            "a": 686128,
            "b": "TEURNST",
            "e": [
              ",NURSE",
              "B,STENT",
              ",STERN",
              ",STRUT",
              ",STUNT",
              ",TRUST",
              ",TUNER",
              ",UTTER",
              ",ENTRUST"
            ]
          },
          "level_013": {
            "a": 686123,
            "b": "EVTDIS",
            "e": [
              ",ITS",
              ",SET",
              ",SIT",
              ",TIE",
              ",TIS",
              ",VET",
              ",VIE",
              ",SITED",
              ",DIVEST"
            ]
          },
          "level_014": {
            "a": 686131,
            "b": "DEIEEVC",
            "e": [
              ",CEDE",
              "B,DICE",
              ",DIVE",
              ",ICED",
              ",VICE",
              ",VIED",
              ",DECEIVE"
            ]
          },
          "level_015": {
            "a": 686135,
            "b": "NCKIL",
            "e": [
              ",ILK",
              ",INK",
              ",KIN",
              ",NIL",
              ",LICK",
              "B,LINK",
              ",NICK",
              ",CLINK"
            ]
          },
          "level_016": {
            "a": 686136,
            "b": "DLWIENS",
            "e": [
              ",LINED",
              ",SINEW",
              ",SLIDE",
              ",SNIDE",
              ",SWINE",
              ",WIDEN",
              ",WIELD",
              ",SWINDLE"
            ]
          },
          "level_017": {
            "a": 686133,
            "b": "NNEBAR",
            "e": [
              ",BANE",
              ",BARE",
              ",BARN",
              ",BEAN",
              ",BEAR",
              ",BRAN",
              ",EARN",
              ",NEAR"
            ]
          },
          "level_018": {
            "a": 686124,
            "b": "STIRESP",
            "e": [
              ",PRIEST",
              ",RESIST",
              ",SISTER",
              ",SPRITE",
              ",STRIPE",
              ",PERSIST"
            ]
          },
          "level_019": {
            "a": 686127,
            "b": "HPIYT",
            "e": [
              ",HIP",
              ",HIT",
              ",PHI",
              ",PIT",
              ",THY",
              ",TIP",
              ",PITY",
              ",PITHY"
            ]
          },
          "level_020": {
            "a": 686129,
            "b": "ILEESRP",
            "e": [
              ",LEPER",
              ",PERIL",
              ",PRIES",
              ",REPEL",
              ",SLEEP",
              ",SPIRE",
              ",SPREE",
              ",REPLIES"
            ]
          }
        },
        "m": 5315503,
        "o": 16626290,
        "r": 5315503,
        "t": 0.65,
        "v": 21759,
        "y": 0.65
      }
    }
  },
  "WS 19": {
    "a": "DESERT",
    "b": "grad_white",
    "c": "grp_desert",
    "d": 0.75,
    "e": 16672257,
    "f": 15951730,
    "g": 16645629,
    "sets": {
      "set_1": {
        "a": "SPIRE",
        "aa": 16672257,
        "d": "bg_desert1.jpg",
        "dd": 16672257,
        "e": 0.2,
        "j": 16672257,
        "l": 16672257,
        "levels": {
          "level_001": {
            "a": 686251,
            "b": "HVTRSEA",
            "e": [
              ",SHAVER",
              ",STARVE",
              ",VASTER",
              ",HARVEST"
            ]
          },
          "level_002": {
            "a": 686247,
            "b": "EFUXRL",
            "e": [
              ",ELF",
              "B,FLU",
              ",FUR",
              ",REF",
              ",RUE",
              ",REFLUX"
            ]
          },
          "level_003": {
            "a": 686235,
            "b": "MENTNIE",
            "e": [
              ",EMIT",
              ",ITEM",
              ",MEET",
              ",MINE",
              ",MINT",
              ",MITE",
              ",NINE",
              ",TEEN",
              ",TIME",
              ",TINE"
            ]
          },
          "level_004": {
            "a": 686249,
            "b": "TOCHREC",
            "e": [
              ",CORE",
              ",CROC",
              ",ECHO",
              ",ETCH",
              ",HERO",
              ",ROTE",
              ",TECH",
              ",TORE",
              ",CROCHET"
            ]
          },
          "level_005": {
            "a": 686248,
            "b": "LHYCLI",
            "e": [
              ",CHI",
              ",ICY",
              ",ILL",
              ",HILL",
              ",LILY",
              ",CHILL",
              ",HILLY",
              ",CHILLY"
            ]
          },
          "level_006": {
            "a": 686252,
            "b": "FOATLA",
            "e": [
              ",ALTO",
              ",FLAT",
              ",FOAL",
              ",LOAF",
              ",LOFT",
              ",ALOFT",
              ",FATAL",
              ",FLOAT",
              ",AFLOAT"
            ]
          },
          "level_007": {
            "a": 686234,
            "b": "ALPCM",
            "e": [
              ",AMP",
              ",CAM",
              ",CAP",
              ",LAM",
              ",LAP",
              ",MAP",
              ",PAL",
              ",CLAMP"
            ]
          },
          "level_008": {
            "a": 686245,
            "b": "NRLOEMG",
            "e": [
              ",GNOME",
              ",GOLEM",
              ",GONER",
              ",LEMON",
              ",LONER",
              ",MELON",
              ",LONGER",
              ",MONGREL"
            ]
          },
          "level_009": {
            "a": 686253,
            "b": "ONPGIE",
            "e": [
              ",GONE",
              "B,NOPE",
              ",OPEN",
              ",PEON",
              ",PINE",
              ",PING",
              ",PONG",
              ",PIGEON"
            ]
          },
          "level_010": {
            "a": 686243,
            "b": "ILGTZ",
            "e": [
              ",GIT",
              "B,LIT",
              ",TIL",
              ",ZIG",
              ",ZIT",
              ",GLITZ"
            ]
          },
          "level_011": {
            "a": 686250,
            "b": "EOTMLY",
            "e": [
              ",ELM",
              "B,LET",
              ",LOT",
              ",LYE",
              ",MET",
              ",TOE",
              ",TOY",
              ",YET",
              ",MOTLEY"
            ]
          },
          "level_012": {
            "a": 686236,
            "b": "TLXUTEA",
            "e": [
              ",AXLE",
              ",LATE",
              ",LUTE",
              ",TALE",
              ",TAUT",
              ",TEAL",
              ",TEXT",
              ",TEXTUAL"
            ]
          },
          "level_013": {
            "a": 686238,
            "b": "VSAITYR",
            "e": [
              ",AIRY",
              ",ARTY",
              ",STAR",
              ",STAY",
              ",STIR",
              ",TRAY",
              ",VARY",
              ",VAST",
              ",VISA"
            ]
          },
          "level_014": {
            "a": 686239,
            "b": "AEKETWS",
            "e": [
              ",ASKEW",
              ",SKATE",
              ",SKEET",
              ",STAKE",
              ",STEAK",
              ",SWEAT",
              ",SWEET",
              ",TEASE",
              ",TWEAK",
              ",WASTE"
            ]
          },
          "level_015": {
            "a": 686237,
            "b": "AEVBHE",
            "e": [
              ",BAH",
              "B,BEE",
              ",EVE",
              ",HAVE",
              ",HEAVE"
            ]
          },
          "level_016": {
            "a": 686240,
            "b": "LAAGRNO",
            "e": [
              ",ALONG",
              "B,ANGLO",
              ",ARGON",
              ",GNARL",
              ",GROAN",
              ",ORGAN",
              ",ANALOG"
            ]
          },
          "level_017": {
            "a": 686246,
            "b": "RATLUVI",
            "e": [
              ",RIVAL",
              ",TRAIL",
              ",TRIAL",
              ",ULTRA",
              ",VAULT",
              ",VIRAL",
              ",VITAL",
              ",RITUAL",
              ",VIRTUAL"
            ]
          },
          "level_018": {
            "a": 686242,
            "b": "NIREGVA",
            "e": [
              ",ANGER",
              ",GIVEN",
              ",GIVER",
              ",GRAIN",
              ",GRAVE",
              ",NAIVE",
              ",RANGE",
              ",RAVEN",
              ",REIGN",
              ",VEGAN"
            ]
          },
          "level_019": {
            "a": 686241,
            "b": "ORTVYLE",
            "e": [
              ",LOVER",
              ",OVERT",
              ",TROVE",
              ",VOTER",
              ",OVERLY",
              ",REVOLT",
              ",OVERTLY"
            ]
          },
          "level_020": {
            "a": 686244,
            "b": "OOTNYS",
            "e": [
              ",NOSY",
              ",ONTO",
              ",SNOT",
              ",SOON",
              ",SOOT",
              ",TOON",
              ",SOOTY",
              ",STONY"
            ]
          }
        },
        "m": 11748097,
        "o": 42980,
        "r": 11748097,
        "t": 0.73,
        "u": 16776703,
        "v": 16672257,
        "y": 0.73,
        "z": 16776703
      },
      "set_2": {
        "a": "ROCK",
        "aa": 16475677,
        "d": "bg_desert2.jpg",
        "dd": 16475677,
        "e": 0.2,
        "j": 16475677,
        "l": 16475677,
        "levels": {
          "level_001": {
            "a": 686374,
            "b": "PBTAZIE",
            "e": [
              ",BAIT",
              ",BEAT",
              ",BETA",
              ",BITE",
              ",PATE",
              ",PEAT",
              ",PITA",
              ",TAPE"
            ]
          },
          "level_002": {
            "a": 686368,
            "b": "TOATMO",
            "e": [
              ",ATOM",
              ",MOAT",
              ",MOOT",
              ",TOOT"
            ]
          },
          "level_003": {
            "a": 686369,
            "b": "EGDRA",
            "e": [
              ",AGED",
              ",DARE",
              ",DEAR",
              ",DRAG",
              ",GEAR",
              ",GRAD",
              ",RAGE",
              ",READ",
              ",GRADE",
              ",RAGED"
            ]
          },
          "level_004": {
            "a": 686375,
            "b": "ISMPEL",
            "e": [
              ",ISLE",
              ",LIME",
              ",LIMP",
              ",LISP",
              ",MILE",
              ",PILE",
              ",SEMI",
              ",SLIM",
              ",SLIP",
              ",SLIME",
              ",SMILE",
              ",SIMPLE"
            ]
          },
          "level_005": {
            "a": 686382,
            "b": "PKOTEC",
            "e": [
              ",COKE",
              ",COPE",
              ",KEPT",
              ",PECK",
              ",POET",
              ",POKE"
            ]
          },
          "level_006": {
            "a": 686379,
            "b": "ABELZ",
            "e": [
              ",ALE",
              ",LAB",
              ",ABLE",
              ",BALE",
              ",ZEAL",
              ",BLAZE"
            ]
          },
          "level_007": {
            "a": 686377,
            "b": "OUDSN",
            "e": [
              ",DON",
              "B,DUN",
              ",DUO",
              ",NOD",
              ",SOD",
              ",SON",
              ",SUN",
              ",SOUND"
            ]
          },
          "level_008": {
            "a": 686372,
            "b": "BAIED",
            "e": [
              ",AIDE",
              ",BADE",
              ",BEAD",
              ",BIDE",
              ",IDEA",
              ",ABIDE"
            ]
          },
          "level_009": {
            "a": 686376,
            "b": "YAHIWHG",
            "e": [
              ",HAG",
              ",HAH",
              ",HAY",
              ",WAG",
              ",WAY",
              ",WHY",
              ",WIG",
              ",HIGHWAY"
            ]
          },
          "level_010": {
            "a": 686381,
            "b": "SESTAF",
            "e": [
              ",EAST",
              ",FAST",
              ",FATE",
              ",FEAT",
              ",FESS",
              ",FETA",
              ",SAFE",
              ",SEAT"
            ]
          },
          "level_011": {
            "a": 686371,
            "b": "ERSDUE",
            "e": [
              ",DEER",
              ",REED",
              ",RUDE",
              ",RUSE",
              ",SEED",
              ",SEER",
              ",SUED",
              ",SURE",
              ",USED",
              ",USER"
            ]
          },
          "level_012": {
            "a": 686370,
            "b": "ERDCEPE",
            "e": [
              ",CREED",
              ",CREEP",
              ",CREPE",
              ",DECREE",
              "B,DEEPER",
              ",PEERED",
              ",RECEDE",
              ",PRECEDE"
            ]
          },
          "level_013": {
            "a": 686367,
            "b": "MRAYR",
            "e": [
              ",ARM",
              "B,MAR",
              ",MAY",
              ",RAM",
              ",RAY",
              ",YAM",
              ",ARMY",
              ",MARRY"
            ]
          },
          "level_014": {
            "a": 686373,
            "b": "MECAR",
            "e": [
              ",ACME",
              "B,ACRE",
              ",CAME",
              ",CARE",
              ",CRAM",
              ",MACE",
              ",MARE",
              ",RACE"
            ]
          },
          "level_015": {
            "a": 686365,
            "b": "LIESRAL",
            "e": [
              ",AISLE",
              ",ARISE",
              ",LASER",
              ",RAISE",
              ",ALLIES",
              ",SERIAL"
            ]
          },
          "level_016": {
            "a": 686364,
            "b": "ARISOFN",
            "e": [
              ",AFRO",
              ",FAIR",
              ",FORA",
              ",INFO",
              ",IRON",
              ",RAIN",
              ",ROAN",
              ",SOAR",
              ",SOFA"
            ]
          },
          "level_017": {
            "a": 686366,
            "b": "EIRWP",
            "e": [
              ",IRE",
              ",PER",
              ",PEW",
              ",PIE",
              ",REP",
              ",RIP",
              ",PIER",
              ",RIPE",
              ",WIPE",
              ",WIRE",
              ",WIPER"
            ]
          },
          "level_018": {
            "a": 686383,
            "b": "YMEKRCO",
            "e": [
              ",COY",
              ",CRY",
              ",KEY",
              ",ORE",
              ",REM",
              ",RYE",
              ",MERCY",
              "B,ROCKY",
              ",MOCKERY"
            ]
          },
          "level_019": {
            "a": 686378,
            "b": "KRAET",
            "e": [
              ",RAKE",
              ",RATE",
              ",TAKE",
              ",TEAK",
              ",TEAR",
              ",TREK"
            ]
          },
          "level_020": {
            "a": 686380,
            "b": "ORDAOBN",
            "e": [
              ",ADORN",
              "B,BARON",
              ",BOARD",
              ",BORON",
              ",BRAND",
              ",BROAD",
              ",BROOD",
              ",DONOR",
              ",RADON"
            ]
          }
        },
        "m": 10572032,
        "o": 42980,
        "r": 10572032,
        "t": 0.7000000000000001,
        "v": 16475677,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "SIERRA",
        "aa": 16279097,
        "d": "bg_desert3.jpg",
        "dd": 16279097,
        "e": 0.2,
        "g": 0.79,
        "j": 16279097,
        "l": 16279097,
        "levels": {
          "level_001": {
            "a": 686484,
            "b": "OOCBRN",
            "e": [
              ",BOO",
              ",BRO",
              ",COB",
              ",CON",
              ",COO",
              ",NOR",
              ",ORB",
              ",ROB",
              ",BOON",
              ",BORN",
              ",CORN"
            ]
          },
          "level_002": {
            "a": 686488,
            "b": "HTELTUS",
            "e": [
              ",LEST",
              "B,LUSH",
              ",LUST",
              ",LUTE",
              ",SHUT",
              ",TEST",
              ",THUS",
              ",TUSH"
            ]
          },
          "level_003": {
            "a": 686483,
            "b": "YAYDAP",
            "e": [
              ",DAY",
              ",PAD",
              ",PAY",
              ",PAYDAY"
            ]
          },
          "level_004": {
            "a": 686481,
            "b": "UTYLORP",
            "e": [
              ",LOUT",
              "B,PLOT",
              ",PLOY",
              ",POLY",
              ",PORT",
              ",POUR",
              ",POUT",
              ",ROUT",
              ",TOUR",
              ",TYPO",
              ",YOUR"
            ]
          },
          "level_005": {
            "a": 686477,
            "b": "LSAOEC",
            "e": [
              ",ALOE",
              ",ALSO",
              ",CASE",
              ",COAL",
              ",COLA",
              ",LACE",
              ",LOSE",
              ",SALE",
              ",SEAL",
              ",SOLE",
              ",CLOSE",
              ",SCALE"
            ]
          },
          "level_006": {
            "a": 686476,
            "b": "UTFON",
            "e": [
              ",FUN",
              ",NOT",
              ",NUT",
              ",OFT",
              ",OUT",
              ",TON",
              ",FONT",
              ",TOFU",
              ",UNTO"
            ]
          },
          "level_007": {
            "a": 686479,
            "b": "RREANB",
            "e": [
              ",ARE",
              ",BAN",
              ",BAR",
              ",BRA",
              ",EAR",
              ",ERA",
              ",ERR",
              ",NAB",
              ",RAN",
              ",BARREN"
            ]
          },
          "level_008": {
            "a": 686490,
            "b": "CCEHDIL",
            "e": [
              ",CHI",
              ",HID",
              ",ICE",
              ",LED",
              ",LID",
              ",LIE",
              ",CHIDE",
              ",CHILD",
              ",CHILE",
              ",CLICHE",
              ",CLICHED"
            ]
          },
          "level_009": {
            "a": 686475,
            "b": "EWOTRRE",
            "e": [
              ",RETRO",
              "B,ROWER",
              ",TOWER",
              ",WROTE"
            ]
          },
          "level_010": {
            "a": 686487,
            "b": "TILSNCE",
            "e": [
              ",CLIENT",
              ",ENLIST",
              ",INSECT",
              ",LISTEN",
              ",NICEST",
              ",SILENT",
              ",TINSEL",
              ",STENCIL"
            ]
          },
          "level_011": {
            "a": 686485,
            "b": "PWLRO",
            "e": [
              ",LOW",
              ",OWL",
              ",POW",
              ",PRO",
              ",ROW",
              ",PLOW",
              "B,PROW"
            ]
          },
          "level_012": {
            "a": 686473,
            "b": "PRITEUC",
            "e": [
              ",CREPT",
              ",CUTER",
              ",CUTIE",
              ",ERUPT",
              ",PRICE",
              ",TRIPE",
              ",TRUCE",
              ",PRECUT"
            ]
          },
          "level_013": {
            "a": 686478,
            "b": "HASW",
            "e": [
              ",ASH",
              "B,HAS",
              ",SAW",
              ",WAS",
              ",WASH"
            ]
          },
          "level_014": {
            "a": 686491,
            "b": "TRAELEH",
            "e": [
              ",HALTER",
              "B,HEALER",
              ",HEATER",
              ",LATHER",
              ",REHEAT",
              ",RELATE"
            ]
          },
          "level_015": {
            "a": 686486,
            "b": "RUHGGE",
            "e": [
              ",EGG",
              ",HER",
              ",HUE",
              ",HUG",
              ",RUE",
              ",RUG",
              ",UGH",
              ",HUGE",
              ",URGE",
              ",HUGER"
            ]
          },
          "level_016": {
            "a": 686472,
            "b": "RECPYTN",
            "e": [
              ",CENT",
              ",PENT",
              ",PERT",
              ",PREY",
              ",PYRE",
              ",RENT",
              ",TERN",
              ",TYPE"
            ]
          },
          "level_017": {
            "a": 686489,
            "b": "STWEP",
            "e": [
              ",PEST",
              ",SPEW",
              ",STEP",
              ",STEW",
              ",WEPT",
              ",WEST"
            ]
          },
          "level_018": {
            "a": 686474,
            "b": "LWTENOD",
            "e": [
              ",DOWEL",
              ",DWELT",
              ",ENDOW",
              ",NOTED",
              ",OLDEN",
              ",OWNED",
              ",TONED",
              ",TOWED",
              ",TOWEL"
            ]
          },
          "level_019": {
            "a": 686482,
            "b": "DSIBYUS",
            "e": [
              ",BID",
              ",BUD",
              ",BUS",
              ",BUY",
              ",DUB",
              ",SIS",
              ",SUB",
              ",SUBSIDY"
            ]
          },
          "level_020": {
            "a": 686480,
            "b": "OERITN",
            "e": [
              ",INERT",
              ",INTER",
              ",INTRO",
              ",TENOR",
              ",TONER",
              ",ORIENT"
            ]
          }
        },
        "m": 11296256,
        "o": 16726016,
        "r": 11296256,
        "t": 0.8300000000000001,
        "v": 16279097,
        "y": 0.8300000000000001
      },
      "set_4": {
        "a": "DUNE",
        "aa": 16082517,
        "d": "bg_desert4.jpg",
        "dd": 16082517,
        "j": 16082517,
        "l": 16082517,
        "levels": {
          "level_001": {
            "a": 686616,
            "b": "KEEWEND",
            "e": [
              ",DEN",
              ",DEW",
              ",EEK",
              ",EKE",
              ",END",
              ",EWE",
              ",NEW",
              ",WED",
              ",WEE",
              ",WEEKEND"
            ]
          },
          "level_002": {
            "a": 686624,
            "b": "IDGNPI",
            "e": [
              ",DIG",
              ",DIN",
              ",DIP",
              ",GIN",
              ",NIP",
              ",PIG",
              ",PIN",
              ",DING",
              "B,PING",
              ",PIDGIN"
            ]
          },
          "level_003": {
            "a": 686610,
            "b": "DBEGA",
            "e": [
              ",AGE",
              ",BAD",
              ",BAG",
              ",BED",
              ",BEG",
              ",DAB",
              ",BADGE"
            ]
          },
          "level_004": {
            "a": 686620,
            "b": "ATCARUY",
            "e": [
              ",ARTY",
              ",AURA",
              ",CART",
              ",CURT",
              ",RACY",
              ",TRAY",
              ",CARAT",
              ",ACTUARY"
            ]
          },
          "level_005": {
            "a": 686617,
            "b": "DIEVDI",
            "e": [
              ",DIED",
              "B,DIVE",
              ",VIED",
              ",DIVIDE"
            ]
          },
          "level_006": {
            "a": 686622,
            "b": "DSMEGU",
            "e": [
              ",DUE",
              ",DUG",
              ",EMU",
              ",GEM",
              ",GUM",
              ",MEG",
              ",MUD",
              ",MUG",
              ",SUE",
              ",SUM",
              ",USE",
              ",SMUDGE"
            ]
          },
          "level_007": {
            "a": 686619,
            "b": "IBLEL",
            "e": [
              ",BELL",
              ",BILE",
              ",BILL",
              ",LIBEL"
            ]
          },
          "level_008": {
            "a": 686625,
            "b": "LONADM",
            "e": [
              ",LAND",
              ",LOAD",
              ",LOAM",
              ",LOAN",
              ",MOAN",
              ",MOLD",
              ",NODAL",
              ",NOMAD"
            ]
          },
          "level_009": {
            "a": 686613,
            "b": "NTENANA",
            "e": [
              ",ANT",
              ",ATE",
              ",EAT",
              ",NAN",
              ",NET",
              ",TAN",
              ",TEA",
              ",TEN",
              ",ANTE",
              ",NEAT"
            ]
          },
          "level_010": {
            "a": 686612,
            "b": "UTIBHAL",
            "e": [
              ",BUILT",
              ",HABIT",
              ",TUBAL",
              ",HALIBUT"
            ]
          },
          "level_011": {
            "a": 686615,
            "b": "YLAC",
            "e": [
              ",CAY",
              ",LAY",
              ",CLAY",
              ",LACY"
            ]
          },
          "level_012": {
            "a": 686611,
            "b": "RUSENTM",
            "e": [
              ",NURSE",
              ",SERUM",
              ",STERN",
              ",STRUM",
              ",TUNER",
              ",UNMET",
              ",MUSTER",
              "B,UNREST",
              ",STERNUM"
            ]
          },
          "level_013": {
            "a": 686614,
            "b": "HKINRS",
            "e": [
              ",HIS",
              ",INK",
              ",KIN",
              ",SIN",
              ",SIR",
              ",SKI",
              ",RINK",
              "B,RISK",
              ",SHIN",
              ",SINK",
              ",SKIN",
              ",SHRINK"
            ]
          },
          "level_014": {
            "a": 686627,
            "b": "PLSIEIM",
            "e": [
              ",ISLE",
              ",LIME",
              ",LIMP",
              ",LISP",
              ",MILE",
              ",PILE",
              ",SEMI",
              ",SLIM",
              ",SLIP",
              ",SLIME",
              "B,SMILE"
            ]
          },
          "level_015": {
            "a": 686626,
            "b": "DEDDGO",
            "e": [
              ",DOE",
              ",DOG",
              ",EGO",
              ",GOD",
              ",ODD",
              ",ODE",
              ",DODGE",
              ",DODGED"
            ]
          },
          "level_016": {
            "a": 686618,
            "b": "UPSOY",
            "e": [
              ",OPS",
              ",PUS",
              ",SOP",
              ",SOY",
              ",SPY",
              ",SUP",
              ",UPS",
              ",YOU",
              ",YUP",
              ",OPUS",
              ",SOUP",
              ",SOUPY"
            ]
          },
          "level_017": {
            "a": 686608,
            "b": "ATIRCOP",
            "e": [
              ",ACTOR",
              ",OPTIC",
              ",PATIO",
              ",RATIO",
              ",TOPIC",
              ",CAPTOR",
              ",TROPIC",
              ",APRICOT"
            ]
          },
          "level_018": {
            "a": 686621,
            "b": "STPETUA",
            "e": [
              ",PASTE",
              "B,PAUSE",
              ",SETUP",
              ",SPATE",
              ",STATE",
              ",TASTE",
              ",TAUPE",
              ",UPSET"
            ]
          },
          "level_019": {
            "a": 686623,
            "b": "OMBLO",
            "e": [
              ",BOLO",
              ",BOOM",
              ",LOOM",
              ",BLOOM"
            ]
          },
          "level_020": {
            "a": 686609,
            "b": "EGRIDNC",
            "e": [
              ",CIDER",
              ",CRIED",
              ",DEIGN",
              ",DINER",
              ",DIRGE",
              ",GRIND",
              ",NICER",
              ",REIGN",
              ",RIDGE"
            ]
          }
        },
        "m": 10183936,
        "o": 42980,
        "r": 10183936,
        "t": 0.74,
        "v": 16082517,
        "y": 0.74
      },
      "set_5": {
        "a": "SAND",
        "aa": 15951730,
        "d": "bg_desert5.jpg",
        "dd": 15951730,
        "e": 0.1,
        "j": 15951730,
        "l": 15951730,
        "levels": {
          "level_001": {
            "a": 686792,
            "b": "HFAGAN",
            "e": [
              ",AAH",
              ",AHA",
              ",FAN",
              ",HAG",
              ",NAG",
              ",FANG",
              "B,HANG",
              ",AFGHAN"
            ]
          },
          "level_002": {
            "a": 686799,
            "b": "ENNEWSM",
            "e": [
              ",SEEM",
              "B,SEEN",
              ",SEWN",
              ",NEWSMEN"
            ]
          },
          "level_003": {
            "a": 686787,
            "b": "IOPNSR",
            "e": [
              ",IRON",
              ",SNIP",
              ",SPIN",
              ",PRISON"
            ]
          },
          "level_004": {
            "a": 686789,
            "b": "CKBYEEU",
            "e": [
              ",BECK",
              "B,BUCK",
              ",CUBE",
              ",YUCK",
              ",BUCKEYE"
            ]
          },
          "level_005": {
            "a": 686788,
            "b": "TPARS",
            "e": [
              ",PART",
              ",PAST",
              ",RAPT",
              ",RASP",
              ",SPAR",
              ",SPAT",
              ",STAR",
              ",TARP",
              ",TRAP"
            ]
          },
          "level_006": {
            "a": 686790,
            "b": "MEXPOCL",
            "e": [
              ",COME",
              ",COMP",
              ",COPE",
              ",EXPO",
              ",LOPE",
              ",MOLE",
              ",POEM",
              ",POLE",
              ",COMPEL"
            ]
          },
          "level_007": {
            "a": 686797,
            "b": "HLTBOER",
            "e": [
              ",BERTH",
              ",BROTH",
              ",HOTEL",
              ",OTHER",
              ",THROB",
              ",BROTHEL"
            ]
          },
          "level_008": {
            "a": 686796,
            "b": "RBECLUM",
            "e": [
              ",BLUER",
              ",CRUEL",
              ",CRUMB",
              ",LEMUR",
              ",RUBLE",
              ",ULCER",
              ",UMBER",
              ",LUMBER",
              ",RUMBLE"
            ]
          },
          "level_009": {
            "a": 686795,
            "b": "ODEVDET",
            "e": [
              ",DEED",
              ",DOTE",
              ",DOVE",
              ",VETO",
              ",VOTE",
              ",DOTED",
              "B,VOTED",
              ",DEVOTED"
            ]
          },
          "level_010": {
            "a": 686791,
            "b": "EIORCL",
            "e": [
              ",COIL",
              ",CORE",
              ",LICE",
              ",LORE",
              ",RICE",
              ",RILE",
              ",ROIL",
              ",ROLE",
              ",RECOIL"
            ]
          },
          "level_011": {
            "a": 686805,
            "b": "IELKLY",
            "e": [
              ",KILL",
              "B,LIKE",
              ",LILY",
              ",YELL",
              ",LIKELY"
            ]
          },
          "level_012": {
            "a": 686800,
            "b": "VADECAN",
            "e": [
              ",ACED",
              ",ACNE",
              ",CANE",
              ",CAVE",
              ",DEAN",
              ",NAVE",
              ",VANE",
              ",VEND",
              ",ADVANCE"
            ]
          },
          "level_013": {
            "a": 686803,
            "b": "RAEHDID",
            "e": [
              ",ADDER",
              ",AIDED",
              ",AIRED",
              ",DARED",
              ",DREAD",
              ",DRIED",
              ",HEARD",
              ",HIRED",
              ",DIEHARD"
            ]
          },
          "level_014": {
            "a": 686798,
            "b": "REMAJM",
            "e": [
              ",ARE",
              ",ARM",
              ",EAR",
              ",ERA",
              ",JAM",
              ",JAR",
              ",MAM",
              ",MAR",
              ",RAM",
              ",REM",
              ",JAMMER"
            ]
          },
          "level_015": {
            "a": 686794,
            "b": "XEDILE",
            "e": [
              ",EEL",
              ",LED",
              ",LID",
              ",LIE",
              ",DELI",
              ",IDLE",
              ",LIED",
              ",EXILED"
            ]
          },
          "level_016": {
            "a": 686801,
            "b": "AENBJWO",
            "e": [
              ",ANEW",
              ",BANE",
              ",BEAN",
              ",BONE",
              ",WANE",
              ",WEAN",
              ",BANJO",
              ",JAWBONE"
            ]
          },
          "level_017": {
            "a": 686802,
            "b": "OCORDT",
            "e": [
              ",COD",
              "B,COO",
              ",COT",
              ",DOC",
              ",DOT",
              ",ROD",
              ",ROT",
              ",TOO",
              ",DOCTOR"
            ]
          },
          "level_018": {
            "a": 686793,
            "b": "EORMTBS",
            "e": [
              ",METRO",
              ",SOBER",
              ",STORE",
              ",STORM",
              ",SOMBER",
              ",SORBET",
              ",STROBE",
              ",MOBSTER"
            ]
          },
          "level_019": {
            "a": 686804,
            "b": "ARMPIRY",
            "e": [
              ",AIRY",
              ",ARMY",
              ",PAIR",
              ",PRAY",
              ",PRIM",
              ",RAMP",
              ",MARRY",
              ",PRIMA"
            ]
          },
          "level_020": {
            "a": 686786,
            "b": "LDOYNUS",
            "e": [
              ",DULY",
              ",LOUD",
              ",NOSY",
              ",ONLY",
              ",ONUS",
              ",SOLD",
              ",SOUL",
              ",UNDO",
              ",LOUSY",
              ",SOUND",
              ",UNSOLD",
              ",SOUNDLY"
            ]
          }
        },
        "m": 10449408,
        "o": 16754432,
        "r": 10449408,
        "t": 0.63,
        "u": 16776701,
        "v": 15951730,
        "y": 0.63,
        "z": 16776701
      }
    }
  },
  "WS 20": {
    "a": "JUNGLE",
    "b": "grad_white",
    "c": "grp_jungle",
    "d": 0.75,
    "e": 56320,
    "f": 41239,
    "sets": {
      "set_1": {
        "a": "VINE",
        "aa": 51712,
        "d": "bg_jungle1.jpg",
        "dd": 51712,
        "e": 0,
        "j": 46080,
        "l": 51712,
        "levels": {
          "level_001": {
            "a": 686947,
            "b": "LEBBSRO",
            "e": [
              ",BOB",
              "B,BRO",
              ",EBB",
              ",LOB",
              ",ORB",
              ",ORE",
              ",ROB",
              ",SOB",
              ",SLOBBER"
            ]
          },
          "level_002": {
            "a": 686944,
            "b": "NNITED",
            "e": [
              ",DENT",
              ",DIET",
              ",DINE",
              ",DINT",
              ",EDIT",
              ",NINE",
              ",TEND",
              ",TIDE",
              ",TIED",
              ",TINE"
            ]
          },
          "level_003": {
            "a": 686953,
            "b": "EIIDSSA",
            "e": [
              ",ADS",
              "B,AID",
              ",SAD",
              ",SEA",
              ",SIS",
              ",ASIDE",
              ",DAISIES"
            ]
          },
          "level_004": {
            "a": 686936,
            "b": "RRTTEU",
            "e": [
              ",ERR",
              ",RUE",
              ",RUT",
              ",TRUER",
              ",UTTER"
            ]
          },
          "level_005": {
            "a": 686941,
            "b": "ERSDSPE",
            "e": [
              ",DEEP",
              ",DEER",
              ",PEER",
              ",REED",
              ",SEED",
              ",SEEP",
              ",SEER",
              ",SPED"
            ]
          },
          "level_006": {
            "a": 686951,
            "b": "OBLGET",
            "e": [
              ",BELT",
              ",BLOG",
              ",BLOT",
              ",BOLT",
              ",GLOB",
              ",LOBE",
              ",OGLE",
              ",GLOBE",
              ",GOBLET"
            ]
          },
          "level_007": {
            "a": 686934,
            "b": "INOXT",
            "e": [
              ",ION",
              ",NIT",
              ",NIX",
              ",NOT",
              ",TIN",
              ",TON",
              ",INTO",
              ",TOXIN"
            ]
          },
          "level_008": {
            "a": 686938,
            "b": "EAREITN",
            "e": [
              ",EATEN",
              ",EATER",
              ",ENTER",
              ",INERT",
              ",INTER",
              ",IRATE",
              ",TRAIN",
              ",ENTIRE",
              ",NEATER",
              ",RETAIN",
              ",RETINA",
              ",TRAINEE"
            ]
          },
          "level_009": {
            "a": 686949,
            "b": "DLFYAG",
            "e": [
              ",DAY",
              ",FAD",
              ",FLY",
              ",GAL",
              ",LAD",
              ",LAG",
              ",LAY",
              ",FLAG",
              ",FLAY",
              ",GLAD",
              ",LADY"
            ]
          },
          "level_010": {
            "a": 686952,
            "b": "UTSELR",
            "e": [
              ",LEST",
              ",LURE",
              ",LUST",
              ",LUTE",
              ",REST",
              ",RULE",
              ",RUSE",
              ",RUST",
              ",SLUR",
              ",SURE",
              ",TRUE",
              ",USER"
            ]
          },
          "level_011": {
            "a": 686937,
            "b": "FEYELR",
            "e": [
              ",FEEL",
              "B,FLEE",
              ",FREE",
              ",LEER",
              ",LYRE",
              ",REEF",
              ",REEL",
              ",RELY",
              ",FREELY"
            ]
          },
          "level_012": {
            "a": 686946,
            "b": "IERBEY",
            "e": [
              ",BEE",
              ",BYE",
              ",EYE",
              ",IRE",
              ",RIB",
              ",RYE",
              ",BEER",
              ",BRIE",
              ",RIBEYE"
            ]
          },
          "level_013": {
            "a": 686939,
            "b": "ALRSO",
            "e": [
              ",OAR",
              ",ALSO",
              ",ORAL",
              ",SOAR"
            ]
          },
          "level_014": {
            "a": 686948,
            "b": "EUDADN",
            "e": [
              ",ADD",
              ",AND",
              ",DAD",
              ",DEN",
              ",DUD",
              ",DUE",
              ",DUN",
              ",END",
              ",UNDEAD"
            ]
          },
          "level_015": {
            "a": 686945,
            "b": "RVALLA",
            "e": [
              ",ALL",
              ",LAVA",
              ",LARVA",
              ",LARVAL"
            ]
          },
          "level_016": {
            "a": 686943,
            "b": "CUBSCUM",
            "e": [
              ",BUM",
              "B,BUS",
              ",CUB",
              ",SUB",
              ",SUM",
              ",SCUM",
              ",MUCUS",
              ",SUCCUMB"
            ]
          },
          "level_017": {
            "a": 686950,
            "b": "NANNOC",
            "e": [
              ",CAN",
              "B,CON",
              ",NAN",
              ",CANNON"
            ]
          },
          "level_018": {
            "a": 686940,
            "b": "CARPHE",
            "e": [
              ",CAPER",
              "B,CHEAP",
              ",PARCH",
              ",PEACH",
              ",PERCH",
              ",REACH",
              ",RECAP",
              ",PREACH"
            ]
          },
          "level_019": {
            "a": 686942,
            "b": "OYDHASW",
            "e": [
              ",AHOY",
              ",ASHY",
              ",DASH",
              ",SHOW",
              ",SODA",
              ",SWAY",
              ",WASH",
              ",WHOA"
            ]
          },
          "level_020": {
            "a": 686935,
            "b": "TIEHLWT",
            "e": [
              ",HILT",
              ",LITE",
              ",TILE",
              ",TILT",
              ",WELT",
              ",WHIT",
              ",WILT",
              ",WITH",
              ",WHITTLE"
            ]
          }
        },
        "m": 32512,
        "o": 16741120,
        "r": 32512,
        "t": 0.75,
        "v": 51712,
        "y": 0.74
      },
      "set_2": {
        "a": "THICK",
        "aa": 53029,
        "cc": 4294967295,
        "d": "bg_jungle2.jpg",
        "dd": 53029,
        "e": 0,
        "ee": 4294967295,
        "i": 4294967295,
        "j": 4116517,
        "k": 4294967295,
        "l": 53029,
        "levels": {
          "level_001": {
            "a": 687171,
            "b": "UDELGS",
            "e": [
              ",DUEL",
              "B,GLUE",
              ",LUGE",
              ",SLED",
              ",SLUG",
              ",SUED",
              ",USED",
              ",GLUED"
            ]
          },
          "level_002": {
            "a": 687168,
            "b": "XATIFE",
            "e": [
              ",AFT",
              "B,ATE",
              ",AXE",
              ",EAT",
              ",FAT",
              ",FAX",
              ",FIT",
              ",FIX",
              ",TAX",
              ",TEA",
              ",TIE",
              ",FIXATE"
            ]
          },
          "level_003": {
            "a": 687158,
            "b": "DHOEATC",
            "e": [
              ",ACHED",
              "B,ACTED",
              ",CADET",
              ",CHEAT",
              ",DEATH",
              ",HATED",
              ",TEACH"
            ]
          },
          "level_004": {
            "a": 687156,
            "b": "TIELRF",
            "e": [
              ",FILET",
              ",FLIER",
              ",FLIRT",
              ",LITER",
              ",RIFLE",
              ",FILTER",
              ",LIFTER",
              ",TRIFLE"
            ]
          },
          "level_005": {
            "a": 687169,
            "b": "KNUJIE",
            "e": [
              ",JUKE",
              ",JUNK",
              ",NUKE",
              ",JUNKIE"
            ]
          },
          "level_006": {
            "a": 687155,
            "b": "NEMOAB",
            "e": [
              ",BAM",
              "B,BAN",
              ",BOA",
              ",MAN",
              ",MEN",
              ",MOB",
              ",NAB",
              ",ONE",
              ",BEMOAN"
            ]
          },
          "level_007": {
            "a": 687167,
            "b": "AMUXMMI",
            "e": [
              ",AIM",
              ",MAM",
              ",MAX",
              ",MIX",
              ",MUM",
              ",UMM",
              ",MAXIM",
              ",MAXIMUM"
            ]
          },
          "level_008": {
            "a": 687153,
            "b": "RETTOPE",
            "e": [
              ",OTTER",
              ",TORTE",
              ",TROPE",
              ",TREETOP"
            ]
          },
          "level_009": {
            "a": 687163,
            "b": "NEREHI",
            "e": [
              ",HEIR",
              ",HERE",
              ",HIRE",
              ",REIN"
            ]
          },
          "level_010": {
            "a": 687159,
            "b": "LSEKORN",
            "e": [
              ",LONER",
              ",LOSER",
              ",SNORE",
              ",SNORKEL"
            ]
          },
          "level_011": {
            "a": 687154,
            "b": "TSRIH",
            "e": [
              ",HIS",
              ",HIT",
              ",ITS",
              ",SIR",
              ",SIT",
              ",TIS",
              ",STIR",
              ",THIS",
              ",SHIRT"
            ]
          },
          "level_012": {
            "a": 687166,
            "b": "DDLNGAE",
            "e": [
              ",ANGLED",
              ",DANGLE",
              ",LANDED",
              ",DANGLED",
              ",GLADDEN"
            ]
          },
          "level_013": {
            "a": 687165,
            "b": "DOMOCME",
            "e": [
              ",CODE",
              ",COED",
              ",COME",
              ",DEMO",
              ",DOME",
              ",DOOM",
              ",MEMO",
              ",MODE",
              ",MOOD",
              ",COOED",
              "B,MODEM"
            ]
          },
          "level_014": {
            "a": 687170,
            "b": "EDMIAL",
            "e": [
              ",AIMED",
              ",EMAIL",
              ",IDEAL",
              ",LAMED",
              ",MEDAL",
              ",MEDIA",
              ",MAILED",
              ",MEDIAL"
            ]
          },
          "level_015": {
            "a": 687160,
            "b": "PESTO",
            "e": [
              ",OPS",
              ",OPT",
              ",PET",
              ",POT",
              ",SET",
              ",SOP",
              ",TOE",
              ",TOP",
              ",PESTO"
            ]
          },
          "level_016": {
            "a": 687157,
            "b": "AYCPNIK",
            "e": [
              ",AKIN",
              ",CYAN",
              ",ICKY",
              ",INKY",
              ",NICK",
              ",PACK",
              ",PAIN",
              ",PICK",
              ",PINK",
              ",YANK"
            ]
          },
          "level_017": {
            "a": 687152,
            "b": "LNYGTE",
            "e": [
              ",GEL",
              ",GET",
              ",LEG",
              ",LET",
              ",LYE",
              ",NET",
              ",TEN",
              ",YEN",
              ",YET",
              ",GENTLY"
            ]
          },
          "level_018": {
            "a": 687164,
            "b": "NLAUDRE",
            "e": [
              ",ALDER",
              ",LADEN",
              ",LEARN",
              ",LUNAR",
              ",LURED",
              ",RENAL",
              ",RULED",
              ",UNDER"
            ]
          },
          "level_019": {
            "a": 687162,
            "b": "LTARKSY",
            "e": [
              ",ARTY",
              ",LARK",
              ",LAST",
              ",SALT",
              ",SLAT",
              ",SLAY",
              ",STAR",
              ",STAY",
              ",TALK",
              ",TASK",
              ",TRAY"
            ]
          },
          "level_020": {
            "a": 687161,
            "b": "GLUBMRE",
            "e": [
              ",BLUER",
              ",BUGLE",
              ",BULGE",
              ",GRUEL",
              ",LEMUR",
              ",RUBLE",
              ",UMBER",
              ",LUMBER",
              "B,RUMBLE"
            ]
          }
        },
        "m": 32512,
        "o": 48538,
        "r": 32512,
        "t": 0.76,
        "v": 53029,
        "x": 4294967295,
        "y": 0.76
      },
      "set_3": {
        "a": "WILD",
        "aa": 54603,
        "cc": 4294967295,
        "d": "bg_jungle3.jpg",
        "dd": 54603,
        "e": 0,
        "ee": 4294967295,
        "g": 0.92,
        "i": 4294967295,
        "j": 49483,
        "k": 4294967295,
        "l": 54603,
        "levels": {
          "level_001": {
            "a": 687308,
            "b": "ENUEAS",
            "e": [
              ",EASE",
              ",SANE",
              ",SEEN",
              ",ENSUE",
              ",UNEASE"
            ]
          },
          "level_002": {
            "a": 687318,
            "b": "LAMNOYA",
            "e": [
              ",LOAM",
              ",LOAN",
              ",MANY",
              ",MOAN",
              ",ONLY",
              ",LAYMAN",
              ",ANOMALY"
            ]
          },
          "level_003": {
            "a": 687312,
            "b": "SPEPUPI",
            "e": [
              ",PEP",
              ",PIE",
              ",PUP",
              ",PUS",
              ",SIP",
              ",SUE",
              ",SUP",
              ",UPS",
              ",USE",
              ",PIPE"
            ]
          },
          "level_004": {
            "a": 687304,
            "b": "SSOUPT",
            "e": [
              ",OPUS",
              ",OUST",
              ",POST",
              ",POUT",
              ",SOUP",
              ",SPOT",
              ",STOP",
              ",TOSS",
              ",SPOUT"
            ]
          },
          "level_005": {
            "a": 687322,
            "b": "UDFON",
            "e": [
              ",DON",
              ",DUN",
              ",DUO",
              ",FUN",
              ",NOD",
              ",FOND",
              ",FUND",
              ",UNDO",
              ",FOUND"
            ]
          },
          "level_006": {
            "a": 687317,
            "b": "RMNIAFE",
            "e": [
              ",AFIRE",
              ",FINER",
              ",FRAME",
              ",INFER",
              ",MINER",
              ",AIRMEN",
              "B,FAMINE",
              ",MARINE",
              ",REMAIN",
              ",FIREMAN"
            ]
          },
          "level_007": {
            "a": 687307,
            "b": "ACDSEE",
            "e": [
              ",ACE",
              "B,ADS",
              ",CAD",
              ",SAC",
              ",SAD",
              ",SEA",
              ",SEE",
              ",CEASED"
            ]
          },
          "level_008": {
            "a": 687315,
            "b": "EDMBUI",
            "e": [
              ",BIDE",
              ",DIME",
              ",IMBUE",
              ",IMBUED"
            ]
          },
          "level_009": {
            "a": 687321,
            "b": "ERYCLCE",
            "e": [
              ",LEER",
              ",LYRE",
              ",REEL",
              ",RELY",
              ",CYCLE",
              ",LEERY",
              ",CELERY",
              ",RECYCLE"
            ]
          },
          "level_010": {
            "a": 687310,
            "b": "FOIDFEM",
            "e": [
              ",DIM",
              "B,DOE",
              ",FED",
              ",FOE",
              ",MID",
              ",ODE",
              ",OFF",
              ",FIEFDOM"
            ]
          },
          "level_011": {
            "a": 687313,
            "b": "GVAEARE",
            "e": [
              ",AGE",
              "B,ARE",
              ",EAR",
              ",ERA",
              ",EVE",
              ",GEE",
              ",RAG",
              ",AVERAGE"
            ]
          },
          "level_012": {
            "a": 687319,
            "b": "LAETSB",
            "e": [
              ",BASTE",
              ",BEAST",
              ",BLASE",
              ",BLAST",
              ",LEAST",
              ",SABLE",
              ",SLATE",
              ",STALE",
              ",STEAL",
              ",TABLE",
              ",STABLE"
            ]
          },
          "level_013": {
            "a": 687311,
            "b": "OCUTLS",
            "e": [
              ",COT",
              ",CUT",
              ",LOT",
              ",OUT",
              ",CLOUT",
              ",LOCUS",
              ",LOTUS",
              ",SCOUT"
            ]
          },
          "level_014": {
            "a": 687320,
            "b": "IWAKERL",
            "e": [
              ",ALIKE",
              "B,WREAK",
              ",WALKER",
              ",WARLIKE"
            ]
          },
          "level_015": {
            "a": 687314,
            "b": "AGGERL",
            "e": [
              ",EARL",
              ",GALE",
              ",GEAR",
              ",RAGE",
              ",REAL",
              ",GLARE",
              ",LAGER",
              ",LARGE",
              ",REGAL"
            ]
          },
          "level_016": {
            "a": 687305,
            "b": "FPUTILI",
            "e": [
              ",FLIP",
              ",FLIT",
              ",LIFT",
              ",UPLIFT",
              ",PITIFUL"
            ]
          },
          "level_017": {
            "a": 687309,
            "b": "ACDLEP",
            "e": [
              ",DECAL",
              ",LACED",
              ",PACED",
              ",PALED",
              ",PEDAL",
              ",PLACE",
              ",PLEAD",
              ",PLACED"
            ]
          },
          "level_018": {
            "a": 687323,
            "b": "LTEOOBK",
            "e": [
              ",BELT",
              "B,BLOT",
              ",BOLO",
              ",BOLT",
              ",BOOK",
              ",BOOT",
              ",LOBE",
              ",LOOK",
              ",LOOT",
              ",OBOE",
              ",TOOK",
              ",TOOL"
            ]
          },
          "level_019": {
            "a": 687316,
            "b": "ITEDRRE",
            "e": [
              ",DETER",
              ",DRIER",
              ",ERRED",
              ",RIDER",
              ",TIRED",
              ",TRIED",
              ",DIETER",
              ",RETIRE",
              ",TIERED",
              ",RETIRED"
            ]
          },
          "level_020": {
            "a": 687306,
            "b": "IIMRLPE",
            "e": [
              ",LIME",
              ",LIMP",
              ",MILE",
              ",MIRE",
              ",PERM",
              ",PIER",
              ",PILE",
              ",PRIM",
              ",RILE",
              ",RIPE",
              ",IMPERIL"
            ]
          }
        },
        "m": 32512,
        "o": 48538,
        "r": 32512,
        "t": 0.7000000000000001,
        "v": 54603,
        "x": 4294967295,
        "y": 0.7000000000000001
      },
      "set_4": {
        "a": "LUSH",
        "aa": 44817,
        "bb": 16777215,
        "cc": 268435455,
        "d": "bg_jungle4.jpg",
        "dd": 44817,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 44817,
        "k": 268435455,
        "l": 44817,
        "levels": {
          "level_001": {
            "a": 687442,
            "b": "YESDAWI",
            "e": [
              ",AIDE",
              ",AWED",
              ",DEWY",
              ",EASY",
              ",IDEA",
              ",SAID",
              ",SIDE",
              ",SWAY",
              ",WADE",
              ",WIDE",
              ",WISE"
            ]
          },
          "level_002": {
            "a": 687451,
            "b": "SILSA",
            "e": [
              ",AIL",
              "B,SIS",
              ",SAIL",
              ",SISAL"
            ]
          },
          "level_003": {
            "a": 687448,
            "b": "EUAPKM",
            "e": [
              ",AMP",
              ",APE",
              ",EMU",
              ",MAP",
              ",PEA",
              ",MAKE",
              "B,PEAK",
              ",PUMA",
              ",MAKEUP"
            ]
          },
          "level_004": {
            "a": 687456,
            "b": "GDAVSEA",
            "e": [
              ",AGED",
              ",GAVE",
              ",SAGA",
              ",SAGE",
              ",SAVE",
              ",VASE",
              ",ADAGE",
              ",AGAVE",
              ",SAVED"
            ]
          },
          "level_005": {
            "a": 687461,
            "b": "GTELRTI",
            "e": [
              ",GEL",
              "B,GET",
              ",GIT",
              ",IRE",
              ",LEG",
              ",LET",
              ",LIE",
              ",LIT",
              ",RIG",
              ",TIE",
              ",TIL",
              ",GLITTER"
            ]
          },
          "level_006": {
            "a": 687449,
            "b": "CLVOYAL",
            "e": [
              ",ALL",
              ",CAY",
              ",COY",
              ",LAY",
              ",OVA",
              ",VAC",
              ",ALLOY",
              ",LOCAL",
              ",LOYAL",
              ",VOCAL"
            ]
          },
          "level_007": {
            "a": 687447,
            "b": "ADESLD",
            "e": [
              ",DALE",
              ",DEAD",
              ",DEAL",
              ",LEAD",
              ",SALE",
              ",SEAL",
              ",SLED",
              ",SADDLE"
            ]
          },
          "level_008": {
            "a": 687446,
            "b": "CNOCTCO",
            "e": [
              ",COCO",
              ",COOT",
              ",ONTO",
              ",TOON"
            ]
          },
          "level_009": {
            "a": 687453,
            "b": "GKDIMON",
            "e": [
              ",DING",
              ",DINK",
              ",KIND",
              ",KING",
              ",MIND",
              ",MINK",
              ",MONK",
              ",DOING",
              ",KINGDOM"
            ]
          },
          "level_010": {
            "a": 687455,
            "b": "TGOORT",
            "e": [
              ",GOO",
              ",GOT",
              ",ROT",
              ",TOO",
              ",TOT",
              ",ROOT",
              "B,TOOT",
              ",TORT",
              ",TROT"
            ]
          },
          "level_011": {
            "a": 687458,
            "b": "MYOSLIK",
            "e": [
              ",LIMO",
              "B,MILK",
              ",OILY",
              ",SILK",
              ",SILO",
              ",SKIM",
              ",SLIM",
              ",SOIL",
              ",YOLK"
            ]
          },
          "level_012": {
            "a": 687443,
            "b": "LIMLSWA",
            "e": [
              ",SMALL",
              ",SWAMI",
              ",SWILL",
              ",SAWMILL"
            ]
          },
          "level_013": {
            "a": 687459,
            "b": "LSENLU",
            "e": [
              ",LENS",
              ",NULL",
              ",SELL",
              ",SULLEN"
            ]
          },
          "level_014": {
            "a": 687450,
            "b": "ELRGKOW",
            "e": [
              ",GLOW",
              ",GORE",
              ",GREW",
              ",GROW",
              ",LORE",
              ",OGLE",
              ",OGRE",
              ",ROLE",
              ",WOKE",
              ",WORE",
              ",WORK"
            ]
          },
          "level_015": {
            "a": 687444,
            "b": "AUWNTL",
            "e": [
              ",ALT",
              ",ANT",
              ",LAT",
              ",LAW",
              ",NAW",
              ",NUT",
              ",TAN",
              ",TAU",
              ",WALNUT"
            ]
          },
          "level_016": {
            "a": 687445,
            "b": "REGDLGU",
            "e": [
              ",DRUG",
              "B,DUEL",
              ",GLUE",
              ",LUGE",
              ",LURE",
              ",RUDE",
              ",RULE",
              ",URGE",
              ",GURGLED"
            ]
          },
          "level_017": {
            "a": 687460,
            "b": "AYWBSU",
            "e": [
              ",ABS",
              ",BAS",
              ",BAY",
              ",BUS",
              ",BUY",
              ",SAW",
              ",SAY",
              ",SUB",
              ",WAS",
              ",WAY",
              ",SUBWAY"
            ]
          },
          "level_018": {
            "a": 687452,
            "b": "OGADLI",
            "e": [
              ",DIAL",
              ",GLAD",
              ",GOAD",
              ",GOAL",
              ",GOLD",
              ",IDOL",
              ",LAID",
              ",LOAD",
              ",DIALOG"
            ]
          },
          "level_019": {
            "a": 687454,
            "b": "TNIDIC",
            "e": [
              ",DIN",
              ",NIT",
              ",TIC",
              ",TIN",
              ",DINT"
            ]
          },
          "level_020": {
            "a": 687457,
            "b": "SLPEETE",
            "e": [
              ",ELSE",
              ",LEST",
              ",PEEL",
              ",PELT",
              ",PEST",
              ",SEEP",
              ",STEP",
              ",STEEPLE"
            ]
          }
        },
        "m": 16640,
        "o": 7391488,
        "r": 40704,
        "t": 0.65,
        "u": 0,
        "v": 44817,
        "w": 16777215,
        "x": 268435455,
        "y": 0.65,
        "z": 0
      },
      "set_5": {
        "a": "GREEN",
        "aa": 41239,
        "cc": 268435455,
        "d": "bg_jungle5.jpg",
        "dd": 41239,
        "e": 0,
        "ee": 268435455,
        "i": 268435455,
        "j": 41239,
        "k": 268435455,
        "l": 41239,
        "levels": {
          "level_001": {
            "a": 687615,
            "b": "ATGEANM",
            "e": [
              ",AGENT",
              ",MEANT",
              ",MAGNET",
              "B,MANAGE"
            ]
          },
          "level_002": {
            "a": 687608,
            "b": "ENINRD",
            "e": [
              ",DINE",
              ",DIRE",
              ",NERD",
              ",NINE",
              ",REIN",
              ",REND",
              ",RIDE",
              ",RIND"
            ]
          },
          "level_003": {
            "a": 687613,
            "b": "ARTPHEE",
            "e": [
              ",EARTH",
              ",EATER",
              ",ETHER",
              ",HATER",
              ",HEART",
              ",TAPER",
              ",THERE",
              ",THREE"
            ]
          },
          "level_004": {
            "a": 687603,
            "b": "QEIUPD",
            "e": [
              ",DIP",
              ",DUE",
              ",PIE",
              ",DUPE",
              ",QUID",
              ",QUIP",
              ",EQUIP",
              ",PIQUED"
            ]
          },
          "level_005": {
            "a": 687602,
            "b": "ODVENKI",
            "e": [
              ",INKED",
              "B,VIDEO",
              ",INVOKE",
              ",INVOKED"
            ]
          },
          "level_006": {
            "a": 687596,
            "b": "TBSAOMB",
            "e": [
              ",ATOM",
              ",BOAT",
              ",BOMB",
              ",MAST",
              ",MOAT",
              ",MOST",
              ",STAB",
              ",TOMB",
              ",ABBOT",
              ",BOAST"
            ]
          },
          "level_007": {
            "a": 687597,
            "b": "LMEWLO",
            "e": [
              ",ELM",
              ",LOW",
              ",MOW",
              ",OWE",
              ",OWL",
              ",WOE",
              ",MELLOW"
            ]
          },
          "level_008": {
            "a": 687611,
            "b": "AIRSNE",
            "e": [
              ",ARISE",
              ",RAISE",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SANER",
              ",SIREN",
              ",SNARE"
            ]
          },
          "level_009": {
            "a": 687599,
            "b": "TESRTI",
            "e": [
              ",REST",
              ",RISE",
              ",RITE",
              ",SIRE",
              ",SITE",
              ",STIR",
              ",TEST",
              ",TIER",
              ",TIRE",
              ",TRIES",
              "B,TRITE",
              ",SITTER"
            ]
          },
          "level_010": {
            "a": 687612,
            "b": "POPDOSE",
            "e": [
              ",DOPE",
              "B,DOSE",
              ",OOPS",
              ",POOP",
              ",POPE",
              ",POSE",
              ",SPED",
              ",POSED",
              ",OPPOSE"
            ]
          },
          "level_011": {
            "a": 687610,
            "b": "DODHSY",
            "e": [
              ",ODD",
              ",SHY",
              ",SOD",
              ",SOY",
              ",SHODDY"
            ]
          },
          "level_012": {
            "a": 687604,
            "b": "MNORCAH",
            "e": [
              ",ACORN",
              ",CHARM",
              ",MACHO",
              ",MACRO",
              ",MANOR",
              ",MARCH",
              ",MOCHA",
              ",NACHO",
              ",RANCH",
              ",ROACH",
              ",ROMAN",
              ",ANCHOR"
            ]
          },
          "level_013": {
            "a": 687598,
            "b": "GIAUAN",
            "e": [
              ",GIN",
              ",GNU",
              ",GUN",
              ",NAG",
              ",GAIN"
            ]
          },
          "level_014": {
            "a": 687614,
            "b": "ECDVIE",
            "e": [
              ",EVE",
              ",ICE",
              ",VIE",
              ",CEDE",
              ",DICE",
              ",DIVE",
              ",ICED",
              ",VICE",
              ",VIED",
              ",DEVICE"
            ]
          },
          "level_015": {
            "a": 687605,
            "b": "ISOTM",
            "e": [
              ",ITS",
              "B,SIM",
              ",SIT",
              ",TIS",
              ",MOIST"
            ]
          },
          "level_016": {
            "a": 687601,
            "b": "HOAGSHW",
            "e": [
              ",GASH",
              ",GOSH",
              ",HASH",
              ",SAGO",
              ",SHAG",
              ",SHAH",
              ",SHOW",
              ",SWAG",
              ",WASH",
              ",WHOA",
              ",HOGWASH"
            ]
          },
          "level_017": {
            "a": 687607,
            "b": "OARURP",
            "e": [
              ",OAR",
              ",OUR",
              ",PAR",
              ",PRO",
              ",RAP",
              ",POUR",
              ",PURR",
              ",ROAR",
              ",UPROAR"
            ]
          },
          "level_018": {
            "a": 687609,
            "b": "IIFFDMR",
            "e": [
              ",DIM",
              ",FIR",
              ",MID",
              ",RID",
              ",RIM",
              ",FIRM",
              "B,RIFF",
              ",MIDRIFF"
            ]
          },
          "level_019": {
            "a": 687606,
            "b": "SRLBIYK",
            "e": [
              ",ILK",
              ",RIB",
              ",SIR",
              ",SKI",
              ",SKY",
              ",SLY",
              ",BRISK",
              ",RISKY",
              ",SILKY",
              ",BRISKLY"
            ]
          },
          "level_020": {
            "a": 687600,
            "b": "CSTIBU",
            "e": [
              ",BUST",
              ",STUB",
              ",SUIT",
              ",CUBIST"
            ]
          }
        },
        "m": 18953,
        "o": 16462080,
        "r": 39759,
        "t": 0.65,
        "v": 41239,
        "x": 268435455,
        "y": 0.65
      }
    }
  },
  "WS 21": {
    "a": "AUTUMN",
    "b": "grad_white",
    "c": "grp_autumn",
    "d": 0.75,
    "e": 16752640,
    "f": 16740096,
    "sets": {
      "set_1": {
        "a": "FALL",
        "aa": 16752640,
        "bb": 6291502,
        "d": "bg_autumn1.jpg",
        "dd": 16752640,
        "e": 0.12,
        "ee": 6291502,
        "j": 16752640,
        "l": 16752640,
        "levels": {
          "level_001": {
            "a": 687810,
            "b": "EGSASS",
            "e": [
              ",AGE",
              ",GAS",
              ",SAG",
              ",SEA",
              ",GASES",
              ",GASSES"
            ]
          },
          "level_002": {
            "a": 687812,
            "b": "YPANP",
            "e": [
              ",ANY",
              ",APP",
              ",NAP",
              ",NAY",
              ",PAN",
              ",PAP",
              ",PAY",
              ",NAPPY"
            ]
          },
          "level_003": {
            "a": 687808,
            "b": "AEOENNM",
            "e": [
              ",MAN",
              ",MEN",
              ",NAN",
              ",ONE",
              ",AMEN",
              ",MANE",
              ",MEAN",
              ",MOAN",
              ",NAME",
              ",NEON",
              ",NONE",
              ",OMEN"
            ]
          },
          "level_004": {
            "a": 687826,
            "b": "EPRCPHI",
            "e": [
              ",CHIP",
              ",EPIC",
              ",HEIR",
              ",HIRE",
              ",PIER",
              ",PIPE",
              ",PREP",
              ",RICE",
              ",RICH",
              ",RIPE",
              ",CIPHER",
              ",HIPPER"
            ]
          },
          "level_005": {
            "a": 687815,
            "b": "OTRECR",
            "e": [
              ",CORE",
              ",ROTE",
              ",TORE",
              ",RETRO"
            ]
          },
          "level_006": {
            "a": 687818,
            "b": "TORCONS",
            "e": [
              ",COOT",
              ",CORN",
              ",COST",
              ",ONTO",
              ",ROOT",
              ",SNOT",
              ",SOON",
              ",SOOT",
              ",SORT",
              ",TOON",
              ",TORN"
            ]
          },
          "level_007": {
            "a": 687814,
            "b": "TLESDE",
            "e": [
              ",EEL",
              "B,LED",
              ",LET",
              ",SEE",
              ",SET",
              ",TEE",
              ",ELDEST"
            ]
          },
          "level_008": {
            "a": 687822,
            "b": "OBNDRZE",
            "e": [
              ",BONED",
              ",BORED",
              ",BORNE",
              ",DOZEN",
              ",DOZER",
              ",DRONE",
              ",ZONED",
              ",BRONZED"
            ]
          },
          "level_009": {
            "a": 687820,
            "b": "AAGMED",
            "e": [
              ",AGED",
              ",DAME",
              ",GAME",
              ",MADE",
              ",MAGE",
              ",MEAD",
              ",MEGA",
              ",DAMAGE"
            ]
          },
          "level_010": {
            "a": 687824,
            "b": "UALSPOS",
            "e": [
              ",ASP",
              "B,LAP",
              ",OPS",
              ",PAL",
              ",PUS",
              ",SAP",
              ",SOP",
              ",SPA",
              ",SUP",
              ",UPS",
              ",LASSO"
            ]
          },
          "level_011": {
            "a": 687809,
            "b": "TKAERA",
            "e": [
              ",AREA",
              ",RAKE",
              ",RATE",
              ",TAKE",
              ",TEAK",
              ",TEAR",
              ",TREK"
            ]
          },
          "level_012": {
            "a": 687821,
            "b": "LLRTHI",
            "e": [
              ",HIT",
              ",ILL",
              ",LIT",
              ",TIL",
              ",HILL",
              "B,HILT",
              ",LILT",
              ",TILL",
              ",TRILL"
            ]
          },
          "level_013": {
            "a": 687816,
            "b": "AREC",
            "e": [
              ",ACE",
              ",ARC",
              ",ARE",
              ",CAR",
              ",EAR",
              ",ERA",
              ",ACRE",
              ",CARE",
              ",RACE"
            ]
          },
          "level_014": {
            "a": 687813,
            "b": "SNEDAC",
            "e": [
              ",ACED",
              ",ACNE",
              ",CANE",
              ",CASE",
              ",DEAN",
              ",SAND",
              ",SANE",
              ",SCAN",
              ",SEND",
              ",DANCE",
              ",SEDAN",
              ",ASCEND"
            ]
          },
          "level_015": {
            "a": 687825,
            "b": "ACMOSI",
            "e": [
              ",CAMO",
              ",COMA",
              ",MICA",
              ",SCAM",
              ",MOSAIC"
            ]
          },
          "level_016": {
            "a": 687811,
            "b": "MYERTL",
            "e": [
              ",LYRE",
              "B,MELT",
              ",RELY",
              ",TERM",
              ",MYRTLE"
            ]
          },
          "level_017": {
            "a": 687819,
            "b": "GELRIL",
            "e": [
              ",GILL",
              ",GIRL",
              ",RILE",
              ",GRILLE"
            ]
          },
          "level_018": {
            "a": 687827,
            "b": "LBAAN",
            "e": [
              ",BAN",
              "B,LAB",
              ",NAB",
              ",BANAL"
            ]
          },
          "level_019": {
            "a": 687817,
            "b": "CROGEYR",
            "e": [
              ",COG",
              "B,COY",
              ",CRY",
              ",EGO",
              ",ERR",
              ",ORE",
              ",RYE",
              ",GROCERY"
            ]
          },
          "level_020": {
            "a": 687823,
            "b": "OHGTHUR",
            "e": [
              ",GOTH",
              ",GOUT",
              ",HOUR",
              ",HURT",
              ",ROUT",
              ",THOU",
              ",THRU",
              ",THUG",
              ",TOUR"
            ]
          }
        },
        "m": 11165184,
        "o": 34047,
        "r": 16777215,
        "t": 0.65,
        "v": 16749312,
        "x": 6291502,
        "y": 0.65
      },
      "set_2": {
        "a": "BARK",
        "aa": 16749312,
        "bb": 16777215,
        "cc": 0,
        "d": "bg_autumn2.jpg",
        "dd": 16749312,
        "e": 0.12,
        "ee": 0,
        "j": 16749312,
        "l": 16749312,
        "levels": {
          "level_001": {
            "a": 687958,
            "b": "EINXOPH",
            "e": [
              ",EXPO",
              ",HONE",
              ",HOPE",
              ",NOPE",
              ",OPEN",
              ",OXEN",
              ",PEON",
              ",PINE"
            ]
          },
          "level_002": {
            "a": 687960,
            "b": "EABHETR",
            "e": [
              ",BATHE",
              "B,BERET",
              ",BERTH",
              ",EARTH",
              ",EATER",
              ",ETHER",
              ",HATER",
              ",HEART",
              ",REHAB",
              ",THERE",
              ",THREE",
              ",BREATHE"
            ]
          },
          "level_003": {
            "a": 687964,
            "b": "YDLAE",
            "e": [
              ",DALE",
              ",DEAL",
              ",LADY",
              ",LEAD"
            ]
          },
          "level_004": {
            "a": 687973,
            "b": "OITDRA",
            "e": [
              ",ARID",
              "B,DART",
              ",DIRT",
              ",IOTA",
              ",RAID",
              ",RIOT",
              ",ROAD",
              ",TOAD",
              ",TRIO",
              ",TROD",
              ",ADROIT"
            ]
          },
          "level_005": {
            "a": 687963,
            "b": "GULYHE",
            "e": [
              ",GEL",
              "B,GUY",
              ",HEY",
              ",HUE",
              ",HUG",
              ",LEG",
              ",LUG",
              ",LYE",
              ",UGH",
              ",HUGELY"
            ]
          },
          "level_006": {
            "a": 687954,
            "b": "TINALP",
            "e": [
              ",ANTI",
              ",LAIN",
              ",LINT",
              ",NAIL",
              ",PAIL",
              ",PAIN",
              ",PANT",
              ",PINT",
              ",PITA",
              ",PLAN",
              ",TAIL"
            ]
          },
          "level_007": {
            "a": 687969,
            "b": "OAOLDNG",
            "e": [
              ",GLAD",
              ",GOAD",
              ",GOAL",
              ",GOLD",
              ",GOOD",
              ",GOON",
              ",LAND",
              ",LOAD",
              ",LOAN",
              ",LOGO",
              ",LONG",
              ",LOON"
            ]
          },
          "level_008": {
            "a": 687956,
            "b": "UCREWSN",
            "e": [
              ",CREW",
              ",CURE",
              ",RUNE",
              ",RUSE",
              ",SEWN",
              ",SURE",
              ",USER",
              ",WREN",
              ",CURSE",
              ",NURSE",
              ",SCREW",
              ",UNSCREW"
            ]
          },
          "level_009": {
            "a": 687967,
            "b": "IBELSKO",
            "e": [
              ",BIKE",
              "B,BILE",
              ",BOIL",
              ",ISLE",
              ",LIKE",
              ",LOBE",
              ",LOSE",
              ",SILK",
              ",SILO",
              ",SLOB",
              ",SOIL",
              ",SOLE"
            ]
          },
          "level_010": {
            "a": 687970,
            "b": "EBLBAB",
            "e": [
              ",ABLE",
              "B,BABE",
              ",BALE",
              ",BABBLE"
            ]
          },
          "level_011": {
            "a": 687955,
            "b": "CIPARY",
            "e": [
              ",AIRY",
              ",CARP",
              ",PAIR",
              ",PRAY",
              ",RACY"
            ]
          },
          "level_012": {
            "a": 687971,
            "b": "GTVOERI",
            "e": [
              ",GIVER",
              ",GROVE",
              ",OVERT",
              ",RIVET",
              ",TIGER",
              ",TROVE",
              ",VIGOR",
              ",VOTER",
              ",GOITER",
              ",VERTIGO"
            ]
          },
          "level_013": {
            "a": 687968,
            "b": "SOIPT",
            "e": [
              ",POST",
              ",SPIT",
              ",SPOT",
              ",STOP",
              ",POSIT"
            ]
          },
          "level_014": {
            "a": 687961,
            "b": "SUAOOMR",
            "e": [
              ",MOOR",
              ",ROAM",
              ",ROOM",
              ",SOAR",
              ",SOUR",
              ",SUMO"
            ]
          },
          "level_015": {
            "a": 687959,
            "b": "EEDTBAR",
            "e": [
              ",BEATER",
              ",BERATE",
              ",DEBATE",
              ",REBATE",
              ",TEARED"
            ]
          },
          "level_016": {
            "a": 687962,
            "b": "LGRDEDI",
            "e": [
              ",GILDED",
              ",GIRDLE",
              ",GLIDED",
              ",GLIDER",
              ",RIDDLE",
              ",RIDGED"
            ]
          },
          "level_017": {
            "a": 687957,
            "b": "RVLIARY",
            "e": [
              ",AIL",
              "B,AIR",
              ",IVY",
              ",LAY",
              ",RAY",
              ",VIA",
              ",RIVALRY"
            ]
          },
          "level_018": {
            "a": 687972,
            "b": "ASOMLL",
            "e": [
              ",ALMS",
              ",ALSO",
              ",LOAM",
              ",MALL",
              ",SLAM",
              ",SMALL",
              ",SLALOM"
            ]
          },
          "level_019": {
            "a": 687966,
            "b": "FCOEFRI",
            "e": [
              ",FORCE",
              ",OFFER",
              ",OFFICE",
              ",OFFICER"
            ]
          },
          "level_020": {
            "a": 687965,
            "b": "DPSITEN",
            "e": [
              ",INEPT",
              ",INSET",
              ",SITED",
              ",SNIDE",
              ",SNIPE",
              ",SPEND",
              ",SPENT",
              ",SPIED",
              ",SPINE",
              ",SPITE",
              ",TEPID",
              ",STIPEND"
            ]
          }
        },
        "m": 11165184,
        "o": 34047,
        "r": 16777215,
        "s": 0,
        "t": 0.6,
        "u": 0,
        "v": 16749312,
        "x": 6291502,
        "y": 0.6,
        "z": 0
      },
      "set_3": {
        "a": "RED",
        "aa": 16746240,
        "d": "bg_autumn3.jpg",
        "dd": 16746240,
        "e": 0,
        "j": 16746240,
        "l": 16746240,
        "levels": {
          "level_001": {
            "a": 688073,
            "b": "RTARSE",
            "e": [
              ",RATER",
              ",STARE",
              ",TERRA",
              ",ARREST",
              ",RAREST"
            ]
          },
          "level_002": {
            "a": 688072,
            "b": "EFNITSS",
            "e": [
              ",FESS",
              ",FINE",
              ",FIST",
              ",NEST",
              ",SENT",
              ",SIFT",
              ",SINE",
              ",SITE",
              ",TINE",
              ",FINEST",
              ",FITNESS"
            ]
          },
          "level_003": {
            "a": 688090,
            "b": "LDAPDE",
            "e": [
              ",ADD",
              ",ALE",
              ",APE",
              ",DAD",
              ",LAD",
              ",LAP",
              ",LED",
              ",PAD",
              ",PAL",
              ",PEA",
              ",PADDLE"
            ]
          },
          "level_004": {
            "a": 688078,
            "b": "ANLOCOR",
            "e": [
              ",ACORN",
              ",CAROL",
              ",COLON",
              ",CORAL",
              ",CROON",
              ",CORONA",
              "B,RACOON",
              ",CORONAL"
            ]
          },
          "level_005": {
            "a": 688084,
            "b": "DIRMRAE",
            "e": [
              ",AIMED",
              ",AIRED",
              ",ARMED",
              ",DREAM",
              ",DRIER",
              ",MEDIA",
              ",MIRED",
              ",RIDER"
            ]
          },
          "level_006": {
            "a": 688076,
            "b": "UPTTOU",
            "e": [
              ",POUT",
              ",PUTT",
              ",TOUT",
              ",TUTU",
              ",OUTPUT"
            ]
          },
          "level_007": {
            "a": 688083,
            "b": "ENTWI",
            "e": [
              ",NET",
              ",NEW",
              ",NIT",
              ",TEN",
              ",TIE",
              ",TIN",
              ",WET",
              ",WIN",
              ",WIT",
              ",TWINE"
            ]
          },
          "level_008": {
            "a": 688074,
            "b": "RTPOEST",
            "e": [
              ",OTTER",
              ",PESTO",
              ",PROSE",
              ",SPORE",
              ",SPORT",
              ",STORE",
              ",STREP",
              ",TORTE",
              ",TROPE"
            ]
          },
          "level_009": {
            "a": 688082,
            "b": "EMYRAGI",
            "e": [
              ",GAMER",
              ",GRIME",
              ",GRIMY",
              ",IMAGE",
              ",IMAGERY"
            ]
          },
          "level_010": {
            "a": 688075,
            "b": "ICOVNIE",
            "e": [
              ",CON",
              ",ICE",
              ",ION",
              ",ONE",
              ",VIE",
              ",COVEN",
              "B,IONIC",
              ",VOICE"
            ]
          },
          "level_011": {
            "a": 688080,
            "b": "SKCTO",
            "e": [
              ",COT",
              ",COST",
              ",SOCK",
              ",STOCK"
            ]
          },
          "level_012": {
            "a": 688088,
            "b": "OABYNTU",
            "e": [
              ",ABUT",
              "B,AUNT",
              ",AUTO",
              ",BOAT",
              ",BONY",
              ",BOUT",
              ",BUNT",
              ",BUOY",
              ",TUBA",
              ",TUNA",
              ",UNTO"
            ]
          },
          "level_013": {
            "a": 688085,
            "b": "LSETUFL",
            "e": [
              ",ELF",
              "B,FLU",
              ",LET",
              ",SET",
              ",SUE",
              ",USE",
              ",FLUTE",
              ",FULLEST"
            ]
          },
          "level_014": {
            "a": 688089,
            "b": "EKCLNKU",
            "e": [
              ",CUE",
              ",ELK",
              ",CLUE",
              ",LUCK",
              ",NECK",
              ",NUKE",
              ",KNUCKLE"
            ]
          },
          "level_015": {
            "a": 688091,
            "b": "FJYISUT",
            "e": [
              ",FIT",
              "B,ITS",
              ",JUS",
              ",JUT",
              ",SIT",
              ",TIS",
              ",JUSTIFY"
            ]
          },
          "level_016": {
            "a": 688077,
            "b": "LRAFIEU",
            "e": [
              ",AFIRE",
              ",FERAL",
              ",FLAIR",
              ",FLARE",
              ",FLIER",
              ",FRAIL",
              ",RIFLE",
              ",EARFUL",
              ",FAILURE"
            ]
          },
          "level_017": {
            "a": 688079,
            "b": "OIFRNMU",
            "e": [
              ",FIRM",
              ",FORM",
              ",FOUR",
              ",FROM",
              ",INFO",
              ",IRON",
              ",NORM",
              ",RUIN",
              ",FORUM",
              ",MINOR",
              ",MOURN",
              ",UNIFORM"
            ]
          },
          "level_018": {
            "a": 688086,
            "b": "BEPRAF",
            "e": [
              ",BARE",
              ",BEAR",
              ",FARE",
              ",FEAR",
              ",PARE",
              ",PEAR",
              ",REAP",
              ",PREFAB"
            ]
          },
          "level_019": {
            "a": 688087,
            "b": "NVMOE",
            "e": [
              ",MOVE",
              ",OMEN",
              ",OVEN",
              ",VENOM"
            ]
          },
          "level_020": {
            "a": 688081,
            "b": "REULDBA",
            "e": [
              ",ALDER",
              "B,BARED",
              ",BEARD",
              ",BLADE",
              ",BLARE",
              ",BLUER",
              ",BREAD",
              ",LURED",
              ",RUBLE",
              ",RULED",
              ",BLARED",
              ",DURABLE"
            ]
          }
        },
        "m": 11165184,
        "o": 35583,
        "r": 16777215,
        "t": 0.55,
        "v": 16746240,
        "x": 6291502,
        "y": 0.55
      },
      "set_4": {
        "a": "VIVID",
        "aa": 16743168,
        "d": "bg_autumn4.jpg",
        "dd": 16743168,
        "e": 0.14,
        "j": 16743168,
        "l": 16743168,
        "levels": {
          "level_001": {
            "a": 688247,
            "b": "OPWOWW",
            "e": [
              ",POW",
              ",WOO",
              ",WOW",
              ",POWWOW"
            ]
          },
          "level_002": {
            "a": 688238,
            "b": "TSOLECO",
            "e": [
              ",CLOSE",
              ",LOOSE",
              ",SCOOT",
              ",STOLE",
              ",STOOL",
              ",CLOSET",
              ",OCELOT",
              ",COOLEST"
            ]
          },
          "level_003": {
            "a": 688245,
            "b": "PYRTROA",
            "e": [
              ",ARTY",
              ",ATOP",
              ",PART",
              ",PORT",
              ",PRAY",
              ",RAPT",
              ",ROAR",
              ",TARP",
              ",TRAP",
              ",TRAY",
              ",TYPO",
              ",PORTRAY"
            ]
          },
          "level_004": {
            "a": 688246,
            "b": "SPRHIAT",
            "e": [
              ",SHARP",
              "B,SHIRT",
              ",STAIR",
              ",STAPH",
              ",STRAP",
              ",STRIP",
              ",TRASH",
              ",HARPIST"
            ]
          },
          "level_005": {
            "a": 688235,
            "b": "NTOOMTA",
            "e": [
              ",ANT",
              ",MAN",
              ",MAT",
              ",MOO",
              ",NOT",
              ",OAT",
              ",TAN",
              ",TON",
              ",TOO",
              ",TOT",
              ",MOTTO",
              ",TOMATO"
            ]
          },
          "level_006": {
            "a": 688232,
            "b": "FEYLAT",
            "e": [
              ",FATE",
              ",FEAT",
              ",FELT",
              ",FETA",
              ",FLAT",
              ",FLAY",
              ",FLEA",
              ",LATE",
              ",LEAF",
              ",LEFT",
              ",TALE",
              ",TEAL"
            ]
          },
          "level_007": {
            "a": 688244,
            "b": "EMGOL",
            "e": [
              ",EGO",
              ",ELM",
              ",GEL",
              ",GEM",
              ",LEG",
              ",LOG",
              ",MEG",
              ",MOLE",
              ",OGLE"
            ]
          },
          "level_008": {
            "a": 688233,
            "b": "ERAETTS",
            "e": [
              ",ESTATE",
              "B,RETEST",
              ",SETTER",
              ",STREET",
              ",TASTER",
              ",TEASER",
              ",TESTER",
              ",RESTATE"
            ]
          },
          "level_009": {
            "a": 688240,
            "b": "SAGYHG",
            "e": [
              ",ASH",
              ",GAG",
              ",GAS",
              ",HAG",
              ",HAS",
              ",HAY",
              ",SAG",
              ",SAY",
              ",SHY",
              ",SHAGGY"
            ]
          },
          "level_010": {
            "a": 688248,
            "b": "DANMNUE",
            "e": [
              ",AMEN",
              ",DAME",
              ",DEAN",
              ",DUNE",
              ",MADE",
              ",MANE",
              ",MEAD",
              ",MEAN",
              ",MEND",
              ",MENU",
              ",NAME",
              ",NUDE"
            ]
          },
          "level_011": {
            "a": 688241,
            "b": "DIOSUM",
            "e": [
              ",DIM",
              ",DUO",
              ",MID",
              ",MUD",
              ",SIM",
              ",SOD",
              ",SUM",
              ",SODIUM"
            ]
          },
          "level_012": {
            "a": 688239,
            "b": "TASLLAB",
            "e": [
              ",ABS",
              "B,ALL",
              ",ALT",
              ",BAS",
              ",BAT",
              ",LAB",
              ",LAT",
              ",SAT",
              ",TAB",
              ",BASALT",
              ",BALLAST"
            ]
          },
          "level_013": {
            "a": 688249,
            "b": "UAETRFE",
            "e": [
              ",AFTER",
              "B,EATER",
              ",REFUTE",
              ",FEATURE"
            ]
          },
          "level_014": {
            "a": 688242,
            "b": "PPLYO",
            "e": [
              ",PLOP",
              ",PLOY",
              ",POLY",
              ",POLYP"
            ]
          },
          "level_015": {
            "a": 688234,
            "b": "HSERW",
            "e": [
              ",HER",
              ",HEW",
              ",SEW",
              ",SHE",
              ",SHREW"
            ]
          },
          "level_016": {
            "a": 688230,
            "b": "OVYRLE",
            "e": [
              ",LEVY",
              ",LORE",
              ",LOVE",
              ",LYRE",
              ",OVER",
              ",RELY",
              ",ROLE",
              ",ROVE",
              ",VERY",
              ",VOLE",
              ",YORE"
            ]
          },
          "level_017": {
            "a": 688237,
            "b": "TARYET",
            "e": [
              ",RATTY",
              ",TEARY",
              ",TREAT",
              ",TREATY"
            ]
          },
          "level_018": {
            "a": 688243,
            "b": "UCYMPL",
            "e": [
              ",CUP",
              ",PLY",
              ",YUM",
              ",YUP",
              ",LUMP",
              ",PLUM",
              ",CLUMP",
              "B,LUMPY",
              ",CLUMPY"
            ]
          },
          "level_019": {
            "a": 688231,
            "b": "SUYTR",
            "e": [
              ",RUT",
              ",TRY",
              ",RUST",
              ",RUSTY"
            ]
          },
          "level_020": {
            "a": 688236,
            "b": "AEGGDLW",
            "e": [
              ",GLADE",
              ",WAGED",
              ",LAGGED",
              "B,WAGGED",
              ",WAGGLED"
            ]
          }
        },
        "m": 8997376,
        "o": 56933,
        "r": 8997376,
        "t": 0.7000000000000001,
        "v": 16743168,
        "y": 0.7000000000000001
      },
      "set_5": {
        "a": "COVER",
        "aa": 16740096,
        "d": "bg_autumn5.jpg",
        "dd": 16740096,
        "e": 0,
        "j": 16740096,
        "l": 16740096,
        "levels": {
          "level_001": {
            "a": 688392,
            "b": "EASNTS",
            "e": [
              ",ANTE",
              ",EAST",
              ",NEAT",
              ",NEST",
              ",SANE",
              ",SEAT",
              ",SENT",
              ",ASSET",
              ",ASSENT"
            ]
          },
          "level_002": {
            "a": 688398,
            "b": "LBUTYS",
            "e": [
              ",BUS",
              ",BUT",
              ",BUY",
              ",SLY",
              ",SUB",
              ",TUB",
              ",BUST",
              "B,BUSY",
              ",LUST",
              ",STUB",
              ",LUSTY"
            ]
          },
          "level_003": {
            "a": 688388,
            "b": "AERD",
            "e": [
              ",ARE",
              ",EAR",
              ",ERA",
              ",RAD",
              ",RED",
              ",DARE",
              "B,DEAR",
              ",READ"
            ]
          },
          "level_004": {
            "a": 688397,
            "b": "TPUSO",
            "e": [
              ",OPUS",
              ",OUST",
              ",POST",
              ",POUT",
              ",SOUP",
              ",SPOT",
              ",STOP",
              ",SPOUT"
            ]
          },
          "level_005": {
            "a": 688383,
            "b": "AFTRC",
            "e": [
              ",ACT",
              ",AFT",
              ",ARC",
              ",ART",
              ",CAR",
              ",CAT",
              ",FAR",
              ",FAT",
              ",RAT",
              ",TAR",
              ",CRAFT"
            ]
          },
          "level_006": {
            "a": 688393,
            "b": "APBLIEL",
            "e": [
              ",LABEL",
              ",LAPEL",
              ",LIBEL",
              ",LIABLE"
            ]
          },
          "level_007": {
            "a": 688387,
            "b": "RAMDOYO",
            "e": [
              ",ARMY",
              ",DOOM",
              ",DOOR",
              ",DORM",
              ",DRAM",
              ",MOOD",
              ",MOOR",
              ",ODOR",
              ",ROAD",
              ",ROAM",
              ",ROOM",
              ",YARD"
            ]
          },
          "level_008": {
            "a": 688384,
            "b": "WMAIRET",
            "e": [
              ",IRATE",
              ",MERIT",
              ",MITER",
              ",TAMER",
              ",TIMER",
              ",WATER",
              ",WRITE",
              ",WARTIME"
            ]
          },
          "level_009": {
            "a": 688394,
            "b": "GNYUGR",
            "e": [
              ",GNU",
              ",GUN",
              ",GUY",
              ",RUG",
              ",RUN",
              ",URN",
              ",RUNG",
              ",GRUNGY"
            ]
          },
          "level_010": {
            "a": 688401,
            "b": "ERSEAV",
            "e": [
              ",EASE",
              "B,EVER",
              ",RAVE",
              ",SAVE",
              ",SEAR",
              ",SEER",
              ",VASE",
              ",VEER",
              ",AVERSE"
            ]
          },
          "level_011": {
            "a": 688396,
            "b": "PLOT",
            "e": [
              ",LOT",
              ",OPT",
              ",POT",
              ",TOP",
              ",PLOT"
            ]
          },
          "level_012": {
            "a": 688399,
            "b": "HEITEPT",
            "e": [
              ",THEE",
              ",PETIT",
              ",TEETH",
              ",EPITHET"
            ]
          },
          "level_013": {
            "a": 688385,
            "b": "AJPAAM",
            "e": [
              ",AMP",
              "B,JAM",
              ",MAP",
              ",PAJAMA"
            ]
          },
          "level_014": {
            "a": 688386,
            "b": "EBBWOC",
            "e": [
              ",BOB",
              ",BOW",
              ",COB",
              ",COW",
              ",EBB",
              ",OWE",
              ",WEB",
              ",WOE",
              ",COBWEB"
            ]
          },
          "level_015": {
            "a": 688395,
            "b": "HEPANP",
            "e": [
              ",APE",
              ",APP",
              ",HEN",
              ",NAP",
              ",PAN",
              ",PAP",
              ",PEA",
              ",PEN",
              ",PEP",
              ",HEAP",
              "B,NAPE",
              ",PANE"
            ]
          },
          "level_016": {
            "a": 688382,
            "b": "EIGNMDL",
            "e": [
              ",DEIGN",
              ",DENIM",
              ",GLIDE",
              ",LINED",
              ",MINED",
              ",MINGLE",
              ",MELDING",
              ",MINGLED"
            ]
          },
          "level_017": {
            "a": 688389,
            "b": "GELAEU",
            "e": [
              ",GALE",
              ",GLEE",
              ",GLUE",
              ",LUGE",
              ",EAGLE"
            ]
          },
          "level_018": {
            "a": 688390,
            "b": "DRECU",
            "e": [
              ",CRUD",
              ",CUED",
              ",CURD",
              ",CURE",
              ",RUDE",
              ",CRUDE",
              ",CURED"
            ]
          },
          "level_019": {
            "a": 688391,
            "b": "ODEFSOA",
            "e": [
              ",DEAF",
              "B,DOSE",
              ",FADE",
              ",FOOD",
              ",SAFE",
              ",SODA",
              ",SOFA",
              ",SEAFOOD"
            ]
          },
          "level_020": {
            "a": 688400,
            "b": "ONICCLA",
            "e": [
              ",AIL",
              ",CAN",
              ",CON",
              ",ION",
              ",NIL",
              ",OIL",
              ",CALICO",
              ",OILCAN",
              ",CONICAL"
            ]
          }
        },
        "m": 8997376,
        "o": 34047,
        "r": 8997376,
        "t": 0.6,
        "v": 16740096,
        "y": 0.6
      }
    }
  },
  "WS 22": {
    "a": "FLORA",
    "b": "grad_white",
    "c": "grp_flora",
    "d": 0.75,
    "e": 15080315,
    "f": 13372071,
    "g": 15398136,
    "sets": {
      "set_1": {
        "a": "PETAL",
        "aa": 15080315,
        "bb": 16777215,
        "d": "bg_floral1.jpg",
        "dd": 15080315,
        "e": 0.18,
        "j": 15080315,
        "l": 15080315,
        "levels": {
          "level_001": {
            "a": 688521,
            "b": "AERMKE",
            "e": [
              ",MAKE",
              ",MARE",
              ",MARK",
              ",MEEK",
              ",MERE",
              ",RAKE",
              ",REEK",
              ",MAKER",
              ",REMAKE"
            ]
          },
          "level_002": {
            "a": 688516,
            "b": "RRBAIYL",
            "e": [
              ",ABLY",
              ",AIRY",
              ",BAIL",
              ",LAIR",
              ",LIAR",
              ",RAIL",
              ",BRIAR",
              ",LIBRARY"
            ]
          },
          "level_003": {
            "a": 688530,
            "b": "AMDINDO",
            "e": [
              ",AMID",
              ",MAID",
              ",MAIN",
              ",MIND",
              ",MOAN",
              ",AMINO",
              "B,NOMAD",
              ",DOMAIN",
              ",DIAMOND"
            ]
          },
          "level_004": {
            "a": 688523,
            "b": "MDUSISE",
            "e": [
              ",DIME",
              ",MESS",
              ",MUSE",
              ",SEMI",
              ",SIDE",
              ",SUDS",
              ",SUED",
              ",USED",
              ",ISSUED",
              "B,MISSED",
              ",MISUSE"
            ]
          },
          "level_005": {
            "a": 688517,
            "b": "REOPPC",
            "e": [
              ",COPE",
              "B,CORE",
              ",CROP",
              ",POPE",
              ",PORE",
              ",PREP",
              ",PROP",
              ",REPO",
              ",ROPE"
            ]
          },
          "level_006": {
            "a": 688528,
            "b": "TEEARB",
            "e": [
              ",BERET",
              ",EATER",
              ",BEATER",
              ",BERATE",
              ",REBATE"
            ]
          },
          "level_007": {
            "a": 688531,
            "b": "TNCEUL",
            "e": [
              ",CENT",
              ",CLUE",
              ",CULT",
              ",CUTE",
              ",LENT",
              ",LUTE",
              ",TUNE",
              ",UNCLE"
            ]
          },
          "level_008": {
            "a": 688532,
            "b": "NRTDOUA",
            "e": [
              ",ADORN",
              ",DONUT",
              ",RADON",
              ",ROUND",
              ",AROUND",
              ",ROTUND",
              ",TUNDRA",
              ",ROTUNDA"
            ]
          },
          "level_009": {
            "a": 688525,
            "b": "SAYZZN",
            "e": [
              ",ANY",
              ",NAY",
              ",SAY",
              ",SNAZZY"
            ]
          },
          "level_010": {
            "a": 688520,
            "b": "AREEDVS",
            "e": [
              ",EASED",
              "B,ERASE",
              ",EVADE",
              ",RAVED",
              ",SAVED",
              ",SAVER",
              ",SERVE",
              ",SEVER",
              ",VERSE"
            ]
          },
          "level_011": {
            "a": 688533,
            "b": "MIYGTH",
            "e": [
              ",GIT",
              "B,GYM",
              ",HIM",
              ",HIT",
              ",THY",
              ",MYTH",
              ",MIGHT",
              ",MIGHTY"
            ]
          },
          "level_012": {
            "a": 688529,
            "b": "NTIEIHG",
            "e": [
              ",EIGHT",
              ",HINGE",
              ",NIGHT",
              ",THINE",
              ",THING",
              ",TINGE",
              ",IGNITE",
              ",NIGHTIE"
            ]
          },
          "level_013": {
            "a": 688522,
            "b": "EWBEENT",
            "e": [
              ",BEEN",
              ",BEET",
              ",BENT",
              ",TEEN",
              ",WENT"
            ]
          },
          "level_014": {
            "a": 688518,
            "b": "MBRIET",
            "e": [
              ",BET",
              ",BIT",
              ",IRE",
              ",MET",
              ",REM",
              ",RIB",
              ",RIM",
              ",TIE",
              ",TIMBER",
              ",TIMBRE"
            ]
          },
          "level_015": {
            "a": 688527,
            "b": "ROBGNIH",
            "e": [
              ",BONG",
              ",BORN",
              ",BRIG",
              ",GRIN",
              ",HORN",
              ",IRON",
              ",NIGH",
              ",RING",
              ",BORING",
              "B,ROBING",
              ",BIGHORN"
            ]
          },
          "level_016": {
            "a": 688519,
            "b": "MLBAGE",
            "e": [
              ",AMBLE",
              ",BAGEL",
              ",BLAME",
              ",GABLE",
              ",GLEAM",
              ",GAMBLE"
            ]
          },
          "level_017": {
            "a": 688514,
            "b": "NLESSO",
            "e": [
              ",LENS",
              ",LESS",
              ",LONE",
              ",LOSE",
              ",LOSS",
              ",NOEL",
              ",NOSE",
              ",SOLE",
              ",LESSON"
            ]
          },
          "level_018": {
            "a": 688526,
            "b": "RUTEIQT",
            "e": [
              ",QUIT",
              ",RITE",
              ",TIER",
              ",TIRE",
              ",TRUE",
              ",QUIET",
              ",QUITE",
              ",TRITE",
              ",UTTER"
            ]
          },
          "level_019": {
            "a": 688524,
            "b": "SCRAEP",
            "e": [
              ",CAPER",
              ",PARSE",
              ",RECAP",
              ",SCARE",
              ",SCRAP",
              ",SPACE",
              ",SPARE",
              ",SPEAR"
            ]
          },
          "level_020": {
            "a": 688515,
            "b": "YUKSEQA",
            "e": [
              ",EASY",
              ",QUAY",
              ",SAKE",
              ",SQUEAK",
              ",SQUEAKY"
            ]
          }
        },
        "m": 8978511,
        "o": 52840,
        "r": 8978511,
        "t": 0.5,
        "u": 0,
        "v": 15080315,
        "w": 16777215,
        "y": 0.5,
        "z": 0
      },
      "set_2": {
        "a": "LILY",
        "aa": 14620294,
        "cc": 16777208,
        "d": "bg_floral2.jpg",
        "dd": 14620294,
        "e": 0.15,
        "ee": 16777208,
        "i": 16777208,
        "j": 14620294,
        "k": 16777208,
        "l": 14620294,
        "levels": {
          "level_001": {
            "a": 688684,
            "b": "DNRAOG",
            "e": [
              ",DARN",
              ",DRAG",
              ",GOAD",
              ",GRAD",
              ",RANG",
              ",ROAD",
              ",ROAN"
            ]
          },
          "level_002": {
            "a": 688676,
            "b": "YLOBIOG",
            "e": [
              ",BLOG",
              ",BOIL",
              ",BOLO",
              ",GLIB",
              ",GLOB",
              ",LOGO",
              ",OILY",
              ",YOGI",
              ",BIOLOGY"
            ]
          },
          "level_003": {
            "a": 688694,
            "b": "IWZSOHB",
            "e": [
              ",BIO",
              ",BIZ",
              ",BOW",
              ",HIS",
              ",HOW",
              ",SOB",
              ",SOW",
              ",WHO",
              ",WIZ",
              ",SHOWBIZ"
            ]
          },
          "level_004": {
            "a": 688689,
            "b": "AROTGU",
            "e": [
              ",AUTO",
              ",GOAT",
              ",GOUT",
              ",ROUT",
              ",TOGA",
              ",TOUR",
              ",GATOR",
              "B,GROUT"
            ]
          },
          "level_005": {
            "a": 688685,
            "b": "STNEEMA",
            "e": [
              ",EATEN",
              ",MEANT",
              ",STEAM",
              ",TEASE",
              ",TENSE",
              ",SEAMEN",
              "B,SENATE",
              ",MEANEST"
            ]
          },
          "level_006": {
            "a": 688682,
            "b": "FERECN",
            "e": [
              ",FEE",
              ",FEN",
              ",REF",
              ",FERN",
              "B,FREE",
              ",REEF",
              ",FENCE",
              ",FENCER"
            ]
          },
          "level_007": {
            "a": 688686,
            "b": "OEVDR",
            "e": [
              ",DOE",
              ",ODE",
              ",ORE",
              ",RED",
              ",ROD",
              ",DOER",
              ",DOVE",
              ",OVER",
              ",REDO",
              ",RODE",
              ",ROVE"
            ]
          },
          "level_008": {
            "a": 688687,
            "b": "SRUCSOE",
            "e": [
              ",CROSS",
              ",CURSE",
              ",ROUSE",
              ",SCORE",
              ",SCOUR",
              ",SUCROSE"
            ]
          },
          "level_009": {
            "a": 688680,
            "b": "EEPRIDX",
            "e": [
              ",DEEP",
              ",DEER",
              ",DIRE",
              ",DRIP",
              ",PEER",
              ",PIER",
              ",REED",
              ",RIDE",
              ",RIPE",
              ",PRIDE",
              ",PRIED"
            ]
          },
          "level_010": {
            "a": 688695,
            "b": "MYEELK",
            "e": [
              ",EEK",
              "B,EEL",
              ",EKE",
              ",ELK",
              ",ELM",
              ",EYE",
              ",KEY",
              ",LYE",
              ",MEEKLY"
            ]
          },
          "level_011": {
            "a": 688678,
            "b": "MDTSI",
            "e": [
              ",DIM",
              ",ITS",
              ",MID",
              ",SIM",
              ",SIT",
              ",TIS",
              ",MIST",
              ",MIDST"
            ]
          },
          "level_012": {
            "a": 688691,
            "b": "SLEUAAX",
            "e": [
              ",ALE",
              ",AXE",
              ",LAX",
              ",SAX",
              ",SEA",
              ",SEX",
              ",SUE",
              ",USE",
              ",ASEXUAL"
            ]
          },
          "level_013": {
            "a": 688688,
            "b": "ROABBS",
            "e": [
              ",BARB",
              ",BOAR",
              ",SOAR",
              ",ABSORB"
            ]
          },
          "level_014": {
            "a": 688693,
            "b": "AIAERRF",
            "e": [
              ",AFIRE",
              ",FRIAR",
              ",FAIRER",
              ",AIRFARE"
            ]
          },
          "level_015": {
            "a": 688677,
            "b": "IMSRMEK",
            "e": [
              ",MISER",
              ",SKIER",
              ",SMIRK",
              ",SIMMER"
            ]
          },
          "level_016": {
            "a": 688690,
            "b": "PDOESRN",
            "e": [
              ",DRONE",
              ",NOSED",
              ",POSED",
              ",PRONE",
              ",PROSE",
              ",ROPED",
              ",SNORE",
              ",SPEND",
              ",SPORE"
            ]
          },
          "level_017": {
            "a": 688679,
            "b": "TTHAOWN",
            "e": [
              ",OATH",
              "B,THAN",
              ",THAT",
              ",THAW",
              ",TOWN",
              ",WANT",
              ",WATT",
              ",WHAT",
              ",WHOA"
            ]
          },
          "level_018": {
            "a": 688692,
            "b": "PLYMIL",
            "e": [
              ",ILL",
              ",IMP",
              ",LIP",
              ",MIL",
              ",PLY",
              ",LILY",
              "B,LIMP",
              ",MILL",
              ",PILL",
              ",IMPLY",
              ",LIMPLY"
            ]
          },
          "level_019": {
            "a": 688681,
            "b": "IPRRYO",
            "e": [
              ",PRO",
              ",PRY",
              ",RIP",
              ",PRIOR"
            ]
          },
          "level_020": {
            "a": 688683,
            "b": "UEFSSRI",
            "e": [
              ",FESS",
              ",FIRE",
              ",FUSE",
              ",FUSS",
              ",RIFE",
              ",RISE",
              ",RUSE",
              ",SIRE",
              ",SURE",
              ",SURF",
              ",USER",
              ",FISSURE"
            ]
          }
        },
        "m": 8978511,
        "o": 52840,
        "r": 8978511,
        "t": 0.7000000000000001,
        "v": 14620294,
        "x": 16777208,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "BLOOM",
        "aa": 14226065,
        "cc": 11528696,
        "d": "bg_floral3.jpg",
        "dd": 14226065,
        "e": 0.15,
        "ee": 11528696,
        "j": 14226065,
        "l": 14226065,
        "levels": {
          "level_001": {
            "a": 688841,
            "b": "TEVPERN",
            "e": [
              ",EVE",
              ",NET",
              ",PEN",
              ",PER",
              ",PET",
              ",REP",
              ",TEE",
              ",TEN",
              ",VET",
              ",REPENT"
            ]
          },
          "level_002": {
            "a": 688828,
            "b": "ARVNEI",
            "e": [
              ",EARN",
              ",NAVE",
              ",NEAR",
              ",RAIN",
              ",RAVE",
              ",REIN",
              ",VAIN",
              ",VANE",
              ",VEIN",
              ",VINE",
              ",NAIVE",
              ",RAVEN"
            ]
          },
          "level_003": {
            "a": 688835,
            "b": "MLIADS",
            "e": [
              ",ALMS",
              "B,AMID",
              ",DIAL",
              ",LAID",
              ",MAID",
              ",MAIL",
              ",MILD",
              ",SAID",
              ",SAIL",
              ",SLAM",
              ",SLID",
              ",SLIM"
            ]
          },
          "level_004": {
            "a": 688837,
            "b": "OIALACX",
            "e": [
              ",COAL",
              ",COAX",
              ",COIL",
              ",COLA",
              ",COAXIAL"
            ]
          },
          "level_005": {
            "a": 688833,
            "b": "ONRW",
            "e": [
              ",NOR",
              ",NOW",
              ",OWN",
              ",ROW",
              ",WON",
              ",WORN"
            ]
          },
          "level_006": {
            "a": 688834,
            "b": "LTMAUU",
            "e": [
              ",ALT",
              ",LAM",
              ",LAT",
              ",MAT",
              ",TAU",
              ",MUTUAL"
            ]
          },
          "level_007": {
            "a": 688838,
            "b": "WNYA",
            "e": [
              ",ANY",
              ",NAW",
              ",NAY",
              ",WAY",
              ",YAWN"
            ]
          },
          "level_008": {
            "a": 688842,
            "b": "IDNESG",
            "e": [
              ",DINE",
              ",DING",
              ",SEND",
              ",SIDE",
              ",SIGN",
              ",SINE",
              ",SING",
              ",DEIGN",
              "B,SINGE",
              ",SNIDE"
            ]
          },
          "level_009": {
            "a": 688831,
            "b": "OSAHL",
            "e": [
              ",ASH",
              ",HAS",
              ",ALSO",
              ",HALO",
              ",LASH",
              ",SHOAL"
            ]
          },
          "level_010": {
            "a": 688840,
            "b": "ELDYTIR",
            "e": [
              ",DEITY",
              ",DIRTY",
              ",LITER",
              ",RILED",
              ",TILED",
              ",TIRED",
              ",TRIED",
              ",YIELD"
            ]
          },
          "level_011": {
            "a": 688827,
            "b": "AGPDAO",
            "e": [
              ",ADO",
              ",AGO",
              ",DOG",
              ",GAP",
              ",GOD",
              ",PAD",
              ",POD",
              ",PAGODA"
            ]
          },
          "level_012": {
            "a": 688836,
            "b": "IIOEZDL",
            "e": [
              ",DELI",
              ",DOLE",
              ",DOZE",
              ",IDLE",
              ",IDOL",
              ",LIED",
              ",LODE",
              ",IDOLIZE"
            ]
          },
          "level_013": {
            "a": 688845,
            "b": "SEIPW",
            "e": [
              ",PEW",
              ",PIE",
              ",SEW",
              ",SIP",
              ",SPEW",
              "B,WIPE",
              ",WISE",
              ",WISP"
            ]
          },
          "level_014": {
            "a": 688826,
            "b": "TAGEDRN",
            "e": [
              ",ARDENT",
              ",DANGER",
              ",GANDER",
              ",GARDEN",
              ",GARNET",
              ",GRATED",
              ",RANGED",
              ",RANTED"
            ]
          },
          "level_015": {
            "a": 688844,
            "b": "MFURO",
            "e": [
              ",FOR",
              ",FRO",
              ",FUR",
              ",OUR",
              ",RUM",
              ",FORM",
              ",FOUR",
              ",FROM",
              ",FORUM"
            ]
          },
          "level_016": {
            "a": 688830,
            "b": "TESPMU",
            "e": [
              ",MUSE",
              ",MUST",
              ",MUTE",
              ",PEST",
              ",SMUT",
              ",STEM",
              ",STEP",
              ",SUMP",
              ",TEMP",
              ",SEPTUM"
            ]
          },
          "level_017": {
            "a": 688832,
            "b": "OITNON",
            "e": [
              ",INN",
              ",ION",
              ",NIT",
              ",NOT",
              ",TIN",
              ",TON",
              ",TOO",
              ",INTO",
              "B,NOON",
              ",ONTO",
              ",TOON",
              ",ONION"
            ]
          },
          "level_018": {
            "a": 688829,
            "b": "ECIPSNT",
            "e": [
              ",INSECT",
              "B,INSTEP",
              ",NICEST",
              ",SEPTIC"
            ]
          },
          "level_019": {
            "a": 688843,
            "b": "SETEAIS",
            "e": [
              ",EASE",
              ",EAST",
              ",SEAT",
              ",SITE",
              ",EASIEST"
            ]
          },
          "level_020": {
            "a": 688839,
            "b": "NLEADC",
            "e": [
              ",CLEAN",
              ",DANCE",
              ",DECAL",
              ",LACED",
              ",LADEN",
              ",LANCE",
              ",CANDLE",
              "B,LANCED"
            ]
          }
        },
        "m": 9242179,
        "o": 52840,
        "r": 9242179,
        "t": 0.65,
        "v": 14226065,
        "x": 11528696,
        "y": 0.64
      },
      "set_4": {
        "a": "FIELD",
        "aa": 13766300,
        "d": "bg_floral4.jpg",
        "dd": 13766300,
        "e": 0.15,
        "j": 13766300,
        "l": 13766300,
        "levels": {
          "level_001": {
            "a": 688989,
            "b": "PEKACOC",
            "e": [
              ",CAKE",
              ",CAPE",
              ",COKE",
              ",COPE",
              ",PACE",
              ",PACK",
              ",PEAK",
              ",PECK",
              ",POKE",
              ",PEACOCK"
            ]
          },
          "level_002": {
            "a": 688983,
            "b": "PAYTS",
            "e": [
              ",PAST",
              ",SPAT",
              ",STAY",
              ",PASTY",
              ",PATSY"
            ]
          },
          "level_003": {
            "a": 688988,
            "b": "TKEYRU",
            "e": [
              ",KEY",
              ",RUE",
              ",RUT",
              ",RYE",
              ",TRY",
              ",YET",
              ",TREK",
              "B,TRUE",
              ",TURKEY"
            ]
          },
          "level_004": {
            "a": 688977,
            "b": "AUNIPOT",
            "e": [
              ",INPUT",
              ",PAINT",
              ",PATIO",
              ",PIANO",
              ",PINOT",
              ",PINTO",
              ",POINT",
              ",UTOPIAN"
            ]
          },
          "level_005": {
            "a": 688987,
            "b": "NUCLOS",
            "e": [
              ",CON",
              ",SON",
              ",SUN",
              ",CONSUL"
            ]
          },
          "level_006": {
            "a": 688974,
            "b": "IANMEC",
            "e": [
              ",ACE",
              ",AIM",
              ",CAM",
              ",CAN",
              ",ICE",
              ",MAN",
              ",MEN",
              ",MANIC",
              ",MINCE",
              ",ANEMIC",
              ",CINEMA"
            ]
          },
          "level_007": {
            "a": 688991,
            "b": "VOEW",
            "e": [
              ",OWE",
              "B,VOW",
              ",WOE",
              ",WOVE"
            ]
          },
          "level_008": {
            "a": 688979,
            "b": "TNIDEUR",
            "e": [
              ",RUINED",
              ",TINDER",
              ",TURNED",
              ",UNITED",
              ",UNTIED"
            ]
          },
          "level_009": {
            "a": 688986,
            "b": "LEDARH",
            "e": [
              ",ALE",
              ",ARE",
              ",EAR",
              ",ERA",
              ",HAD",
              ",HER",
              ",LAD",
              ",LED",
              ",RAD",
              ",RED",
              ",HERALD"
            ]
          },
          "level_010": {
            "a": 688975,
            "b": "EGLUPN",
            "e": [
              ",GLEN",
              "B,GLUE",
              ",GULP",
              ",LUGE",
              ",LUNG",
              ",PLUG",
              ",PLUNGE"
            ]
          },
          "level_011": {
            "a": 688990,
            "b": "PNAEL",
            "e": [
              ",LANE",
              ",LEAN",
              ",LEAP",
              ",NAPE",
              ",PALE",
              ",PANE",
              ",PEAL",
              ",PLAN",
              ",PLEA"
            ]
          },
          "level_012": {
            "a": 688982,
            "b": "AHREDAC",
            "e": [
              ",ACHED",
              ",AHEAD",
              ",CADRE",
              ",CARED",
              ",CEDAR",
              ",CHARD",
              ",DACHA",
              ",HEARD",
              ",RACED",
              ",REACH",
              ",ARCADE",
              ",ARCHED"
            ]
          },
          "level_013": {
            "a": 688976,
            "b": "UYMDP",
            "e": [
              ",MUD",
              ",YUM",
              ",YUP",
              ",DUMP"
            ]
          },
          "level_014": {
            "a": 688980,
            "b": "TREOLV",
            "e": [
              ",LORE",
              ",LOVE",
              ",OVER",
              ",ROLE",
              ",ROTE",
              ",ROVE",
              ",TORE",
              ",VETO",
              ",VOLE",
              ",VOTE",
              ",REVOLT"
            ]
          },
          "level_015": {
            "a": 688981,
            "b": "PAYPCA",
            "e": [
              ",APP",
              "B,CAP",
              ",CAY",
              ",PAP",
              ",PAY",
              ",PAPA"
            ]
          },
          "level_016": {
            "a": 688972,
            "b": "BETRMLU",
            "e": [
              ",BLUER",
              ",BLURT",
              ",BRUTE",
              ",LEMUR",
              ",RUBLE",
              ",TUBER",
              ",UMBER",
              ",BUTLER",
              ",LUMBER",
              ",RUMBLE",
              ",TUMBLE"
            ]
          },
          "level_017": {
            "a": 688973,
            "b": "ISENID",
            "e": [
              ",DEN",
              ",DIN",
              ",END",
              ",SIN",
              ",INSIDE"
            ]
          },
          "level_018": {
            "a": 688978,
            "b": "LYCSOT",
            "e": [
              ",COT",
              ",COY",
              ",LOT",
              ",SLY",
              ",SOY",
              ",TOY",
              ",CLOT",
              "B,COLT",
              ",COST",
              ",CYST",
              ",LOST",
              ",SLOT"
            ]
          },
          "level_019": {
            "a": 688984,
            "b": "EEKW",
            "e": [
              ",EEK",
              ",EKE",
              ",EWE",
              ",WEE",
              ",WEEK"
            ]
          },
          "level_020": {
            "a": 688985,
            "b": "TIEECPR",
            "e": [
              ",CREEP",
              "B,CREPE",
              ",CREPT",
              ",ERECT",
              ",PIECE",
              ",PRICE",
              ",TRIPE",
              ",RECEIPT"
            ]
          }
        },
        "m": 9242179,
        "o": 52840,
        "r": 9242179,
        "t": 0.7000000000000001,
        "v": 13766300,
        "y": 0.7000000000000001
      },
      "set_5": {
        "a": "SEED",
        "aa": 13372071,
        "bb": 16777215,
        "d": "bg_floral5.jpg",
        "dd": 13372071,
        "e": 0.12,
        "j": 13372071,
        "l": 13372071,
        "levels": {
          "level_001": {
            "a": 689179,
            "b": "ODIERP",
            "e": [
              ",PRIDE",
              "B,PRIED",
              ",ROPED",
              ",PERIOD"
            ]
          },
          "level_002": {
            "a": 689193,
            "b": "SHIMSAI",
            "e": [
              ",MASH",
              ",SASH",
              ",SHAM",
              ",SMASH",
              ",SASHIMI"
            ]
          },
          "level_003": {
            "a": 689181,
            "b": "DOWR",
            "e": [
              ",DOW",
              ",ROD",
              ",ROW",
              ",WORD"
            ]
          },
          "level_004": {
            "a": 689188,
            "b": "AETALCT",
            "e": [
              ",LACE",
              ",LATE",
              ",TACT",
              ",TALC",
              ",TALE",
              ",TEAL",
              ",CATTLE",
              ",LACTATE"
            ]
          },
          "level_005": {
            "a": 689184,
            "b": "AUNJTY",
            "e": [
              ",ANT",
              ",ANY",
              ",JAY",
              ",JUT",
              ",NAY",
              ",NUT",
              ",TAN",
              ",TAU",
              ",AUNT",
              ",TUNA"
            ]
          },
          "level_006": {
            "a": 689194,
            "b": "AEGIBG",
            "e": [
              ",AGE",
              ",BAG",
              ",BEG",
              ",BIG",
              ",EGG",
              ",GAG",
              ",GIG",
              ",BAGGIE"
            ]
          },
          "level_007": {
            "a": 689180,
            "b": "LMLITE",
            "e": [
              ",ELM",
              ",ILL",
              ",LET",
              ",LIE",
              ",LIT",
              ",MET",
              ",MIL",
              ",TIE",
              ",TIL",
              ",MILLET"
            ]
          },
          "level_008": {
            "a": 689182,
            "b": "EUTHSL",
            "e": [
              ",LEST",
              ",LUSH",
              ",LUST",
              ",LUTE",
              ",SHUT",
              ",THUS",
              ",TUSH",
              ",HUSTLE",
              "B,SLEUTH"
            ]
          },
          "level_009": {
            "a": 689183,
            "b": "MCEENA",
            "e": [
              ",ACME",
              ",ACNE",
              ",AMEN",
              ",CAME",
              ",CANE",
              ",MACE",
              ",MANE",
              ",MEAN",
              ",NAME",
              ",MENACE"
            ]
          },
          "level_010": {
            "a": 689190,
            "b": "NRWTES",
            "e": [
              ",NEST",
              ",RENT",
              ",REST",
              ",SENT",
              ",SEWN",
              ",STEW",
              ",TERN",
              ",WENT",
              ",WEST",
              ",WREN"
            ]
          },
          "level_011": {
            "a": 689191,
            "b": "REESIAD",
            "e": [
              ",DESIRE",
              ",EASIER",
              ",ERASED",
              ",RAISED",
              ",RESIDE",
              ",SEARED"
            ]
          },
          "level_012": {
            "a": 689187,
            "b": "SLRPUUS",
            "e": [
              ",PUS",
              ",SUP",
              ",UPS",
              ",PLUS",
              ",SLUR",
              ",SPUR",
              ",SLURP",
              ",USURP"
            ]
          },
          "level_013": {
            "a": 689189,
            "b": "HRETEWH",
            "e": [
              ",HERE",
              ",THEE",
              ",TREE",
              ",WERE",
              ",ETHER",
              "B,THERE",
              ",THREE",
              ",THREW",
              ",WHERE"
            ]
          },
          "level_014": {
            "a": 689185,
            "b": "LNIMDIE",
            "e": [
              ",DENIM",
              "B,LINED",
              ",MINED",
              ",MIDLINE"
            ]
          },
          "level_015": {
            "a": 689178,
            "b": "IELCEPS",
            "e": [
              ",CLIP",
              ",ELSE",
              ",EPIC",
              ",ISLE",
              ",LICE",
              ",LISP",
              ",PEEL",
              ",PILE",
              ",SEEP",
              ",SLIP",
              ",SPEC"
            ]
          },
          "level_016": {
            "a": 689186,
            "b": "CUDDEDE",
            "e": [
              ",CUE",
              ",DUD",
              ",DUE",
              ",CEDE",
              ",CUED",
              ",DEED",
              ",DUDE",
              ",DEDUCED"
            ]
          },
          "level_017": {
            "a": 689177,
            "b": "WHOSSO",
            "e": [
              ",HOW",
              ",OOH",
              ",SOW",
              ",WHO",
              ",WOO",
              ",SHOO",
              ",SHOW"
            ]
          },
          "level_018": {
            "a": 689192,
            "b": "SUIROSE",
            "e": [
              ",EURO",
              "B,RISE",
              ",ROSE",
              ",RUSE",
              ",SIRE",
              ",SORE",
              ",SOUR",
              ",SURE",
              ",USER",
              ",ISSUER",
              ",SERIOUS"
            ]
          },
          "level_019": {
            "a": 689195,
            "b": "FRNOFU",
            "e": [
              ",FOR",
              "B,FRO",
              ",FUN",
              ",FUR",
              ",NOR",
              ",OFF",
              ",OUR",
              ",RUN",
              ",URN",
              ",FOUR"
            ]
          },
          "level_020": {
            "a": 689176,
            "b": "OEMETD",
            "e": [
              ",DEEM",
              ",DEMO",
              ",DOME",
              ",DOTE",
              ",MEET",
              ",MODE",
              ",MOTE",
              ",TOME",
              ",DEMOTE"
            ]
          }
        },
        "m": 9241721,
        "o": 52840,
        "r": 9241721,
        "t": 0.54,
        "u": 0,
        "v": 13372071,
        "w": 16777215,
        "y": 0.54,
        "z": 0
      }
    }
  },
  "WS 23": {
    "a": "WINTER",
    "b": "grad_white",
    "c": "grp_winter",
    "d": 0.6,
    "e": 41193,
    "f": 4151011,
    "sets": {
      "set_1": {
        "a": "CHILL",
        "aa": 41193,
        "bb": 16777215,
        "d": "bg_winter1.jpg",
        "dd": 41193,
        "e": 0.1,
        "j": 41193,
        "l": 41193,
        "levels": {
          "level_001": {
            "a": 689348,
            "b": "SEUNRTN",
            "e": [
              ",NURSE",
              "B,STERN",
              ",TUNER",
              ",UNREST"
            ]
          },
          "level_002": {
            "a": 689344,
            "b": "SDORTIE",
            "e": [
              ",DRIEST",
              ",EDITOR",
              ",RIOTED",
              ",SORTED",
              ",STORED",
              ",STRIDE",
              ",STRODE",
              ",STEROID",
              ",STORIED"
            ]
          },
          "level_003": {
            "a": 689340,
            "b": "ELRTIT",
            "e": [
              ",LITER",
              ",TITLE",
              ",TRITE",
              ",LITTER"
            ]
          },
          "level_004": {
            "a": 689342,
            "b": "LEORBBC",
            "e": [
              ",BOB",
              ",BRO",
              ",COB",
              ",EBB",
              ",LOB",
              ",ORB",
              ",ORE",
              ",ROB",
              ",CLOBBER",
              ",COBBLER"
            ]
          },
          "level_005": {
            "a": 689341,
            "b": "NADLAS",
            "e": [
              ",ADS",
              ",AND",
              ",LAD",
              ",SAD",
              ",LAND",
              ",SAND",
              ",NASAL",
              "B,SALAD"
            ]
          },
          "level_006": {
            "a": 689346,
            "b": "LYULCIK",
            "e": [
              ",CULL",
              ",ICKY",
              ",KILL",
              ",LICK",
              ",LILY",
              ",LUCK",
              ",YUCK",
              ",LUCKY",
              ",LUCKILY"
            ]
          },
          "level_007": {
            "a": 689333,
            "b": "AACRTTT",
            "e": [
              ",ACT",
              ",ARC",
              ",ART",
              ",CAR",
              ",CAT",
              ",RAT",
              ",TAR",
              ",ATTRACT"
            ]
          },
          "level_008": {
            "a": 689335,
            "b": "EPOLCRU",
            "e": [
              ",COUPE",
              "B,CRUEL",
              ",ULCER",
              ",COUPLER"
            ]
          },
          "level_009": {
            "a": 689339,
            "b": "CREHOBI",
            "e": [
              ",BORE",
              ",BRIE",
              ",CORE",
              ",CRIB",
              ",ECHO",
              ",HEIR",
              ",HERB",
              ",HERO",
              ",HIRE",
              ",RICE",
              ",RICH",
              ",ROBE"
            ]
          },
          "level_010": {
            "a": 689334,
            "b": "STIUNQ",
            "e": [
              ",QUIT",
              ",STUN",
              ",SUIT",
              ",UNIT",
              ",SQUINT"
            ]
          },
          "level_011": {
            "a": 689345,
            "b": "OGTPESA",
            "e": [
              ",PASTE",
              "B,PESTO",
              ",SPATE",
              ",STAGE",
              ",POSTAGE"
            ]
          },
          "level_012": {
            "a": 689336,
            "b": "LUOTDOH",
            "e": [
              ",HOLD",
              ",HOOD",
              ",HOOT",
              ",LOOT",
              ",LOUD",
              ",LOUT",
              ",THOU",
              ",THUD",
              ",TOLD",
              ",TOOL",
              ",OUTDO",
              ",HOLDOUT"
            ]
          },
          "level_013": {
            "a": 689337,
            "b": "RKAO",
            "e": [
              ",ARK",
              ",OAK",
              ",OAR",
              ",OKRA"
            ]
          },
          "level_014": {
            "a": 689343,
            "b": "DEGLES",
            "e": [
              ",EEL",
              ",GEE",
              ",GEL",
              ",LED",
              ",LEG",
              ",SEE",
              ",LEDGE",
              ",SEDGE"
            ]
          },
          "level_015": {
            "a": 689349,
            "b": "HCSAK",
            "e": [
              ",ASH",
              ",ASK",
              ",HAS",
              ",SAC",
              ",CASH",
              ",CASK",
              ",HACK",
              ",SACK"
            ]
          },
          "level_016": {
            "a": 689351,
            "b": "TIYBRGO",
            "e": [
              ",BRIG",
              ",GORY",
              ",GRIT",
              ",RIOT",
              ",TRIO",
              ",YOGI",
              ",BIGOT",
              "B,ORBIT",
              ",BIGOTRY"
            ]
          },
          "level_017": {
            "a": 689338,
            "b": "LAGIN",
            "e": [
              ",AIL",
              ",GAL",
              ",GIN",
              ",LAG",
              ",NAG",
              ",NIL",
              ",GAIN",
              "B,LAIN",
              ",NAIL"
            ]
          },
          "level_018": {
            "a": 689332,
            "b": "EDNMGSI",
            "e": [
              ",DIME",
              ",DINE",
              ",DING",
              ",MEND",
              ",MIND",
              ",MINE",
              ",SEMI",
              ",SEND",
              ",SIDE",
              ",SIGN",
              ",SINE",
              ",SING"
            ]
          },
          "level_019": {
            "a": 689350,
            "b": "YOCULD",
            "e": [
              ",COD",
              ",COY",
              ",DOC",
              ",DUO",
              ",OLD",
              ",YOU",
              ",CLOUD",
              ",COULD"
            ]
          },
          "level_020": {
            "a": 689347,
            "b": "UERFNIG",
            "e": [
              ",FEIGN",
              ",FINER",
              ",FUNGI",
              ",GRIEF",
              ",INFER",
              ",INURE",
              ",REIGN",
              ",FIGURE",
              ",FINGER",
              ",FRINGE"
            ]
          }
        },
        "m": 22957,
        "o": 45048,
        "r": 22957,
        "t": 0.45,
        "u": 0,
        "v": 41193,
        "w": 16777215,
        "y": 0.45,
        "z": 0
      },
      "set_2": {
        "a": "BITE",
        "aa": 1019367,
        "bb": 16777215,
        "d": "bg_winter2.jpg",
        "dd": 1019367,
        "e": 0.1,
        "j": 1019367,
        "l": 1019367,
        "levels": {
          "level_001": {
            "a": 689541,
            "b": "RMTUP",
            "e": [
              ",PUT",
              ",RUM",
              ",RUT",
              ",TRUMP"
            ]
          },
          "level_002": {
            "a": 689549,
            "b": "VENROG",
            "e": [
              ",GONE",
              "B,GORE",
              ",OGRE",
              ",OVEN",
              ",OVER",
              ",ROVE",
              ",GOVERN"
            ]
          },
          "level_003": {
            "a": 689546,
            "b": "MREAB",
            "e": [
              ",ARE",
              ",ARM",
              ",BAM",
              ",BAR",
              ",BRA",
              ",EAR",
              ",ERA",
              ",MAR",
              ",RAM",
              ",REM",
              ",AMBER"
            ]
          },
          "level_004": {
            "a": 689552,
            "b": "TNCAIT",
            "e": [
              ",ANTI",
              ",TACT",
              ",TINT",
              ",ANTIC",
              "B,ATTIC",
              ",TACIT",
              ",TAINT",
              ",TITAN"
            ]
          },
          "level_005": {
            "a": 689542,
            "b": "LFELWO",
            "e": [
              ",ELF",
              "B,FEW",
              ",FOE",
              ",LOW",
              ",OWE",
              ",OWL",
              ",WOE",
              ",FELLOW"
            ]
          },
          "level_006": {
            "a": 689543,
            "b": "RLDEFEA",
            "e": [
              ",ALDER",
              ",DEFER",
              ",ELDER",
              ",FARED",
              ",FERAL",
              ",FLARE",
              ",FREED",
              ",FEDERAL"
            ]
          },
          "level_007": {
            "a": 689554,
            "b": "HEACSR",
            "e": [
              ",CHASE",
              ",CRASH",
              ",REACH",
              ",SCARE",
              ",SHARE",
              ",SHEAR",
              ",ARCHES",
              ",CHASER",
              ",SEARCH"
            ]
          },
          "level_008": {
            "a": 689547,
            "b": "TPMTEAT",
            "e": [
              ",MATE",
              ",MEAT",
              ",PATE",
              ",PEAT",
              ",TAME",
              ",TAMP",
              ",TAPE",
              ",TEAM",
              ",TEMP",
              ",MATTE",
              ",TEMPT",
              ",ATTEMPT"
            ]
          },
          "level_009": {
            "a": 689537,
            "b": "WENET",
            "e": [
              ",EWE",
              ",NET",
              ",NEW",
              ",TEE",
              ",TEN",
              ",WEE",
              ",WET",
              ",TWEEN"
            ]
          },
          "level_010": {
            "a": 689545,
            "b": "MLYRIP",
            "e": [
              ",LIMP",
              "B,PRIM",
              ",IMPLY",
              ",PRIMLY"
            ]
          },
          "level_011": {
            "a": 689548,
            "b": "IOEKOC",
            "e": [
              ",COO",
              ",ICE",
              ",KOI",
              ",COKE",
              ",COOK",
              ",COOKIE"
            ]
          },
          "level_012": {
            "a": 689551,
            "b": "ELARGE",
            "e": [
              ",AGREE",
              ",EAGER",
              ",EAGLE",
              ",GLARE",
              ",LAGER",
              ",LARGE",
              ",REGAL",
              ",REGALE"
            ]
          },
          "level_013": {
            "a": 689539,
            "b": "RYABEK",
            "e": [
              ",BAKE",
              ",BARE",
              ",BARK",
              ",BEAK",
              ",BEAR",
              ",RAKE",
              ",YEAR",
              ",BAKER",
              "B,BRAKE",
              ",BREAK",
              ",BAKERY"
            ]
          },
          "level_014": {
            "a": 689538,
            "b": "APULLR",
            "e": [
              ",ALL",
              ",LAP",
              ",PAL",
              ",PAR",
              ",RAP",
              ",PALL",
              ",PULL",
              ",PLURAL"
            ]
          },
          "level_015": {
            "a": 689553,
            "b": "YASE",
            "e": [
              ",AYE",
              ",SAY",
              ",SEA",
              ",YEA",
              ",YES",
              ",EASY"
            ]
          },
          "level_016": {
            "a": 689544,
            "b": "GNETAVA",
            "e": [
              ",ANTE",
              ",GATE",
              ",GAVE",
              ",GENT",
              ",GNAT",
              ",NAVE",
              ",NEAT",
              ",TANG",
              ",VANE",
              ",VENT",
              ",VANTAGE"
            ]
          },
          "level_017": {
            "a": 689550,
            "b": "DISPINI",
            "e": [
              ",DIN",
              ",DIP",
              ",NIP",
              ",PIN",
              ",SIN",
              ",SIP",
              ",SNIP",
              ",SPIN"
            ]
          },
          "level_018": {
            "a": 689540,
            "b": "TUOPPRR",
            "e": [
              ",PORT",
              ",POUR",
              ",POUT",
              ",PROP",
              ",PURR",
              ",ROUT",
              ",TOUR"
            ]
          },
          "level_019": {
            "a": 689555,
            "b": "TOTUNB",
            "e": [
              ",BOT",
              "B,BUN",
              ",BUT",
              ",NOT",
              ",NUB",
              ",NUT",
              ",OUT",
              ",TON",
              ",TOT",
              ",TUB",
              ",BUTTON"
            ]
          },
          "level_020": {
            "a": 689536,
            "b": "CCAULMI",
            "e": [
              ",ALUM",
              ",CALM",
              ",CLAM",
              ",MAIL",
              ",MAUL",
              ",MICA",
              ",CLAIM",
              ",CALCIUM"
            ]
          }
        },
        "m": 22957,
        "o": 45048,
        "r": 22957,
        "t": 0.55,
        "u": 0,
        "v": 1019367,
        "w": 16777215,
        "y": 0.55,
        "z": 0
      },
      "set_3": {
        "a": "FLAKE",
        "aa": 2063334,
        "d": "bg_winter3.jpg",
        "dd": 2063334,
        "e": 0.11,
        "j": 2063334,
        "l": 2063334,
        "levels": {
          "level_001": {
            "a": 689688,
            "b": "EACRORT",
            "e": [
              ",ACTOR",
              ",CARER",
              ",CATER",
              ",CRATE",
              ",RACER",
              ",RATER",
              ",REACT",
              ",RETRO",
              ",TERRA",
              ",TRACE"
            ]
          },
          "level_002": {
            "a": 689699,
            "b": "ALEDVU",
            "e": [
              ",DALE",
              ",DEAL",
              ",DUAL",
              ",DUEL",
              ",LAUD",
              ",LEAD",
              ",VALE",
              ",VEAL"
            ]
          },
          "level_003": {
            "a": 689696,
            "b": "YURLSO",
            "e": [
              ",ROSY",
              ",SLUR",
              ",SOUL",
              ",SOUR",
              ",YOUR"
            ]
          },
          "level_004": {
            "a": 689693,
            "b": "MYCNAA",
            "e": [
              ",ANY",
              ",CAM",
              ",CAN",
              ",CAY",
              ",MAN",
              ",MAY",
              ",NAY",
              ",YAM",
              ",CYAN",
              ",MANY",
              ",CAYMAN"
            ]
          },
          "level_005": {
            "a": 689689,
            "b": "RTYAAS",
            "e": [
              ",ARTY",
              ",STAR",
              ",STAY",
              ",TRAY"
            ]
          },
          "level_006": {
            "a": 689707,
            "b": "AWRIEV",
            "e": [
              ",RAVE",
              ",VIEW",
              ",WAVE",
              ",WEAR",
              ",WIRE",
              ",WAIVE",
              "B,WAVER",
              ",WAIVER"
            ]
          },
          "level_007": {
            "a": 689704,
            "b": "SOEARC",
            "e": [
              ",ACRE",
              "B,CARE",
              ",CASE",
              ",CORE",
              ",ORCA",
              ",RACE",
              ",ROSE",
              ",SCAR",
              ",SEAR",
              ",SOAR",
              ",SORE",
              ",COARSE"
            ]
          },
          "level_008": {
            "a": 689690,
            "b": "VPIARET",
            "e": [
              ",AVERT",
              ",IRATE",
              ",RIVET",
              ",TAPER",
              ",TRIPE",
              ",VIPER",
              ",PIRATE",
              ",PRIVATE"
            ]
          },
          "level_009": {
            "a": 689706,
            "b": "DIMUFLN",
            "e": [
              ",FILM",
              ",FIND",
              ",FUND",
              ",MILD",
              ",MIND"
            ]
          },
          "level_010": {
            "a": 689701,
            "b": "BRNONI",
            "e": [
              ",BORN",
              "B,IRON",
              ",ROBIN",
              ",INBORN"
            ]
          },
          "level_011": {
            "a": 689698,
            "b": "TREGI",
            "e": [
              ",GET",
              ",GIT",
              ",IRE",
              ",RIG",
              ",TIE",
              ",TIGER"
            ]
          },
          "level_012": {
            "a": 689695,
            "b": "FELGNU",
            "e": [
              ",FLUE",
              ",FUEL",
              ",GLEN",
              ",GLUE",
              ",GULF",
              ",LUGE",
              ",LUNG",
              ",FLUNG",
              ",LUNGE"
            ]
          },
          "level_013": {
            "a": 689692,
            "b": "ASWT",
            "e": [
              ",SAT",
              ",SAW",
              ",WAS",
              ",SWAT"
            ]
          },
          "level_014": {
            "a": 689702,
            "b": "IQEDURE",
            "e": [
              ",DEER",
              ",DIRE",
              ",QUID",
              ",REED",
              ",RIDE",
              ",RUDE",
              ",QUEER",
              ",QUERIED"
            ]
          },
          "level_015": {
            "a": 689697,
            "b": "ILPCAEN",
            "e": [
              ",ALIEN",
              ",CLEAN",
              ",LANCE",
              ",PANEL",
              ",PANIC",
              ",PECAN",
              ",PENAL",
              ",PLACE",
              ",PLAIN",
              ",PLANE",
              ",ALPINE",
              "B,PENCIL"
            ]
          },
          "level_016": {
            "a": 689691,
            "b": "DRPSEA",
            "e": [
              ",DRAPE",
              ",PADRE",
              ",PARED",
              ",PARSE",
              ",SPADE",
              ",SPARE",
              ",SPEAR",
              ",PARSED",
              "B,RASPED",
              ",SPARED",
              ",SPREAD"
            ]
          },
          "level_017": {
            "a": 689703,
            "b": "ENOTS",
            "e": [
              ",NEST",
              ",NOSE",
              ",NOTE",
              ",SENT",
              ",SNOT",
              ",TONE",
              ",ONSET",
              ",STONE"
            ]
          },
          "level_018": {
            "a": 689700,
            "b": "MEOERPR",
            "e": [
              ",MERE",
              ",MORE",
              ",PEER",
              ",PERM",
              ",POEM",
              ",PORE",
              ",PROM",
              ",REPO",
              ",ROMP",
              ",ROPE",
              ",EMPEROR"
            ]
          },
          "level_019": {
            "a": 689705,
            "b": "AEMIL",
            "e": [
              ",AIL",
              ",AIM",
              ",ALE",
              ",ELM",
              ",LAM",
              ",LIE",
              ",MIL",
              ",EMAIL"
            ]
          },
          "level_020": {
            "a": 689694,
            "b": "ONOAPRS",
            "e": [
              ",APRON",
              "B,ARSON",
              ",SNOOP",
              ",SONAR",
              ",SPOON",
              ",SPOOR",
              ",PARSON",
              ",SOPRANO"
            ]
          }
        },
        "m": 22957,
        "o": 52843,
        "r": 22957,
        "t": 0.6,
        "v": 2063334,
        "y": 0.6
      },
      "set_4": {
        "a": "WHITE",
        "aa": 3107044,
        "d": "bg_winter4.jpg",
        "dd": 3107044,
        "e": 0.1,
        "h": "wscapes_snow",
        "j": 3107044,
        "l": 3107044,
        "levels": {
          "level_001": {
            "a": 689869,
            "b": "UHIRBS",
            "e": [
              ",BUS",
              ",HIS",
              ",HUB",
              ",RIB",
              ",RUB",
              ",SIR",
              ",SUB",
              ",HUBRIS"
            ]
          },
          "level_002": {
            "a": 689867,
            "b": "TDYLHEA",
            "e": [
              ",DEALT",
              "B,DEATH",
              ",DELAY",
              ",DELTA",
              ",ETHYL",
              ",HATED",
              ",HEADY",
              ",LATHE"
            ]
          },
          "level_003": {
            "a": 689859,
            "b": "WOMN",
            "e": [
              ",MOW",
              ",NOW",
              ",OWN",
              ",WON",
              ",MOWN"
            ]
          },
          "level_004": {
            "a": 689876,
            "b": "RNEVTUE",
            "e": [
              ",ENTER",
              ",EVENT",
              ",NERVE",
              ",NEVER",
              ",TUNER",
              ",VENUE",
              ",NEUTER",
              ",TENURE",
              ",TUREEN"
            ]
          },
          "level_005": {
            "a": 689870,
            "b": "UROOJNS",
            "e": [
              ",JUS",
              ",NOR",
              ",OUR",
              ",RUN",
              ",SON",
              ",SUN",
              ",URN",
              ",SOJOURN"
            ]
          },
          "level_006": {
            "a": 689864,
            "b": "RMSAEOT",
            "e": [
              ",AROSE",
              "B,METRO",
              ",ROAST",
              ",SMART",
              ",SMEAR",
              ",STARE",
              ",STEAM",
              ",STORE",
              ",STORM",
              ",TAMER",
              ",MAESTRO"
            ]
          },
          "level_007": {
            "a": 689872,
            "b": "DLYLOB",
            "e": [
              ",BOD",
              ",BOY",
              ",LOB",
              ",OLD",
              ",BODY",
              ",BOLD",
              ",BOLL",
              ",DOLL",
              ",DOLLY"
            ]
          },
          "level_008": {
            "a": 689874,
            "b": "SIOTNLR",
            "e": [
              ",INTRO",
              "B,SNORT",
              ",TONSIL",
              ",NOSTRIL"
            ]
          },
          "level_009": {
            "a": 689860,
            "b": "LLRAYO",
            "e": [
              ",ALLY",
              ",ORAL",
              ",ROLL",
              ",ALLOY",
              ",LOYAL",
              ",RALLY",
              ",ROYAL",
              ",ORALLY"
            ]
          },
          "level_010": {
            "a": 689877,
            "b": "TEUDQEA",
            "e": [
              ",ATE",
              ",DUE",
              ",EAT",
              ",TAD",
              ",TAU",
              ",TEA",
              ",TEE",
              ",DATE",
              "B,DUET",
              ",QUAD",
              ",EQUATED"
            ]
          },
          "level_011": {
            "a": 689866,
            "b": "ELHOL",
            "e": [
              ",HOE",
              ",HELL",
              ",HOLE",
              ",HELLO"
            ]
          },
          "level_012": {
            "a": 689868,
            "b": "ELIETSF",
            "e": [
              ",ELITE",
              ",FILET",
              ",FLEET",
              ",FLIES",
              ",ISLET",
              ",SLEET",
              ",STEEL",
              ",ITSELF",
              ",STIFLE",
              ",LEFTIES"
            ]
          },
          "level_013": {
            "a": 689873,
            "b": "SPDIEL",
            "e": [
              ",DELI",
              ",IDLE",
              ",ISLE",
              ",LIED",
              ",LISP",
              ",PILE",
              ",PLED",
              ",SIDE",
              ",SLED",
              ",SLID",
              ",SLIP",
              ",SPED"
            ]
          },
          "level_014": {
            "a": 689858,
            "b": "PLEUOC",
            "e": [
              ",COP",
              ",CUE",
              ",CUP",
              ",CLUE",
              ",COPE",
              ",COUP",
              ",LOPE",
              ",POLE",
              ",COUPE",
              ",COUPLE"
            ]
          },
          "level_015": {
            "a": 689862,
            "b": "CDRCOA",
            "e": [
              ",ADO",
              ",ARC",
              ",CAD",
              ",CAR",
              ",COD",
              ",DOC",
              ",OAR",
              ",RAD",
              ",ROD",
              ",ACCORD"
            ]
          },
          "level_016": {
            "a": 689863,
            "b": "RBUEL",
            "e": [
              ",BLUE",
              ",BLUR",
              ",LUBE",
              ",LURE",
              ",RULE",
              ",BLUER",
              ",RUBLE"
            ]
          },
          "level_017": {
            "a": 689865,
            "b": "OOACVNL",
            "e": [
              ",CLAN",
              ",COAL",
              ",COLA",
              ",COOL",
              ",LOAN",
              ",LOON",
              ",NOVA",
              ",OVAL"
            ]
          },
          "level_018": {
            "a": 689871,
            "b": "CBTTOOY",
            "e": [
              ",BOOT",
              "B,COOT",
              ",TOOT",
              ",BOYCOTT"
            ]
          },
          "level_019": {
            "a": 689861,
            "b": "LEERV",
            "e": [
              ",EEL",
              ",EVE",
              ",EVER",
              ",LEER",
              ",REEL",
              ",VEER",
              ",LEVER",
              "B,REVEL"
            ]
          },
          "level_020": {
            "a": 689875,
            "b": "MNHGIAG",
            "e": [
              ",GAIN",
              ",GANG",
              ",HANG",
              ",MAIN",
              ",NIGH",
              ",AGING",
              ",GAMING",
              ",GINGHAM"
            ]
          }
        },
        "m": 15506,
        "o": 45048,
        "r": 15506,
        "t": 0.75,
        "v": 3107044,
        "y": 0.7000000000000001
      },
      "set_5": {
        "a": "FROST",
        "aa": 4151011,
        "d": "bg_winter5.jpg",
        "dd": 4151011,
        "e": 0.1,
        "j": 4151011,
        "l": 4151011,
        "levels": {
          "level_001": {
            "a": 689997,
            "b": "SERTSA",
            "e": [
              ",EAST",
              ",RATE",
              ",REST",
              ",SEAR",
              ",SEAT",
              ",STAR",
              ",TEAR",
              ",ASSERT"
            ]
          },
          "level_002": {
            "a": 690000,
            "b": "ATUIRM",
            "e": [
              ",MART",
              ",TRAM",
              ",TRIM",
              ",ATRIUM"
            ]
          },
          "level_003": {
            "a": 689993,
            "b": "CYEUNTH",
            "e": [
              ",CENT",
              ",CUTE",
              ",ETCH",
              ",HUNT",
              ",TECH",
              ",THEN",
              ",THEY",
              ",TUNE"
            ]
          },
          "level_004": {
            "a": 689996,
            "b": "EWDLDA",
            "e": [
              ",AWED",
              ",DALE",
              ",DEAD",
              ",DEAL",
              ",LEAD",
              ",LEWD",
              ",WADE",
              ",WELD",
              ",DAWDLE",
              ",WADDLE"
            ]
          },
          "level_005": {
            "a": 689987,
            "b": "NEYHEGI",
            "e": [
              ",EYE",
              ",GEE",
              ",GIN",
              ",HEN",
              ",HEY",
              ",YEN",
              ",YIN",
              ",EYEING",
              ",HYGIENE"
            ]
          },
          "level_006": {
            "a": 690004,
            "b": "STAOGPP",
            "e": [
              ",ATOP",
              ",GASP",
              ",GOAT",
              ",PAST",
              ",POST",
              ",SAGO",
              ",SOAP",
              ",SPAT",
              ",SPOT",
              ",STAG",
              ",STOP",
              ",TOGA"
            ]
          },
          "level_007": {
            "a": 690001,
            "b": "VDOICE",
            "e": [
              ",CODE",
              ",COED",
              ",COVE",
              ",DICE",
              ",DIVE",
              ",DOVE",
              ",ICED",
              ",VICE",
              ",VIED",
              ",VOID",
              ",VOICED"
            ]
          },
          "level_008": {
            "a": 689989,
            "b": "GRLUAJU",
            "e": [
              ",GAL",
              "B,JAG",
              ",JAR",
              ",JUG",
              ",LAG",
              ",LUG",
              ",RAG",
              ",RUG",
              ",JUGULAR"
            ]
          },
          "level_009": {
            "a": 690005,
            "b": "NOETA",
            "e": [
              ",ANTE",
              "B,NEAT",
              ",NOTE",
              ",TONE"
            ]
          },
          "level_010": {
            "a": 689990,
            "b": "URSEPU",
            "e": [
              ",PURE",
              ",RUSE",
              ",SPUR",
              ",SURE",
              ",USER",
              ",PURSE",
              ",SUPER",
              ",USURP",
              ",PURSUE"
            ]
          },
          "level_011": {
            "a": 690003,
            "b": "EEHXAL",
            "e": [
              ",AXLE",
              ",HEAL",
              ",HEEL",
              ",EXHALE"
            ]
          },
          "level_012": {
            "a": 689995,
            "b": "ETAUABL",
            "e": [
              ",ABATE",
              "B,TABLE",
              ",TUBAL",
              ",TABLEAU"
            ]
          },
          "level_013": {
            "a": 689991,
            "b": "ANYPT",
            "e": [
              ",ANT",
              ",ANY",
              ",APT",
              ",NAP",
              ",NAY",
              ",PAN",
              ",PAT",
              ",PAY",
              ",TAN",
              ",TAP",
              ",PANTY"
            ]
          },
          "level_014": {
            "a": 689988,
            "b": "SITEGN",
            "e": [
              ",INSET",
              ",SINGE",
              ",STING",
              ",TINGE"
            ]
          },
          "level_015": {
            "a": 689994,
            "b": "TCCNONE",
            "e": [
              ",CON",
              ",COT",
              ",NET",
              ",NOT",
              ",ONE",
              ",TEN",
              ",TOE",
              ",TON",
              ",CONNECT"
            ]
          },
          "level_016": {
            "a": 689998,
            "b": "GTELSNI",
            "e": [
              ",ENLIST",
              ",INGEST",
              ",LISTEN",
              ",SILENT",
              ",SINGLE",
              ",TINGLE",
              ",TINSEL",
              ",GLISTEN"
            ]
          },
          "level_017": {
            "a": 689992,
            "b": "CENNIA",
            "e": [
              ",ACE",
              "B,CAN",
              ",ICE",
              ",INN",
              ",NAN",
              ",INANE"
            ]
          },
          "level_018": {
            "a": 689986,
            "b": "ERERVES",
            "e": [
              ",SERVE",
              ",SEVER",
              ",VERSE",
              ",REVERE",
              ",SERVER",
              ",SEVERE",
              ",RESERVE",
              ",REVERSE"
            ]
          },
          "level_019": {
            "a": 690002,
            "b": "TUOGUD",
            "e": [
              ",DOG",
              "B,DOT",
              ",DUG",
              ",DUO",
              ",GOD",
              ",GOT",
              ",GUT",
              ",OUT",
              ",TUG",
              ",GOUT"
            ]
          },
          "level_020": {
            "a": 689999,
            "b": "MMSEIDT",
            "e": [
              ",DIM",
              "B,ITS",
              ",MET",
              ",MID",
              ",SET",
              ",SIM",
              ",SIT",
              ",TIE",
              ",TIS",
              ",DIMMEST"
            ]
          }
        },
        "m": 15506,
        "o": 45048,
        "r": 15506,
        "t": 0.75,
        "v": 4151011,
        "y": 0.75
      }
    }
  },
  "WS 24": {
    "a": "MOUNTAIN",
    "b": "grad_white",
    "c": "grp_mountain",
    "d": 1,
    "e": 5586657,
    "f": 8126683,
    "sets": {
      "set_1": {
        "a": "CREST",
        "aa": 5586657,
        "d": "bg_mountain1.jpg",
        "dd": 5586657,
        "e": 0.1,
        "j": 5586657,
        "l": 5586657,
        "levels": {
          "level_001": {
            "a": 690120,
            "b": "MLIP",
            "e": [
              ",IMP",
              ",LIP",
              ",MIL",
              ",LIMP"
            ]
          },
          "level_002": {
            "a": 690135,
            "b": "YAMLES",
            "e": [
              ",ALMS",
              ",EASY",
              ",LAME",
              ",MALE",
              ",MEAL",
              ",MESA",
              ",SALE",
              ",SAME",
              ",SEAL",
              ",SEAM",
              ",SLAM",
              ",SLAY"
            ]
          },
          "level_003": {
            "a": 690125,
            "b": "RUSFEE",
            "e": [
              ",FEE",
              ",FUR",
              ",REF",
              ",RUE",
              ",SEE",
              ",SUE",
              ",USE",
              ",REUSE"
            ]
          },
          "level_004": {
            "a": 690124,
            "b": "OANYCR",
            "e": [
              ",ACORN",
              "B,CORNY",
              ",CRONY",
              ",RAYON",
              ",CRAYON"
            ]
          },
          "level_005": {
            "a": 690128,
            "b": "RREOD",
            "e": [
              ",DOER",
              ",REDO",
              ",RODE",
              ",ORDER"
            ]
          },
          "level_006": {
            "a": 690129,
            "b": "BUODREN",
            "e": [
              ",BONED",
              ",BORED",
              ",BORNE",
              ",BOUND",
              ",DRONE",
              ",ROUND",
              ",UNDER",
              ",BURDEN",
              ",BURNED",
              ",REBOUND"
            ]
          },
          "level_007": {
            "a": 690131,
            "b": "OBMSO",
            "e": [
              ",BOO",
              "B,MOB",
              ",MOO",
              ",SOB",
              ",BOSOM"
            ]
          },
          "level_008": {
            "a": 690121,
            "b": "BCHAKEO",
            "e": [
              ",ACHE",
              "B,BACK",
              ",BAKE",
              ",BEAK",
              ",BECK",
              ",CAKE",
              ",COKE",
              ",EACH",
              ",ECHO",
              ",HACK",
              ",HOCK",
              ",BACKHOE"
            ]
          },
          "level_009": {
            "a": 690132,
            "b": "AMRREK",
            "e": [
              ",ARE",
              ",ARK",
              ",ARM",
              ",EAR",
              ",ERA",
              ",ERR",
              ",MAR",
              ",RAM",
              ",REM",
              ",MAKER",
              ",MARKER",
              ",REMARK"
            ]
          },
          "level_010": {
            "a": 690136,
            "b": "YNRBAD",
            "e": [
              ",BANDY",
              ",BRAND",
              ",RANDY",
              ",BRANDY"
            ]
          },
          "level_011": {
            "a": 690130,
            "b": "IRLAV",
            "e": [
              ",AIL",
              ",AIR",
              ",VIA",
              ",LAIR",
              ",LIAR",
              ",RAIL",
              ",VIAL",
              ",RIVAL",
              ",VIRAL"
            ]
          },
          "level_012": {
            "a": 690123,
            "b": "PSRPHEI",
            "e": [
              ",HEIR",
              ",HIRE",
              ",PIER",
              ",PIPE",
              ",PREP",
              ",RIPE",
              ",RISE",
              ",SHIP",
              ",SIRE",
              ",HIPPER",
              ",PERISH",
              ",SHIPPER"
            ]
          },
          "level_013": {
            "a": 690126,
            "b": "LNEGED",
            "e": [
              ",EDGE",
              ",GENE",
              ",GLEE",
              ",GLEN",
              ",LEND",
              ",NEED",
              ",LEDGE",
              ",LEGEND"
            ]
          },
          "level_014": {
            "a": 690122,
            "b": "OUCCKO",
            "e": [
              ",COO",
              ",COCO",
              ",COOK",
              ",CUCKOO"
            ]
          },
          "level_015": {
            "a": 690137,
            "b": "AYSHT",
            "e": [
              ",ASH",
              ",HAS",
              ",HAT",
              ",HAY",
              ",SAT",
              ",SAY",
              ",SHY",
              ",THY",
              ",ASHY",
              "B,STAY",
              ",HASTY"
            ]
          },
          "level_016": {
            "a": 690133,
            "b": "EOFHLOX",
            "e": [
              ",ELF",
              ",FOE",
              ",FOX",
              ",HEX",
              ",HOE",
              ",LOX",
              ",OOH",
              ",FOXHOLE"
            ]
          },
          "level_017": {
            "a": 690118,
            "b": "NRCSOE",
            "e": [
              ",CONE",
              ",CORE",
              ",CORN",
              ",NOSE",
              ",ONCE",
              ",ROSE",
              ",SORE",
              ",CENSOR"
            ]
          },
          "level_018": {
            "a": 690127,
            "b": "URBWOR",
            "e": [
              ",BOW",
              ",BRO",
              ",ORB",
              ",OUR",
              ",ROB",
              ",ROW",
              ",RUB",
              ",BROW",
              "B,BURR",
              ",BURROW"
            ]
          },
          "level_019": {
            "a": 690134,
            "b": "LAOLW",
            "e": [
              ",ALL",
              "B,LAW",
              ",LOW",
              ",OWL",
              ",WALL"
            ]
          },
          "level_020": {
            "a": 690119,
            "b": "RTEIHSP",
            "e": [
              ",HEIST",
              ",PRIES",
              ",SHIRE",
              ",SHIRT",
              ",SPIRE",
              ",SPITE",
              ",STREP",
              ",STRIP",
              ",THEIR",
              ",TRIES",
              ",TRIPE"
            ]
          }
        },
        "m": 3090059,
        "o": 50527,
        "r": 3090059,
        "t": 0.7000000000000001,
        "v": 5586657,
        "y": 0.7000000000000001
      },
      "set_2": {
        "a": "FJORD",
        "aa": 6172383,
        "d": "bg_mountain2.jpg",
        "dd": 6172383,
        "e": 0.1,
        "j": 6172383,
        "l": 6172383,
        "levels": {
          "level_001": {
            "a": 690322,
            "b": "ADTUI",
            "e": [
              ",AID",
              ",TAD",
              ",TAU",
              ",AUDIT"
            ]
          },
          "level_002": {
            "a": 690314,
            "b": "CPALIAT",
            "e": [
              ",CLAP",
              ",CLIP",
              ",PACT",
              ",PAIL",
              ",PITA",
              ",TAIL",
              ",TALC",
              ",CAPITAL"
            ]
          },
          "level_003": {
            "a": 690329,
            "b": "GNEAB",
            "e": [
              ",AGE",
              ",BAG",
              ",BAN",
              ",BEG",
              ",NAB",
              ",NAG",
              ",BANE",
              ",BANG",
              ",BEAN",
              ",BEGAN"
            ]
          },
          "level_004": {
            "a": 690315,
            "b": "ELILRAD",
            "e": [
              ",AIRED",
              ",ALDER",
              ",DRILL",
              ",IDEAL",
              ",LADLE",
              ",RILED",
              ",ALLIED",
              "B,DERAIL",
              ",RAILED",
              ",RALLIED"
            ]
          },
          "level_005": {
            "a": 690320,
            "b": "EERGD",
            "e": [
              ",GEE",
              ",RED",
              ",EDGER",
              ",GREED"
            ]
          },
          "level_006": {
            "a": 690312,
            "b": "OPREEN",
            "e": [
              ",NOPE",
              ",OPEN",
              ",PEER",
              ",PEON",
              ",PORE",
              ",REPO",
              ",ROPE",
              ",PREEN",
              ",PRONE"
            ]
          },
          "level_007": {
            "a": 690328,
            "b": "EUTDEIR",
            "e": [
              ",DETER",
              ",TIRED",
              ",TRIED",
              ",DIETER",
              "B,TIERED"
            ]
          },
          "level_008": {
            "a": 690321,
            "b": "UERNET",
            "e": [
              ",RENT",
              ",RUNE",
              ",RUNT",
              ",TEEN",
              ",TERN",
              ",TREE",
              ",TRUE",
              ",TUNE",
              ",TURN",
              ",NEUTER",
              "B,TENURE",
              ",TUREEN"
            ]
          },
          "level_009": {
            "a": 690323,
            "b": "DLEDHDU",
            "e": [
              ",DUD",
              ",DUE",
              ",DUH",
              ",HUE",
              ",LED",
              ",DUDE",
              ",DUEL",
              ",HELD",
              ",HUDDLED"
            ]
          },
          "level_010": {
            "a": 690319,
            "b": "EGLORBB",
            "e": [
              ",BLOB",
              ",BLOG",
              ",BORE",
              ",GLOB",
              ",GORE",
              ",LOBE",
              ",LORE",
              ",OGLE",
              ",OGRE",
              ",ROBE",
              ",ROLE",
              ",GOBBLER"
            ]
          },
          "level_011": {
            "a": 690326,
            "b": "PYAYBOL",
            "e": [
              ",BAY",
              ",BOA",
              ",BOP",
              ",BOY",
              ",LAB",
              ",LAP",
              ",LAY",
              ",LOB",
              ",PAL",
              ",PAY",
              ",PLY",
              ",PLAYBOY"
            ]
          },
          "level_012": {
            "a": 690324,
            "b": "OLWOPDY",
            "e": [
              ",LOOP",
              ",PLOW",
              ",PLOY",
              ",POLO",
              ",POLY",
              ",POOL",
              ",WOOD",
              ",WOOL",
              ",YOWL",
              ",LOOPY",
              ",WOOLY",
              ",PLYWOOD"
            ]
          },
          "level_013": {
            "a": 690331,
            "b": "GOSA",
            "e": [
              ",AGO",
              "B,GAS",
              ",SAG",
              ",SAGO"
            ]
          },
          "level_014": {
            "a": 690330,
            "b": "OEUDNF",
            "e": [
              ",DONE",
              ",DUNE",
              ",FEND",
              ",FEUD",
              ",FOND",
              ",FUND",
              ",NODE",
              ",NUDE",
              ",UNDO",
              ",FOUND",
              ",FONDUE"
            ]
          },
          "level_015": {
            "a": 690325,
            "b": "OBATR",
            "e": [
              ",BOAR",
              "B,BOAT",
              ",BRAT",
              ",ABORT"
            ]
          },
          "level_016": {
            "a": 690313,
            "b": "TRSUEYA",
            "e": [
              ",ARTSY",
              ",RUSTY",
              ",STARE",
              ",STRAY",
              ",TEARY",
              ",YEAST",
              ",SURETY"
            ]
          },
          "level_017": {
            "a": 690327,
            "b": "CDOA",
            "e": [
              ",ADO",
              ",CAD",
              ",COD",
              ",DOC",
              ",CODA"
            ]
          },
          "level_018": {
            "a": 690318,
            "b": "RLTYFAI",
            "e": [
              ",FAIRY",
              "B,FLAIR",
              ",FLIRT",
              ",FRAIL",
              ",LAITY",
              ",TRAIL",
              ",TRIAL",
              ",FRAILTY"
            ]
          },
          "level_019": {
            "a": 690316,
            "b": "EEDDDCI",
            "e": [
              ",CEDED",
              ",DICED",
              ",DECIDE",
              ",DECIDED"
            ]
          },
          "level_020": {
            "a": 690317,
            "b": "SUTNEAT",
            "e": [
              ",STATE",
              ",STENT",
              ",STUNT",
              ",TASTE",
              ",TAUNT",
              ",ASTUTE",
              ",STATUE",
              ",UNSEAT",
              ",TETANUS"
            ]
          }
        },
        "m": 3090061,
        "o": 13434986,
        "r": 3090061,
        "t": 0.8,
        "v": 6172383,
        "y": 0.75
      },
      "set_3": {
        "a": "CLIMB",
        "aa": 6823902,
        "d": "bg_mountain3.jpg",
        "dd": 6823902,
        "e": 0.1,
        "j": 6823902,
        "l": 6823902,
        "levels": {
          "level_001": {
            "a": 690432,
            "b": "ESNCT",
            "e": [
              ",NET",
              ",SET",
              ",TEN",
              ",CENT",
              ",NEST",
              ",SECT",
              ",SENT",
              ",SCENT"
            ]
          },
          "level_002": {
            "a": 690436,
            "b": "CIDLLIY",
            "e": [
              ",DILL",
              "B,IDLY",
              ",LILY",
              ",IDYLLIC"
            ]
          },
          "level_003": {
            "a": 690434,
            "b": "ELBAT",
            "e": [
              ",ABLE",
              ",BALE",
              ",BEAT",
              ",BELT",
              ",BETA",
              ",LATE",
              ",TALE",
              ",TEAL",
              ",TABLE"
            ]
          },
          "level_004": {
            "a": 690447,
            "b": "EROETRC",
            "e": [
              ",COT",
              ",ERR",
              ",ORE",
              ",ROT",
              ",TEE",
              ",TOE",
              ",ERECT",
              ",RETRO",
              ",ERECTOR"
            ]
          },
          "level_005": {
            "a": 690443,
            "b": "SKACEAN",
            "e": [
              ",ACE",
              ",ASK",
              ",CAN",
              ",SAC",
              ",SEA",
              ",SNACK",
              "B,SNAKE",
              ",SNEAK"
            ]
          },
          "level_006": {
            "a": 690430,
            "b": "IOTFFP",
            "e": [
              ",FIT",
              ",OFF",
              ",OFT",
              ",OPT",
              ",PIT",
              ",POT",
              ",TIP",
              ",TOP",
              ",TIPOFF"
            ]
          },
          "level_007": {
            "a": 690442,
            "b": "TNDTEA",
            "e": [
              ",ANTE",
              ",DATE",
              ",DEAN",
              ",DENT",
              ",NEAT",
              ",TEND",
              ",TENT",
              ",ATTEND"
            ]
          },
          "level_008": {
            "a": 690435,
            "b": "LUTEOPL",
            "e": [
              ",LOPE",
              ",LOUT",
              ",LUTE",
              ",PELT",
              ",PLOT",
              ",POET",
              ",POLE",
              ",POLL",
              ",POUT",
              ",PULL",
              ",TELL",
              ",TOLL"
            ]
          },
          "level_009": {
            "a": 690437,
            "b": "ORNIGI",
            "e": [
              ",GIN",
              ",ION",
              ",NOR",
              ",RIG",
              ",GRIN",
              ",IRON",
              ",RING",
              ",ORIGIN"
            ]
          },
          "level_010": {
            "a": 690440,
            "b": "LCSTIAE",
            "e": [
              ",AISLE",
              ",CASTE",
              ",CLEAT",
              ",ISLET",
              ",LEAST",
              ",SCALE",
              ",SLATE",
              ",SLICE",
              ",STALE",
              ",STEAL",
              ",CASTLE",
              ",ELASTIC"
            ]
          },
          "level_011": {
            "a": 690441,
            "b": "DHAEA",
            "e": [
              ",AAH",
              ",AHA",
              ",HAD",
              ",HEAD",
              ",AHEAD"
            ]
          },
          "level_012": {
            "a": 690445,
            "b": "SALGTYH",
            "e": [
              ",ASHY",
              ",GASH",
              ",HALT",
              ",LASH",
              ",LAST",
              ",SALT",
              ",SHAG",
              ",SLAT",
              ",SLAY",
              ",STAG",
              ",STAY",
              ",GHASTLY"
            ]
          },
          "level_013": {
            "a": 690439,
            "b": "RIVUEVS",
            "e": [
              ",IRE",
              "B,RUE",
              ",SIR",
              ",SUE",
              ",USE",
              ",VIE",
              ",VIRUS",
              ",SURVIVE"
            ]
          },
          "level_014": {
            "a": 690448,
            "b": "YRBEWEH",
            "e": [
              ",BEER",
              ",BREW",
              ",HERB",
              ",HERE",
              ",WERE",
              ",WHEY",
              ",WHERE",
              ",HEREBY"
            ]
          },
          "level_015": {
            "a": 690446,
            "b": "BTEY",
            "e": [
              ",BET",
              "B,BYE",
              ",YET",
              ",BYTE"
            ]
          },
          "level_016": {
            "a": 690433,
            "b": "EUSFLFC",
            "e": [
              ",CLUE",
              "B,CUFF",
              ",FLUE",
              ",FUEL",
              ",FUSE",
              ",SELF",
              ",SCUFF",
              ",SCUFFLE"
            ]
          },
          "level_017": {
            "a": 690444,
            "b": "RDPDAE",
            "e": [
              ",DARE",
              ",DEAD",
              ",DEAR",
              ",PARE",
              ",PEAR",
              ",READ",
              ",REAP",
              ",DRAPED"
            ]
          },
          "level_018": {
            "a": 690431,
            "b": "ARTINE",
            "e": [
              ",INERT",
              ",INTER",
              ",IRATE",
              ",TRAIN"
            ]
          },
          "level_019": {
            "a": 690438,
            "b": "NHESARS",
            "e": [
              ",EARN",
              ",HARE",
              ",HEAR",
              ",NEAR",
              ",RASH",
              ",SANE",
              ",SASH",
              ",SEAR",
              ",RASHES"
            ]
          },
          "level_020": {
            "a": 690449,
            "b": "UTENHAR",
            "e": [
              ",EARTH",
              ",HATER",
              ",HAUNT",
              ",HEART",
              ",TUNER",
              ",HUNTER",
              "B,NATURE",
              ",UNEARTH"
            ]
          }
        },
        "m": 3801748,
        "o": 16753152,
        "r": 3801748,
        "t": 0.8,
        "v": 6823902,
        "y": 0.8
      },
      "set_4": {
        "a": "SCALE",
        "aa": 7475164,
        "d": "bg_mountain4.jpg",
        "dd": 7475164,
        "e": 0.1,
        "j": 7475164,
        "l": 7475164,
        "levels": {
          "level_001": {
            "a": 690592,
            "b": "SEIUTD",
            "e": [
              ",DIET",
              ",DUET",
              ",DUST",
              ",EDIT",
              ",SIDE",
              ",SITE",
              ",STUD",
              ",SUED",
              ",SUIT",
              ",TIDE",
              ",TIED",
              ",USED"
            ]
          },
          "level_002": {
            "a": 690595,
            "b": "RLEWADE",
            "e": [
              ",DEALER",
              ",LEADER",
              ",WELDER",
              ",LEEWARD"
            ]
          },
          "level_003": {
            "a": 690585,
            "b": "LMEAF",
            "e": [
              ",ALE",
              ",ELF",
              ",ELM",
              ",LAM",
              ",FAME",
              ",FLEA",
              ",LAME",
              ",LEAF",
              ",MALE",
              ",MEAL",
              ",FLAME"
            ]
          },
          "level_004": {
            "a": 690593,
            "b": "FLEUTRF",
            "e": [
              ",FLUTE",
              ",RUFFLE",
              ",FRETFUL",
              ",TRUFFLE"
            ]
          },
          "level_005": {
            "a": 690580,
            "b": "SMETL",
            "e": [
              ",LEST",
              ",MELT",
              ",STEM",
              ",SMELT"
            ]
          },
          "level_006": {
            "a": 690579,
            "b": "CERELY",
            "e": [
              ",LEER",
              ",LYRE",
              ",REEL",
              ",RELY",
              ",LEERY",
              ",CELERY"
            ]
          },
          "level_007": {
            "a": 690586,
            "b": "LVRIAVE",
            "e": [
              ",ALIVE",
              ",LIVER",
              ",RAVEL",
              ",RIVAL",
              ",VALVE",
              ",VIRAL"
            ]
          },
          "level_008": {
            "a": 690590,
            "b": "HTUEDLS",
            "e": [
              ",HUSTLE",
              ",LUSTED",
              ",SLEUTH",
              ",HUSTLED"
            ]
          },
          "level_009": {
            "a": 690597,
            "b": "INVAL",
            "e": [
              ",LAIN",
              "B,NAIL",
              ",VAIN",
              ",VIAL",
              ",ANVIL"
            ]
          },
          "level_010": {
            "a": 690584,
            "b": "NAITT",
            "e": [
              ",ANT",
              ",NIT",
              ",TAN",
              ",TIN",
              ",ANTI",
              ",TINT",
              ",TAINT",
              "B,TITAN"
            ]
          },
          "level_011": {
            "a": 690588,
            "b": "YDUBD",
            "e": [
              ",BUD",
              ",BUY",
              ",DUB",
              ",DUD",
              ",BUDDY"
            ]
          },
          "level_012": {
            "a": 690596,
            "b": "ILETYV",
            "e": [
              ",EVIL",
              ",LEVY",
              ",LITE",
              ",LIVE",
              ",TILE",
              ",VEIL",
              ",VILE",
              ",YETI",
              ",LEVITY"
            ]
          },
          "level_013": {
            "a": 690589,
            "b": "IRCTOSH",
            "e": [
              ",COST",
              ",HOST",
              ",ITCH",
              ",RICH",
              ",RIOT",
              ",SHOT",
              ",SORT",
              ",STIR",
              ",THIS",
              ",TRIO"
            ]
          },
          "level_014": {
            "a": 690591,
            "b": "YRTNEER",
            "e": [
              ",RENT",
              ",TEEN",
              ",TERN",
              ",TREE",
              ",ENTER",
              "B,ENTRY",
              ",RETRY",
              ",TEENY",
              ",RENTER",
              ",REENTRY"
            ]
          },
          "level_015": {
            "a": 690581,
            "b": "SLHVEE",
            "e": [
              ",EEL",
              ",EVE",
              ",SEE",
              ",SHE",
              ",ELSE",
              "B,HEEL",
              ",ELVES",
              ",SHELVE"
            ]
          },
          "level_016": {
            "a": 690583,
            "b": "YOEOGBD",
            "e": [
              ",BODE",
              ",BODY",
              ",EDGY",
              ",GOOD",
              ",OBEY",
              ",OBOE",
              ",BOGEY",
              ",BOOED",
              ",GOODY",
              ",GOOEY"
            ]
          },
          "level_017": {
            "a": 690587,
            "b": "SGHULO",
            "e": [
              ",HOG",
              ",HUG",
              ",LOG",
              ",LUG",
              ",UGH",
              ",GOSH",
              "B,GUSH",
              ",LUSH",
              ",SLOG",
              ",SLUG",
              ",SOUL"
            ]
          },
          "level_018": {
            "a": 690594,
            "b": "GRPNLOO",
            "e": [
              ",GOON",
              "B,GOOP",
              ",LOGO",
              ",LONG",
              ",LOON",
              ",LOOP",
              ",POLO",
              ",PONG",
              ",POOL",
              ",POOR",
              ",PRONG",
              ",PROLONG"
            ]
          },
          "level_019": {
            "a": 690578,
            "b": "EWHOMSO",
            "e": [
              ",HOME",
              ",HOSE",
              ",MEOW",
              ",MESH",
              ",SHOE",
              ",SHOO",
              ",SHOW",
              ",SOME",
              ",WHOM",
              ",WHOSE",
              ",SOMEHOW"
            ]
          },
          "level_020": {
            "a": 690582,
            "b": "TUILEBR",
            "e": [
              ",BLUER",
              ",BLURT",
              ",BRUTE",
              ",BUILT",
              ",LITER",
              ",RUBLE",
              ",TRIBE",
              ",TUBER"
            ]
          }
        },
        "m": 3801748,
        "o": 47103,
        "r": 3801748,
        "t": 0.55,
        "v": 7475164,
        "y": 0.55
      },
      "set_5": {
        "a": "PEAK",
        "aa": 8126683,
        "d": "bg_mountain5.jpg",
        "dd": 8126683,
        "e": 0.1,
        "j": 8126683,
        "l": 8126683,
        "levels": {
          "level_001": {
            "a": 690697,
            "b": "CRROCET",
            "e": [
              ",COT",
              "B,ERR",
              ",ORE",
              ",ROT",
              ",TOE",
              ",RECTOR",
              ",CORRECT"
            ]
          },
          "level_002": {
            "a": 690704,
            "b": "PDTOKES",
            "e": [
              ",DEPOT",
              "B,OPTED",
              ",PESTO",
              ",POKED",
              ",POSED",
              ",SPOKE",
              ",STOKE",
              ",DESKTOP"
            ]
          },
          "level_003": {
            "a": 690693,
            "b": "KLIDE",
            "e": [
              ",ELK",
              ",ILK",
              ",KID",
              ",LED",
              ",LID",
              ",LIE",
              ",DELI",
              ",DIKE",
              ",IDLE",
              ",LIED",
              ",LIKE"
            ]
          },
          "level_004": {
            "a": 690702,
            "b": "XMSIPLE",
            "e": [
              ",ISLE",
              ",LIME",
              ",LIMP",
              ",LISP",
              ",MILE",
              ",PILE",
              ",SEMI",
              ",SLIM",
              ",SLIP",
              ",SIMPLE",
              ",SIMPLEX"
            ]
          },
          "level_005": {
            "a": 690701,
            "b": "UKSPN",
            "e": [
              ",PUN",
              ",PUS",
              ",SUN",
              ",SUP",
              ",UPS",
              ",PUNK",
              "B,SPUN",
              ",SUNK",
              ",SPUNK"
            ]
          },
          "level_006": {
            "a": 690695,
            "b": "ESRBUOC",
            "e": [
              ",CURSE",
              ",ROUSE",
              ",SCORE",
              ",SCOUR",
              ",SCRUB",
              ",SOBER",
              ",COURSE",
              ",SOURCE",
              ",OBSCURE"
            ]
          },
          "level_007": {
            "a": 690692,
            "b": "LTREA",
            "e": [
              ",EARL",
              ",LATE",
              ",RATE",
              ",REAL",
              ",TALE",
              ",TEAL",
              ",TEAR",
              ",ALERT",
              ",ALTER",
              ",LATER"
            ]
          },
          "level_008": {
            "a": 690700,
            "b": "SEDIRUN",
            "e": [
              ",DINER",
              ",DRIES",
              ",INURE",
              ",NURSE",
              ",RESIN",
              ",RINSE",
              ",RISEN",
              ",SIREN",
              ",SNIDE",
              ",UNDER"
            ]
          },
          "level_009": {
            "a": 690707,
            "b": "CKNBOE",
            "e": [
              ",BECK",
              "B,BONE",
              ",BONK",
              ",COKE",
              ",CONE",
              ",KNOB",
              ",NECK",
              ",ONCE"
            ]
          },
          "level_010": {
            "a": 690691,
            "b": "RYBEBIR",
            "e": [
              ",BRIE",
              ",BERRY",
              "B,BRIBE",
              ",BRIBERY"
            ]
          },
          "level_011": {
            "a": 690703,
            "b": "OINIMSS",
            "e": [
              ",ION",
              ",SIM",
              ",SIN",
              ",SIS",
              ",SON",
              ",MISSION"
            ]
          },
          "level_012": {
            "a": 690696,
            "b": "JNEKUT",
            "e": [
              ",JET",
              ",JUT",
              ",NET",
              ",NUT",
              ",TEN",
              ",JUKE",
              ",JUNK",
              ",NUKE",
              ",TUNE",
              ",JUNKET"
            ]
          },
          "level_013": {
            "a": 690699,
            "b": "UOONCL",
            "e": [
              ",CON",
              ",COO",
              ",COLON",
              ",UNCOOL"
            ]
          },
          "level_014": {
            "a": 690690,
            "b": "OGLILRA",
            "e": [
              ",GALL",
              ",GILL",
              ",GIRL",
              ",GOAL",
              ",LAIR",
              ",LIAR",
              ",ORAL",
              ",RAIL",
              ",ROIL",
              ",ROLL",
              ",GORILLA"
            ]
          },
          "level_015": {
            "a": 690705,
            "b": "OMWB",
            "e": [
              ",BOW",
              ",MOB",
              ",MOW",
              ",WOMB"
            ]
          },
          "level_016": {
            "a": 690688,
            "b": "TTOPACO",
            "e": [
              ",ATOP",
              ",COAT",
              ",COOP",
              ",COOT",
              ",PACT",
              ",TACO",
              ",TACT",
              ",TOOT",
              ",POTATO",
              ",TOPCOAT"
            ]
          },
          "level_017": {
            "a": 690694,
            "b": "CMAIUSL",
            "e": [
              ",CLAIM",
              "B,MUSIC",
              ",SUMAC",
              ",MUSICAL"
            ]
          },
          "level_018": {
            "a": 690706,
            "b": "IOFRPF",
            "e": [
              ",FIR",
              ",FOR",
              ",FRO",
              ",OFF",
              ",PRO",
              ",RIP",
              ",RIFF",
              ",RIPOFF"
            ]
          },
          "level_019": {
            "a": 690689,
            "b": "BKLAN",
            "e": [
              ",BAN",
              ",LAB",
              ",NAB",
              ",BLANK"
            ]
          },
          "level_020": {
            "a": 690698,
            "b": "ITNEGLE",
            "e": [
              ",ELITE",
              ",GENIE",
              ",GLINT",
              ",INLET",
              ",LEGIT",
              ",TINGE",
              ",GENTLE",
              ",TEEING",
              ",TINGLE"
            ]
          }
        },
        "m": 5308557,
        "o": 16738922,
        "r": 5308557,
        "t": 0.65,
        "v": 8126683,
        "y": 0.65
      }
    }
  },
  "WS 25": {
    "a": "TROPIC",
    "b": "grad_white",
    "c": "grp_tropic",
    "d": 1,
    "e": 16763153,
    "f": 16711476,
    "g": 2451,
    "h": 147,
    "i": true,
    "j": 0.45,
    "sets": {
      "set_1": {
        "a": "SHORE",
        "aa": 16763153,
        "cc": 204947,
        "d": "bg_tropical1.jpg",
        "dd": 16763153,
        "e": 0.1,
        "ee": 204947,
        "g": 0.93,
        "i": 204947,
        "j": 16763153,
        "k": 204947,
        "l": 16763153,
        "levels": {
          "level_001": {
            "a": 690855,
            "b": "NBRIWAO",
            "e": [
              ",BARN",
              "B,BOAR",
              ",BORN",
              ",BRAN",
              ",BROW",
              ",IRON",
              ",RAIN",
              ",ROAN",
              ",WARN",
              ",WORN"
            ]
          },
          "level_002": {
            "a": 690854,
            "b": "OSCRUP",
            "e": [
              ",COUP",
              ",CROP",
              ",CUSP",
              ",OPUS",
              ",POUR",
              ",SOUP",
              ",SOUR",
              ",SPUR",
              ",CORPUS"
            ]
          },
          "level_003": {
            "a": 690849,
            "b": "ARPLEC",
            "e": [
              ",CAPER",
              ",CLEAR",
              ",PALER",
              ",PEARL",
              ",PLACE",
              ",RECAP",
              ",PARCEL"
            ]
          },
          "level_004": {
            "a": 690859,
            "b": "CHLCEAN",
            "e": [
              ",CACHE",
              ",CLEAN",
              ",LANCE",
              ",LEACH",
              ",CANCEL",
              ",CHANCE",
              ",CLENCH",
              ",CHANCEL"
            ]
          },
          "level_005": {
            "a": 690850,
            "b": "EABVR",
            "e": [
              ",ARE",
              ",BAR",
              ",BRA",
              ",EAR",
              ",ERA",
              ",BARE",
              ",BEAR",
              ",RAVE",
              ",VERB",
              ",BRAVE"
            ]
          },
          "level_006": {
            "a": 690860,
            "b": "NATDEHS",
            "e": [
              ",ASHEN",
              ",DEATH",
              ",HASTE",
              ",HATED",
              ",SATED",
              ",SEDAN",
              ",SHADE",
              ",STAND",
              ",STEAD",
              ",HASTEN",
              ",HANDSET"
            ]
          },
          "level_007": {
            "a": 690847,
            "b": "ECVDA",
            "e": [
              ",ACE",
              ",CAD",
              ",VAC",
              ",ACED",
              ",CAVE"
            ]
          },
          "level_008": {
            "a": 690858,
            "b": "DEECADC",
            "e": [
              ",CEDED",
              ",ACCEDE",
              "B,DECADE",
              ",ACCEDED"
            ]
          },
          "level_009": {
            "a": 690843,
            "b": "ESOWRC",
            "e": [
              ",CORE",
              ",CREW",
              ",CROW",
              ",ROSE",
              ",SORE",
              ",WORE"
            ]
          },
          "level_010": {
            "a": 690846,
            "b": "RPONVE",
            "e": [
              ",NOPE",
              ",OPEN",
              ",OVEN",
              ",OVER",
              ",PEON",
              ",PORE",
              ",REPO",
              ",ROPE",
              ",ROVE",
              ",PROVEN"
            ]
          },
          "level_011": {
            "a": 690851,
            "b": "RTIUCCI",
            "e": [
              ",CUR",
              "B,CUT",
              ",RUT",
              ",TIC",
              ",CRITIC"
            ]
          },
          "level_012": {
            "a": 690842,
            "b": "METSANY",
            "e": [
              ",ANTSY",
              ",MEANT",
              ",MEATY",
              ",NASTY",
              ",SEAMY",
              ",STEAM",
              ",YEAST",
              ",STEAMY",
              ",AMNESTY"
            ]
          },
          "level_013": {
            "a": 690848,
            "b": "NRGID",
            "e": [
              ",DIG",
              ",DIN",
              ",GIN",
              ",RID",
              ",RIG",
              ",DING",
              "B,GRID",
              ",GRIN",
              ",RIND",
              ",RING",
              ",GRIND"
            ]
          },
          "level_014": {
            "a": 690845,
            "b": "STAYHAR",
            "e": [
              ",ARTY",
              "B,ASHY",
              ",HART",
              ",RASH",
              ",STAR",
              ",STAY",
              ",TRAY",
              ",ASHTRAY"
            ]
          },
          "level_015": {
            "a": 690861,
            "b": "OOILP",
            "e": [
              ",LOOP",
              "B,POLO",
              ",POOL",
              ",POLIO"
            ]
          },
          "level_016": {
            "a": 690852,
            "b": "UGHRTO",
            "e": [
              ",GOTH",
              ",GOUT",
              ",HOUR",
              ",HURT",
              ",ROUT",
              ",THOU",
              ",THRU",
              ",THUG",
              ",TOUR",
              ",TROUGH"
            ]
          },
          "level_017": {
            "a": 690856,
            "b": "OSITNEC",
            "e": [
              ",INSECT",
              ",NICEST",
              ",NOTICE",
              ",SECTION"
            ]
          },
          "level_018": {
            "a": 690844,
            "b": "DMREUE",
            "e": [
              ",DUE",
              ",EMU",
              ",MUD",
              ",RED",
              ",REM",
              ",RUE",
              ",RUM",
              ",DEMURE"
            ]
          },
          "level_019": {
            "a": 690853,
            "b": "TLYLE",
            "e": [
              ",LET",
              ",LYE",
              ",YET",
              ",TELL",
              ",YELL",
              ",TELLY"
            ]
          },
          "level_020": {
            "a": 690857,
            "b": "BEADBLD",
            "e": [
              ",ABLE",
              ",BABE",
              ",BADE",
              ",BALD",
              ",BALE",
              ",BEAD",
              ",BLED",
              ",DALE",
              ",DEAD",
              ",DEAL",
              ",LEAD",
              ",DABBLED"
            ]
          }
        },
        "m": 10586447,
        "o": 32511,
        "r": 7757884,
        "t": 0.7000000000000001,
        "u": 16777211,
        "v": 16763153,
        "x": 204947,
        "y": 0.7000000000000001,
        "z": 16777211
      },
      "set_2": {
        "a": "FROND",
        "aa": 16700953,
        "cc": 204947,
        "d": "bg_tropical2.jpg",
        "dd": 16700953,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16700953,
        "k": 204947,
        "l": 16700953,
        "levels": {
          "level_001": {
            "a": 691037,
            "b": "IECYPR",
            "e": [
              ",EPIC",
              "B,PIER",
              ",PREY",
              ",PYRE",
              ",RICE",
              ",RIPE",
              ",PRICE",
              ",PRICEY"
            ]
          },
          "level_002": {
            "a": 691041,
            "b": "TNISTOA",
            "e": [
              ",SAINT",
              "B,SATIN",
              ",STAIN",
              ",STINT",
              ",TAINT",
              ",TITAN",
              ",TOAST",
              ",STATION"
            ]
          },
          "level_003": {
            "a": 691042,
            "b": "TMAET",
            "e": [
              ",ATE",
              ",EAT",
              ",MAT",
              ",MET",
              ",TEA",
              ",MATE",
              ",MEAT",
              ",TAME",
              ",TEAM"
            ]
          },
          "level_004": {
            "a": 691028,
            "b": "NCEOUTR",
            "e": [
              ",COUNT",
              ",COURT",
              ",CRONE",
              ",CUTER",
              ",OUNCE",
              ",OUTER",
              ",RECON",
              ",ROUTE",
              ",TENOR",
              ",TONER",
              ",TRUCE",
              ",TUNER"
            ]
          },
          "level_005": {
            "a": 691047,
            "b": "UOISTD",
            "e": [
              ",DOT",
              ",DUO",
              ",ITS",
              ",OUT",
              ",SIT",
              ",SOD",
              ",TIS",
              ",DUST",
              "B,OUST",
              ",STUD",
              ",SUIT",
              ",STUDIO"
            ]
          },
          "level_006": {
            "a": 691031,
            "b": "NVELNEI",
            "e": [
              ",EEL",
              ",EVE",
              ",INN",
              ",LIE",
              ",NIL",
              ",VIE",
              ",LINEN",
              "B,LIVEN"
            ]
          },
          "level_007": {
            "a": 691044,
            "b": "NECDTE",
            "e": [
              ",DEN",
              ",END",
              ",NET",
              ",TEE",
              ",TEN",
              ",CEDE",
              "B,CENT",
              ",DENT",
              ",NEED",
              ",TEEN",
              ",TEND",
              ",DECENT"
            ]
          },
          "level_008": {
            "a": 691036,
            "b": "EEIDRRF",
            "e": [
              ",DEFER",
              ",DRIER",
              ",ERRED",
              ",FIRED",
              ",FREED",
              ",FREER",
              ",FRIED",
              ",REFER",
              ",RIDER"
            ]
          },
          "level_009": {
            "a": 691035,
            "b": "OLRWD",
            "e": [
              ",DOW",
              ",LOW",
              ",OLD",
              ",OWL",
              ",ROD",
              ",ROW",
              ",LORD",
              ",WORD"
            ]
          },
          "level_010": {
            "a": 691038,
            "b": "IVASSEM",
            "e": [
              ",MESA",
              ",MESS",
              ",SAME",
              ",SAVE",
              ",SEAM",
              ",SEMI",
              ",VASE",
              ",VISA",
              ",VISE"
            ]
          },
          "level_011": {
            "a": 691034,
            "b": "VLHEA",
            "e": [
              ",HAVE",
              "B,HEAL",
              ",VALE",
              ",VEAL",
              ",HALVE"
            ]
          },
          "level_012": {
            "a": 691030,
            "b": "ZIGYTL",
            "e": [
              ",GIT",
              ",LIT",
              ",TIL",
              ",ZIG",
              ",ZIT",
              ",GLITZ",
              ",GLITZY"
            ]
          },
          "level_013": {
            "a": 691046,
            "b": "AORTT",
            "e": [
              ",ART",
              ",OAR",
              ",OAT",
              ",RAT",
              ",ROT",
              ",TAR",
              ",TOT",
              ",TART",
              ",TORT",
              ",TROT"
            ]
          },
          "level_014": {
            "a": 691045,
            "b": "WRROOM",
            "e": [
              ",MOOR",
              ",ROOM",
              ",WORM",
              ",MORROW"
            ]
          },
          "level_015": {
            "a": 691043,
            "b": "EGNERE",
            "e": [
              ",GENE",
              ",GENRE",
              ",GREEN",
              ",RENEGE"
            ]
          },
          "level_016": {
            "a": 691039,
            "b": "ERUDTEP",
            "e": [
              ",DETER",
              ",ERUPT",
              ",PRUDE",
              ",PUREE",
              ",PUREED",
              ",REPUTE",
              ",ERUPTED",
              ",REPUTED"
            ]
          },
          "level_017": {
            "a": 691029,
            "b": "SPYEEL",
            "e": [
              ",ELSE",
              ",PEEL",
              ",SEEP",
              ",YELP",
              ",SLEEP"
            ]
          },
          "level_018": {
            "a": 691032,
            "b": "PDILLA",
            "e": [
              ",DIAL",
              ",DILL",
              ",LAID",
              ",PAID",
              ",PAIL",
              ",PALL",
              ",PILL",
              ",PALLID"
            ]
          },
          "level_019": {
            "a": 691033,
            "b": "YEKRFA",
            "e": [
              ",FAKE",
              ",FARE",
              ",FEAR",
              ",FRAY",
              ",RAKE",
              ",YEAR",
              ",FAKER",
              ",FREAK",
              ",FREAKY"
            ]
          },
          "level_020": {
            "a": 691040,
            "b": "DLOCEDD",
            "e": [
              ",CLOD",
              ",CODE",
              ",COED",
              ",COLD",
              ",DOLE",
              ",LODE",
              ",CODED",
              ",DOLED"
            ]
          }
        },
        "m": 10386765,
        "o": 32511,
        "r": 9730909,
        "t": 0.7000000000000001,
        "v": 16700953,
        "x": 204947,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "PALM",
        "aa": 16704546,
        "cc": 204947,
        "d": "bg_tropical3.jpg",
        "dd": 16704546,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16704546,
        "k": 204947,
        "l": 16704546,
        "levels": {
          "level_001": {
            "a": 691215,
            "b": "MRSAASC",
            "e": [
              ",ARC",
              ",ARM",
              ",CAM",
              ",CAR",
              ",MAR",
              ",RAM",
              ",SAC",
              ",SARCASM"
            ]
          },
          "level_002": {
            "a": 691205,
            "b": "ICRALAN",
            "e": [
              ",CLAN",
              ",LAIN",
              ",LAIR",
              ",LIAR",
              ",NAIL",
              ",RAIL",
              ",RAIN",
              ",CRANIAL"
            ]
          },
          "level_003": {
            "a": 691212,
            "b": "ICMPH",
            "e": [
              ",CHI",
              ",HIM",
              ",HIP",
              ",IMP",
              ",PHI",
              ",PIC",
              ",CHIP",
              ",CHIMP"
            ]
          },
          "level_004": {
            "a": 691207,
            "b": "FTESLTI",
            "e": [
              ",FILET",
              ",FLIES",
              ",ISLET",
              ",STILT",
              ",TITLE",
              ",ITSELF",
              ",STIFLE",
              ",LEFTIST"
            ]
          },
          "level_005": {
            "a": 691202,
            "b": "VYEON",
            "e": [
              ",ONE",
              ",YEN",
              ",YON",
              ",ENVOY"
            ]
          },
          "level_006": {
            "a": 691216,
            "b": "NFAETSS",
            "e": [
              ",ASSENT",
              "B,FASTEN",
              ",SAFEST",
              ",FATNESS"
            ]
          },
          "level_007": {
            "a": 691201,
            "b": "HPASSL",
            "e": [
              ",ASH",
              ",ASP",
              ",HAS",
              ",LAP",
              ",PAL",
              ",SAP",
              ",SPA",
              ",LASH",
              ",SASH",
              ",SLAP",
              ",SPLASH"
            ]
          },
          "level_008": {
            "a": 691203,
            "b": "WLFYTSI",
            "e": [
              ",FIST",
              "B,FLIT",
              ",LIFT",
              ",LIST",
              ",SIFT",
              ",SILT",
              ",SLIT",
              ",WILT",
              ",WILY",
              ",SWIFTLY"
            ]
          },
          "level_009": {
            "a": 691204,
            "b": "DINOCTU",
            "e": [
              ",COIN",
              ",DINT",
              ",DUCT",
              ",ICON",
              ",INTO",
              ",UNDO",
              ",UNIT",
              ",UNTO"
            ]
          },
          "level_010": {
            "a": 691208,
            "b": "REVRLYE",
            "e": [
              ",EVER",
              ",LEER",
              ",LEVY",
              ",LYRE",
              ",REEL",
              ",RELY",
              ",VEER",
              ",VERY"
            ]
          },
          "level_011": {
            "a": 691218,
            "b": "MOEHR",
            "e": [
              ",HEM",
              ",HER",
              ",HOE",
              ",OHM",
              ",ORE",
              ",REM",
              ",HERO",
              ",HOME",
              ",MORE",
              ",HOMER"
            ]
          },
          "level_012": {
            "a": 691217,
            "b": "ODESTUL",
            "e": [
              ",DOUSE",
              ",LOTUS",
              ",LOUSE",
              ",STOLE",
              ",LUSTED",
              ",OLDEST",
              ",OUSTED",
              ",LOUDEST",
              ",TOUSLED"
            ]
          },
          "level_013": {
            "a": 691209,
            "b": "AAGEGR",
            "e": [
              ",AGE",
              "B,ARE",
              ",EAR",
              ",EGG",
              ",ERA",
              ",GAG",
              ",RAG",
              ",GARAGE"
            ]
          },
          "level_014": {
            "a": 691211,
            "b": "LEMREDA",
            "e": [
              ",ALDER",
              ",ARMED",
              ",DREAM",
              ",ELDER",
              ",LAMED",
              ",MEDAL",
              ",REALM",
              ",EMERALD"
            ]
          },
          "level_015": {
            "a": 691210,
            "b": "UEOCNP",
            "e": [
              ",CONE",
              ",COPE",
              ",COUP",
              ",NOPE",
              ",ONCE",
              ",OPEN",
              ",PEON",
              ",UPON"
            ]
          },
          "level_016": {
            "a": 691219,
            "b": "GPOEERT",
            "e": [
              ",GORE",
              "B,OGRE",
              ",PEER",
              ",PERT",
              ",POET",
              ",PORE",
              ",PORT",
              ",REPO",
              ",ROPE",
              ",ROTE",
              ",TORE",
              ",TREE"
            ]
          },
          "level_017": {
            "a": 691213,
            "b": "TRNUB",
            "e": [
              ",BUN",
              ",BUT",
              ",NUB",
              ",NUT",
              ",RUB",
              ",RUN",
              ",RUT",
              ",TUB",
              ",URN",
              ",BRUNT",
              "B,BURNT"
            ]
          },
          "level_018": {
            "a": 691214,
            "b": "WNYRBA",
            "e": [
              ",AWRY",
              ",BARN",
              ",BRAN",
              ",NARY",
              ",WARN",
              ",WARY",
              ",YARN",
              ",YAWN",
              ",BRAWN"
            ]
          },
          "level_019": {
            "a": 691200,
            "b": "DBLAE",
            "e": [
              ",ALE",
              ",BAD",
              ",BED",
              ",DAB",
              ",LAB",
              ",LAD",
              ",LED",
              ",BLADE"
            ]
          },
          "level_020": {
            "a": 691206,
            "b": "DTNUEAD",
            "e": [
              ",DATED",
              ",TUNED",
              ",DAUNTED",
              "B,UNDATED"
            ]
          }
        },
        "m": 11174743,
        "o": 32511,
        "r": 9072707,
        "t": 0.75,
        "v": 16704546,
        "x": 204947,
        "y": 0.75
      },
      "set_4": {
        "a": "BEACH",
        "aa": 16707883,
        "bb": 16777215,
        "cc": 204947,
        "d": "bg_tropical4.jpg",
        "dd": 16707883,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16707883,
        "k": 204947,
        "l": 16707883,
        "levels": {
          "level_001": {
            "a": 691337,
            "b": "YCDTIIA",
            "e": [
              ",ACT",
              ",AID",
              ",CAD",
              ",CAT",
              ",CAY",
              ",DAY",
              ",ICY",
              ",TAD",
              ",TIC",
              ",ACID",
              ",CITY",
              ",TIDY"
            ]
          },
          "level_002": {
            "a": 691333,
            "b": "LARGADU",
            "e": [
              ",AURA",
              ",DRAG",
              ",DRUG",
              ",DUAL",
              ",GALA",
              ",GLAD",
              ",GRAD",
              ",LARD",
              ",LAUD",
              ",GRADUAL"
            ]
          },
          "level_003": {
            "a": 691326,
            "b": "EORLN",
            "e": [
              ",LONE",
              ",LORE",
              ",NOEL",
              ",ROLE"
            ]
          },
          "level_004": {
            "a": 691338,
            "b": "UNEDG",
            "e": [
              ",DUNE",
              "B,DUNG",
              ",NUDE",
              ",NUDGE"
            ]
          },
          "level_005": {
            "a": 691323,
            "b": "GUERFEE",
            "e": [
              ",FEE",
              ",FUR",
              ",GEE",
              ",REF",
              ",RUE",
              ",RUG",
              ",FREE",
              ",REEF",
              ",URGE",
              ",REFUGE",
              ",REFUGEE"
            ]
          },
          "level_006": {
            "a": 691331,
            "b": "GAVARE",
            "e": [
              ",AREA",
              "B,GAVE",
              ",GEAR",
              ",RAGE",
              ",RAVE",
              ",RAVAGE"
            ]
          },
          "level_007": {
            "a": 691327,
            "b": "DIPEW",
            "e": [
              ",DEW",
              ",DIP",
              ",PEW",
              ",PIE",
              ",WED",
              ",WIDE",
              ",WIPE",
              ",WIPED"
            ]
          },
          "level_008": {
            "a": 691322,
            "b": "NERORVU",
            "e": [
              ",EURO",
              ",OVEN",
              ",OVER",
              ",ROVE",
              ",RUNE",
              ",RERUN",
              ",ROVER",
              ",OVERRUN"
            ]
          },
          "level_009": {
            "a": 691329,
            "b": "ETRDI",
            "e": [
              ",DIET",
              ",DIRE",
              ",DIRT",
              ",EDIT",
              ",RIDE",
              ",RITE",
              ",TIDE",
              ",TIED",
              ",TIER",
              ",TIRE",
              ",TIRED",
              ",TRIED"
            ]
          },
          "level_010": {
            "a": 691324,
            "b": "YREDAIL",
            "e": [
              ",DEARLY",
              ",DERAIL",
              ",RAILED",
              ",READILY"
            ]
          },
          "level_011": {
            "a": 691340,
            "b": "LYALA",
            "e": [
              ",ALL",
              ",LAY",
              ",ALLY",
              ",ALLAY"
            ]
          },
          "level_012": {
            "a": 691334,
            "b": "OUIRST",
            "e": [
              ",OUST",
              ",RIOT",
              ",ROUT",
              ",RUST",
              ",SORT",
              ",SOUR",
              ",STIR",
              ",SUIT",
              ",TOUR",
              ",TRIO",
              ",SUITOR"
            ]
          },
          "level_013": {
            "a": 691330,
            "b": "RNIGW",
            "e": [
              ",GIN",
              ",RIG",
              ",WIG",
              ",WIN",
              ",GRIN",
              ",RING",
              ",WING",
              ",WRING"
            ]
          },
          "level_014": {
            "a": 691325,
            "b": "ASTOCM",
            "e": [
              ",ATOM",
              "B,CAMO",
              ",CAST",
              ",COAT",
              ",COMA",
              ",COST",
              ",MAST",
              ",MOAT",
              ",MOST",
              ",SCAM",
              ",TACO",
              ",MASCOT"
            ]
          },
          "level_015": {
            "a": 691341,
            "b": "OCAITRE",
            "e": [
              ",ACTOR",
              "B,CATER",
              ",CRATE",
              ",IRATE",
              ",RATIO",
              ",REACT",
              ",TRACE",
              ",EROTIC"
            ]
          },
          "level_016": {
            "a": 691339,
            "b": "YTNGHAU",
            "e": [
              ",AUNT",
              ",GNAT",
              ",HANG",
              ",HUNG",
              ",HUNT",
              ",TANG",
              ",THAN",
              ",THUG",
              ",TUNA",
              ",NAUGHT"
            ]
          },
          "level_017": {
            "a": 691336,
            "b": "QSISUH",
            "e": [
              ",HIS",
              ",SIS",
              ",SUSHI",
              ",SQUISH"
            ]
          },
          "level_018": {
            "a": 691328,
            "b": "PLOYRLA",
            "e": [
              ",ALLOY",
              ",LOYAL",
              ",POLAR",
              ",RALLY",
              ",ROYAL",
              ",ORALLY",
              "B,PALLOR",
              ",PAYROLL"
            ]
          },
          "level_019": {
            "a": 691335,
            "b": "WNOSH",
            "e": [
              ",HOW",
              "B,NOW",
              ",OWN",
              ",SON",
              ",SOW",
              ",WHO",
              ",WON",
              ",SHOWN"
            ]
          },
          "level_020": {
            "a": 691332,
            "b": "IUDCSS",
            "e": [
              ",CUSS",
              ",DISC",
              ",SCUD",
              ",SUDS",
              ",DISCUS"
            ]
          }
        },
        "m": 12025910,
        "o": 32511,
        "r": 7490864,
        "t": 0.35000000000000003,
        "u": 0,
        "v": 16707883,
        "w": 16777215,
        "x": 204947,
        "y": 0.35000000000000003,
        "z": 0
      },
      "set_5": {
        "a": "COAST",
        "aa": 16711476,
        "cc": 204947,
        "d": "bg_tropical5.jpg",
        "dd": 16711476,
        "e": 0.1,
        "ee": 204947,
        "i": 204947,
        "j": 16711476,
        "k": 204947,
        "l": 16711476,
        "levels": {
          "level_001": {
            "a": 691478,
            "b": "HRFEATR",
            "e": [
              ",FATHER",
              ",RAFTER",
              ",RATHER",
              ",FARTHER"
            ]
          },
          "level_002": {
            "a": 691461,
            "b": "LCATTE",
            "e": [
              ",LACE",
              ",LATE",
              ",TACT",
              ",TALC",
              ",TALE",
              ",TEAL",
              ",CLEAT",
              ",LATTE"
            ]
          },
          "level_003": {
            "a": 691474,
            "b": "BUUSLOB",
            "e": [
              ",BOB",
              ",BUS",
              ",LOB",
              ",SOB",
              ",SUB",
              ",BLOB",
              ",BULB",
              ",SLOB",
              ",SOUL"
            ]
          },
          "level_004": {
            "a": 691468,
            "b": "DILESD",
            "e": [
              ",DELI",
              ",DIED",
              ",IDLE",
              ",ISLE",
              ",LIED",
              ",SIDE",
              ",SLED",
              ",SLID",
              ",IDLED",
              ",SIDED",
              ",SLIDE",
              ",SIDLED"
            ]
          },
          "level_005": {
            "a": 691479,
            "b": "MSYMTPO",
            "e": [
              ",MOM",
              "B,MOP",
              ",OPS",
              ",OPT",
              ",POT",
              ",SOP",
              ",SOY",
              ",SPY",
              ",TOP",
              ",TOY",
              ",SYMPTOM"
            ]
          },
          "level_006": {
            "a": 691460,
            "b": "OARRCL",
            "e": [
              ",COAL",
              ",COLA",
              ",ORAL",
              ",ORCA",
              ",ROAR",
              ",CAROL",
              ",CORAL",
              ",CORRAL"
            ]
          },
          "level_007": {
            "a": 691465,
            "b": "NOBRI",
            "e": [
              ",BIN",
              ",BIO",
              ",BRO",
              ",ION",
              ",NOR",
              ",ORB",
              ",RIB",
              ",ROB",
              ",BORN",
              ",IRON"
            ]
          },
          "level_008": {
            "a": 691475,
            "b": "LTLHOAS",
            "e": [
              ",ATOLL",
              ",LOATH",
              ",SHALL",
              ",SHOAL",
              ",SLOTH",
              ",STALL",
              ",SHALLOT"
            ]
          },
          "level_009": {
            "a": 691463,
            "b": "SUAMEQ",
            "e": [
              ",MESA",
              "B,MUSE",
              ",SAME",
              ",SEAM",
              ",AMUSE"
            ]
          },
          "level_010": {
            "a": 691466,
            "b": "METYSA",
            "e": [
              ",MEATY",
              "B,SEAMY",
              ",STEAM",
              ",YEAST",
              ",STEAMY"
            ]
          },
          "level_011": {
            "a": 691473,
            "b": "PHLAA",
            "e": [
              ",AAH",
              "B,AHA",
              ",LAP",
              ",PAL",
              ",ALPHA"
            ]
          },
          "level_012": {
            "a": 691464,
            "b": "OPRPTES",
            "e": [
              ",PESTO",
              ",PROSE",
              ",SPORE",
              ",SPORT",
              ",STORE",
              ",STREP",
              ",TROPE",
              ",POSTER",
              ",TOPPER"
            ]
          },
          "level_013": {
            "a": 691470,
            "b": "AMGYN",
            "e": [
              ",ANY",
              ",GYM",
              ",MAG",
              ",MAN",
              ",MAY",
              ",NAG",
              ",NAY",
              ",YAM",
              ",MANY"
            ]
          },
          "level_014": {
            "a": 691462,
            "b": "ETRFUON",
            "e": [
              ",FORTE",
              ",FRONT",
              ",FUTON",
              ",OFTEN",
              ",OUTER",
              ",ROUTE",
              ",TENOR",
              ",TONER",
              ",TUNER"
            ]
          },
          "level_015": {
            "a": 691477,
            "b": "TCEONI",
            "e": [
              ",CENT",
              ",CITE",
              ",COIN",
              ",CONE",
              ",ICON",
              ",INTO",
              ",NICE",
              ",NOTE",
              ",ONCE",
              ",TINE",
              ",TONE",
              ",TONIC"
            ]
          },
          "level_016": {
            "a": 691467,
            "b": "ATNCELR",
            "e": [
              ",ANTLER",
              ",CARTEL",
              ",CLARET",
              ",NECTAR",
              ",RECANT",
              ",RENTAL",
              ",TRANCE",
              ",CENTRAL"
            ]
          },
          "level_017": {
            "a": 691471,
            "b": "TTYRBEA",
            "e": [
              ",ARTY",
              ",BARE",
              ",BEAR",
              ",BEAT",
              ",BETA",
              ",BRAT",
              ",BYTE",
              ",RATE",
              ",TART",
              ",TEAR",
              ",TRAY",
              ",YEAR"
            ]
          },
          "level_018": {
            "a": 691476,
            "b": "ERIRVEE",
            "e": [
              ",ERR",
              ",EVE",
              ",IRE",
              ",VIE",
              ",EERIE",
              "B,RIVER",
              ",REVERE",
              ",REVERIE"
            ]
          },
          "level_019": {
            "a": 691472,
            "b": "TPIS",
            "e": [
              ",ITS",
              ",PIT",
              ",SIP",
              ",SIT",
              ",TIP",
              ",TIS",
              ",SPIT"
            ]
          },
          "level_020": {
            "a": 691469,
            "b": "SEADNLR",
            "e": [
              ",LANDER",
              ",SANDER",
              ",SNARED",
              ",SLANDER",
              "B,SNARLED"
            ]
          }
        },
        "m": 9793072,
        "o": 32511,
        "r": 9198123,
        "t": 0.7000000000000001,
        "v": 16711476,
        "x": 204947,
        "y": 0.7000000000000001
      }
    }
  },
  "WS 26": {
    "a": "SKY",
    "b": "grad_white",
    "c": "grp_sky",
    "d": 1,
    "e": 16669205,
    "f": 16755245,
    "sets": {
      "set_1": {
        "a": "WIND",
        "aa": 16669205,
        "d": "bg_sky1.jpg",
        "dd": 16669205,
        "e": 0.1,
        "j": 16669205,
        "l": 16669205,
        "levels": {
          "level_001": {
            "a": 691693,
            "b": "NATRBU",
            "e": [
              ",BRUNT",
              ",BURNT",
              ",URBAN",
              ",TURBAN"
            ]
          },
          "level_002": {
            "a": 691685,
            "b": "SDCIERU",
            "e": [
              ",CIDER",
              "B,CRIED",
              ",CRIES",
              ",CRUDE",
              ",CURED",
              ",CURSE",
              ",DRIES",
              ",CRUISED"
            ]
          },
          "level_003": {
            "a": 691694,
            "b": "NDSDEEC",
            "e": [
              ",CEDE",
              ",DEED",
              ",NEED",
              ",SEED",
              ",SEEN",
              ",SEND",
              ",CEDED",
              ",DENSE",
              ",ENDED",
              ",SCENE"
            ]
          },
          "level_004": {
            "a": 691687,
            "b": "NYGATR",
            "e": [
              ",ANGRY",
              ",GRANT",
              ",RANGY",
              ",TANGY",
              ",GANTRY"
            ]
          },
          "level_005": {
            "a": 691683,
            "b": "DODECL",
            "e": [
              ",COD",
              ",DOC",
              ",DOE",
              ",LED",
              ",ODD",
              ",ODE",
              ",OLD",
              ",CODDLE"
            ]
          },
          "level_006": {
            "a": 691686,
            "b": "NGERET",
            "e": [
              ",GENE",
              ",GENT",
              ",RENT",
              ",TEEN",
              ",TERN",
              ",TREE",
              ",EGRET",
              ",ENTER",
              ",GENRE",
              ",GREEN",
              ",GREET",
              ",REGENT"
            ]
          },
          "level_007": {
            "a": 691691,
            "b": "RLMCOA",
            "e": [
              ",ARC",
              "B,ARM",
              ",CAM",
              ",CAR",
              ",LAM",
              ",MAR",
              ",OAR",
              ",RAM",
              ",CLAMOR"
            ]
          },
          "level_008": {
            "a": 691697,
            "b": "ERTTO",
            "e": [
              ",ORE",
              ",ROT",
              ",TOE",
              ",TOT",
              ",ROTE",
              ",TORE",
              ",TORT",
              ",TOTE",
              ",TROT",
              ",OTTER",
              ",TORTE"
            ]
          },
          "level_009": {
            "a": 691699,
            "b": "NAMIEA",
            "e": [
              ",AMEN",
              ",MAIN",
              ",MANE",
              ",MEAN",
              ",MINE",
              ",NAME",
              ",ANEMIA"
            ]
          },
          "level_010": {
            "a": 691701,
            "b": "KUTMEPN",
            "e": [
              ",KEPT",
              "B,MENU",
              ",MUTE",
              ",NUKE",
              ",PENT",
              ",PUNK",
              ",PUNT",
              ",TEMP",
              ",TUNE",
              ",UNMET"
            ]
          },
          "level_011": {
            "a": 691688,
            "b": "TICUAY",
            "e": [
              ",ACT",
              "B,CAT",
              ",CAY",
              ",CUT",
              ",ICY",
              ",TAU",
              ",TIC",
              ",CITY"
            ]
          },
          "level_012": {
            "a": 691682,
            "b": "LRPEUY",
            "e": [
              ",LURE",
              ",LYRE",
              ",PREY",
              ",PURE",
              ",PYRE",
              ",RELY",
              ",RULE",
              ",YELP"
            ]
          },
          "level_013": {
            "a": 691689,
            "b": "SBIEED",
            "e": [
              ",BED",
              ",BEE",
              ",BID",
              ",SEE",
              ",BESIDE"
            ]
          },
          "level_014": {
            "a": 691696,
            "b": "AARYWDW",
            "e": [
              ",AWAY",
              ",AWRY",
              ",DRAW",
              ",WARD",
              ",WARY",
              ",YARD",
              ",AWARD",
              ",WAYWARD"
            ]
          },
          "level_015": {
            "a": 691692,
            "b": "FRWAE",
            "e": [
              ",ARE",
              ",AWE",
              ",EAR",
              ",ERA",
              ",FAR",
              ",FEW",
              ",RAW",
              ",REF",
              ",WAR",
              ",FARE",
              ",FEAR",
              ",WEAR"
            ]
          },
          "level_016": {
            "a": 691690,
            "b": "ECROUGA",
            "e": [
              ",ARGUE",
              ",AUGER",
              ",CARGO",
              ",GRACE",
              ",ROGUE",
              ",ROUGE",
              ",COUGAR",
              ",COURAGE"
            ]
          },
          "level_017": {
            "a": 691698,
            "b": "ETFA",
            "e": [
              ",AFT",
              ",ATE",
              ",EAT",
              ",FAT",
              ",TEA",
              ",FATE",
              "B,FEAT",
              ",FETA"
            ]
          },
          "level_018": {
            "a": 691700,
            "b": "SALNTU",
            "e": [
              ",AUNT",
              ",LAST",
              ",LUST",
              ",SALT",
              ",SLAT",
              ",STUN",
              ",TUNA",
              ",SLANT"
            ]
          },
          "level_019": {
            "a": 691684,
            "b": "OCPHE",
            "e": [
              ",COP",
              ",HOE",
              ",HOP",
              ",CHOP",
              ",COPE",
              ",ECHO",
              ",HOPE",
              ",EPOCH"
            ]
          },
          "level_020": {
            "a": 691695,
            "b": "XSSESEL",
            "e": [
              ",ELSE",
              "B,EXES",
              ",LESS",
              ",SEXES",
              ",SEXLESS"
            ]
          }
        },
        "m": 10629909,
        "o": 10113023,
        "t": 0.79,
        "v": 16669205,
        "y": 0.79
      },
      "set_2": {
        "a": "RAYS",
        "aa": 16674331,
        "d": "bg_sky2.jpg",
        "dd": 16674331,
        "e": 0.1,
        "j": 16674331,
        "l": 16674331,
        "levels": {
          "level_001": {
            "a": 691879,
            "b": "GELCAIN",
            "e": [
              ",AGILE",
              "B,ALIEN",
              ",ALIGN",
              ",ANGEL",
              ",ANGLE",
              ",CLANG",
              ",CLEAN",
              ",CLING",
              ",GLEAN",
              ",LANCE"
            ]
          },
          "level_002": {
            "a": 691886,
            "b": "ALERAV",
            "e": [
              ",AREA",
              ",EARL",
              ",LAVA",
              ",RAVE",
              ",REAL",
              ",VALE",
              ",VEAL",
              ",LARVA",
              ",RAVEL"
            ]
          },
          "level_003": {
            "a": 691889,
            "b": "YDREN",
            "e": [
              ",DEN",
              ",DRY",
              ",DYE",
              ",END",
              ",RED",
              ",RYE",
              ",YEN",
              ",DENY",
              "B,NERD",
              ",REND"
            ]
          },
          "level_004": {
            "a": 691895,
            "b": "EUAHGC",
            "e": [
              ",ACE",
              "B,AGE",
              ",CUE",
              ",HAG",
              ",HUE",
              ",HUG",
              ",UGH",
              ",GAUCHE"
            ]
          },
          "level_005": {
            "a": 691884,
            "b": "DGILRYI",
            "e": [
              ",GIRL",
              ",GRID",
              ",IDLY",
              ",RIGID"
            ]
          },
          "level_006": {
            "a": 691876,
            "b": "LILYANF",
            "e": [
              ",ALLY",
              ",FAIL",
              ",FALL",
              ",FILL",
              ",FLAN",
              ",FLAY",
              ",LAIN",
              ",LILY",
              ",NAIL"
            ]
          },
          "level_007": {
            "a": 691892,
            "b": "OCYSELL",
            "e": [
              ",COY",
              ",LYE",
              ",SLY",
              ",SOY",
              ",YES",
              ",CELLO",
              "B,CLOSE",
              ",SOLELY"
            ]
          },
          "level_008": {
            "a": 691885,
            "b": "RPAESNP",
            "e": [
              ",ASPEN",
              "B,PAPER",
              ",PARSE",
              ",SANER",
              ",SNARE",
              ",SPARE",
              ",SPEAR",
              ",SNAPPER"
            ]
          },
          "level_009": {
            "a": 691882,
            "b": "GIWGLE",
            "e": [
              ",EGG",
              "B,GEL",
              ",GIG",
              ",LEG",
              ",LIE",
              ",WIG",
              ",WIGGLE"
            ]
          },
          "level_010": {
            "a": 691881,
            "b": "SHRCTA",
            "e": [
              ",ARCH",
              ",CART",
              ",CASH",
              ",CAST",
              ",CHAR",
              ",CHAT",
              ",HART",
              ",RASH",
              ",SCAR",
              ",STAR",
              ",STARCH"
            ]
          },
          "level_011": {
            "a": 691877,
            "b": "OVILNI",
            "e": [
              ",LION",
              ",LOIN",
              ",VINO",
              ",VIOLIN"
            ]
          },
          "level_012": {
            "a": 691880,
            "b": "BBREBLU",
            "e": [
              ",EBB",
              ",RUB",
              ",RUE",
              ",BLUER",
              ",BLURB",
              ",RUBLE",
              ",BUBBLE",
              ",RUBBLE"
            ]
          },
          "level_013": {
            "a": 691887,
            "b": "BOACN",
            "e": [
              ",BAN",
              ",BOA",
              ",CAB",
              ",CAN",
              ",COB",
              ",CON",
              ",NAB",
              ",BACON"
            ]
          },
          "level_014": {
            "a": 691888,
            "b": "WNYKO",
            "e": [
              ",NOW",
              ",OWN",
              ",WOK",
              ",WON",
              ",YON",
              ",KNOW",
              ",WONK",
              ",WONKY"
            ]
          },
          "level_015": {
            "a": 691890,
            "b": "YETIHG",
            "e": [
              ",GET",
              ",GIT",
              ",HEY",
              ",HIT",
              ",THE",
              ",THY",
              ",TIE",
              ",YET",
              ",THEY",
              ",YETI",
              ",EIGHT"
            ]
          },
          "level_016": {
            "a": 691883,
            "b": "IKDCRRE",
            "e": [
              ",DECK",
              ",DICE",
              ",DIKE",
              ",DIRE",
              ",ICED",
              ",RICE",
              ",RIDE",
              ",DERRICK"
            ]
          },
          "level_017": {
            "a": 691891,
            "b": "YAEZLS",
            "e": [
              ",EASY",
              ",LAZY",
              ",SALE",
              ",SEAL",
              ",SLAY",
              ",ZEAL"
            ]
          },
          "level_018": {
            "a": 691894,
            "b": "TARTUEQ",
            "e": [
              ",RATE",
              ",TART",
              ",TAUT",
              ",TEAR",
              ",TRUE",
              ",QUART",
              ",TREAT",
              ",UTTER",
              ",QUARTET"
            ]
          },
          "level_019": {
            "a": 691893,
            "b": "UCNSK",
            "e": [
              ",SUN",
              ",SUCK",
              ",SUNK",
              ",SNUCK"
            ]
          },
          "level_020": {
            "a": 691878,
            "b": "SDIAVOW",
            "e": [
              ",AVID",
              ",DIVA",
              ",SAID",
              ",SODA",
              ",VISA",
              ",VOID",
              ",AVOID",
              ",DISAVOW"
            ]
          }
        },
        "m": 10629909,
        "o": 10113023,
        "t": 0.85,
        "v": 16674331,
        "y": 0.8
      },
      "set_3": {
        "a": "DUSK",
        "aa": 16679457,
        "d": "bg_sky3.jpg",
        "dd": 16679457,
        "e": 0.1,
        "j": 16679457,
        "l": 16679457,
        "levels": {
          "level_001": {
            "a": 692045,
            "b": "EIGNRO",
            "e": [
              ",GONE",
              ",GORE",
              ",GRIN",
              ",IRON",
              ",OGRE",
              ",REIN",
              ",RING",
              ",IGNORE",
              "B,REGION"
            ]
          },
          "level_002": {
            "a": 692059,
            "b": "USDISE",
            "e": [
              ",DUE",
              ",SIS",
              ",SUE",
              ",USE",
              ",SIDE",
              ",SUDS",
              ",SUED",
              ",USED",
              ",ISSUE",
              ",ISSUED"
            ]
          },
          "level_003": {
            "a": 692052,
            "b": "OBINTA",
            "e": [
              ",ANTI",
              ",BAIT",
              ",BOAT",
              ",INTO",
              ",IOTA"
            ]
          },
          "level_004": {
            "a": 692055,
            "b": "LSATOUT",
            "e": [
              ",ALT",
              ",LAT",
              ",LOT",
              ",OAT",
              ",OUT",
              ",SAT",
              ",TAU",
              ",TOT",
              ",LOTUS",
              "B,STOUT",
              ",TOAST",
              ",TOTAL"
            ]
          },
          "level_005": {
            "a": 692046,
            "b": "YITN",
            "e": [
              ",NIT",
              ",TIN",
              ",YIN",
              ",TINY"
            ]
          },
          "level_006": {
            "a": 692054,
            "b": "NHMINAU",
            "e": [
              ",AIM",
              ",HAM",
              ",HIM",
              ",HUM",
              ",INN",
              ",MAN",
              ",NAN",
              ",NUN",
              ",INHUMAN"
            ]
          },
          "level_007": {
            "a": 692047,
            "b": "PMORO",
            "e": [
              ",MOO",
              ",MOP",
              ",PRO",
              ",MOOR",
              ",POOR",
              ",PROM",
              ",ROMP",
              ",ROOM"
            ]
          },
          "level_008": {
            "a": 692051,
            "b": "ESCEIRD",
            "e": [
              ",CIDER",
              ",CREED",
              ",CRIED",
              ",CRIES",
              ",DRIES",
              ",SCREE",
              ",DESIRE",
              "B,RESIDE",
              ",DECRIES"
            ]
          },
          "level_009": {
            "a": 692044,
            "b": "SWAY",
            "e": [
              ",SAW",
              ",SAY",
              ",WAS",
              ",WAY",
              ",SWAY"
            ]
          },
          "level_010": {
            "a": 692048,
            "b": "TEAFRL",
            "e": [
              ",AFTER",
              "B,ALERT",
              ",ALTER",
              ",FERAL",
              ",FETAL",
              ",FLARE",
              ",LATER",
              ",FALTER"
            ]
          },
          "level_011": {
            "a": 692058,
            "b": "OHRTC",
            "e": [
              ",COT",
              "B,HOT",
              ",ROT",
              ",TORCH"
            ]
          },
          "level_012": {
            "a": 692057,
            "b": "ERRSBEK",
            "e": [
              ",BEE",
              ",EEK",
              ",EKE",
              ",ERR",
              ",SEE",
              ",BEER",
              ",REEK",
              ",SEEK",
              ",SEER",
              ",BERSERK"
            ]
          },
          "level_013": {
            "a": 692056,
            "b": "EWATK",
            "e": [
              ",TAKE",
              ",TEAK",
              ",WAKE",
              ",WEAK"
            ]
          },
          "level_014": {
            "a": 692049,
            "b": "PKICLE",
            "e": [
              ",CLIP",
              ",EPIC",
              ",KELP",
              ",LICE",
              ",LICK",
              ",LIKE",
              ",PECK",
              ",PICK",
              ",PIKE",
              ",PILE",
              ",PICKLE"
            ]
          },
          "level_015": {
            "a": 692053,
            "b": "MOLRAA",
            "e": [
              ",ARM",
              ",LAM",
              ",MAR",
              ",OAR",
              ",RAM",
              ",LOAM",
              ",ORAL",
              ",ROAM"
            ]
          },
          "level_016": {
            "a": 692061,
            "b": "RIRBTUO",
            "e": [
              ",BOUT",
              ",BURR",
              ",RIOT",
              ",ROUT",
              ",TOUR",
              ",TRIO",
              ",BURRO",
              "B,ORBIT",
              ",TURBO",
              ",BURRITO"
            ]
          },
          "level_017": {
            "a": 692042,
            "b": "TUPSRDI",
            "e": [
              ",DIRT",
              ",DRIP",
              ",DUST",
              ",RUST",
              ",SPIT",
              ",SPUD",
              ",SPUR",
              ",STIR",
              ",STUD",
              ",SUIT",
              ",TRIP",
              ",DISRUPT"
            ]
          },
          "level_018": {
            "a": 692060,
            "b": "RMEPUFE",
            "e": [
              ",FREE",
              ",MERE",
              ",PEER",
              ",PERM",
              ",PURE",
              ",REEF",
              ",RUMP",
              ",PERFUME"
            ]
          },
          "level_019": {
            "a": 692043,
            "b": "ROODB",
            "e": [
              ",BOD",
              ",BOO",
              ",BRO",
              ",ORB",
              ",ROB",
              ",ROD",
              ",BROOD"
            ]
          },
          "level_020": {
            "a": 692050,
            "b": "IWPATRE",
            "e": [
              ",IRATE",
              ",TAPER",
              ",TRIPE",
              ",WATER",
              ",WIPER",
              ",WRITE",
              ",PIRATE",
              ",WAITER"
            ]
          }
        },
        "m": 12997665,
        "o": 14570594,
        "t": 0.81,
        "v": 16679457,
        "y": 0.81
      },
      "set_4": {
        "a": "CLOUD",
        "aa": 16684583,
        "d": "bg_sky4.jpg",
        "dd": 16684583,
        "e": 0.1,
        "f": 39167,
        "j": 16684583,
        "l": 16684583,
        "levels": {
          "level_001": {
            "a": 692229,
            "b": "ARCKT",
            "e": [
              ",ACT",
              ",ARC",
              ",ARK",
              ",ART",
              ",CAR",
              ",CAT",
              ",RAT",
              ",TAR",
              ",CART",
              ",RACK",
              ",TACK"
            ]
          },
          "level_002": {
            "a": 692227,
            "b": "OTCUMEO",
            "e": [
              ",COME",
              ",COOT",
              ",CUTE",
              ",MOOT",
              ",MOTE",
              ",MUTE",
              ",TOME",
              ",OUTCOME"
            ]
          },
          "level_003": {
            "a": 692218,
            "b": "DRTDNEO",
            "e": [
              ",DOTED",
              "B,DRONE",
              ",NOTED",
              ",ODDER",
              ",TENOR",
              ",TONED",
              ",TONER",
              ",TREND",
              ",TRODDEN"
            ]
          },
          "level_004": {
            "a": 692221,
            "b": "RUGEPOR",
            "e": [
              ",GROPE",
              ",GROUP",
              ",PURER",
              ",PURGE",
              ",ROGUE",
              ",ROUGE",
              ",GROUPER",
              "B,REGROUP"
            ]
          },
          "level_005": {
            "a": 692217,
            "b": "OYMBED",
            "e": [
              ",BODE",
              ",BODY",
              ",DEMO",
              ",DOME",
              ",MODE",
              ",OBEY"
            ]
          },
          "level_006": {
            "a": 692220,
            "b": "TCRDETA",
            "e": [
              ",CARTED",
              ",REDACT",
              ",TRACED",
              ",DETRACT"
            ]
          },
          "level_007": {
            "a": 692223,
            "b": "AAELG",
            "e": [
              ",AGE",
              ",ALE",
              ",GAL",
              ",GEL",
              ",LAG",
              ",LEG",
              ",GALA",
              ",GALE",
              ",ALGAE"
            ]
          },
          "level_008": {
            "a": 692225,
            "b": "CDOEORR",
            "e": [
              ",CODER",
              "B,COOED",
              ",CORED",
              ",CREDO",
              ",DECOR",
              ",ORDER",
              ",RODEO",
              ",CORRODE"
            ]
          },
          "level_009": {
            "a": 692230,
            "b": "OLELRH",
            "e": [
              ",HELL",
              ",HERO",
              ",HOLE",
              ",LORE",
              ",ROLE",
              ",ROLL"
            ]
          },
          "level_010": {
            "a": 692231,
            "b": "DELEMD",
            "e": [
              ",EEL",
              ",ELM",
              ",LED",
              ",DEED",
              ",DEEM",
              ",MELD",
              ",MEDDLE",
              "B,MELDED"
            ]
          },
          "level_011": {
            "a": 692219,
            "b": "DEUTLI",
            "e": [
              ",DELI",
              ",DIET",
              ",DUEL",
              ",DUET",
              ",EDIT",
              ",IDLE",
              ",LIED",
              ",LITE",
              ",LUTE",
              ",TIDE",
              ",TIED",
              ",TILE"
            ]
          },
          "level_012": {
            "a": 692224,
            "b": "DANORLI",
            "e": [
              ",ADORN",
              ",DRAIN",
              ",NODAL",
              ",RADIO",
              ",RADON",
              ",ORDAIN"
            ]
          },
          "level_013": {
            "a": 692228,
            "b": "GAOCNRI",
            "e": [
              ",ARCING",
              "B,CARING",
              ",RACING",
              ",ORGANIC"
            ]
          },
          "level_014": {
            "a": 692213,
            "b": "NTTPAE",
            "e": [
              ",ANTE",
              ",NAPE",
              ",NEAT",
              ",PANE",
              ",PANT",
              ",PATE",
              ",PEAT",
              ",PENT",
              ",TAPE",
              ",TENT"
            ]
          },
          "level_015": {
            "a": 692226,
            "b": "IONFCNE",
            "e": [
              ",COIN",
              ",CONE",
              ",FINE",
              ",ICON",
              ",INFO",
              ",NEON",
              ",NICE",
              ",NINE",
              ",NONE",
              ",ONCE",
              ",CONFINE"
            ]
          },
          "level_016": {
            "a": 692222,
            "b": "REROTT",
            "e": [
              ",ROTE",
              ",TORE",
              ",TORT",
              ",TOTE",
              ",TROT",
              ",OTTER",
              ",RETRO",
              ",TORTE"
            ]
          },
          "level_017": {
            "a": 692214,
            "b": "PRGMAAE",
            "e": [
              ",AGAPE",
              ",GAMER",
              ",GRAPE",
              ",PAGER"
            ]
          },
          "level_018": {
            "a": 692212,
            "b": "ONNOGIG",
            "e": [
              ",GOGO",
              ",GONG",
              ",GOON",
              ",NOON",
              ",GOING",
              ",ONION",
              ",NOGGIN",
              ",ONGOING"
            ]
          },
          "level_019": {
            "a": 692216,
            "b": "ORSHCU",
            "e": [
              ",CUR",
              ",OUR",
              ",HOUR",
              ",OUCH",
              ",RUSH",
              ",SOUR",
              ",SUCH",
              ",CRUSH",
              ",SCOUR",
              ",CHORUS"
            ]
          },
          "level_020": {
            "a": 692215,
            "b": "LEEVSIR",
            "e": [
              ",ELVES",
              "B,LEVER",
              ",LIVER",
              ",REVEL",
              ",SERVE",
              ",SEVER",
              ",SIEVE",
              ",VERSE",
              ",SERVILE"
            ]
          }
        },
        "m": 12997665,
        "o": 39167,
        "t": 0.8300000000000001,
        "v": 16684583,
        "y": 0.8300000000000001
      },
      "set_5": {
        "a": "SUN",
        "aa": 16755245,
        "bb": 16777215,
        "d": "bg_sky5.jpg",
        "dd": 16755245,
        "e": 0.1,
        "f": 109,
        "j": 16755245,
        "l": 16755245,
        "levels": {
          "level_001": {
            "a": 692388,
            "b": "ROLDO",
            "e": [
              ",DOOR",
              ",LORD",
              ",ODOR",
              ",DROOL"
            ]
          },
          "level_002": {
            "a": 692400,
            "b": "GISSAN",
            "e": [
              ",GAS",
              ",GIN",
              ",NAG",
              ",SAG",
              ",SIN",
              ",SIS",
              ",GAIN",
              "B,SANG",
              ",SIGN",
              ",SING",
              ",SNAG"
            ]
          },
          "level_003": {
            "a": 692401,
            "b": "EVREY",
            "e": [
              ",EVER",
              ",VEER",
              ",VERY",
              ",EVERY"
            ]
          },
          "level_004": {
            "a": 692399,
            "b": "LEGBBO",
            "e": [
              ",BLOB",
              ",BLOG",
              ",GLOB",
              ",LOBE",
              ",OGLE",
              ",GLOBE",
              ",GOBBLE"
            ]
          },
          "level_005": {
            "a": 692397,
            "b": "KUYCPL",
            "e": [
              ",CUP",
              ",PLY",
              ",YUP",
              ",LUCK",
              ",PUCK",
              ",YUCK",
              ",LUCKY",
              "B,PLUCK"
            ]
          },
          "level_006": {
            "a": 692402,
            "b": "EWCRMEN",
            "e": [
              ",EWE",
              ",MEN",
              ",NEW",
              ",REM",
              ",WEE",
              ",CREW",
              ",MERE",
              ",WERE",
              ",WREN",
              ",CREME",
              ",NEWER",
              ",RENEW"
            ]
          },
          "level_007": {
            "a": 692403,
            "b": "RTEHE",
            "e": [
              ",HER",
              ",TEE",
              ",THE",
              ",HERE",
              "B,THEE",
              ",TREE"
            ]
          },
          "level_008": {
            "a": 692394,
            "b": "NTAUOIM",
            "e": [
              ",AMINO",
              ",MOUNT",
              ",AMOUNT",
              ",MANITOU"
            ]
          },
          "level_009": {
            "a": 692389,
            "b": "LNGETCE",
            "e": [
              ",CENT",
              ",GENE",
              ",GENT",
              ",GLEE",
              ",GLEN",
              ",LENT",
              ",TEEN",
              ",GENTLE"
            ]
          },
          "level_010": {
            "a": 692398,
            "b": "OBSAT",
            "e": [
              ",ABS",
              ",BAS",
              ",BAT",
              ",BOA",
              ",BOT",
              ",OAT",
              ",SAT",
              ",SOB",
              ",TAB",
              ",BOAT",
              ",STAB"
            ]
          },
          "level_011": {
            "a": 692395,
            "b": "NERSYT",
            "e": [
              ",NET",
              ",RYE",
              ",SET",
              ",TEN",
              ",TRY",
              ",YEN",
              ",YES",
              ",YET",
              ",SENTRY"
            ]
          },
          "level_012": {
            "a": 692391,
            "b": "LOWIWYL",
            "e": [
              ",LILY",
              ",OILY",
              ",WILL",
              ",WILY",
              ",YOWL",
              ",LOWLY",
              ",WILLOW",
              ",WILLOWY"
            ]
          },
          "level_013": {
            "a": 692392,
            "b": "ERNWDI",
            "e": [
              ",DINER",
              ",WEIRD",
              ",WIDEN",
              ",WIDER",
              ",WIRED"
            ]
          },
          "level_014": {
            "a": 692396,
            "b": "ISTL",
            "e": [
              ",ITS",
              ",LIT",
              ",SIT",
              ",TIL",
              ",TIS",
              ",LIST",
              ",SILT",
              ",SLIT"
            ]
          },
          "level_015": {
            "a": 692390,
            "b": "SFELIMH",
            "e": [
              ",FILE",
              "B,FILM",
              ",FISH",
              ",HELM",
              ",ISLE",
              ",LIFE",
              ",LIME",
              ",MESH",
              ",MILE",
              ",SELF",
              ",SEMI",
              ",SLIM"
            ]
          },
          "level_016": {
            "a": 692387,
            "b": "CEIPSO",
            "e": [
              ",COP",
              ",ICE",
              ",OPS",
              ",PIC",
              ",PIE",
              ",SIP",
              ",SOP",
              ",COPSE",
              "B,POISE",
              ",SCOPE",
              ",SPICE"
            ]
          },
          "level_017": {
            "a": 692393,
            "b": "RUDEASC",
            "e": [
              ",CADRE",
              "B,CARED",
              ",CAUSE",
              ",CEDAR",
              ",CRUDE",
              ",CURED",
              ",CURSE",
              ",RACED",
              ",SAUCE",
              ",SCARE"
            ]
          },
          "level_018": {
            "a": 692385,
            "b": "FTORSIL",
            "e": [
              ",FIRST",
              ",FLIRT",
              ",FROST",
              ",FLORIST"
            ]
          },
          "level_019": {
            "a": 692386,
            "b": "REFID",
            "e": [
              ",FED",
              ",FIR",
              ",IRE",
              ",RED",
              ",REF",
              ",RID",
              ",FIRED",
              ",FRIED"
            ]
          },
          "level_020": {
            "a": 692384,
            "b": "IDHAYNL",
            "e": [
              ",DIAL",
              ",HAIL",
              ",HAND",
              ",HIND",
              ",IDLY",
              ",LADY",
              ",LAID",
              ",LAIN",
              ",LAND",
              ",NAIL",
              ",HANDILY"
            ]
          }
        },
        "m": 12997665,
        "o": 14831615,
        "t": 0.5,
        "u": 0,
        "v": 16755245,
        "w": 16777215,
        "y": 0.5,
        "z": 0
      }
    }
  },
  "WS 27": {
    "a": "CANYON",
    "b": "grad_white",
    "c": "grp_canyon",
    "d": 0.9500000000000001,
    "e": 14286931,
    "f": 13893632,
    "sets": {
      "set_1": {
        "a": "RAVINE",
        "aa": 14286931,
        "d": "bg_canyon1.jpg",
        "dd": 14286931,
        "e": 0.2,
        "j": 14286931,
        "l": 14286931,
        "levels": {
          "level_001": {
            "a": 692594,
            "b": "TSEAF",
            "e": [
              ",EAST",
              "B,FAST",
              ",FATE",
              ",FEAT",
              ",FETA",
              ",SAFE",
              ",SEAT",
              ",FEAST"
            ]
          },
          "level_002": {
            "a": 692591,
            "b": "EDIITD",
            "e": [
              ",DID",
              ",TIE",
              ",DIED",
              "B,DIET",
              ",EDIT",
              ",TIDE",
              ",TIED",
              ",TIDIED"
            ]
          },
          "level_003": {
            "a": 692596,
            "b": "HPSEA",
            "e": [
              ",APE",
              ",ASH",
              ",ASP",
              ",HAS",
              ",PEA",
              ",SAP",
              ",SEA",
              ",SHE",
              ",SPA",
              ",HEAP"
            ]
          },
          "level_004": {
            "a": 692590,
            "b": "MYSDEIT",
            "e": [
              ",DEITY",
              ",DITSY",
              ",MIDST",
              ",MISTY",
              ",SITED",
              ",TIMED",
              ",STYMIE",
              ",STYMIED"
            ]
          },
          "level_005": {
            "a": 692578,
            "b": "ITNUTIO",
            "e": [
              ",ION",
              ",NIT",
              ",NOT",
              ",NUT",
              ",OUT",
              ",TIN",
              ",TON",
              ",TOT",
              ",TUITION"
            ]
          },
          "level_006": {
            "a": 692585,
            "b": "HHAA",
            "e": [
              ",AAH",
              ",AHA",
              ",HAH",
              ",HAHA"
            ]
          },
          "level_007": {
            "a": 692586,
            "b": "BGARE",
            "e": [
              ",AGE",
              ",ARE",
              ",BAG",
              ",BAR",
              ",BEG",
              ",BRA",
              ",EAR",
              ",ERA",
              ",RAG",
              ",BARGE"
            ]
          },
          "level_008": {
            "a": 692581,
            "b": "MPOEIDL",
            "e": [
              ",LOPED",
              ",MODEL",
              ",MOPED",
              ",OILED",
              ",PILED",
              ",PLIED",
              ",DIMPLE",
              "B,LIMPED",
              ",IMPLODE"
            ]
          },
          "level_009": {
            "a": 692589,
            "b": "IESMED",
            "e": [
              ",DIM",
              ",MID",
              ",SEE",
              ",SIM",
              ",DEMISE"
            ]
          },
          "level_010": {
            "a": 692584,
            "b": "RAPCH",
            "e": [
              ",ARC",
              ",CAP",
              ",CAR",
              ",PAR",
              ",RAP",
              ",ARCH",
              "B,CARP",
              ",CHAP",
              ",CHAR",
              ",HARP"
            ]
          },
          "level_011": {
            "a": 692587,
            "b": "OECCLNA",
            "e": [
              ",ACE",
              ",ALE",
              ",CAN",
              ",CON",
              ",ONE",
              ",ALONE",
              "B,CANOE",
              ",CLEAN",
              ",CLONE",
              ",LANCE",
              ",OCEAN",
              ",CANCEL"
            ]
          },
          "level_012": {
            "a": 692597,
            "b": "LALPGO",
            "e": [
              ",GALL",
              "B,GOAL",
              ",OPAL",
              ",PALL",
              ",POLL",
              ",GALLOP"
            ]
          },
          "level_013": {
            "a": 692580,
            "b": "YAEDRR",
            "e": [
              ",DARE",
              ",DEAR",
              ",RARE",
              ",READ",
              ",REAR",
              ",YARD",
              ",YEAR",
              ",DREARY"
            ]
          },
          "level_014": {
            "a": 692593,
            "b": "HIOPAYX",
            "e": [
              ",HAY",
              ",HIP",
              ",HOP",
              ",PAY",
              ",PHI",
              ",POX",
              ",AHOY",
              ",HOAX"
            ]
          },
          "level_015": {
            "a": 692583,
            "b": "UYSLO",
            "e": [
              ",SLY",
              ",SOY",
              ",YOU",
              ",SOUL",
              ",LOUSY"
            ]
          },
          "level_016": {
            "a": 692582,
            "b": "XUMDHEE",
            "e": [
              ",DUE",
              ",DUH",
              ",EMU",
              ",HEM",
              ",HEX",
              ",HUE",
              ",HUM",
              ",MUD",
              ",EXUDE",
              ",HEXED",
              ",EXHUMED"
            ]
          },
          "level_017": {
            "a": 692579,
            "b": "POEYD",
            "e": [
              ",DOE",
              ",DYE",
              ",ODE",
              ",POD",
              ",YEP",
              ",DOPE"
            ]
          },
          "level_018": {
            "a": 692592,
            "b": "ONSERT",
            "e": [
              ",ONSET",
              ",SNORE",
              ",SNORT",
              ",STERN",
              ",STONE",
              ",STORE",
              ",TENOR",
              ",TONER"
            ]
          },
          "level_019": {
            "a": 692588,
            "b": "ALIFN",
            "e": [
              ",AIL",
              ",FAN",
              ",FIN",
              ",NIL",
              ",FINAL"
            ]
          },
          "level_020": {
            "a": 692595,
            "b": "LEALOC",
            "e": [
              ",ALOE",
              ",CALL",
              ",CELL",
              ",COAL",
              ",COLA",
              ",LACE",
              ",CELLO",
              ",LOCAL",
              ",LOCALE"
            ]
          }
        },
        "m": 7929912,
        "o": 52952,
        "r": 7929912,
        "t": 0.78,
        "v": 14286931,
        "y": 0.78
      },
      "set_2": {
        "a": "PASS",
        "aa": 14155838,
        "d": "bg_canyon2b.jpg",
        "dd": 14155838,
        "e": 0.2,
        "j": 14155838,
        "l": 14155838,
        "levels": {
          "level_001": {
            "a": 692832,
            "b": "AAMLL",
            "e": [
              ",ALL",
              ",LAM",
              ",MALL",
              ",LLAMA"
            ]
          },
          "level_002": {
            "a": 692835,
            "b": "NLYEBI",
            "e": [
              ",BILE",
              "B,LIEN",
              ",LINE",
              ",BYLINE"
            ]
          },
          "level_003": {
            "a": 692838,
            "b": "YGLEAM",
            "e": [
              ",GALE",
              "B,GAME",
              ",GLAM",
              ",LAME",
              ",MAGE",
              ",MALE",
              ",MEAL",
              ",MEGA"
            ]
          },
          "level_004": {
            "a": 692830,
            "b": "LEATYHR",
            "e": [
              ",ALERT",
              ",ALTER",
              ",EARLY",
              ",EARTH",
              ",ETHYL",
              ",HATER",
              ",HEART",
              ",LATER",
              ",LATHE",
              ",LAYER",
              ",RELAY",
              ",TEARY"
            ]
          },
          "level_005": {
            "a": 692828,
            "b": "ONSFFDE",
            "e": [
              ",DONE",
              "B,DOSE",
              ",FEND",
              ",FOND",
              ",NODE",
              ",NOSE",
              ",SEND",
              ",OFFEND"
            ]
          },
          "level_006": {
            "a": 692839,
            "b": "AAIRMN",
            "e": [
              ",AIM",
              ",AIR",
              ",ARM",
              ",MAN",
              ",MAR",
              ",RAM",
              ",RAN",
              ",RIM",
              ",ANIMA",
              ",MANIA",
              ",AIRMAN",
              ",MARINA"
            ]
          },
          "level_007": {
            "a": 692840,
            "b": "NECDRI",
            "e": [
              ",CIDER",
              ",CRIED",
              ",DINER",
              ",NICER",
              ",CINDER"
            ]
          },
          "level_008": {
            "a": 692833,
            "b": "UEPNIR",
            "e": [
              ",PIER",
              ",PINE",
              ",PURE",
              ",REIN",
              ",RIPE",
              ",RUIN",
              ",RUNE",
              ",INURE",
              ",PRUNE",
              ",RIPEN"
            ]
          },
          "level_009": {
            "a": 692829,
            "b": "LCHEENO",
            "e": [
              ",CONE",
              ",ECHO",
              ",HEEL",
              ",HOLE",
              ",HONE",
              ",LONE",
              ",NOEL",
              ",ONCE"
            ]
          },
          "level_010": {
            "a": 692834,
            "b": "RPIADE",
            "e": [
              ",AIRED",
              ",DRAPE",
              ",PADRE",
              ",PARED",
              ",PRIDE",
              ",PRIED",
              ",RAPID",
              ",DIAPER",
              ",PAIRED",
              ",REPAID"
            ]
          },
          "level_011": {
            "a": 692827,
            "b": "IDEL",
            "e": [
              ",LED",
              ",LID",
              ",LIE",
              ",DELI",
              ",IDLE",
              ",LIED"
            ]
          },
          "level_012": {
            "a": 692823,
            "b": "ICARECM",
            "e": [
              ",ACME",
              ",ACRE",
              ",CAME",
              ",CARE",
              ",CRAM",
              ",MACE",
              ",MARE",
              ",MICA",
              ",MICE",
              ",MIRE",
              ",RACE",
              ",RICE"
            ]
          },
          "level_013": {
            "a": 692836,
            "b": "SOLDC",
            "e": [
              ",COD",
              ",DOC",
              ",OLD",
              ",SOD",
              ",CLOD",
              ",COLD",
              ",SOLD",
              ",SCOLD"
            ]
          },
          "level_014": {
            "a": 692826,
            "b": "YCPOAIT",
            "e": [
              ",ATOP",
              ",CITY",
              ",COAT",
              ",COPY",
              ",IOTA",
              ",PACT",
              ",PITA",
              ",PITY",
              ",TACO",
              ",TYPO",
              ",OPACITY"
            ]
          },
          "level_015": {
            "a": 692831,
            "b": "HOTLE",
            "e": [
              ",HOE",
              "B,HOT",
              ",LET",
              ",LOT",
              ",THE",
              ",TOE",
              ",HOTEL"
            ]
          },
          "level_016": {
            "a": 692841,
            "b": "MKEUST",
            "e": [
              ",MUSE",
              "B,MUSK",
              ",MUST",
              ",MUTE",
              ",SMUT",
              ",STEM",
              ",TUSK",
              ",MUSKET"
            ]
          },
          "level_017": {
            "a": 692837,
            "b": "HTRITS",
            "e": [
              ",HIS",
              ",HIT",
              ",ITS",
              ",SIR",
              ",SIT",
              ",TIS",
              ",STIR",
              ",THIS"
            ]
          },
          "level_018": {
            "a": 692822,
            "b": "KARWPYA",
            "e": [
              ",AWAY",
              ",AWRY",
              ",PARA",
              ",PARK",
              ",PRAY",
              ",WARP",
              ",WARY",
              ",WRAP"
            ]
          },
          "level_019": {
            "a": 692825,
            "b": "MCELEWO",
            "e": [
              ",COME",
              "B,COWL",
              ",MEOW",
              ",MOLE"
            ]
          },
          "level_020": {
            "a": 692824,
            "b": "SNUOT",
            "e": [
              ",ONUS",
              ",OUST",
              ",SNOT",
              ",STUN",
              ",UNTO",
              ",SNOUT"
            ]
          }
        },
        "m": 7929912,
        "o": 13925632,
        "r": 7929912,
        "t": 0.6,
        "v": 14155838,
        "w": 16777215,
        "y": 0.6
      },
      "set_3": {
        "a": "ARCH",
        "aa": 14090281,
        "d": "bg_canyon3.jpg",
        "dd": 14090281,
        "e": 0.2,
        "j": 14090281,
        "l": 14090281,
        "levels": {
          "level_001": {
            "a": 693008,
            "b": "TANWY",
            "e": [
              ",ANT",
              ",ANY",
              ",NAW",
              ",NAY",
              ",TAN",
              ",WAY",
              ",WANT",
              ",YAWN"
            ]
          },
          "level_002": {
            "a": 693022,
            "b": "VETOD",
            "e": [
              ",DOTE",
              ",DOVE",
              ",VETO",
              ",VOTE"
            ]
          },
          "level_003": {
            "a": 693020,
            "b": "EIEWHRN",
            "e": [
              ",NEWER",
              ",RENEW",
              ",WHERE",
              ",WHINE"
            ]
          },
          "level_004": {
            "a": 693024,
            "b": "MOROFTC",
            "e": [
              ",COOT",
              "B,FOOT",
              ",FORM",
              ",FORT",
              ",FROM",
              ",MOOR",
              ",MOOT",
              ",ROOF",
              ",ROOM",
              ",ROOT",
              ",MOTOR",
              ",COMFORT"
            ]
          },
          "level_005": {
            "a": 693012,
            "b": "HEDWRS",
            "e": [
              ",DEW",
              ",HER",
              ",HEW",
              ",RED",
              ",SEW",
              ",SHE",
              ",WED",
              ",DREW",
              ",HERD",
              ",SHED"
            ]
          },
          "level_006": {
            "a": 693023,
            "b": "ALHHTYE",
            "e": [
              ",HALT",
              ",HATE",
              ",HEAL",
              ",HEAT",
              ",LATE",
              ",TALE",
              ",TEAL",
              ",THEY",
              ",YEAH",
              ",HEALTHY"
            ]
          },
          "level_007": {
            "a": 693013,
            "b": "ULLERA",
            "e": [
              ",EARL",
              ",LURE",
              ",REAL",
              ",RULE"
            ]
          },
          "level_008": {
            "a": 693025,
            "b": "ITLETEN",
            "e": [
              ",ELITE",
              ",INLET",
              ",TENET",
              ",TITLE",
              ",NETTLE",
              ",ENTITLE"
            ]
          },
          "level_009": {
            "a": 693018,
            "b": "TNSACE",
            "e": [
              ",CASTE",
              ",ENACT",
              ",SCANT",
              ",SCENT"
            ]
          },
          "level_010": {
            "a": 693016,
            "b": "BUGRALR",
            "e": [
              ",BLUR",
              ",BRAG",
              ",BURG",
              ",BURR",
              ",GARB",
              ",GRAB",
              ",GRUB"
            ]
          },
          "level_011": {
            "a": 693017,
            "b": "ASTP",
            "e": [
              ",APT",
              ",ASP",
              ",PAT",
              ",SAP",
              ",SAT",
              ",SPA",
              ",TAP",
              ",PAST",
              "B,SPAT"
            ]
          },
          "level_012": {
            "a": 693011,
            "b": "EPXETRC",
            "e": [
              ",CREEP",
              "B,CREPE",
              ",CREPT",
              ",ERECT",
              ",EXERT"
            ]
          },
          "level_013": {
            "a": 693015,
            "b": "EDNLAIH",
            "e": [
              ",ALIEN",
              ",IDEAL",
              ",LADEN",
              ",LINED",
              ",DENIAL",
              ",HAILED",
              ",HANDLE",
              ",INHALE",
              ",NAILED",
              ",INHALED"
            ]
          },
          "level_014": {
            "a": 693026,
            "b": "YOKFSL",
            "e": [
              ",FLY",
              ",SKY",
              ",SLY",
              ",SOY",
              ",FOLKSY"
            ]
          },
          "level_015": {
            "a": 693009,
            "b": "LOFFUKR",
            "e": [
              ",FLU",
              ",FOR",
              ",FRO",
              ",FUR",
              ",OFF",
              ",OUR",
              ",FOLK",
              ",FORK",
              ",FOUL",
              ",FOUR",
              ",LURK"
            ]
          },
          "level_016": {
            "a": 693027,
            "b": "SGPNRU",
            "e": [
              ",GNU",
              "B,GUN",
              ",PUG",
              ",PUN",
              ",PUS",
              ",RUG",
              ",RUN",
              ",SUN",
              ",SUP",
              ",UPS",
              ",URN",
              ",SPURN"
            ]
          },
          "level_017": {
            "a": 693019,
            "b": "ACTORR",
            "e": [
              ",ACT",
              ",ARC",
              ",ART",
              ",CAR",
              ",CAT",
              ",COT",
              ",OAR",
              ",OAT",
              ",RAT",
              ",ROT",
              ",TAR",
              ",ACTOR"
            ]
          },
          "level_018": {
            "a": 693021,
            "b": "NWESIST",
            "e": [
              ",NEST",
              "B,SENT",
              ",SEWN",
              ",SINE",
              ",SITE",
              ",STEW",
              ",TINE",
              ",TWIN",
              ",WENT",
              ",WEST",
              ",WINE",
              ",WISE"
            ]
          },
          "level_019": {
            "a": 693010,
            "b": "AEKETR",
            "e": [
              ",RAKE",
              ",RATE",
              ",REEK",
              ",TAKE",
              ",TEAK",
              ",TEAR",
              ",TREE",
              ",TREK"
            ]
          },
          "level_020": {
            "a": 693014,
            "b": "ANRUOD",
            "e": [
              ",DARN",
              ",DOUR",
              ",ROAD",
              ",ROAN",
              ",UNDO",
              ",ADORN",
              "B,RADON",
              ",ROUND",
              ",AROUND"
            ]
          }
        },
        "m": 7929912,
        "o": 5712331,
        "r": 7929912,
        "t": 0.65,
        "v": 14090281,
        "y": 0.65
      },
      "set_4": {
        "a": "CLIFF",
        "aa": 13959188,
        "d": "bg_canyon4c.jpg",
        "dd": 13959188,
        "e": 0.2,
        "j": 13959188,
        "l": 13959188,
        "levels": {
          "level_001": {
            "a": 693150,
            "b": "AILR",
            "e": [
              ",AIL",
              ",AIR",
              ",LAIR",
              ",LIAR",
              ",RAIL"
            ]
          },
          "level_002": {
            "a": 693151,
            "b": "DHORGTU",
            "e": [
              ",DOUGH",
              "B,GOURD",
              ",GROUT",
              ",OUGHT",
              ",ROUGH",
              ",TOUGH",
              ",TROUGH",
              ",DROUGHT"
            ]
          },
          "level_003": {
            "a": 693141,
            "b": "DCUEDLD",
            "e": [
              ",CLUE",
              "B,CUED",
              ",DUDE",
              ",DUEL"
            ]
          },
          "level_004": {
            "a": 693156,
            "b": "RBTEITU",
            "e": [
              ",BRUTE",
              ",BUTTE",
              ",TRIBE",
              ",TRITE",
              ",TUBER",
              ",UTTER",
              ",TRIBUTE"
            ]
          },
          "level_005": {
            "a": 693146,
            "b": "CRTTUE",
            "e": [
              ",CUE",
              ",CUR",
              ",CUT",
              ",RUE",
              ",RUT",
              ",CURE",
              ",CURT",
              ",CUTE",
              ",TRUE"
            ]
          },
          "level_006": {
            "a": 693142,
            "b": "ODHANOM",
            "e": [
              ",DOOM",
              ",HAND",
              ",HOOD",
              ",MOAN",
              ",MONO",
              ",MOOD",
              ",MOON",
              ",MANHOOD"
            ]
          },
          "level_007": {
            "a": 693147,
            "b": "YBLKCO",
            "e": [
              ",BOY",
              ",COB",
              ",COY",
              ",LOB",
              ",LOCK",
              "B,YOLK",
              ",BLOCK",
              ",BLOCKY"
            ]
          },
          "level_008": {
            "a": 693145,
            "b": "DMEUBLR",
            "e": [
              ",BLUER",
              ",LEMUR",
              ",LURED",
              ",RUBLE",
              ",RULED",
              ",UMBER",
              ",LUMBER",
              ",RUMBLE",
              ",RUMBLED"
            ]
          },
          "level_009": {
            "a": 693140,
            "b": "EACNAKP",
            "e": [
              ",ACE",
              ",APE",
              ",CAN",
              ",CAP",
              ",NAP",
              ",PAN",
              ",PEA",
              ",PEN",
              ",PANCAKE"
            ]
          },
          "level_010": {
            "a": 693144,
            "b": "ROCSUEF",
            "e": [
              ",CURSE",
              ",FOCUS",
              ",FORCE",
              ",ROUSE",
              ",SCORE",
              ",SCOUR",
              ",COURSE",
              "B,FRESCO",
              ",SOURCE"
            ]
          },
          "level_011": {
            "a": 693155,
            "b": "YSIALE",
            "e": [
              ",EASY",
              ",ISLE",
              ",SAIL",
              ",SALE",
              ",SEAL",
              ",SLAY",
              ",AISLE"
            ]
          },
          "level_012": {
            "a": 693138,
            "b": "TDOROPE",
            "e": [
              ",DEPOT",
              ",DROOP",
              ",OPTED",
              ",RODEO",
              ",ROPED",
              ",TROOP",
              ",TROPE",
              ",DEPORT",
              ",ROOTED",
              ",TORPEDO",
              ",TROOPED"
            ]
          },
          "level_013": {
            "a": 693148,
            "b": "INLGO",
            "e": [
              ",GIN",
              ",ION",
              ",LOG",
              ",NIL",
              ",OIL",
              ",LION",
              ",LOIN",
              ",LONG"
            ]
          },
          "level_014": {
            "a": 693154,
            "b": "EPDXSNA",
            "e": [
              ",APEX",
              "B,AXED",
              ",DEAN",
              ",NAPE",
              ",PANE",
              ",SAND",
              ",SANE",
              ",SEND",
              ",SNAP",
              ",SPAN",
              ",SPED",
              ",EXPAND"
            ]
          },
          "level_015": {
            "a": 693139,
            "b": "TERTEW",
            "e": [
              ",EWE",
              ",TEE",
              ",WEE",
              ",WET",
              ",TWEET"
            ]
          },
          "level_016": {
            "a": 693149,
            "b": "EGALLED",
            "e": [
              ",AGED",
              ",DALE",
              ",DEAL",
              ",DELL",
              ",EDGE",
              ",GALE",
              ",GALL",
              ",GLAD",
              ",GLEE",
              ",LEAD",
              ",ALLEGE"
            ]
          },
          "level_017": {
            "a": 693157,
            "b": "LEDEG",
            "e": [
              ",EEL",
              "B,GEE",
              ",GEL",
              ",LED",
              ",LEG",
              ",LEDGE"
            ]
          },
          "level_018": {
            "a": 693143,
            "b": "RDOBCEK",
            "e": [
              ",BORED",
              ",BROKE",
              ",CODER",
              ",CORED",
              ",CREDO",
              ",DECOR",
              ",ROCKED",
              ",BEDROCK"
            ]
          },
          "level_019": {
            "a": 693152,
            "b": "DEUFS",
            "e": [
              ",DUE",
              ",FED",
              ",SUE",
              ",USE",
              ",FEUD",
              ",FUSE",
              ",SUED",
              ",USED"
            ]
          },
          "level_020": {
            "a": 693153,
            "b": "OPLABM",
            "e": [
              ",BALM",
              ",BLAM",
              ",BOLA",
              ",LAMB",
              ",LAMP",
              ",LOAM",
              ",OPAL",
              ",PALM"
            ]
          }
        },
        "m": 8323072,
        "o": 52952,
        "r": 8323072,
        "t": 0.63,
        "v": 13959188,
        "y": 0.63
      },
      "set_5": {
        "a": "PILLAR",
        "aa": 13893632,
        "d": "bg_canyon5.jpg",
        "dd": 13893632,
        "e": 0.2,
        "j": 13893632,
        "l": 13893632,
        "levels": {
          "level_001": {
            "a": 693397,
            "b": "PTIHC",
            "e": [
              ",CHI",
              ",HIP",
              ",HIT",
              ",PHI",
              ",PIC",
              ",PIT",
              ",TIC",
              ",TIP",
              ",CHIP",
              "B,ITCH",
              ",PITCH"
            ]
          },
          "level_002": {
            "a": 693402,
            "b": "ECERNS",
            "e": [
              ",SEEN",
              ",SEER",
              ",SCENE",
              ",SCREE",
              ",SNEER",
              ",SCREEN"
            ]
          },
          "level_003": {
            "a": 693413,
            "b": "KMBERA",
            "e": [
              ",BAKE",
              "B,BARE",
              ",BARK",
              ",BEAK",
              ",BEAM",
              ",BEAR",
              ",BERM",
              ",MAKE",
              ",MARE",
              ",MARK",
              ",RAKE"
            ]
          },
          "level_004": {
            "a": 693409,
            "b": "IKOEOB",
            "e": [
              ",BIO",
              ",BOO",
              ",KOI",
              ",BIKE",
              ",BOOK",
              ",OBOE",
              ",EBOOK",
              ",BOOKIE"
            ]
          },
          "level_005": {
            "a": 693394,
            "b": "PDACESE",
            "e": [
              ",CEASE",
              ",EASED",
              ",PACED",
              ",PEACE",
              ",SPACE",
              ",SPADE",
              ",SPEED",
              ",CEASED",
              ",ESCAPE",
              ",SPACED"
            ]
          },
          "level_006": {
            "a": 693399,
            "b": "RYTEDN",
            "e": [
              ",DENT",
              ",DENY",
              ",NERD",
              ",REND",
              ",RENT",
              ",TEND",
              ",TERN",
              ",TRENDY"
            ]
          },
          "level_007": {
            "a": 693395,
            "b": "STINT",
            "e": [
              ",ITS",
              ",NIT",
              ",SIN",
              ",SIT",
              ",TIN",
              ",TIS",
              ",TINT"
            ]
          },
          "level_008": {
            "a": 693410,
            "b": "MESISX",
            "e": [
              ",MIX",
              ",SEX",
              ",SIM",
              ",SIS",
              ",SIX",
              ",MESS",
              "B,SEMI",
              ",SEXISM"
            ]
          },
          "level_009": {
            "a": 693411,
            "b": "ARRPIE",
            "e": [
              ",PAIR",
              ",PARE",
              ",PEAR",
              ",PIER",
              ",RARE",
              ",REAP",
              ",REAR",
              ",RIPE",
              ",RIPER"
            ]
          },
          "level_010": {
            "a": 693401,
            "b": "PYRAPLE",
            "e": [
              ",APPLE",
              ",APPLY",
              ",EARLY",
              ",LAYER",
              ",PALER",
              ",PAPER",
              ",PAYER",
              ",PEARL",
              ",RELAY",
              ",REPAY",
              ",REPLY",
              ",REAPPLY"
            ]
          },
          "level_011": {
            "a": 693405,
            "b": "IRADYM",
            "e": [
              ",AIRY",
              ",AMID",
              ",ARID",
              ",ARMY",
              ",DRAM",
              ",MAID",
              ",RAID",
              ",YARD"
            ]
          },
          "level_012": {
            "a": 693404,
            "b": "SATRNEG",
            "e": [
              ",AGENT",
              ",ANGER",
              ",ANGST",
              ",GRANT",
              ",GRATE",
              ",GREAT",
              ",RANGE",
              ",SANER",
              ",SNARE",
              ",STAGE",
              ",STARE",
              ",STERN"
            ]
          },
          "level_013": {
            "a": 693412,
            "b": "MUODN",
            "e": [
              ",DON",
              ",DUN",
              ",DUO",
              ",MUD",
              ",NOD",
              ",MOUND"
            ]
          },
          "level_014": {
            "a": 693400,
            "b": "ALLORF",
            "e": [
              ",AFRO",
              "B,FALL",
              ",FOAL",
              ",FORA",
              ",LOAF",
              ",ORAL",
              ",ROLL",
              ",FLORAL"
            ]
          },
          "level_015": {
            "a": 693396,
            "b": "YZZRGIL",
            "e": [
              ",RIG",
              ",ZIG",
              ",GIRL",
              ",GRIZZLY"
            ]
          },
          "level_016": {
            "a": 693408,
            "b": "EDIUNT",
            "e": [
              ",TUNED",
              ",UNITE",
              ",UNTIE",
              ",UNITED",
              ",UNTIED"
            ]
          },
          "level_017": {
            "a": 693407,
            "b": "GEABT",
            "e": [
              ",AGE",
              "B,ATE",
              ",BAG",
              ",BAT",
              ",BEG",
              ",BET",
              ",EAT",
              ",GET",
              ",TAB",
              ",TAG",
              ",TEA",
              ",BEGAT"
            ]
          },
          "level_018": {
            "a": 693406,
            "b": "PLAUWK",
            "e": [
              ",LAP",
              ",LAW",
              ",PAL",
              ",PAW",
              ",WALKUP"
            ]
          },
          "level_019": {
            "a": 693403,
            "b": "RFTOS",
            "e": [
              ",FORT",
              "B,SOFT",
              ",SORT",
              ",FROST"
            ]
          },
          "level_020": {
            "a": 693398,
            "b": "ETJYTIR",
            "e": [
              ",IRE",
              ",JET",
              ",RYE",
              ",TIE",
              ",TRY",
              ",YET",
              ",JITTER",
              ",JITTERY"
            ]
          }
        },
        "m": 8323072,
        "o": 52834,
        "r": 16777215,
        "t": 0.88,
        "v": 13893632,
        "y": 0.78
      }
    }
  },
  "WS 28": {
    "a": "FOREST",
    "b": "grad_white",
    "c": "grp_forest",
    "d": 0.75,
    "e": 634893,
    "f": 48013,
    "sets": {
      "set_1": {
        "a": "PINE",
        "aa": 634893,
        "d": "bg_forest1.jpg",
        "dd": 634893,
        "e": 0.2,
        "j": 634893,
        "l": 634893,
        "levels": {
          "level_001": {
            "a": 693586,
            "b": "LYLWHO",
            "e": [
              ",HOW",
              ",LOW",
              ",OWL",
              ",WHO",
              ",WHY",
              ",HOLLY",
              ",LOWLY",
              ",WHOLLY"
            ]
          },
          "level_002": {
            "a": 693575,
            "b": "OADOCVA",
            "e": [
              ",ADO",
              ",CAD",
              ",COD",
              ",COO",
              ",DOC",
              ",OVA",
              ",VAC",
              ",AVOCADO"
            ]
          },
          "level_003": {
            "a": 693571,
            "b": "EVROKE",
            "e": [
              ",EVER",
              "B,OVER",
              ",REEK",
              ",ROVE",
              ",VEER",
              ",REVOKE"
            ]
          },
          "level_004": {
            "a": 693572,
            "b": "MPUDRIE",
            "e": [
              ",IMPURE",
              ",PRIMED",
              ",UMPIRE",
              ",UMPIRED"
            ]
          },
          "level_005": {
            "a": 693581,
            "b": "TRAUPQE",
            "e": [
              ",ERUPT",
              "B,QUART",
              ",TAPER",
              ",TAUPE"
            ]
          },
          "level_006": {
            "a": 693578,
            "b": "LOUTCC",
            "e": [
              ",COT",
              ",CUT",
              ",LOT",
              ",OUT",
              ",CLOT",
              ",COLT",
              ",CULT",
              ",LOUT",
              ",OCCULT"
            ]
          },
          "level_007": {
            "a": 693568,
            "b": "BLEUNA",
            "e": [
              ",ALE",
              ",BAN",
              ",BUN",
              ",LAB",
              ",NAB",
              ",NUB",
              ",NEBULA",
              ",UNABLE"
            ]
          },
          "level_008": {
            "a": 693583,
            "b": "NBGILO",
            "e": [
              ",BLOG",
              ",BOIL",
              ",BONG",
              ",GLIB",
              ",GLOB",
              ",LION",
              ",LOIN",
              ",LONG",
              ",BINGO",
              ",BLING",
              ",LINGO",
              ",LOGIN"
            ]
          },
          "level_009": {
            "a": 693574,
            "b": "YWNSO",
            "e": [
              ",NOW",
              "B,OWN",
              ",SON",
              ",SOW",
              ",SOY",
              ",WON",
              ",YON",
              ",SNOWY"
            ]
          },
          "level_010": {
            "a": 693573,
            "b": "UTRHST",
            "e": [
              ",HURT",
              ",RUSH",
              ",RUST",
              ",SHUT",
              ",THRU",
              ",THUS",
              ",TUSH",
              ",STRUT",
              ",TRUST",
              ",TRUTH"
            ]
          },
          "level_011": {
            "a": 693569,
            "b": "ELNAEB",
            "e": [
              ",ABLE",
              ",BALE",
              ",BANE",
              ",BEAN",
              ",BEEN",
              ",LANE",
              ",LEAN",
              ",ENABLE"
            ]
          },
          "level_012": {
            "a": 693584,
            "b": "ENROVCU",
            "e": [
              ",COVEN",
              "B,COVER",
              ",CRONE",
              ",CURVE",
              ",OUNCE",
              ",RECON",
              ",UNCOVER"
            ]
          },
          "level_013": {
            "a": 693587,
            "b": "DEDOER",
            "e": [
              ",DEED",
              ",DEER",
              ",DOER",
              ",REDO",
              ",REED",
              ",RODE",
              ",ERODE",
              "B,ODDER"
            ]
          },
          "level_014": {
            "a": 693570,
            "b": "LRDGANA",
            "e": [
              ",AND",
              ",GAL",
              ",LAD",
              ",LAG",
              ",NAG",
              ",RAD",
              ",RAG",
              ",RAN",
              ",GLAND",
              ",GNARL",
              ",GRAND"
            ]
          },
          "level_015": {
            "a": 693580,
            "b": "AHOLSWL",
            "e": [
              ",ALSO",
              ",HALL",
              ",HALO",
              ",HOWL",
              ",LASH",
              ",SHOW",
              ",SLAW",
              ",SLOW",
              ",WALL",
              ",WASH",
              ",WHOA"
            ]
          },
          "level_016": {
            "a": 693582,
            "b": "NVOITAO",
            "e": [
              ",ANTI",
              ",INTO",
              ",IOTA",
              ",NOVA",
              ",ONTO",
              ",TOON",
              ",VAIN",
              ",VINO",
              ",OVATION"
            ]
          },
          "level_017": {
            "a": 693576,
            "b": "RATBLI",
            "e": [
              ",BAIL",
              ",BAIT",
              ",BRAT",
              ",LAIR",
              ",LIAR",
              ",RAIL",
              ",TAIL",
              ",TRIBAL"
            ]
          },
          "level_018": {
            "a": 693585,
            "b": "CURINON",
            "e": [
              ",COIN",
              ",CORN",
              ",ICON",
              ",IRON",
              ",NOUN",
              ",RUIN",
              ",UNICORN"
            ]
          },
          "level_019": {
            "a": 693579,
            "b": "GREDAGY",
            "e": [
              ",GRADE",
              ",RAGED",
              ",READY",
              ",DAGGER",
              ",RAGGED"
            ]
          },
          "level_020": {
            "a": 693577,
            "b": "ITESLGH",
            "e": [
              ",EIGHT",
              ",HEIST",
              ",ISLET",
              ",LEGIT",
              ",LIGHT",
              ",LITHE",
              ",SIGHT",
              ",SLEIGH",
              "B,SLIGHT"
            ]
          }
        },
        "m": 617485,
        "o": 50687,
        "r": 617485,
        "t": 0.6,
        "u": 16580605,
        "v": 634893,
        "y": 0.52,
        "z": 16580605
      },
      "set_2": {
        "a": "DEW",
        "aa": 438829,
        "d": "bg_forest2.jpg",
        "dd": 438829,
        "e": 0.2,
        "j": 438829,
        "l": 438829,
        "levels": {
          "level_001": {
            "a": 693726,
            "b": "IIEHPP",
            "e": [
              ",HIP",
              "B,PEP",
              ",PHI",
              ",PIE",
              ",HIPPIE"
            ]
          },
          "level_002": {
            "a": 693736,
            "b": "MMUGY",
            "e": [
              ",GUM",
              "B,GUY",
              ",GYM",
              ",MUG",
              ",MUM",
              ",UMM",
              ",YUM",
              ",GUMMY"
            ]
          },
          "level_003": {
            "a": 693730,
            "b": "ALOANC",
            "e": [
              ",CAN",
              ",CON",
              ",CLAN",
              ",COAL",
              ",COLA",
              ",LOAN",
              ",CANAL",
              ",CANOLA"
            ]
          },
          "level_004": {
            "a": 693731,
            "b": "URNMTAT",
            "e": [
              ",AUNT",
              ",MART",
              ",MUTT",
              ",RANT",
              ",RUNT",
              ",TART",
              ",TAUT",
              ",TRAM",
              ",TUNA",
              ",TURN",
              ",TAUNT"
            ]
          },
          "level_005": {
            "a": 693729,
            "b": "ESOEERF",
            "e": [
              ",FEE",
              "B,FOE",
              ",FOR",
              ",FRO",
              ",ORE",
              ",REF",
              ",SEE",
              ",FORESEE"
            ]
          },
          "level_006": {
            "a": 693734,
            "b": "EEMEGDR",
            "e": [
              ",EDGER",
              ",GREED",
              ",MERGE",
              ",DEGREE",
              ",EMERGE",
              ",MERGED",
              ",REDEEM",
              ",EMERGED"
            ]
          },
          "level_007": {
            "a": 693735,
            "b": "RREAGD",
            "e": [
              ",AGED",
              ",DARE",
              ",DEAR",
              ",DRAG",
              ",GEAR",
              ",GRAD",
              ",RAGE",
              ",RARE",
              ",READ",
              ",REAR"
            ]
          },
          "level_008": {
            "a": 693723,
            "b": "PUPGNI",
            "e": [
              ",GIN",
              "B,GNU",
              ",GUN",
              ",NIP",
              ",PIG",
              ",PIN",
              ",PUG",
              ",PUN",
              ",PUP",
              ",UPPING"
            ]
          },
          "level_009": {
            "a": 693724,
            "b": "NMAERN",
            "e": [
              ",AMEN",
              ",EARN",
              ",MANE",
              ",MARE",
              ",MEAN",
              ",NAME",
              ",NEAR",
              ",MANNER"
            ]
          },
          "level_010": {
            "a": 693738,
            "b": "DHRAC",
            "e": [
              ",ARCH",
              ",CARD",
              ",CHAD",
              ",CHAR",
              ",HARD",
              ",CHARD"
            ]
          },
          "level_011": {
            "a": 693739,
            "b": "AHDEWRA",
            "e": [
              ",AHEAD",
              "B,AWARD",
              ",AWARE",
              ",HEARD",
              ",WARHEAD"
            ]
          },
          "level_012": {
            "a": 693737,
            "b": "EUPOMTC",
            "e": [
              ",COME",
              ",COMP",
              ",COPE",
              ",COUP",
              ",CUTE",
              ",MOTE",
              ",MUTE",
              ",POEM",
              ",POET",
              ",POUT",
              ",TEMP",
              ",TOME"
            ]
          },
          "level_013": {
            "a": 693733,
            "b": "SCSRA",
            "e": [
              ",ARC",
              "B,CAR",
              ",SAC",
              ",CRASS"
            ]
          },
          "level_014": {
            "a": 693728,
            "b": "DADBLER",
            "e": [
              ",BADDER",
              ",BLARED",
              ",LADDER",
              ",BLADDER"
            ]
          },
          "level_015": {
            "a": 693721,
            "b": "CLVPEI",
            "e": [
              ",CLIP",
              ",EPIC",
              ",EVIL",
              ",LICE",
              ",LIVE",
              ",PILE",
              ",VEIL",
              ",VICE",
              ",VILE",
              ",PELVIC"
            ]
          },
          "level_016": {
            "a": 693732,
            "b": "STFNEI",
            "e": [
              ",FINE",
              ",FIST",
              ",NEST",
              ",SENT",
              ",SIFT",
              ",SINE",
              ",SITE",
              ",TINE",
              ",FEINT",
              ",INSET"
            ]
          },
          "level_017": {
            "a": 693722,
            "b": "ASNFU",
            "e": [
              ",FAN",
              ",FUN",
              ",SUN",
              ",SNAFU"
            ]
          },
          "level_018": {
            "a": 693720,
            "b": "KVEDOE",
            "e": [
              ",DOE",
              ",EEK",
              ",EKE",
              ",EVE",
              ",ODE",
              ",DOVE",
              ",EVOKE",
              ",EVOKED"
            ]
          },
          "level_019": {
            "a": 693727,
            "b": "RSAHIV",
            "e": [
              ",AIR",
              ",ASH",
              ",HAS",
              ",HIS",
              ",SIR",
              ",VIA",
              ",HAIR",
              ",RASH",
              ",VISA"
            ]
          },
          "level_020": {
            "a": 693725,
            "b": "RBELMU",
            "e": [
              ",BUM",
              ",ELM",
              ",EMU",
              ",REM",
              ",RUB",
              ",RUE",
              ",RUM",
              ",BLUER",
              ",LEMUR",
              ",RUBLE",
              ",UMBER"
            ]
          }
        },
        "m": 422930,
        "o": 3655952,
        "r": 422930,
        "t": 0.62,
        "v": 438829,
        "y": 0.7000000000000001
      },
      "set_3": {
        "a": "FLOW",
        "aa": 308557,
        "d": "bg_forest3.jpg",
        "dd": 308557,
        "e": 0.2,
        "g": 0.79,
        "j": 308557,
        "l": 308557,
        "levels": {
          "level_001": {
            "a": 693886,
            "b": "SGWIN",
            "e": [
              ",SIGN",
              ",SING",
              ",SWIG",
              ",WING"
            ]
          },
          "level_002": {
            "a": 693892,
            "b": "FALEFAL",
            "e": [
              ",ALE",
              ",ALL",
              ",ELF",
              ",FALL",
              "B,FELL",
              ",FLEA",
              ",LEAF",
              ",FALAFEL"
            ]
          },
          "level_003": {
            "a": 693887,
            "b": "HCOYSP",
            "e": [
              ",COP",
              ",COY",
              ",HOP",
              ",OPS",
              ",SHY",
              ",SOP",
              ",SOY",
              ",SPY",
              ",CHOP",
              ",COPY",
              ",POSH",
              ",SHOP"
            ]
          },
          "level_004": {
            "a": 693876,
            "b": "GREOSU",
            "e": [
              ",EURO",
              ",GOES",
              ",GORE",
              ",OGRE",
              ",ROSE",
              ",RUSE",
              ",SORE",
              ",SOUR",
              ",SURE",
              ",URGE",
              ",USER",
              ",GROUSE"
            ]
          },
          "level_005": {
            "a": 693879,
            "b": "GTNE",
            "e": [
              ",GET",
              "B,NET",
              ",TEN",
              ",GENT"
            ]
          },
          "level_006": {
            "a": 693891,
            "b": "ERNGDE",
            "e": [
              ",DEN",
              ",END",
              ",GEE",
              ",RED",
              ",DEER",
              ",EDGE",
              ",GENE",
              ",NEED",
              ",NERD",
              ",REED",
              ",REND",
              ",GENDER"
            ]
          },
          "level_007": {
            "a": 693884,
            "b": "LOSTH",
            "e": [
              ",HOST",
              ",LOST",
              ",SHOT",
              ",SLOT",
              ",SLOTH"
            ]
          },
          "level_008": {
            "a": 693895,
            "b": "MDEORLS",
            "e": [
              ",LOSER",
              ",MODEL",
              ",OLDER",
              ",MORSEL",
              "B,RESOLD",
              ",SELDOM",
              ",SOLDER",
              ",SMOLDER"
            ]
          },
          "level_009": {
            "a": 693889,
            "b": "IOMRNTO",
            "e": [
              ",ION",
              "B,MOO",
              ",NIT",
              ",NOR",
              ",NOT",
              ",RIM",
              ",ROT",
              ",TIN",
              ",TON",
              ",TOO",
              ",MONITOR"
            ]
          },
          "level_010": {
            "a": 693893,
            "b": "SPLAY",
            "e": [
              ",PLAY",
              ",SLAP",
              ",SLAY",
              ",PALSY"
            ]
          },
          "level_011": {
            "a": 693880,
            "b": "SRDTOEY",
            "e": [
              ",STORE",
              ",STORY",
              ",TOYED",
              ",OYSTER",
              ",SORTED",
              ",STORED",
              ",STRODE",
              ",DESTROY"
            ]
          },
          "level_012": {
            "a": 693894,
            "b": "SENLWSI",
            "e": [
              ",LIE",
              ",NEW",
              ",NIL",
              ",SEW",
              ",SIN",
              ",SIS",
              ",WIN",
              ",SINEW",
              ",SWINE",
              ",WINLESS"
            ]
          },
          "level_013": {
            "a": 693890,
            "b": "KWOE",
            "e": [
              ",OWE",
              ",WOE",
              ",WOK",
              ",WOKE"
            ]
          },
          "level_014": {
            "a": 693881,
            "b": "DSFIHRE",
            "e": [
              ",DRIES",
              ",FIRED",
              ",FRESH",
              ",FRIED",
              ",FRIES",
              ",HIRED",
              ",SHIED",
              ",SHIRE",
              ",SHRED",
              ",FISHED",
              ",FISHER"
            ]
          },
          "level_015": {
            "a": 693882,
            "b": "LLATYE",
            "e": [
              ",ALLY",
              "B,LATE",
              ",TALE",
              ",TALL",
              ",TEAL",
              ",TELL",
              ",YELL",
              ",LATELY"
            ]
          },
          "level_016": {
            "a": 693878,
            "b": "EEBDUMS",
            "e": [
              ",DEEM",
              ",MUSE",
              ",SEED",
              ",SEEM",
              ",SUED",
              ",USED",
              ",BUSED",
              ",EMBED",
              ",MUSED",
              ",SUEDE",
              ",BEMUSED"
            ]
          },
          "level_017": {
            "a": 693877,
            "b": "ELISLEJ",
            "e": [
              ",ELSE",
              ",ISLE",
              ",SELL",
              ",SILL"
            ]
          },
          "level_018": {
            "a": 693888,
            "b": "DYEWE",
            "e": [
              ",DEWY",
              ",EYED",
              ",WEED",
              ",WEEDY"
            ]
          },
          "level_019": {
            "a": 693885,
            "b": "IPOUDM",
            "e": [
              ",DIM",
              "B,DIP",
              ",DUO",
              ",IMP",
              ",MID",
              ",MOP",
              ",MUD",
              ",POD",
              ",DUMP",
              ",OPIUM",
              ",PODIUM"
            ]
          },
          "level_020": {
            "a": 693883,
            "b": "MTDREIM",
            "e": [
              ",MERIT",
              ",MIMED",
              ",MIRED",
              ",MITER",
              ",TIMED",
              ",TIMER",
              ",TIRED",
              ",TRIED"
            ]
          }
        },
        "m": 293685,
        "o": 15488838,
        "r": 293685,
        "t": 0.78,
        "v": 308557,
        "y": 0.78
      },
      "set_4": {
        "a": "FOG",
        "aa": 178285,
        "bb": 16777215,
        "d": "bg_forest4.jpg",
        "dd": 178285,
        "e": 0.2,
        "j": 178285,
        "l": 178285,
        "levels": {
          "level_001": {
            "a": 694068,
            "b": "IREARNM",
            "e": [
              ",MINER",
              ",AIRMEN",
              "B,MARINE",
              ",REMAIN"
            ]
          },
          "level_002": {
            "a": 694069,
            "b": "YEHYAD",
            "e": [
              ",AYE",
              ",DAY",
              ",DYE",
              ",HAD",
              ",HAY",
              ",HEY",
              ",YEA",
              ",HEYDAY"
            ]
          },
          "level_003": {
            "a": 694058,
            "b": "ESEFOFN",
            "e": [
              ",FEE",
              "B,FEN",
              ",FOE",
              ",OFF",
              ",ONE",
              ",SEE",
              ",SON",
              ",OFFENSE"
            ]
          },
          "level_004": {
            "a": 694057,
            "b": "OINMAL",
            "e": [
              ",LAIN",
              ",LIMO",
              ",LION",
              ",LOAM",
              ",LOAN",
              ",LOIN",
              ",MAIL",
              ",MAIN",
              ",MOAN",
              ",NAIL",
              ",AMINO",
              ",OILMAN"
            ]
          },
          "level_005": {
            "a": 694053,
            "b": "IRHTE",
            "e": [
              ",HEIR",
              ",HIRE",
              ",RITE",
              ",TIER",
              ",TIRE"
            ]
          },
          "level_006": {
            "a": 694071,
            "b": "AYRBCB",
            "e": [
              ",ARC",
              "B,BAR",
              ",BAY",
              ",BRA",
              ",CAB",
              ",CAR",
              ",CAY",
              ",CRY",
              ",RAY",
              ",CABBY",
              ",CRABBY"
            ]
          },
          "level_007": {
            "a": 694054,
            "b": "OTTUIW",
            "e": [
              ",OUT",
              ",TOT",
              ",TOW",
              ",TWO",
              ",WIT",
              ",TOUT"
            ]
          },
          "level_008": {
            "a": 694056,
            "b": "EIPTREL",
            "e": [
              ",ELITE",
              ",LEPER",
              ",LITER",
              ",PERIL",
              ",REPEL",
              ",TRIPE",
              ",TRIPLE",
              ",REPTILE"
            ]
          },
          "level_009": {
            "a": 694064,
            "b": "ELCROV",
            "e": [
              ",CORE",
              ",COVE",
              ",LORE",
              ",LOVE",
              ",OVER",
              ",ROLE",
              ",ROVE",
              ",VOLE",
              ",CLOVER"
            ]
          },
          "level_010": {
            "a": 694061,
            "b": "ELLVAIB",
            "e": [
              ",ALIVE",
              "B,LABEL",
              ",LIBEL",
              ",VILLA",
              ",LIVABLE"
            ]
          },
          "level_011": {
            "a": 694060,
            "b": "VERGA",
            "e": [
              ",AGE",
              ",ARE",
              ",EAR",
              ",ERA",
              ",RAG",
              ",GAVE",
              ",GEAR",
              ",RAGE",
              ",RAVE",
              ",GRAVE"
            ]
          },
          "level_012": {
            "a": 694067,
            "b": "TVAINAL",
            "e": [
              ",ANVIL",
              ",AVAIL",
              ",AVIAN",
              ",NAVAL",
              ",VITAL",
              ",VALIANT"
            ]
          },
          "level_013": {
            "a": 694063,
            "b": "TYERHO",
            "e": [
              ",HERO",
              ",ROTE",
              ",THEY",
              ",TORE",
              ",YORE",
              ",THEORY"
            ]
          },
          "level_014": {
            "a": 694065,
            "b": "EMRSDI",
            "e": [
              ",DIME",
              "B,DIRE",
              ",MIRE",
              ",RIDE",
              ",RISE",
              ",SEMI",
              ",SIDE",
              ",SIRE"
            ]
          },
          "level_015": {
            "a": 694055,
            "b": "ACETF",
            "e": [
              ",ACE",
              "B,ACT",
              ",AFT",
              ",ATE",
              ",CAT",
              ",EAT",
              ",FAT",
              ",TEA",
              ",FACET"
            ]
          },
          "level_016": {
            "a": 694062,
            "b": "RAEVNDI",
            "e": [
              ",AIRED",
              ",DINER",
              ",DIVAN",
              ",DIVER",
              ",DRAIN",
              ",DRIVE",
              ",NAIVE",
              ",RAVED",
              ",RAVEN",
              ",INVADER"
            ]
          },
          "level_017": {
            "a": 694052,
            "b": "TTIBAHA",
            "e": [
              ",AAH",
              ",AHA",
              ",BAH",
              ",BAT",
              ",BIT",
              ",HAT",
              ",HIT",
              ",TAB",
              ",BAIT",
              ",BATH",
              ",THAT",
              ",HABIT"
            ]
          },
          "level_018": {
            "a": 694059,
            "b": "STENYRL",
            "e": [
              ",ENTRY",
              ",STERN",
              ",STYLE",
              ",SENTRY"
            ]
          },
          "level_019": {
            "a": 694070,
            "b": "BSELSJO",
            "e": [
              ",JOB",
              ",LOB",
              ",SOB",
              ",LESS",
              ",LOBE",
              ",LOSE",
              ",LOSS",
              ",SLOB",
              ",SOLE"
            ]
          },
          "level_020": {
            "a": 694066,
            "b": "BLERZA",
            "e": [
              ",ABLE",
              ",BALE",
              ",BARE",
              ",BEAR",
              ",EARL",
              ",RAZE",
              ",REAL",
              ",ZEAL",
              ",BLARE",
              ",BLAZE",
              ",ZEBRA"
            ]
          }
        },
        "m": 162137,
        "r": 16777215,
        "t": 0.7000000000000001,
        "u": 0,
        "v": 178285,
        "w": 16777215,
        "y": 0.58,
        "z": 0
      },
      "set_5": {
        "a": "LIFE",
        "aa": 48013,
        "d": "bg_forest5.jpg",
        "dd": 48013,
        "e": 0.2,
        "j": 48013,
        "l": 48013,
        "levels": {
          "level_001": {
            "a": 694236,
            "b": "AMEEFL",
            "e": [
              ",FAME",
              ",FEEL",
              ",FLEA",
              ",FLEE",
              ",LAME",
              ",LEAF",
              ",MALE",
              ",MEAL",
              ",FLAME"
            ]
          },
          "level_002": {
            "a": 694234,
            "b": "NWTGA",
            "e": [
              ",ANT",
              ",NAG",
              ",NAW",
              ",TAG",
              ",TAN",
              ",WAG",
              ",GNAT",
              ",GNAW",
              ",TANG",
              ",WANT"
            ]
          },
          "level_003": {
            "a": 694244,
            "b": "NAYK",
            "e": [
              ",ANY",
              ",NAY",
              ",YAK",
              ",YANK"
            ]
          },
          "level_004": {
            "a": 694226,
            "b": "RNCTEIE",
            "e": [
              ",ENTER",
              ",ERECT",
              ",INERT",
              ",INTER",
              ",NICER",
              ",NIECE",
              ",ENTICE",
              ",ENTIRE",
              ",RECENT",
              ",RECITE",
              ",ENTERIC"
            ]
          },
          "level_005": {
            "a": 694237,
            "b": "RAHHS",
            "e": [
              ",ASH",
              ",HAH",
              ",HAS",
              ",HARSH"
            ]
          },
          "level_006": {
            "a": 694239,
            "b": "EDRGGU",
            "e": [
              ",DUE",
              ",DUG",
              ",EGG",
              ",RED",
              ",RUE",
              ",RUG",
              ",URGED",
              ",GRUDGE",
              "B,RUGGED"
            ]
          },
          "level_007": {
            "a": 694238,
            "b": "LTEFI",
            "e": [
              ",ELF",
              ",FIT",
              ",LET",
              ",LIE",
              ",LIT",
              ",TIE",
              ",TIL",
              ",FILET"
            ]
          },
          "level_008": {
            "a": 694233,
            "b": "PTTIESL",
            "e": [
              ",ISLET",
              ",PETIT",
              ",SLEPT",
              ",SPILT",
              ",SPITE",
              ",SPLIT",
              ",STILT",
              ",TITLE"
            ]
          },
          "level_009": {
            "a": 694232,
            "b": "MNAEDM",
            "e": [
              ",AND",
              ",DAM",
              ",DEN",
              ",END",
              ",MAD",
              ",MAM",
              ",MAN",
              ",MEN",
              ",AMEND",
              "B,NAMED"
            ]
          },
          "level_010": {
            "a": 694229,
            "b": "CUESIFF",
            "e": [
              ",CUE",
              ",ICE",
              ",SUE",
              ",USE",
              ",CUFF",
              "B,FIFE",
              ",FUSE",
              ",SUFFICE"
            ]
          },
          "level_011": {
            "a": 694231,
            "b": "IEMMUN",
            "e": [
              ",MENU",
              ",MIME",
              ",MINE",
              ",IMMUNE"
            ]
          },
          "level_012": {
            "a": 694227,
            "b": "URIPTSR",
            "e": [
              ",PURR",
              ",RUST",
              ",SPIT",
              ",SPUR",
              ",STIR",
              ",SUIT",
              ",TRIP",
              ",STIRRUP"
            ]
          },
          "level_013": {
            "a": 694245,
            "b": "ULFOR",
            "e": [
              ",FLU",
              ",FOR",
              ",FRO",
              ",FUR",
              ",OUR",
              ",FOUL",
              "B,FOUR",
              ",FLOUR"
            ]
          },
          "level_014": {
            "a": 694228,
            "b": "AETGENL",
            "e": [
              ",GENTLE",
              ",NEGATE",
              ",TANGLE",
              ",ELEGANT"
            ]
          },
          "level_015": {
            "a": 694242,
            "b": "SRFHERE",
            "e": [
              ",FREE",
              ",HERE",
              ",REEF",
              ",SEER",
              ",FREER",
              "B,FRESH",
              ",REFER",
              ",SHEER"
            ]
          },
          "level_016": {
            "a": 694230,
            "b": "UCKATOB",
            "e": [
              ",ABUT",
              ",AUTO",
              ",BACK",
              ",BOAT",
              ",BOUT",
              ",BUCK",
              ",COAT",
              ",TACK",
              ",TACO",
              ",TUBA",
              ",TUCK"
            ]
          },
          "level_017": {
            "a": 694235,
            "b": "VLEIR",
            "e": [
              ",EVIL",
              "B,LIVE",
              ",RILE",
              ",VEIL",
              ",VILE",
              ",LIVER"
            ]
          },
          "level_018": {
            "a": 694243,
            "b": "SFARTEI",
            "e": [
              ",AFIRE",
              ",AFTER",
              ",ARISE",
              ",FEAST",
              ",FIRST",
              ",FRIES",
              ",IRATE",
              ",RAISE",
              ",SAFER",
              ",STAIR",
              ",STARE",
              ",TRIES"
            ]
          },
          "level_019": {
            "a": 694240,
            "b": "PLOAR",
            "e": [
              ",LAP",
              ",OAR",
              ",PAL",
              ",PAR",
              ",PRO",
              ",RAP",
              ",OPAL",
              ",ORAL",
              ",POLAR"
            ]
          },
          "level_020": {
            "a": 694241,
            "b": "YLHUMAN",
            "e": [
              ",ALUM",
              ",HAUL",
              ",HULA",
              ",HYMN",
              ",MANY",
              ",MAUL",
              ",HUMAN",
              ",MANLY",
              ",HUMANLY"
            ]
          }
        },
        "m": 30554,
        "o": 16752897,
        "r": 30554,
        "t": 0.8200000000000001,
        "v": 48013,
        "y": 0.8
      }
    }
  }
};