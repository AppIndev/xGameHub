﻿$(window).ready(function () {
    
    //$('head').append('<script src="sweetalert.min.js"></script>');
    
    function daysDiff(date1, date2) {
        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        return diffDays;
    }

    function isAlert() {
        var pastString = localStorage.getItem(document.title + "notifydate");

        if (pastString == null) {
            return true;
        }
        else {
            var past = new Date(pastString);
            var diffDays = daysDiff(new Date(), past);

            if (diffDays > 1)
                return true;
            else
                return false;
        }
    }

    if (isAlert()) {
    //if (true) {
        setTimeout(function (e) {
            
            swal("Congratulations!", "You got 100 dollars daily login coins!!!", "success")

            localStorage.setItem(document.title + 'notifydate', new Date());

            var storedCoin = scoreController.getCoin();

            storedCoin += 100;
            scoreController.setCoin(storedCoin);

            $('#coinsNumberSpan').html(storedCoin);

            soundController.coin();

        }, 500);
    }
});